<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\FullscreenMenu;

final class InlineStylesBuilder
{
    /**
     * @param array<string, array<string, float|int|string>|bool|float|int|string> $settings
     */
    public function build(string $scopeSelector, array $settings): string
    {
        $declarations = [
            '--thecore-fsm-toggle-color' => (string) $settings['toggle_color'],
            '--thecore-fsm-toggle-open-color' => (string) $settings['toggle_open_color'],
            '--thecore-fsm-overlay-color' => (string) $settings['overlay_background_color'],
            '--thecore-fsm-toggle-top' => (string) (int) $settings['toggle_position_top'],
            '--thecore-fsm-toggle-right' => (string) (int) $settings['toggle_position_right'],
            '--thecore-fsm-desktop-link-color' => (string) $settings['desktop_link_color'],
            '--thecore-fsm-desktop-font-family' => (string) $settings['desktop_font_family'],
            '--thecore-fsm-desktop-font-size' => $this->formatSize($settings['desktop_font_size']),
            '--thecore-fsm-desktop-font-weight' => (string) $settings['desktop_font_weight'],
            '--thecore-fsm-desktop-line-height' => $this->formatSize($settings['desktop_line_height']),
            '--thecore-fsm-desktop-letter-spacing' => $this->formatSize($settings['desktop_letter_spacing']),
            '--thecore-fsm-desktop-font-style' => (string) $settings['desktop_font_style'],
            '--thecore-fsm-desktop-text-decoration' => (string) $settings['desktop_text_decoration'],
            '--thecore-fsm-desktop-text-transform' => (string) $settings['desktop_text_transform'],
            '--thecore-fsm-overlay-link-color' => (string) $settings['overlay_link_color'],
            '--thecore-fsm-overlay-font-family' => (string) $settings['overlay_font_family'],
            '--thecore-fsm-overlay-font-size' => $this->formatSize($settings['overlay_font_size']),
            '--thecore-fsm-overlay-font-weight' => (string) $settings['overlay_font_weight'],
            '--thecore-fsm-overlay-line-height' => $this->formatSize($settings['overlay_line_height']),
            '--thecore-fsm-overlay-letter-spacing' => $this->formatSize($settings['overlay_letter_spacing']),
            '--thecore-fsm-overlay-font-style' => (string) $settings['overlay_font_style'],
            '--thecore-fsm-overlay-text-decoration' => (string) $settings['overlay_text_decoration'],
            '--thecore-fsm-overlay-text-transform' => (string) $settings['overlay_text_transform'],
        ];

        $rules = [];

        foreach ($declarations as $property => $value) {
            $rules[] = $property . ':' . $value;
        }

        $css = $scopeSelector . '{' . implode(';', $rules) . ';}';
        $css .= $this->buildLayoutRules($scopeSelector, $settings);

        return $css;
    }

    /**
     * @param array<string, array<string, float|int|string>|bool|float|int|string> $settings
     */
    private function buildLayoutRules(string $scopeSelector, array $settings): string
    {
        $mobileRules = [
            $scopeSelector . ' .thecore-fullscreen-menu__desktop-nav{display:none;}',
            $scopeSelector . ' .thecore-fullscreen-menu__toggle{display:inline-flex;}',
        ];

        if (! empty($settings['overlay_only'])) {
            return implode('', $mobileRules);
        }

        $breakpoint = (int) ($settings['mobile_breakpoint'] ?? DisplaySettings::DEFAULT_MOBILE_BREAKPOINT);
        $breakpoint = max(320, min(1920, $breakpoint));

        return '@media (max-width:' . $breakpoint . 'px){' . implode('', $mobileRules) . '}';
    }

    /**
     * @param mixed $size
     */
    private function formatSize(mixed $size): string
    {
        if (! is_array($size)) {
            return '';
        }

        $value = $size['size'] ?? null;
        $unit = $size['unit'] ?? '';

        if (! is_numeric($value) || ! is_string($unit) || '' === $unit) {
            return '';
        }

        return $this->formatNumber((float) $value) . $unit;
    }

    private function formatNumber(float $value): string
    {
        if ((float) (int) $value === $value) {
            return (string) (int) $value;
        }

        return rtrim(rtrim(sprintf('%.4F', $value), '0'), '.');
    }
}
