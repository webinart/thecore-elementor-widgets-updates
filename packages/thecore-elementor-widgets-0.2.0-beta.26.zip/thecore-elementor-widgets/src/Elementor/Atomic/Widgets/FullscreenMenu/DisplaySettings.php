<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\FullscreenMenu;

final class DisplaySettings
{
    public const DEFAULT_MOBILE_BREAKPOINT = 768;
    public const DEFAULT_OVERLAY_OPACITY = 90;
    public const DEFAULT_TOGGLE_POSITION_TOP = 5;
    public const DEFAULT_TOGGLE_POSITION_RIGHT = 2;
    public const DEFAULT_TOGGLE_COLOR = '#FF5252';
    public const DEFAULT_TOGGLE_OPEN_COLOR = '#FFFFFF';
    public const DEFAULT_OVERLAY_COLOR = 'rgba(119, 119, 119, 0.9)';
    public const DEFAULT_DESKTOP_LINK_COLOR = '#111111';
    public const DEFAULT_OVERLAY_LINK_COLOR = '#FFFFFF';
    public const DEFAULT_FONT_FAMILY = 'inherit';
    public const DEFAULT_FONT_SIZE = [
        'size' => 16.0,
        'unit' => 'px',
    ];
    public const DEFAULT_LINE_HEIGHT = [
        'size' => 1.2,
        'unit' => 'em',
    ];
    public const DEFAULT_LETTER_SPACING = [
        'size' => 0.0,
        'unit' => 'px',
    ];
    private const FONT_WEIGHT_OPTIONS = ['100', '200', '300', '400', '500', '600', '700', '800', '900'];
    private const FONT_STYLE_OPTIONS = ['normal', 'italic', 'oblique'];
    private const TEXT_TRANSFORM_OPTIONS = ['none', 'uppercase', 'lowercase', 'capitalize'];
    private const TEXT_DECORATION_OPTIONS = ['none', 'underline', 'line-through', 'overline'];
    private const FONT_SIZE_UNITS = ['px', 'em', 'rem'];
    private const LINE_HEIGHT_UNITS = ['em', 'px', 'rem'];
    private const LETTER_SPACING_UNITS = ['px', 'em', 'rem'];

    /**
     * @param array<string, mixed> $settings
     *
     * @return array<string, array<string, float|string>|bool|int|string>
     */
    public function normalize(array $settings): array
    {
        $overlayOpacity = $this->clampInt(
            $settings['overlay_opacity'] ?? self::DEFAULT_OVERLAY_OPACITY,
            0,
            100,
            self::DEFAULT_OVERLAY_OPACITY
        );

        return [
            'menu_id' => $this->toPositiveInt($settings['menu_id'] ?? 0),
            'overlay_only' => $this->toBool($settings['overlay_only'] ?? false),
            'mobile_breakpoint' => $this->clampInt(
                $settings['mobile_breakpoint'] ?? self::DEFAULT_MOBILE_BREAKPOINT,
                320,
                1920,
                self::DEFAULT_MOBILE_BREAKPOINT
            ),
            'overlay_opacity' => $overlayOpacity,
            'toggle_color' => $this->sanitizeColor(
                $settings['toggle_color'] ?? self::DEFAULT_TOGGLE_COLOR,
                self::DEFAULT_TOGGLE_COLOR
            ),
            'toggle_open_color' => $this->sanitizeColor(
                $settings['toggle_open_color'] ?? self::DEFAULT_TOGGLE_OPEN_COLOR,
                self::DEFAULT_TOGGLE_OPEN_COLOR
            ),
            'overlay_background_color' => $this->normalizeOverlayBackgroundColor(
                $settings['overlay_background_color'] ?? self::DEFAULT_OVERLAY_COLOR,
                $overlayOpacity
            ),
            'toggle_position_top' => $this->clampInt(
                $settings['toggle_position_top'] ?? self::DEFAULT_TOGGLE_POSITION_TOP,
                0,
                100,
                self::DEFAULT_TOGGLE_POSITION_TOP
            ),
            'toggle_position_right' => $this->clampInt(
                $settings['toggle_position_right'] ?? self::DEFAULT_TOGGLE_POSITION_RIGHT,
                0,
                100,
                self::DEFAULT_TOGGLE_POSITION_RIGHT
            ),
            'desktop_link_color' => $this->sanitizeColor(
                $settings['desktop_link_color'] ?? self::DEFAULT_DESKTOP_LINK_COLOR,
                self::DEFAULT_DESKTOP_LINK_COLOR
            ),
            'desktop_font_family' => $this->sanitizeFontFamily(
                $settings['desktop_font_family'] ?? self::DEFAULT_FONT_FAMILY,
                self::DEFAULT_FONT_FAMILY
            ),
            'desktop_font_size' => $this->sanitizeSize(
                $settings['desktop_font_size'] ?? self::DEFAULT_FONT_SIZE,
                self::DEFAULT_FONT_SIZE,
                self::FONT_SIZE_UNITS,
                0,
                400
            ),
            'desktop_font_weight' => $this->sanitizeEnum(
                $settings['desktop_font_weight'] ?? '400',
                self::FONT_WEIGHT_OPTIONS,
                '400'
            ),
            'desktop_line_height' => $this->sanitizeSize(
                $settings['desktop_line_height'] ?? self::DEFAULT_LINE_HEIGHT,
                self::DEFAULT_LINE_HEIGHT,
                self::LINE_HEIGHT_UNITS,
                0,
                10
            ),
            'desktop_letter_spacing' => $this->sanitizeSize(
                $settings['desktop_letter_spacing'] ?? self::DEFAULT_LETTER_SPACING,
                self::DEFAULT_LETTER_SPACING,
                self::LETTER_SPACING_UNITS,
                -50,
                50
            ),
            'desktop_font_style' => $this->sanitizeEnum(
                $settings['desktop_font_style'] ?? 'normal',
                self::FONT_STYLE_OPTIONS,
                'normal'
            ),
            'desktop_text_decoration' => $this->sanitizeEnum(
                $settings['desktop_text_decoration'] ?? 'none',
                self::TEXT_DECORATION_OPTIONS,
                'none'
            ),
            'desktop_text_transform' => $this->sanitizeEnum(
                $settings['desktop_text_transform'] ?? 'none',
                self::TEXT_TRANSFORM_OPTIONS,
                'none'
            ),
            'overlay_link_color' => $this->sanitizeColor(
                $settings['overlay_link_color'] ?? self::DEFAULT_OVERLAY_LINK_COLOR,
                self::DEFAULT_OVERLAY_LINK_COLOR
            ),
            'overlay_font_family' => $this->sanitizeFontFamily(
                $settings['overlay_font_family'] ?? self::DEFAULT_FONT_FAMILY,
                self::DEFAULT_FONT_FAMILY
            ),
            'overlay_font_size' => $this->sanitizeSize(
                $settings['overlay_font_size'] ?? self::DEFAULT_FONT_SIZE,
                self::DEFAULT_FONT_SIZE,
                self::FONT_SIZE_UNITS,
                0,
                400
            ),
            'overlay_font_weight' => $this->sanitizeEnum(
                $settings['overlay_font_weight'] ?? '400',
                self::FONT_WEIGHT_OPTIONS,
                '400'
            ),
            'overlay_line_height' => $this->sanitizeSize(
                $settings['overlay_line_height'] ?? self::DEFAULT_LINE_HEIGHT,
                self::DEFAULT_LINE_HEIGHT,
                self::LINE_HEIGHT_UNITS,
                0,
                10
            ),
            'overlay_letter_spacing' => $this->sanitizeSize(
                $settings['overlay_letter_spacing'] ?? self::DEFAULT_LETTER_SPACING,
                self::DEFAULT_LETTER_SPACING,
                self::LETTER_SPACING_UNITS,
                -50,
                50
            ),
            'overlay_font_style' => $this->sanitizeEnum(
                $settings['overlay_font_style'] ?? 'normal',
                self::FONT_STYLE_OPTIONS,
                'normal'
            ),
            'overlay_text_decoration' => $this->sanitizeEnum(
                $settings['overlay_text_decoration'] ?? 'none',
                self::TEXT_DECORATION_OPTIONS,
                'none'
            ),
            'overlay_text_transform' => $this->sanitizeEnum(
                $settings['overlay_text_transform'] ?? 'none',
                self::TEXT_TRANSFORM_OPTIONS,
                'none'
            ),
        ];
    }

    private function clampInt(mixed $value, int $min, int $max, int $default): int
    {
        if (! is_numeric($value)) {
            return $default;
        }

        return max($min, min($max, (int) $value));
    }

    private function toPositiveInt(mixed $value): int
    {
        if (! is_numeric($value)) {
            return 0;
        }

        return max(0, (int) $value);
    }

    private function toBool(mixed $value): bool
    {
        if (is_bool($value)) {
            return $value;
        }

        if (is_numeric($value)) {
            return 1 === (int) $value;
        }

        if (! is_string($value)) {
            return false;
        }

        return in_array(
            strtolower(trim($value)),
            ['1', 'true', 'yes', 'on'],
            true
        );
    }

    private function sanitizeColor(mixed $value, string $default): string
    {
        if (! is_string($value)) {
            return $default;
        }

        $normalized = trim($value);

        if ('' === $normalized) {
            return $default;
        }

        if (1 === preg_match('/^#(?:[0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/', $normalized)) {
            return $normalized;
        }

        if (1 === preg_match('/^(?:rgb|rgba|hsl|hsla)\([0-9.,%\s\/-]+\)$/i', $normalized)) {
            return $normalized;
        }

        if (1 === preg_match('/^var\(--[a-zA-Z0-9_-]+\)$/', $normalized)) {
            return $normalized;
        }

        if (in_array(strtolower($normalized), ['transparent', 'currentcolor', 'inherit'], true)) {
            return $normalized;
        }

        return $default;
    }

    private function normalizeOverlayBackgroundColor(mixed $value, int $legacyOpacity): string
    {
        $color = $this->sanitizeColor($value, self::DEFAULT_OVERLAY_COLOR);

        if (100 === $legacyOpacity || $this->colorAlreadyHasAlpha($color)) {
            return $color;
        }

        if (1 === preg_match('/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $color, $matches)) {
            $hex = $matches[1];

            if (3 === strlen($hex)) {
                $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
            }

            $red = hexdec(substr($hex, 0, 2));
            $green = hexdec(substr($hex, 2, 2));
            $blue = hexdec(substr($hex, 4, 2));

            return sprintf('rgba(%d, %d, %d, %s)', $red, $green, $blue, $this->formatAlpha($legacyOpacity));
        }

        return $color;
    }

    private function colorAlreadyHasAlpha(string $color): bool
    {
        if (1 === preg_match('/^#(?:[0-9a-fA-F]{4}|[0-9a-fA-F]{8})$/', $color)) {
            return true;
        }

        if (1 === preg_match('/^(?:rgba|hsla)\(/i', $color)) {
            return true;
        }

        if (1 === preg_match('/^(?:rgb|hsl)\([^)]*\/[^)]*\)$/i', $color)) {
            return true;
        }

        return in_array(strtolower($color), ['transparent', 'currentcolor', 'inherit'], true)
            || 1 === preg_match('/^var\(--[a-zA-Z0-9_-]+\)$/', $color);
    }

    private function formatAlpha(int $opacity): string
    {
        $alpha = $opacity / 100;

        if ((float) (int) $alpha === $alpha) {
            return (string) (int) $alpha;
        }

        return rtrim(rtrim(sprintf('%.4F', $alpha), '0'), '.');
    }

    private function sanitizeFontFamily(mixed $value, string $default): string
    {
        if (! is_string($value)) {
            return $default;
        }

        $normalized = trim(str_replace([';', '{', '}', '<', '>'], '', $value));

        return '' !== $normalized ? $normalized : $default;
    }

    /**
     * @param array<int, string> $allowed
     */
    private function sanitizeEnum(mixed $value, array $allowed, string $default): string
    {
        if (! is_string($value)) {
            return $default;
        }

        $normalized = trim($value);

        return in_array($normalized, $allowed, true) ? $normalized : $default;
    }

    /**
     * @param array{size: float|int, unit: string} $default
     * @param array<int, string>                   $allowedUnits
     *
     * @return array{size: float, unit: string}
     */
    private function sanitizeSize(mixed $value, array $default, array $allowedUnits, float $min, float $max): array
    {
        if (! is_array($value)) {
            return $default;
        }

        $size = $value['size'] ?? null;
        $unit = $value['unit'] ?? null;

        if (! is_numeric($size) || ! is_string($unit) || ! in_array($unit, $allowedUnits, true)) {
            return $default;
        }

        $numericSize = max($min, min($max, (float) $size));

        return [
            'size' => $numericSize,
            'unit' => $unit,
        ];
    }
}
