(function () {
    'use strict';

    if (window.theCoreFormFlowEditor) { return; }

    const TYPE = 'thecore-form-flow-editor';
    const FORM = 'thecore-form';
    const GROUP = 'thecore-form-group';
    const ALL = '__all__';
    const HIDDEN = 'data-thecore-flow-editor-hidden';
    const ACTIVE = 'data-thecore-flow-editor-active';
    const INITIAL = 'data-thecore-flow-initial-hidden';
    // The script only runs in the parent editor and attaches to its canvas document.
    // Atomic client rerenders do not always retain PHP's editor-preview template flag.
    const FORM_SELECTOR = 'form[data-thecore-form="1"]';
    const states = new Map();
    const subscribers = new Set();
    const snapshots = new Map();
    const cleanups = [];
    let previewDocument = null, previewObserver = null, previewStyle = null;
    let scheduled = false, destroyed = false, lastSelection = '', registered = false, version = 0;

    const translate = (text) => window.wp?.i18n?.__(text, 'thecore-elementor-widgets') || text;
    const elementsApi = () => window.elementorV2?.editorElements;
    const unwrap = (value) => {
        let depth = 0;
        while (value && typeof value === 'object' && typeof value.$$type === 'string' && depth++ < 5) { value = value.value; }
        return value;
    };
    const read = (settings, key, fallback = '') => unwrap(settings?.[key]) ?? fallback;
    const getContainer = (id) => elementsApi()?.getContainer?.(id) || window.elementor?.getContainer?.(id);
    const typeOf = (container) => container?.model?.get?.('widgetType') || container?.model?.get?.('elType');
    const getDocumentId = () => String(elementsApi()?.getCurrentDocumentId?.() || 'current');
    const keyFor = (id) => getDocumentId() + ':' + id;

    function collectGroups(data) {
        const groups = [], memberships = new Map(), radioNames = new Map();
        let visited = 0;
        function walk(children, ancestors) {
            for (const node of Array.isArray(children) ? children : []) {
                if (!node || typeof node !== 'object' || ++visited > 500) { continue; }
                // A nested independent form must never share another form's authoring state.
                if ((node.widgetType || node.elType) === FORM) { continue; }
                const nodeType = node.widgetType || node.elType, settings = node.settings || {};
                if (nodeType === 'e-form-radio-button' || nodeType === 'e-form-input' && read(settings, 'type') === 'radio') {
                    const name = read(settings, 'name'), cssId = read(settings, '_cssid');
                    if (name && cssId) { radioNames.set(cssId, 'radio:' + name); }
                }
                let chain = ancestors;
                if ((node.widgetType || node.elType) === GROUP && typeof node.id === 'string') {
                    const group = {
                        id: node.id,
                        label: String(read(settings, 'label') || node.editor_settings?.title || translate('Groupe sans titre')).slice(0, 1000),
                        step: read(settings, 'is-step', false) === true,
                        field: String(read(settings, 'condition-field')),
                        value: String(read(settings, 'condition-value')),
                        ancestors: ancestors.map((group) => group.id),
                    };
                    groups.push(group);
                    chain = [...ancestors, group];
                }
                if (typeof node.id === 'string') { memberships.set(node.id, chain.map((group) => group.id)); }
                walk(node.elements, chain);
            }
        }
        walk(data?.elements, []);
        groups.forEach((group) => { group.conditionKey = radioNames.get(group.field) || group.field; });
        return { groups, memberships };
    }

    function formFor(id) {
        let container = getContainer(id), remaining = 100;
        while (container && remaining-- > 0) {
            if (typeOf(container) === FORM) { return container; }
            container = container.parent;
        }
        return null;
    }

    function findForm(id) {
        if (!previewDocument) { return null; }
        return Array.from(previewDocument.querySelectorAll(FORM_SELECTOR))
            .find((form) => form.getAttribute('data-id') === id) || null;
    }

    function getState(id) {
        const container = getContainer(id);
        if (!container || typeOf(container) !== FORM) { return null; }
        const data = container.model?.toJSON?.();
        const { groups, memberships } = collectGroups(data);
        const key = keyFor(id), steps = groups.filter((group) => group.step);
        let state = states.get(key);
        if (!state) {
            state = { id, key, step: steps[0]?.id || ALL, branch: ALL };
            states.set(key, state);
        }
        state.groups = groups;
        state.steps = steps;
        state.memberships = memberships;
        if (state.step !== ALL && !steps.some((group) => group.id === state.step)) { state.step = steps[0]?.id || ALL; }
        if (state.branch !== ALL && !groups.some((group) => group.id === state.branch && group.field)) { state.branch = ALL; }
        return state;
    }

    function branchesFor(state) {
        return state.groups.filter((group) => group.field && (state.step === ALL || !group.step &&
            !group.ancestors.some((id) => state.steps.some((step) => step.id === id)) ||
            group.id === state.step || group.ancestors.includes(state.step)));
    }

    function notify() {
        version++;
        subscribers.forEach((callback) => callback());
    }

    function remember(element) {
        if (!snapshots.has(element)) {
            snapshots.set(element, { initial: element.getAttribute(INITIAL), hidden: element.getAttribute(HIDDEN), active: element.getAttribute(ACTIVE) });
        }
    }

    function restore(element, attributes) {
        for (const [attribute, value] of [[INITIAL, attributes.initial], [HIDDEN, attributes.hidden], [ACTIVE, attributes.active]]) {
            if (value === null) { element.removeAttribute(attribute); }
            else { element.setAttribute(attribute, value); }
        }
    }

    function applyState(state, form, touched = null) {
        remember(form);
        touched?.add(form);
        form.setAttribute(ACTIVE, '1');
        const selected = state.groups.find((group) => group.id === state.branch);
        const selectedChain = selected ? [...selected.ancestors, selected.id] : [];
        const conditions = new Map(state.groups.filter((group) => selectedChain.includes(group.id) && group.field)
            .map((group) => [group.conditionKey, group.value]));
        const groupsById = new Map(state.groups.map((group) => [group.id, group]));
        for (const element of form.querySelectorAll('[data-thecore-form-group]')) {
            if (element.closest('form') !== form) { continue; }
            const group = groupsById.get(element.getAttribute('data-thecore-form-group'));
            if (!group) { continue; }
            remember(element);
            touched?.add(element);
            // Only the editor DOM is touched. Let the element's native display/grid/flex styles apply.
            element.removeAttribute(INITIAL);
            const chain = [...group.ancestors, group.id].map((id) => groupsById.get(id)).filter(Boolean);
            const wrongStep = state.step !== ALL && chain.some((item) => item.step && item.id !== state.step);
            const wrongBranch = chain.some((item) => item.field && conditions.has(item.conditionKey) && conditions.get(item.conditionKey) !== item.value);
            if (wrongStep || wrongBranch) { element.setAttribute(HIDDEN, '1'); }
            else { element.removeAttribute(HIDDEN); }
        }
    }

    function sync() {
        if (destroyed || !previewDocument) { return; }
        const touched = new Set();
        for (const form of previewDocument.querySelectorAll(FORM_SELECTOR)) {
            const id = form.getAttribute('data-id'), state = id && getState(id);
            if (state && state.groups.length) { applyState(state, form, touched); }
        }
        for (const [element, attributes] of snapshots) {
            if (!touched.has(element)) { restore(element, attributes); snapshots.delete(element); }
        }
        for (const [key] of states) {
            if (!key.startsWith(getDocumentId() + ':')) { states.delete(key); }
        }
        notify();
    }

    function schedule() {
        if (scheduled || destroyed) { return; }
        scheduled = true;
        window.queueMicrotask(() => { scheduled = false; attachPreview(); sync(); });
    }

    function preventSubmit(event) {
        const target = event.target?.closest?.(FORM_SELECTOR);
        if (target && (event.type === 'submit' || event.target.closest('button[type="submit"],input[type="submit"],.thecore-flow-next,.thecore-flow-previous'))) {
            event.preventDefault();
        }
    }

    function detachPreview() {
        previewObserver?.disconnect(); previewObserver = null;
        previewDocument?.removeEventListener('submit', preventSubmit, true);
        previewDocument?.removeEventListener('click', preventSubmit, true);
        snapshots.forEach((attributes, element) => restore(element, attributes)); snapshots.clear();
        previewStyle?.remove(); previewStyle = null; previewDocument = null;
    }

    function attachPreview() {
        let candidate;
        try {
            candidate = window.elementorV2?.editorV1Adapters?.getCanvasIframeDocument?.() ||
                window.elementor?.$preview?.[0]?.contentDocument || window.document.querySelector('#elementor-preview-iframe')?.contentDocument;
        } catch { return; }
        if (!candidate?.body || candidate === previewDocument) { return; }
        detachPreview(); previewDocument = candidate;
        previewStyle = candidate.createElement('style');
        previewStyle.setAttribute('data-thecore-flow-editor-style', '1');
        previewStyle.textContent = 'form[data-thecore-form="1"][data-thecore-flow-editor-active="1"] [data-thecore-flow-editor-hidden="1"]{display:none!important}';
        candidate.head.append(previewStyle);
        candidate.addEventListener('submit', preventSubmit, true);
        candidate.addEventListener('click', preventSubmit, true);
        previewObserver = new window.MutationObserver((records) => {
            const concernsForms = records.some((record) => record.target?.closest?.(FORM_SELECTOR) ||
                [...record.addedNodes, ...record.removedNodes].some((node) => node.matches?.(FORM_SELECTOR) || node.querySelector?.(FORM_SELECTOR)));
            if (concernsForms) { schedule(); }
        });
        // Attribute mutations caused by our own view state must never retrigger this observer.
        previewObserver.observe(candidate.body, { childList: true, subtree: true });
    }

    function selectedElement() {
        return elementsApi()?.getSelectedElements?.()?.[0]?.id || '';
    }

    function revealSelection(id, force = false) {
        const selectionKey = keyFor(id);
        if (!id) { lastSelection = ''; return; }
        if (!force && selectionKey === lastSelection) { return; }
        lastSelection = selectionKey;
        const form = formFor(id), formId = form?.model?.get?.('id') || form?.id;
        if (!formId || formId === id) { return; }
        const state = getState(formId);
        if (!state) { return; }
        const chain = (state.memberships.get(id) || []).map((groupId) => state.groups.find((group) => group.id === groupId)).filter(Boolean);
        const step = chain.find((group) => group.step), branch = chain.filter((group) => group.field).at(-1);
        if (step) { state.step = step.id; }
        else if (chain.some((group) => group.field)) { state.step = ALL; }
        state.branch = branch?.id || ALL;
        const dom = findForm(formId);
        if (dom) { applyState(state, dom); }
        notify();
    }

    function setStep(id, step) {
        const state = getState(id);
        if (!state || step !== ALL && !state.steps.some((group) => group.id === step)) { return; }
        state.step = step; state.branch = ALL;
        const form = findForm(id); if (form) { applyState(state, form); }
        notify();
    }

    function setBranch(id, branch) {
        const state = getState(id);
        if (!state || branch !== ALL && !branchesFor(state).some((group) => group.id === branch)) { return; }
        state.branch = branch;
        const form = findForm(id); if (form) { applyState(state, form); }
        notify();
    }

    function onCommand(event) {
        const command = event.detail?.command || '';
        if (/^editor\/documents\/(?:attach-preview|switch|open)$/.test(command)) { documentLoaded(); }
        if (command === 'document/elements/delete') {
            // Delete only after a confirmed editor command, not during a temporary canvas reload.
            for (const [key, state] of states) { if (!getContainer(state.id)) { states.delete(key); } }
        }
        if (/^document\/elements\/(?:select|deselect|select-all|deselect-all)$/.test(command)) {
            revealSelection(selectedElement());
        }
        if (/^document\/(?:elements\/|history\/|switch|open)/.test(command)) { schedule(); }
    }

    function documentLoaded() {
        schedule();
        // A canvas load may precede its model containers. Native attach-preview is the reliable retry.
        window.queueMicrotask(() => { if (!destroyed) { revealSelection(selectedElement(), true); } });
    }

    function registerControl() {
        const panel = window.elementorV2?.editorEditingPanel, React = window.React;
        if (!panel?.controlsRegistry || !panel.useElement || !React) { return false; }
        if (panel.controlsRegistry.get(TYPE)) { return true; }
        const Control = (props) => {
            const { element } = panel.useElement();
            const [, setVersion] = React.useState(version);
            React.useEffect(() => {
                const update = () => setVersion(version);
                subscribers.add(update);
                return () => subscribers.delete(update);
            }, []);
            const container = formFor(props.context?.elementId || element?.id);
            const id = container?.model?.get?.('id') || container?.id;
            const state = id && getState(id);
            const uid = React.useId();
            if (!state) { return null; }
            const branches = branchesFor(state), index = state.steps.findIndex((step) => step.id === state.step);
            const option = (value, label) => React.createElement('option', { value, key: value }, label);
            return React.createElement('div', { className: 'tc-form-flow-editor' },
                React.createElement('label', { className: 'tc-form-flow-editor__field', htmlFor: uid + '-step' },
                    React.createElement('span', null, translate('Étape affichée')),
                    React.createElement('select', { id: uid + '-step', value: state.step, onChange: (event) => setStep(id, event.target.value) },
                        option(ALL, translate('Tout afficher')),
                        state.steps.map((step, number) => option(step.id, (number + 1) + ' · ' + step.label)))),
                state.steps.length > 1 ? React.createElement('div', { className: 'tc-form-flow-editor__navigation' },
                    React.createElement('button', { type: 'button', disabled: index <= 0, onClick: () => setStep(id, state.steps[index - 1].id) }, translate('Précédent')),
                    React.createElement('button', { type: 'button', disabled: index < 0 || index >= state.steps.length - 1, onClick: () => setStep(id, state.steps[index + 1].id) }, translate('Suivant'))) : null,
                branches.length ? React.createElement('label', { className: 'tc-form-flow-editor__field', htmlFor: uid + '-branch' },
                    React.createElement('span', null, translate('Branche conditionnelle')),
                    React.createElement('select', { id: uid + '-branch', value: state.branch, onChange: (event) => setBranch(id, event.target.value) },
                        option(ALL, translate('Toutes les branches')),
                        branches.map((branch) => option(branch.id, branch.label + ' — ' + branch.field + ' = ' + branch.value)))) : null,
                React.createElement('p', { className: 'tc-form-flow-editor__help' }, translate('Cet affichage facilite l’édition et ne modifie pas le parcours des visiteurs. Sélectionner un champ dans la Structure affiche automatiquement son étape.')));
        };
        panel.controlsRegistry.register(TYPE, Control, 'full');
        return true;
    }

    function boot() {
        if (destroyed) { return; }
        registered = registerControl();
        attachPreview(); sync();
        revealSelection(selectedElement());
    }

    function destroy() {
        if (destroyed) { return; }
        destroyed = true; detachPreview(); cleanups.forEach((cleanup) => cleanup());
        states.clear(); subscribers.clear();
    }

    // Exposed for lifecycle integration and regression tests; no network or persistent state.
    window.theCoreFormFlowEditor = { refresh: schedule, setStep, setBranch, revealSelection, destroy,
        snapshot: (id) => { const state = getState(id); return state ? { step: state.step, branch: state.branch, steps: state.steps.map((step) => step.id) } : null; } };
    const listen = (target, event, callback, capture = false) => { target.addEventListener(event, callback, capture); cleanups.push(() => target.removeEventListener(event, callback, capture)); };
    listen(window, 'elementor/commands/run/after', onCommand);
    listen(window, 'elementor/initialized', boot);
    listen(window, 'elementor/edit-mode/change', schedule);
    listen(window, 'pagehide', destroy);
    listen(window.document, 'load', (event) => { if (event.target?.id === 'elementor-preview-iframe') { schedule(); } }, true);
    if (window.elementor?.on) {
        window.elementor.on('preview:loaded', schedule);
        window.elementor.on('document:loaded', documentLoaded);
        cleanups.push(() => window.elementor?.off?.('preview:loaded', schedule));
        cleanups.push(() => window.elementor?.off?.('document:loaded', documentLoaded));
    }
    if (window.document.readyState === 'loading') { listen(window.document, 'DOMContentLoaded', boot); }
    else { boot(); }
    // Packages may register after the editor script hook; retries stop once mounted, never during idle editing.
    let attempts = 0;
    const timer = window.setInterval(() => {
        if (destroyed || registered || ++attempts > 40) { window.clearInterval(timer); return; }
        boot();
    }, 250);
    cleanups.push(() => window.clearInterval(timer));
})();
