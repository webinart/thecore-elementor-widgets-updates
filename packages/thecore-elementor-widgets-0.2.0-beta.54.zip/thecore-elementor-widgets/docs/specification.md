# Specification

## Goal

Créer un plugin WordPress autonome pour centraliser les widgets Elementor custom de The Core, avec une administration minimale, extensible et versionnée.

## Functional Scope

### Admin

- Une entrée de menu top-level `The Core`
- Une page `Widgets` avec un toggle par widget
- Une page `Features` avec un toggle par fonctionnalité globale

### Widgets

- `Fullscreen Menu` comme premier widget Atomics
- Menu desktop inline sur les items de premier niveau
- Hamburger mobile
- Overlay mobile plein écran
- Animation d’apparition des items
- Paramètres de breakpoint, position du toggle, couleurs et opacité

### Global Features

- `Overlay Scroll Lock` pour verrouiller le scroll du document pendant l’ouverture des overlays compatibles

## Technical Scope

- OOP
- PSR-4
- PSR-12
- PHPDoc quand pertinent
- Tests unitaires sur les composants métier pertinents
- Dépôt git local dédié au plugin
- `Update URI` plugin avec updater GitHub dédié
- Distribution des updates par manifest public `beta` / `prod`

## Deferred Work

- Portage d’autres widgets legacy vers Elementor V4
