# Elementor V4 / Atomic Investigation

## Purpose

Cette note documente ce que fait réellement l'API Atomic/V4 d'Elementor dans l'instance locale, à partir du code source livré, et non à partir de la communication produit.

Objectif:

- comprendre le contrat technique réel des widgets V4
- distinguer `settings controls` et `style controls`
- savoir ce qu'un addon externe peut raisonnablement exploiter aujourd'hui
- capitaliser ce contexte pour `thecore-elementor-widgets`

## Local Snapshot

- Elementor installé: `4.0.0-dev1`
- flag `e_opt_in_v4`: `active`
- flag `e_atomic_elements`: `active`

Sources:

- `wp-content/plugins/elementor/elementor.php`
- `wp-content/plugins/elementor/modules/atomic-widgets/opt-in/opt-in.php`
- `wp-content/plugins/elementor/modules/atomic-widgets/module.php`

## Activation Model

L'Editor V4 et les Atomic Widgets sont deux expérimentations distinctes:

- `e_opt_in_v4`: active l'éditeur V4
- `e_atomic_elements`: active le module Atomic Widgets

Dans le code:

- `e_opt_in_v4` est encore marqué `ALPHA`
- `e_atomic_elements` est marqué `BETA`

Le module Atomic n'est chargé que si `Module::is_active()` retourne `true`, donc si `e_atomic_elements` est actif.

## Core Architecture

### 1. Deux familles d'objets

Elementor distingue:

- `Atomic_Widget_Base`
  - pour les widgets V4 simples
  - catégorie `v4-elements`
  - héritage de `Widget_Base`
- `Atomic_Element_Base`
  - pour les éléments/nested elements V4
  - héritage de `Element_Base`
  - support des enfants, du nesting, des `default_children`

En pratique:

- `Atomic_Button`, `Atomic_Heading`, `Atomic_Image` sont des `Atomic_Widget_Base`
- `Atomic_Tabs`, `Atomic_Form`, `Div_Block`, `Flexbox` sont des `Atomic_Element_Base`

### 2. Contrat minimal d'un widget Atomic

Pour un widget V4 simple, le contrat observable est:

- `static get_element_type(): string`
- `define_props_schema(): array`
- `define_atomic_controls(): array`
- `define_base_styles(): array`
- `get_templates(): array`
- optionnellement `get_script_depends()` / `get_style_depends()`

Traits importants:

- `Has_Atomic_Base`
- `Has_Base_Styles`
- `Has_Template` ou `Has_Element_Template`

## Data Model

### Props schema

Les `settings` du widget ne sont pas des champs libres. Ils sont définis par `define_props_schema()` sous forme de `Prop_Type`.

Exemples vus dans les widgets natifs:

- `String_Prop_Type`
- `Number_Prop_Type`
- `Boolean_Prop_Type`
- `Link_Prop_Type`
- `Html_V3_Prop_Type`
- `Image_Prop_Type`
- `Size_Prop_Type`
- `Dimensions_Prop_Type`
- `Background_Prop_Type`

Le schéma est validé et sanitizé au save via:

- `Props_Parser`
- `Has_Atomic_Base::get_data_for_save()`

Puis résolu au rendu via:

- `Render_Props_Resolver::for_settings()`

### Controls

Les contrôles du panneau "Content/Settings" sont déclarés par `define_atomic_controls()`.

Ils sont sérialisés en objets JSON avec:

- un `bind` vers une prop du schéma
- un `type`
- des `props`
- du `meta`

Important:

- un contrôle Atomic PHP doit binder une prop existante du schéma
- sinon `Has_Atomic_Base` le rejette

## Controls Inventory

Les types de contrôles PHP réellement fournis dans `modules/atomic-widgets/controls/types` sont:

- `chips`
- `date-time`
- `email-form-action`
- `html-tag`
- `image`
- `inline-editing`
- `link`
- `number`
- `query`
- `repeatable`
- `select`
- `size`
- `svg`
- `switch`
- `text`
- `textarea`
- `toggle`
- `video`
- `elements/tabs`

Constat important:

- il n'y a pas de `Color_Control` PHP natif dans ce dossier
- il n'y a pas de `Typography_Control` PHP natif dans ce dossier

Conclusion:

- les vrais color pickers / typography editors du panneau Style V4 ne passent pas par des `Atomic_Control_Base` PHP classiques
- ils semblent être générés côté éditeur à partir du système de styles, pas à partir de `define_atomic_controls()`

## Styles System

### 1. Les styles ne sont pas les controls

Le système V4 sépare clairement:

- les `atomic_controls` pour les réglages de contenu/comportement
- les `base_styles` et les `styles` pour le panneau Style

Autrement dit:

- les `Text_Control`, `Number_Control`, `Select_Control`, etc. ne pilotent pas le panneau Style natif
- le panneau Style s'appuie sur le schéma de styles et sur les cibles de style déclarées par le widget

### 2. Style schema global

`Style_Schema` expose les props de style autorisées, notamment:

- typo: `font-family`, `font-weight`, `font-size`, `color`, `letter-spacing`, `line-height`, `text-align`, `font-style`, `text-decoration`, `text-transform`
- fond: `background`
- bordure: `border-radius`, `border-width`, `border-color`, `border-style`
- layout: `display`, `flex-*`, `gap`, etc.
- effets: ombres, filtres, transitions, transforms

Donc V4 sait bien représenter couleur, typo, fond et spacing.

### 3. Base styles

Chaque widget/élément peut déclarer des `base_styles` via `define_base_styles()`.

`Has_Base_Styles`:

- génère un id CSS stable par cible: `{element_type}-{key}`
- retourne:
  - `get_base_styles()`: les définitions complètes
  - `get_base_styles_dictionary()`: le mapping `key -> css class id`

Exemple:

- widget `e-image`
- clé `base`
- id final `e-image-base`

### 4. Définition d'une cible de style

Une cible de style est un `Style_Definition` contenant une ou plusieurs `Style_Variant`.

Une variante peut contenir:

- des `props`
- un `breakpoint`
- un `state`

Exemple natif simple:

- `Atomic_Button`
  - cible `base`
  - props: `background`, `padding`, `border-radius`, `text-align`

Exemple natif multi-cibles:

- `Atomic_Image`
  - `base`
  - `link-base`
- `Atomic_Heading`
  - `base`
  - `link-base`

### 5. Rendu CSS

Le CSS V4 est généré via:

- `Atomic_Widget_Base_Styles`
  - styles globaux des cibles de base de tous les widgets/éléments atomics
- `Atomic_Widget_Styles`
  - styles locaux sauvegardés par instance dans le document
- `Atomic_Styles_Manager`
  - orchestre rendu, cache et fichiers CSS
- `Styles_Renderer`
  - transforme les props en CSS final

Le sélecteur de base généré par `Styles_Renderer` est de la forme:

- `.elementor .<style-id>`

Exemple:

- `.elementor .thecore-classic-menu-overlay-links`

### 6. Conséquence pratique

Si le template n'applique pas la classe d'une cible de style sur le bon noeud DOM:

- le panneau Style peut exister
- mais les styles ne s'appliqueront à rien

Inversement, si le template applique bien la classe:

- le CSS peut être correct
- mais encore faut-il que l'éditeur décide d'exposer cette cible dans son UI

## Editor Style Tab Internals

### 1. Le panneau Style n'est pas construit depuis `define_atomic_controls()`

Le bundle éditeur `editor-editing-panel.js` contient un `StyleTab` avec des sections codées en dur:

- `Layout`
- `Spacing`
- `Size`
- `Position`
- `Typography`
- `Background`
- `Border`
- `Effects`

Et surtout, chaque section déclare explicitement ses champs.

Exemples observés dans le code compilé:

- `Typography` inclut `font-family`, `font-weight`, `font-size`, `text-align`, `color`, `line-height`, `letter-spacing`, `word-spacing`, `column-count`, `text-decoration`, `text-transform`, `direction`, `font-style`, `stroke`
- `Background` inclut `background`

Conclusion:

- l'absence d'un color picker dans notre widget n'est pas due à l'absence d'un champ `color` dans la liste des champs du Style tab
- l'éditeur sait théoriquement afficher `ColorControl` et `BackgroundControl`

### 2. Les champs Style passent par `StylesField`

Chaque champ du Style tab est branché sur:

- `StylesField`
- `useStylesField()`
- `useStylesFields()`

Le chemin est:

- `StylesField(bind="color")`
- `useStylesField('color')`
- `useStylesFields(['color'])`

`useStylesFields()` lit/écrit les props de style via:

- l'id du style actif
- le provider de styles actif
- les métadonnées `breakpoint/state`

### 3. L'id du style actif ne vient pas des `base_styles`

Le point le plus important est dans `useActiveStyleDefId()`:

- il lit un état local `active-style-id`
- il regarde la valeur du prop `classes`
- il prend soit la classe active, soit la première classe appliquée

Autrement dit:

- le choix du "style actif" dans l'éditeur ne se base pas sur `base_styles`
- il se base sur les classes appliquées à l'élément

Et `base_styles` n'est utilisé que dans la logique d'héritage (`styles-inheritance-context`) pour enrichir la chaîne d'héritage, pas pour sélectionner la cible éditée.

Conséquence directe:

- déclarer `toggle`, `overlay`, `desktop-links`, `overlay-links` dans `define_base_styles()` ne suffit pas à les rendre éditables séparément dans le panneau Style
- l'éditeur V4 ne semble pas offrir, dans cette build, une UI addon documentée pour choisir une cible de style custom parmi les `base_styles`

### 4. Ce que cela explique pour notre widget

Cela explique bien le comportement observé sur `Fullscreen Menu`:

- on voit un bloc de typographie natif dans `Style`
- mais on n'obtient pas 4 groupes distincts `Toggle / Overlay / Desktop Links / Overlay Links`
- et les réglages visibles ne pilotent pas naturellement nos ancres desktop/overlay

Raison probable:

- le panneau édite un style local/générique appliqué au wrapper
- alors que notre rendu réel s'appuie aussi sur des classes de `base_styles` dédiées sur des noeuds internes

Donc:

- la V4 sait afficher des contrôles de style natifs
- mais elle ne nous donne pas encore, côté addon externe, un contrat clair pour exposer proprement plusieurs cibles de style custom dans l'UI

### 5. Contrôle croisé avec les widgets natifs

`Atomic_Button` déclare bien:

- `background` sur sa cible `base`

`Atomic_Heading` déclare bien:

- `base`
- `link-base`

Donc:

- les props `color` et `background` sont bien supportées dans l'absolu
- le problème ne vient pas du type de prop lui-même
- le problème est plutôt l'articulation entre notre widget addon, le style actif de l'éditeur, et l'absence apparente d'un sélecteur de cibles custom exploitable proprement

### 6. Conséquence stratégique

Pour un addon externe, dans cette build Elementor:

- `Content / Settings` est exploitable de manière relativement stable
- le frontend custom est maîtrisable
- le panneau `Style` V4 natif n'est pas encore une base fiable pour exposer plusieurs cibles de style fines sur un widget custom

Ce constat renforce l'approche hybride décidée pour `thecore-elementor-widgets`:

- widget bien V4 côté édition
- rendu frontend indépendant
- réglages critiques de design gérés explicitement par le widget si nécessaire

## Templates And Rendering

Avec `Has_Template`, Elementor:

- enregistre les templates Twig
- injecte dans le contexte:
  - `settings`
  - `base_styles`
  - `interaction_id`
  - `id`
  - `type`

Le template reçoit donc seulement le dictionnaire des classes de style, pas les définitions complètes.

Exemple de pattern natif:

- `base_styles.base` est presque toujours appliqué au noeud principal
- les cibles secondaires comme `link-base` sont appliquées aux noeuds internes

Observation importante:

- les widgets natifs simples utilisent tous une cible `base`
- plusieurs utilisent aussi une cible secondaire dédiée à un sous-noeud

## Frontend Runtime

Par défaut:

- `Atomic_Widget_Base::get_script_depends()` retourne `elementor-v2-widgets-frontend`
- `Atomic_Element_Base` ajoute aussi ce runtime

Ce runtime est enregistré par:

- `elements/loader/frontend-assets-loader.php`

Handles importants:

- `elementor-v2-widgets-frontend`
- `elementor-v2-frontend-handlers`
- `elementor-v2-alpinejs`

Conséquence pour notre plugin:

- un widget Atomic peut fonctionner sans ce runtime si son JS est autonome
- mais Elementor le considère comme dépendance frontend standard
- si le thème `deregister` ces handles, les dépendances Atomics cassent

## Native Widget Patterns

### Atomic Button

Pattern observé:

- peu de controls "content/settings"
- tout le style principal passe par `base_styles`
- un seul target `base`

### Atomic Heading

Pattern observé:

- content/settings minimal
- style principal sur `base`
- style du lien sur `link-base`

### Atomic Image

Pattern observé:

- content/settings minimal
- `base` sur l'image
- `link-base` sur le wrapper lien

### Atomic Tabs / Atomic Form

Pattern observé:

- ce sont des `Atomic_Element_Base`
- ils utilisent du nesting, des `default_children`, des `Element_Control_Base`
- le système V4 gère aussi des structures plus riches que de simples widgets

## What This Means For Addon Development

### Ce qui est clair

- on peut déclarer un vrai widget V4/Atomic externe
- on peut définir un schéma de props propre
- on peut définir des sections de controls pour le contenu/comportement
- on peut définir des cibles de style avec des props de couleur/typo/fond/layout
- on peut rendre en Twig avec classes de style injectées

### Ce qui n'est pas clair

La partie encore floue pour un addon externe n'est pas le runtime PHP, mais l'UI exacte du panneau Style V4.

Constats:

- les widgets natifs s'appuient fortement sur `base`
- le système expose bien `base_styles` dans `get_config()`
- les props de style de type `color`, `background`, `font-size`, etc. existent bien
- pourtant, dans nos essais, l'éditeur ne remonte pas toujours les cibles custom comme on l'attend

Hypothèses plausibles:

1. l'éditeur V4 attend implicitement une cible `base` sur le noeud principal
2. certaines cibles custom ne sont pas affichées si elles ne correspondent pas à un pattern UI interne
3. une partie du panneau Style repose sur du code JS interne non documenté, au-delà de ce qui est visible côté PHP
4. l'API addon externe pour les style targets est encore incomplète ou instable

## Current Working Theory For Our Plugin

Aujourd'hui, la stratégie la plus défendable est:

- utiliser V4 pour l'édition
- garder notre frontend HTML/CSS/JS sous contrôle
- utiliser les `base_styles` là où Elementor les expose correctement
- ne pas présumer que tout le panneau Style V4 addon est stable
- éviter d'inventer des faux contrôles qui imitent le panneau Style si le moteur natif peut encore être débloqué

## Practical Rules For `thecore-elementor-widgets`

1. Toujours prévoir une cible `base` sur le wrapper principal d'un widget V4.
2. Ajouter ensuite des cibles secondaires seulement si elles correspondent à des noeuds DOM stables et utiles.
3. Réserver `define_atomic_controls()` aux réglages de contenu/comportement et aux réglages explicitement non gérés par le panneau Style.
4. Considérer les color pickers et contrôles typo V4 comme relevant d'abord du système de styles, pas des controls PHP.
5. Garder le frontend indépendant d'Elementor autant que possible.
6. Ne pas dépendre du runtime `elementor-v2-widgets-frontend` si le widget n'en a pas besoin.
7. Vérifier le `get_config()` réel du widget quand l'UI de l'éditeur ne correspond pas à ce qu'on attend.

## Known Gaps

Questions encore ouvertes après cette investigation:

- quelles règles exactes l'éditeur V4 utilise pour afficher ou non une cible de style custom
- si une cible custom a besoin d'un marquage supplémentaire côté config JS
- si le panneau Style V4 applique des restrictions selon le type de widget, la présence de `base`, ou certains patterns de template

## Suggested Next Debug Step

Pour nos prochains essais sur `Fullscreen Menu`, l'ordre logique est:

1. garantir une cible `base` minimale sur le wrapper principal
2. garder `toggle`, `overlay`, `desktop-links`, `overlay-links`
3. comparer le `get_config()` de notre widget à celui d'un widget natif multi-cibles
4. si l'UI ne remonte toujours pas les cibles, inspecter le code JS V4 de l'éditeur ciblant les `base_styles`

## Current Local Experiment

Sur `thecore-elementor-widgets`, une première itération a été posée sur `Fullscreen Menu`:

- réintroduction d'une cible `base`
- application de `base_styles.base` sur le wrapper principal en Twig et en rendu PHP
- conservation des cibles `toggle`, `overlay`, `desktop-links`, `overlay-links`

Constat vérifié côté PHP:

- `get_base_styles_dictionary()` expose maintenant:
  - `base`
  - `toggle`
  - `overlay`
  - `desktop-links`
  - `overlay-links`

Point non encore validé dans cette note:

- il faut encore confirmer visuellement dans l'éditeur V4 que cette présence d'un `base` suffit à faire réapparaître les vrais contrôles de style attendus.
