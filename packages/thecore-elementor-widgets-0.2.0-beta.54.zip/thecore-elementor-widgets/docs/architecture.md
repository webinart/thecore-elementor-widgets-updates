# Architecture

## Bootstrap

- `thecore-elementor-widgets.php` initialise les constantes, l’autoload runtime PSR-4 et le singleton du plugin

## Core Services

- `Plugin`: composition root
- `RequirementsChecker`: contrôle Elementor et l’état du mode Atomics
- `OptionsRepository`: persistance des états widgets/features
- `StateSanitizer`: normalisation stricte des flags stockés

## Registries

- `WidgetsRegistry`: inventaire des widgets disponibles
- `FeaturesRegistry`: inventaire des fonctionnalités globales

## Admin

- `AdminMenu`: déclaration des pages, rendu des formulaires et sauvegarde sécurisée
- `AdminAssets`: styles spécifiques aux écrans du plugin

## Frontend

- `FrontendAssets`: enregistrement des assets du `Fullscreen Menu`
- `WidgetsModule`: branchement Elementor et enregistrement conditionnel des widgets
- `PluginUpdater`: détection des updates GitHub, lecture du manifest public et normalisation du package pendant l’upgrade

## Atomic Widget Strategy

- Implémentation directe sur l’API Atomics locale d’Elementor
- Aucun auto-activation de l’expérimentation `e_atomic_elements`
- Si l’expérimentation n’est pas active, le plugin affiche un avertissement admin et n’enregistre pas le widget

## Runtime Packaging

- Le plugin reste exécutable sans `vendor/`
- Composer sert surtout au développement, aux tests et aux outils qualité
