<?php

declare(strict_types=1);

if (! function_exists('sanitize_text_field')) {
    function sanitize_text_field($value): string
    {
        if (! is_scalar($value)) {
            return '';
        }

        $value = strip_tags((string) $value);
        $value = preg_replace('/[\r\n\t ]+/', ' ', $value);

        return trim((string) $value);
    }
}

if (! function_exists('sanitize_textarea_field')) {
    function sanitize_textarea_field($value): string
    {
        if (! is_scalar($value)) {
            return '';
        }

        $value = strip_tags((string) $value);
        $value = preg_replace("/\r\n|\r/", "\n", $value);
        $value = preg_replace("/[ \t]+/", ' ', $value);

        return trim((string) $value);
    }
}

if (! function_exists('sanitize_key')) {
    function sanitize_key($key): string
    {
        $key = strtolower((string) $key);

        return preg_replace('/[^a-z0-9_\-]/', '', $key) ?? '';
    }
}

if (! function_exists('wp_strip_all_tags')) {
    function wp_strip_all_tags($value): string
    {
        return trim(strip_tags((string) $value));
    }
}

if (! function_exists('esc_url_raw')) {
    function esc_url_raw($url): string
    {
        $url = filter_var((string) $url, FILTER_SANITIZE_URL);

        if (! is_string($url) || '' === $url) {
            return '';
        }

        $scheme = parse_url($url, PHP_URL_SCHEME);

        if (is_string($scheme) && '' !== $scheme && ! in_array(strtolower($scheme), ['http', 'https'], true)) {
            return '';
        }

        return $url;
    }
}
