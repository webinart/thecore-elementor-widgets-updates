<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Tests\Unit;

use TheCore\ElementorWidgets\Elementor\Legacy\Widgets\MarqueeBanner\DisplaySettings;

final class LegacyMarqueeBannerDisplaySettingsTest extends TestCase
{
    public function testNormalizeKeepsValidValues(): void
    {
        $settings = (new DisplaySettings())->normalize([
            'images' => [
                [
                    'image' => [
                        'id' => 12,
                        'url' => 'https://example.com/logo.png',
                    ],
                    'alt' => 'Logo',
                    'link' => [
                        'url' => 'https://example.com',
                        'is_external' => '1',
                        'nofollow' => '',
                    ],
                    'item_size' => 1.5,
                    'item_padding_left' => [
                        'size' => 8,
                    ],
                    'item_padding_right' => [
                        'size' => 12,
                    ],
                ],
            ],
        ]);

        self::assertCount(1, $settings['images']);
        self::assertSame(12, $settings['images'][0]['image_id']);
        self::assertSame('https://example.com/logo.png', $settings['images'][0]['image_url']);
        self::assertSame('Logo', $settings['images'][0]['alt']);
        self::assertSame('https://example.com', $settings['images'][0]['link_url']);
        self::assertTrue($settings['images'][0]['link_external']);
        self::assertFalse($settings['images'][0]['link_nofollow']);
        self::assertSame(1.5, $settings['images'][0]['item_scale']);
        self::assertSame(8, $settings['images'][0]['item_padding_left']);
        self::assertSame(12, $settings['images'][0]['item_padding_right']);
    }

    public function testNormalizeDropsInvalidImageAndFallsBack(): void
    {
        $settings = (new DisplaySettings())->normalize([
            'images' => [
                [
                    'image' => [
                        'url' => 'javascript:alert(1)',
                    ],
                    'alt' => '<strong>Logo</strong>',
                    'item_size' => 9,
                    'item_padding_left' => [
                        'size' => 100,
                    ],
                ],
            ],
            'opacity' => 4,
            'background_color' => '</style>',
            'lazy_method' => 'weird',
        ]);

        self::assertSame([], $settings['images']);
        self::assertSame(1.0, $settings['opacity']);
        self::assertSame(DisplaySettings::DEFAULT_BACKGROUND_COLOR, $settings['background_color']);
        self::assertSame(DisplaySettings::DEFAULT_LAZY_METHOD, $settings['lazy_method']);
    }
}
