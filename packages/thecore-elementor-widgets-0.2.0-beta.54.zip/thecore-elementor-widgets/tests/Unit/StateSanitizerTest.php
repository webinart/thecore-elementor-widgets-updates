<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Tests\Unit;

use TheCore\ElementorWidgets\Options\StateSanitizer;

final class StateSanitizerTest extends TestCase
{
    public function testNormalizeKeepsOnlyRegisteredKeysAndCoercesFlags(): void
    {
        $sanitizer = new StateSanitizer();

        $normalized = $sanitizer->normalize(
            [
                'classic-menu' => '1',
                'overlay-scroll-lock' => 'no',
                'unknown-item' => '1',
            ],
            [
                'classic-menu' => 0,
                'overlay-scroll-lock' => 1,
            ]
        );

        self::assertSame(
            [
                'classic-menu' => 1,
                'overlay-scroll-lock' => 0,
            ],
            $normalized
        );
    }

    public function testNormalizeFallsBackToDefaultsForMissingKeys(): void
    {
        $sanitizer = new StateSanitizer();

        $normalized = $sanitizer->normalize(
            [],
            [
                'classic-menu' => 1,
                'overlay-scroll-lock' => 0,
            ]
        );

        self::assertSame(
            [
                'classic-menu' => 1,
                'overlay-scroll-lock' => 0,
            ],
            $normalized
        );
    }
}
