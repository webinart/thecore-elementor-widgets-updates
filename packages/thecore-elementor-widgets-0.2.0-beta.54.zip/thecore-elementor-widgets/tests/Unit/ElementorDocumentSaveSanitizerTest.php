<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Tests\Unit;

use TheCore\ElementorWidgets\Support\ElementorDocumentSaveSanitizer;

final class ElementorDocumentSaveSanitizerTest extends TestCase
{
    public function testNormalizeWidgetSettingsCoercesInvalidLetterSpacingValues(): void
    {
        $sanitizer = new ElementorDocumentSaveSanitizer();

        $settings = $sanitizer->normalizeWidgetSettings([
            'desktop_letter_spacing' => [
                '$$type' => 'size',
                'value' => [
                    'size' => '',
                    'unit' => '',
                ],
            ],
            'overlay_letter_spacing' => [
                '$$type' => 'size',
                'value' => null,
                'disabled' => true,
            ],
        ]);

        self::assertSame(
            [
                '$$type' => 'size',
                'value' => [
                    'size' => 0.0,
                    'unit' => 'px',
                ],
            ],
            $settings['desktop_letter_spacing']
        );

        self::assertSame(
            [
                '$$type' => 'size',
                'value' => [
                    'size' => 0.0,
                    'unit' => 'px',
                ],
                'disabled' => true,
            ],
            $settings['overlay_letter_spacing']
        );
    }

    public function testNormalizeWidgetSettingsKeepsValidSizeValues(): void
    {
        $sanitizer = new ElementorDocumentSaveSanitizer();

        $settings = $sanitizer->normalizeWidgetSettings([
            'desktop_letter_spacing' => [
                '$$type' => 'size',
                'value' => [
                    'size' => '1.5',
                    'unit' => 'em',
                ],
            ],
            'overlay_letter_spacing' => [
                'size' => -2,
                'unit' => 'rem',
            ],
        ]);

        self::assertSame(
            [
                '$$type' => 'size',
                'value' => [
                    'size' => 1.5,
                    'unit' => 'em',
                ],
            ],
            $settings['desktop_letter_spacing']
        );

        self::assertSame(
            [
                '$$type' => 'size',
                'value' => [
                    'size' => -2.0,
                    'unit' => 'rem',
                ],
            ],
            $settings['overlay_letter_spacing']
        );
    }

    public function testNormalizeFullscreenMenuSettingsTouchesOnlyTargetWidget(): void
    {
        $sanitizer = new ElementorDocumentSaveSanitizer();

        $data = $sanitizer->normalizeFullscreenMenuSettings([
            'elements' => [
                [
                    'elType' => 'widget',
                    'widgetType' => 'heading',
                    'settings' => [
                        'desktop_letter_spacing' => 'leave-me-alone',
                    ],
                ],
                [
                    'elType' => 'container',
                    'elements' => [
                        [
                            'elType' => 'widget',
                            'widgetType' => 'thecore-classic-menu',
                            'settings' => [
                                'desktop_letter_spacing' => [
                                    '$$type' => 'size',
                                    'value' => [
                                        'size' => null,
                                        'unit' => '',
                                    ],
                                ],
                                'overlay_letter_spacing' => [
                                    '$$type' => 'size',
                                    'value' => [
                                        'size' => '3',
                                        'unit' => 'PX',
                                    ],
                                ],
                            ],
                        ],
                    ],
                ],
            ],
        ], null);

        self::assertSame('leave-me-alone', $data['elements'][0]['settings']['desktop_letter_spacing']);
        self::assertSame(
            [
                '$$type' => 'size',
                'value' => [
                    'size' => 0.0,
                    'unit' => 'px',
                ],
            ],
            $data['elements'][1]['elements'][0]['settings']['desktop_letter_spacing']
        );
        self::assertSame(
            [
                '$$type' => 'size',
                'value' => [
                    'size' => 3.0,
                    'unit' => 'px',
                ],
            ],
            $data['elements'][1]['elements'][0]['settings']['overlay_letter_spacing']
        );
    }
}
