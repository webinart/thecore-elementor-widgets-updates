<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Tests\Unit;

use TheCore\ElementorWidgets\Elementor\Atomic\Widgets\FullscreenMenu\DisplaySettings;
use TheCore\ElementorWidgets\Elementor\Atomic\Widgets\FullscreenMenu\InlineStylesBuilder;

final class InlineStylesBuilderTest extends TestCase
{
    public function testBuildOutputsScopedVariables(): void
    {
        $settings = (new DisplaySettings())->normalize([
            'toggle_color' => '#123456',
            'toggle_open_color' => '#ffffff',
            'overlay_background_color' => '#010203',
            'overlay_opacity' => 65,
            'desktop_font_family' => 'DM Sans',
            'desktop_font_size' => [
                'size' => 18,
                'unit' => 'px',
            ],
            'overlay_font_size' => [
                'size' => 2,
                'unit' => 'rem',
            ],
        ]);

        $css = (new InlineStylesBuilder())->build('[data-thecore-fullscreen-menu-scope="thecore-fsm-123"]', $settings);

        self::assertStringContainsString('[data-thecore-fullscreen-menu-scope="thecore-fsm-123"]{', $css);
        self::assertStringContainsString('--thecore-fsm-toggle-color:#123456', $css);
        self::assertStringContainsString('--thecore-fsm-overlay-opacity:0.65', $css);
        self::assertStringContainsString('--thecore-fsm-desktop-font-family:DM Sans', $css);
        self::assertStringContainsString('--thecore-fsm-desktop-font-size:18px', $css);
        self::assertStringContainsString('--thecore-fsm-overlay-font-size:2rem', $css);
    }

    public function testBuildOutputsResponsiveLayoutRulesForBreakpointMode(): void
    {
        $settings = (new DisplaySettings())->normalize([
            'overlay_only' => false,
            'mobile_breakpoint' => 980,
        ]);

        $css = (new InlineStylesBuilder())->build('[data-thecore-fullscreen-menu-scope="thecore-fsm-123"]', $settings);

        self::assertStringContainsString('@media (max-width:980px){', $css);
        self::assertStringContainsString(
            '[data-thecore-fullscreen-menu-scope="thecore-fsm-123"] .thecore-fullscreen-menu__desktop-nav{display:none;}',
            $css
        );
        self::assertStringContainsString(
            '[data-thecore-fullscreen-menu-scope="thecore-fsm-123"] .thecore-fullscreen-menu__toggle{display:inline-flex;}',
            $css
        );
    }

    public function testBuildOutputsImmediateLayoutRulesForOverlayOnlyMode(): void
    {
        $settings = (new DisplaySettings())->normalize([
            'overlay_only' => true,
            'mobile_breakpoint' => 980,
        ]);

        $css = (new InlineStylesBuilder())->build('[data-thecore-fullscreen-menu-scope="thecore-fsm-123"]', $settings);

        self::assertStringNotContainsString('@media (max-width:980px){', $css);
        self::assertStringContainsString(
            '[data-thecore-fullscreen-menu-scope="thecore-fsm-123"] .thecore-fullscreen-menu__desktop-nav{display:none;}',
            $css
        );
        self::assertStringContainsString(
            '[data-thecore-fullscreen-menu-scope="thecore-fsm-123"] .thecore-fullscreen-menu__toggle{display:inline-flex;}',
            $css
        );
    }
}
