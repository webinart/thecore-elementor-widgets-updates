<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Tests\Unit;

use Brain\Monkey\Functions;
use TheCore\ElementorWidgets\Options\OptionsRepository;
use TheCore\ElementorWidgets\Options\StateSanitizer;

final class OptionsRepositoryTest extends TestCase
{
    public function testGetWidgetsStateReturnsNormalizedStoredState(): void
    {
        Functions\expect('get_option')
            ->once()
            ->with(OptionsRepository::WIDGETS_OPTION, [])
            ->andReturn([
                'classic-menu' => '1',
                'unexpected-widget' => '1',
            ]);

        $repository = new OptionsRepository(new StateSanitizer());

        $state = $repository->getWidgetsState([
            'classic-menu' => 0,
        ]);

        self::assertSame(['classic-menu' => 1], $state);
    }

    public function testSaveFeaturesStatePersistsNormalizedFlags(): void
    {
        Functions\expect('update_option')
            ->once()
            ->with(
                OptionsRepository::FEATURES_OPTION,
                [
                    'overlay-scroll-lock' => 0,
                ]
            )
            ->andReturn(true);

        $repository = new OptionsRepository(new StateSanitizer());

        $repository->saveFeaturesState(
            [
                'overlay-scroll-lock' => '0',
                'unknown-feature' => '1',
            ],
            [
                'overlay-scroll-lock' => 1,
            ]
        );

        self::assertTrue(true);
    }
}
