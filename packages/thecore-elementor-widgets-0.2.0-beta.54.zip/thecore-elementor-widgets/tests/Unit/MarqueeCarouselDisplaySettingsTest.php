<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Tests\Unit;

use TheCore\ElementorWidgets\Elementor\Atomic\Widgets\MarqueeCarousel\DisplaySettings;

final class MarqueeCarouselDisplaySettingsTest extends TestCase
{
    public function testNormalizeKeepsValidValues(): void
    {
        $settings = (new DisplaySettings())->normalize([
            'items' => [
                [
                    'image_id' => 42,
                    'image_url' => 'https://example.com/logo-1.png',
                    'alt' => 'Logo 1',
                    'link_url' => 'https://example.com',
                    'link_external' => true,
                    'link_nofollow' => false,
                    'item_scale' => 1.4,
                    'item_padding_left' => 8,
                    'item_padding_right' => 12,
                ],
            ],
            'marquee_speed' => 24,
            'image_height' => 96,
            'image_opacity' => 72,
            'image_gap' => 18,
            'background_color' => '#111111',
            'lazy_load' => '1',
            'lazy_method' => 'delay',
            'lazy_delay' => 1400,
        ]);

        self::assertCount(1, $settings['items']);
        self::assertSame(42, $settings['items'][0]['image_id']);
        self::assertSame('https://example.com/logo-1.png', $settings['items'][0]['image_url']);
        self::assertSame('Logo 1', $settings['items'][0]['alt']);
        self::assertSame('https://example.com', $settings['items'][0]['link_url']);
        self::assertTrue($settings['items'][0]['link_external']);
        self::assertFalse($settings['items'][0]['link_nofollow']);
        self::assertSame(1.4, $settings['items'][0]['item_scale']);
        self::assertSame(8, $settings['items'][0]['item_padding_left']);
        self::assertSame(12, $settings['items'][0]['item_padding_right']);
        self::assertSame(24, $settings['marquee_speed']);
        self::assertSame(96, $settings['image_height']);
        self::assertSame(72, $settings['image_opacity']);
        self::assertSame(18, $settings['image_gap']);
        self::assertSame('#111111', $settings['background_color']);
        self::assertTrue($settings['lazy_load']);
        self::assertSame('delay', $settings['lazy_method']);
        self::assertSame(1400, $settings['lazy_delay']);
    }

    public function testNormalizeFallsBackForInvalidValues(): void
    {
        $settings = (new DisplaySettings())->normalize([
            'items' => [
                [
                    'image_id' => 'bad',
                    'image_url' => 'javascript:alert(1)',
                    'alt' => '<strong>Logo</strong>',
                    'item_scale' => 12,
                    'item_padding_left' => 90,
                    'item_padding_right' => -10,
                ],
            ],
            'marquee_speed' => 100,
            'image_height' => 2,
            'image_opacity' => 140,
            'image_gap' => -1,
            'background_color' => '</style>',
            'lazy_load' => 'nope',
            'lazy_method' => 'weird',
            'lazy_delay' => 50,
        ]);

        self::assertSame([], $settings['items']);
        self::assertSame(60, $settings['marquee_speed']);
        self::assertSame(24, $settings['image_height']);
        self::assertSame(100, $settings['image_opacity']);
        self::assertSame(0, $settings['image_gap']);
        self::assertSame(DisplaySettings::DEFAULT_BACKGROUND_COLOR, $settings['background_color']);
        self::assertFalse($settings['lazy_load']);
        self::assertSame(DisplaySettings::DEFAULT_LAZY_METHOD, $settings['lazy_method']);
        self::assertSame(DisplaySettings::DEFAULT_LAZY_DELAY, $settings['lazy_delay']);
    }
}
