<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Tests\Unit;

use TheCore\ElementorWidgets\Elementor\Atomic\Widgets\FullscreenMenu\DisplaySettings;

final class DisplaySettingsTest extends TestCase
{
    public function testNormalizeKeepsValidValuesWithinBounds(): void
    {
        $settings = (new DisplaySettings())->normalize([
            'menu_id' => '12',
            'overlay_only' => '1',
            'mobile_breakpoint' => 980,
            'toggle_color' => '#abc123',
            'toggle_open_color' => 'rgb(255, 255, 255)',
            'overlay_background_color' => '#123456',
            'overlay_opacity' => 65,
            'toggle_position_top' => 12,
            'toggle_position_right' => 7,
            'desktop_link_color' => '#654321',
            'desktop_font_family' => 'DM Sans',
            'desktop_font_size' => [
                'size' => 18,
                'unit' => 'px',
            ],
            'desktop_font_weight' => '700',
            'desktop_line_height' => [
                'size' => 1.6,
                'unit' => 'em',
            ],
            'desktop_letter_spacing' => [
                'size' => 2,
                'unit' => 'px',
            ],
            'desktop_font_style' => 'italic',
            'desktop_text_decoration' => 'underline',
            'desktop_text_transform' => 'uppercase',
            'overlay_link_color' => '#ffffff',
            'overlay_font_family' => 'var(--e-global-typography-primary-font-family)',
            'overlay_font_size' => [
                'size' => 2,
                'unit' => 'rem',
            ],
            'overlay_font_weight' => '500',
            'overlay_line_height' => [
                'size' => 1.4,
                'unit' => 'em',
            ],
            'overlay_letter_spacing' => [
                'size' => 0.2,
                'unit' => 'em',
            ],
            'overlay_font_style' => 'oblique',
            'overlay_text_decoration' => 'line-through',
            'overlay_text_transform' => 'capitalize',
        ]);

        self::assertSame(12, $settings['menu_id']);
        self::assertTrue($settings['overlay_only']);
        self::assertSame(980, $settings['mobile_breakpoint']);
        self::assertSame('#abc123', $settings['toggle_color']);
        self::assertSame('rgb(255, 255, 255)', $settings['toggle_open_color']);
        self::assertSame('#123456', $settings['overlay_background_color']);
        self::assertSame(65, $settings['overlay_opacity']);
        self::assertSame(12, $settings['toggle_position_top']);
        self::assertSame(7, $settings['toggle_position_right']);
        self::assertSame('#654321', $settings['desktop_link_color']);
        self::assertSame('DM Sans', $settings['desktop_font_family']);
        self::assertSame(['size' => 18.0, 'unit' => 'px'], $settings['desktop_font_size']);
        self::assertSame('700', $settings['desktop_font_weight']);
        self::assertSame(['size' => 1.6, 'unit' => 'em'], $settings['desktop_line_height']);
        self::assertSame(['size' => 2.0, 'unit' => 'px'], $settings['desktop_letter_spacing']);
        self::assertSame('italic', $settings['desktop_font_style']);
        self::assertSame('underline', $settings['desktop_text_decoration']);
        self::assertSame('uppercase', $settings['desktop_text_transform']);
        self::assertSame('#ffffff', $settings['overlay_link_color']);
        self::assertSame(
            'var(--e-global-typography-primary-font-family)',
            $settings['overlay_font_family']
        );
        self::assertSame(['size' => 2.0, 'unit' => 'rem'], $settings['overlay_font_size']);
        self::assertSame('500', $settings['overlay_font_weight']);
        self::assertSame(['size' => 1.4, 'unit' => 'em'], $settings['overlay_line_height']);
        self::assertSame(['size' => 0.2, 'unit' => 'em'], $settings['overlay_letter_spacing']);
        self::assertSame('oblique', $settings['overlay_font_style']);
        self::assertSame('line-through', $settings['overlay_text_decoration']);
        self::assertSame('capitalize', $settings['overlay_text_transform']);
    }

    public function testNormalizeFallsBackForInvalidValues(): void
    {
        $settings = (new DisplaySettings())->normalize([
            'menu_id' => 'foo',
            'overlay_only' => 'nope',
            'mobile_breakpoint' => 200,
            'toggle_color' => '</style>',
            'toggle_open_color' => '#12',
            'overlay_background_color' => '',
            'overlay_opacity' => 120,
            'toggle_position_top' => -4,
            'toggle_position_right' => 140,
            'desktop_link_color' => 'bad-color',
            'desktop_font_family' => '";}</style>',
            'desktop_font_size' => [
                'size' => 999,
                'unit' => 'foo',
            ],
            'desktop_font_weight' => '950',
            'desktop_line_height' => [
                'size' => -1,
                'unit' => 'px',
            ],
            'desktop_letter_spacing' => [
                'size' => -100,
                'unit' => 'rem',
            ],
            'desktop_font_style' => 'weird',
            'desktop_text_decoration' => 'blink',
            'desktop_text_transform' => 'random',
        ]);

        self::assertSame(0, $settings['menu_id']);
        self::assertFalse($settings['overlay_only']);
        self::assertSame(320, $settings['mobile_breakpoint']);
        self::assertSame(DisplaySettings::DEFAULT_TOGGLE_COLOR, $settings['toggle_color']);
        self::assertSame(DisplaySettings::DEFAULT_TOGGLE_OPEN_COLOR, $settings['toggle_open_color']);
        self::assertSame(DisplaySettings::DEFAULT_OVERLAY_COLOR, $settings['overlay_background_color']);
        self::assertSame(100, $settings['overlay_opacity']);
        self::assertSame(0, $settings['toggle_position_top']);
        self::assertSame(100, $settings['toggle_position_right']);
        self::assertSame(DisplaySettings::DEFAULT_DESKTOP_LINK_COLOR, $settings['desktop_link_color']);
        self::assertSame('"/style', $settings['desktop_font_family']);
        self::assertSame(DisplaySettings::DEFAULT_FONT_SIZE, $settings['desktop_font_size']);
        self::assertSame('400', $settings['desktop_font_weight']);
        self::assertSame(['size' => 0.0, 'unit' => 'px'], $settings['desktop_line_height']);
        self::assertSame(['size' => -50.0, 'unit' => 'rem'], $settings['desktop_letter_spacing']);
        self::assertSame('normal', $settings['desktop_font_style']);
        self::assertSame('none', $settings['desktop_text_decoration']);
        self::assertSame('none', $settings['desktop_text_transform']);
    }
}
