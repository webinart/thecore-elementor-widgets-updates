<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Tests\Unit;

use Brain\Monkey\Functions;
use TheCore\ElementorWidgets\Elementor\Legacy\Widgets\AccessibilityModule\DisplaySettings;

final class AccessibilityModuleDisplaySettingsTest extends TestCase
{
    public function testNormalizeKeepsValidValues(): void
    {
        Functions\when('home_url')->justReturn('https://example.com/wp-sitemap.xml');

        $settings = (new DisplaySettings())->normalize([
            'header_eyebrow_text' => 'Access',
            'header_title_text' => 'Tools',
            'header_subtitle_text' => 'Adjust things.',
            'module_vertical_position' => 'top',
            'module_horizontal_position' => 'left',
            'close_button_label' => 'Close panel',
            'reset_label' => 'Reset everything',
            'section_content_adjustments_title' => 'Content Tools',
            'section_orientation_adjustments_title' => 'Orientation Tools',
            'section_color_adjustments_title' => 'Color Tools',
            'feature_bigger_text' => 'yes',
            'feature_bigger_text_label' => 'Large text',
            'feature_reading_mask_label' => 'Reading guide',
            'help_label' => 'Need help?',
            'help_url' => [
                'url' => 'https://example.com/help',
            ],
            'feedback_label' => 'Send feedback',
            'feedback_url' => [
                'url' => 'https://example.com/feedback',
            ],
            'skip_link_enabled' => 'yes',
            'skip_link_label' => 'Skip',
            'skip_link_hidden' => 'yes',
            'skip_link_target_selector' => '#content, main',
            'skip_link_mount_selector' => 'header.site-header',
        ]);

        self::assertSame('Access', $settings['header_eyebrow_text']);
        self::assertSame('Tools', $settings['header_title_text']);
        self::assertSame('Adjust things.', $settings['header_subtitle_text']);
        self::assertSame('top', $settings['module_vertical_position']);
        self::assertSame('left', $settings['module_horizontal_position']);
        self::assertSame('Close panel', $settings['close_button_label']);
        self::assertSame('Reset everything', $settings['reset_label']);
        self::assertSame('Content Tools', $settings['section_content_adjustments_title']);
        self::assertSame('Orientation Tools', $settings['section_orientation_adjustments_title']);
        self::assertSame('Color Tools', $settings['section_color_adjustments_title']);
        self::assertTrue($settings['feature_bigger_text']);
        self::assertSame('Large text', $settings['feature_bigger_text_label']);
        self::assertSame('Reading guide', $settings['feature_reading_mask_label']);
        self::assertSame('Need help?', $settings['help_label']);
        self::assertSame('https://example.com/help', $settings['help_url']);
        self::assertSame('Send feedback', $settings['feedback_label']);
        self::assertSame('https://example.com/feedback', $settings['feedback_url']);
        self::assertTrue($settings['skip_link_enabled']);
        self::assertSame('Skip', $settings['skip_link_label']);
        self::assertTrue($settings['skip_link_hidden']);
        self::assertSame('#content, main', $settings['skip_link_target_selector']);
        self::assertSame('header.site-header', $settings['skip_link_mount_selector']);
    }

    public function testNormalizeFallsBackForInvalidValues(): void
    {
        Functions\when('home_url')->justReturn('https://example.com/wp-sitemap.xml');

        $settings = (new DisplaySettings())->normalize([
            'header_eyebrow_text' => '',
            'header_title_text' => [],
            'header_subtitle_text' => '',
            'module_vertical_position' => 'side',
            'module_horizontal_position' => 'center',
            'close_button_label' => '',
            'reset_label' => [],
            'section_content_adjustments_title' => '',
            'section_orientation_adjustments_title' => [],
            'section_color_adjustments_title' => '',
            'feature_bigger_text' => false,
            'feature_bigger_text_label' => '',
            'feature_reading_mask_label' => [],
            'help_label' => '',
            'help_url' => 'javascript:alert(1)',
            'feedback_label' => '',
            'feedback_url' => 'javascript:alert(1)',
            'skip_link_enabled' => false,
            'skip_link_label' => '',
            'skip_link_hidden' => false,
            'skip_link_target_selector' => '',
            'skip_link_mount_selector' => '',
        ]);

        self::assertSame(DisplaySettings::DEFAULT_HEADER_EYEBROW, $settings['header_eyebrow_text']);
        self::assertSame(DisplaySettings::DEFAULT_HEADER_TITLE, $settings['header_title_text']);
        self::assertSame(DisplaySettings::DEFAULT_HEADER_SUBTITLE, $settings['header_subtitle_text']);
        self::assertSame(DisplaySettings::DEFAULT_MODULE_VERTICAL_POSITION, $settings['module_vertical_position']);
        self::assertSame(DisplaySettings::DEFAULT_MODULE_HORIZONTAL_POSITION, $settings['module_horizontal_position']);
        self::assertSame(DisplaySettings::DEFAULT_CLOSE_BUTTON_LABEL, $settings['close_button_label']);
        self::assertSame(DisplaySettings::DEFAULT_RESET_LABEL, $settings['reset_label']);
        self::assertSame(
            DisplaySettings::DEFAULT_SECTION_TITLES['section_content_adjustments_title'],
            $settings['section_content_adjustments_title']
        );
        self::assertSame(
            DisplaySettings::DEFAULT_SECTION_TITLES['section_orientation_adjustments_title'],
            $settings['section_orientation_adjustments_title']
        );
        self::assertSame(
            DisplaySettings::DEFAULT_SECTION_TITLES['section_color_adjustments_title'],
            $settings['section_color_adjustments_title']
        );
        self::assertFalse($settings['feature_bigger_text']);
        self::assertSame(DisplaySettings::DEFAULT_FEATURE_LABELS['feature_bigger_text_label'], $settings['feature_bigger_text_label']);
        self::assertSame(DisplaySettings::DEFAULT_FEATURE_LABELS['feature_reading_mask_label'], $settings['feature_reading_mask_label']);
        self::assertSame(DisplaySettings::DEFAULT_HELP_LABEL, $settings['help_label']);
        self::assertSame('', $settings['help_url']);
        self::assertSame(DisplaySettings::DEFAULT_FEEDBACK_LABEL, $settings['feedback_label']);
        self::assertSame('', $settings['feedback_url']);
        self::assertFalse($settings['skip_link_enabled']);
        self::assertSame(DisplaySettings::DEFAULT_SKIP_LINK_LABEL, $settings['skip_link_label']);
        self::assertFalse($settings['skip_link_hidden']);
        self::assertSame(DisplaySettings::DEFAULT_SKIP_LINK_TARGET_SELECTOR, $settings['skip_link_target_selector']);
        self::assertSame(DisplaySettings::DEFAULT_SKIP_LINK_MOUNT_SELECTOR, $settings['skip_link_mount_selector']);
    }
}
