<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Tests\Unit;

use TheCore\ElementorWidgets\Registry\FeaturesRegistry;
use TheCore\ElementorWidgets\Registry\WidgetsRegistry;

final class RegistryDefaultsTest extends TestCase
{
    public function testWidgetDefaultsCanBeReadWithoutTranslations(): void
    {
        self::assertSame(
            [
                'classic-menu' => 1,
                'marquee-carousel' => 1,
                'marquee-banner-legacy' => 1,
                'header-menu-legacy' => 1,
                'search-modal-legacy' => 1,
                'accessibility-module-legacy' => 1,
                'accessibility-trigger-legacy' => 1,
                'cookie-consent' => 1,
                'tchat' => 1,
                'tchat-trigger' => 1,
            ],
            (new WidgetsRegistry())->defaults()
        );
    }

    public function testFeatureDefaultsCanBeReadWithoutTranslations(): void
    {
        self::assertSame(
            [
                'overlay-scroll-lock' => 1,
            ],
            (new FeaturesRegistry())->defaults()
        );
    }
}
