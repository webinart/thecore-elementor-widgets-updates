<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Tests\Unit;

use TheCore\ElementorWidgets\Update\PluginUpdater;

final class PluginUpdaterTest extends TestCase
{
    public function testParseRepositoryFromUpdateUriReturnsGithubRepository(): void
    {
        self::assertSame(
            'webinart/thecore-elementor-widgets',
            PluginUpdater::parseRepositoryFromUpdateUri('https://github.com/webinart/thecore-elementor-widgets')
        );
    }

    public function testNormalizeBranchStripsGitPrefix(): void
    {
        self::assertSame('beta', PluginUpdater::normalizeBranch('refs/heads/beta'));
    }

    public function testDefaultChannelForVersionUsesBetaSuffix(): void
    {
        self::assertSame('beta', PluginUpdater::defaultChannelForVersion('0.2.0-beta.1'));
        self::assertSame('prod', PluginUpdater::defaultChannelForVersion('0.2.0'));
    }

    public function testBuildManifestUrlUsesRawGithubFormat(): void
    {
        self::assertSame(
            'https://raw.githubusercontent.com/webinart/thecore-elementor-widgets-updates/plugin-updates/beta.json',
            PluginUpdater::buildManifestUrl(
                'webinart/thecore-elementor-widgets-updates',
                'plugin-updates',
                'beta'
            )
        );
    }

    public function testParsePluginHeadersReadsExpectedHeaders(): void
    {
        $headers = PluginUpdater::parsePluginHeaders(
            <<<'PHP'
<?php
/**
 * Plugin Name: The Core - Elementor Widgets
 * Version: 0.2.0-beta.1
 * Requires at least: 6.6
 * Requires PHP: 8.1
 */
PHP
        );

        self::assertSame(
            [
                'Version' => '0.2.0-beta.1',
                'RequiresPHP' => '8.1',
                'RequiresWP' => '6.6',
            ],
            $headers
        );
    }
}
