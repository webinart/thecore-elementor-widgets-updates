<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Tests\Unit;

use Brain\Monkey\Functions;
use TheCore\ElementorWidgets\Elementor\Legacy\Widgets\SearchModal\DisplaySettings;

final class SearchModalDisplaySettingsTest extends TestCase
{
    public function testNormalizeKeepsValidValues(): void
    {
        Functions\when('get_post_types')->justReturn(['post', 'page', 'event']);

        $settings = (new DisplaySettings())->normalize([
            'trigger_label' => 'Search',
            'placeholder' => 'Search the site',
            'dialog_title' => 'Search dialog',
            'results_limit' => 10,
            'search_post_types' => ['event', 'page'],
            'popular_searches' => [
                ['term' => 'Transport'],
                ['term' => 'Agenda'],
                ['term' => 'Transport'],
            ],
            'quick_links' => [
                [
                    'title' => 'Town hall',
                    'url' => [
                        'url' => 'https://example.com/town-hall',
                        'is_external' => '1',
                    ],
                ],
            ],
            'enable_shortcut' => 'yes',
            'show_shortcut_hint' => 'yes',
        ]);

        self::assertSame('Search', $settings['trigger_label']);
        self::assertSame('Search the site', $settings['placeholder']);
        self::assertSame('Search dialog', $settings['dialog_title']);
        self::assertSame(10, $settings['results_limit']);
        self::assertSame(['event', 'page'], $settings['search_post_types']);
        self::assertSame(['Transport', 'Agenda'], $settings['popular_searches']);
        self::assertSame(
            [
                [
                    'title' => 'Town hall',
                    'url' => 'https://example.com/town-hall',
                    'target' => true,
                ],
            ],
            $settings['quick_links']
        );
        self::assertTrue($settings['enable_shortcut']);
        self::assertTrue($settings['show_shortcut_hint']);
    }

    public function testNormalizeFallsBackForInvalidValues(): void
    {
        Functions\when('get_post_types')->justReturn(['post', 'page']);

        $settings = (new DisplaySettings())->normalize([
            'trigger_label' => '',
            'placeholder' => [],
            'dialog_title' => '',
            'results_limit' => 99,
            'search_post_types' => ['event'],
            'popular_searches' => [
                ['term' => ''],
                'bad',
            ],
            'quick_links' => [
                [
                    'title' => 'Broken',
                    'url' => [
                        'url' => 'javascript:alert(1)',
                    ],
                ],
            ],
            'enable_shortcut' => false,
            'show_shortcut_hint' => true,
        ]);

        self::assertSame(DisplaySettings::DEFAULT_TRIGGER_LABEL, $settings['trigger_label']);
        self::assertSame(DisplaySettings::DEFAULT_PLACEHOLDER, $settings['placeholder']);
        self::assertSame(DisplaySettings::DEFAULT_DIALOG_TITLE, $settings['dialog_title']);
        self::assertSame(12, $settings['results_limit']);
        self::assertSame(['post', 'page'], $settings['search_post_types']);
        self::assertSame([], $settings['popular_searches']);
        self::assertSame([], $settings['quick_links']);
        self::assertFalse($settings['enable_shortcut']);
        self::assertFalse($settings['show_shortcut_hint']);
    }
}
