<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Tests\Unit;

use TheCore\ElementorWidgets\Elementor\Legacy\Widgets\HeaderMenu\DisplaySettings;

final class HeaderMenuDisplaySettingsTest extends TestCase
{
    public function testNormalizeKeepsValidValues(): void
    {
        $settings = (new DisplaySettings())->normalize([
            'menu_id' => '42',
            'menu_model' => 'minimal-light',
            'mobile_breakpoint' => '768',
        ]);

        self::assertSame(42, $settings['menu_id']);
        self::assertSame('minimal-light', $settings['menu_model']);
        self::assertSame('768', $settings['mobile_breakpoint']);
    }

    public function testNormalizeFallsBackForInvalidValues(): void
    {
        $settings = (new DisplaySettings())->normalize([
            'menu_id' => 'bad',
            'menu_model' => 'unknown',
            'mobile_breakpoint' => '999',
        ]);

        self::assertSame(0, $settings['menu_id']);
        self::assertSame(DisplaySettings::DEFAULT_MODEL, $settings['menu_model']);
        self::assertSame(DisplaySettings::DEFAULT_BREAKPOINT, $settings['mobile_breakpoint']);
    }
}
