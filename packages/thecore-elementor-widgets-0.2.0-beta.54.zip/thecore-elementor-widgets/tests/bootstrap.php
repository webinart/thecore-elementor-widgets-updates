<?php

declare(strict_types=1);

$autoload = dirname(__DIR__) . '/vendor/autoload.php';

if (! file_exists($autoload)) {
    fwrite(STDERR, "Composer dependencies are missing. Run `composer install` in the plugin directory.\n");
    exit(1);
}

require_once $autoload;
require_once __DIR__ . '/wp-function-shims.php';
