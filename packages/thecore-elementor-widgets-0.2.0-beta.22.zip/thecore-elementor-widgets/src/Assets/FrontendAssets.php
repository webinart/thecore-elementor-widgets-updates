<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Assets;

use TheCore\ElementorWidgets\Contracts\Bootable;
use TheCore\ElementorWidgets\Options\OptionsRepository;
use TheCore\ElementorWidgets\Registry\FeaturesRegistry;

final class FrontendAssets implements Bootable
{
    public const FULLSCREEN_MENU_SCRIPT = 'thecore-fullscreen-menu';
    public const FULLSCREEN_MENU_STYLE = 'thecore-fullscreen-menu';
    public const MARQUEE_CAROUSEL_SCRIPT = 'thecore-marquee-carousel';
    public const MARQUEE_CAROUSEL_STYLE = 'thecore-marquee-carousel';
    public const MARQUEE_BANNER_LEGACY_SCRIPT = 'thecore-marquee-banner-legacy';
    public const MARQUEE_BANNER_LEGACY_STYLE = 'thecore-marquee-banner-legacy';

    private bool $stylesRegistered = false;
    private bool $scriptsRegistered = false;

    public function __construct(
        private readonly OptionsRepository $optionsRepository,
        private readonly FeaturesRegistry $featuresRegistry
    ) {
    }

    public function register(): void
    {
        add_action('wp_enqueue_scripts', [$this, 'registerStyles']);
        add_action('wp_enqueue_scripts', [$this, 'registerScripts']);
        add_action('elementor/editor/before_enqueue_styles', [$this, 'registerStyles']);
        add_action('elementor/editor/before_enqueue_scripts', [$this, 'registerScripts']);
        add_action('elementor/atomic-widgets/frontend/loader/scripts/register', [$this, 'registerScripts']);
    }

    public function registerStyles(): void
    {
        if ($this->stylesRegistered) {
            return;
        }

        wp_register_style(
            self::FULLSCREEN_MENU_STYLE,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/fullscreen-menu.css',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION
        );

        wp_register_style(
            self::MARQUEE_CAROUSEL_STYLE,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/marquee-carousel.css',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION
        );

        wp_register_style(
            self::MARQUEE_BANNER_LEGACY_STYLE,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/marquee-banner-legacy.css',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION
        );

        $this->stylesRegistered = true;
    }

    public function registerScripts(mixed $loader = null): void
    {
        if ($this->scriptsRegistered) {
            return;
        }

        wp_register_script(
            self::FULLSCREEN_MENU_SCRIPT,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/fullscreen-menu.js',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION,
            true
        );

        wp_add_inline_script(
            self::FULLSCREEN_MENU_SCRIPT,
            $this->buildFullscreenMenuConfigScript(),
            'before'
        );

        wp_register_script(
            self::MARQUEE_CAROUSEL_SCRIPT,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/marquee-carousel.js',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION,
            true
        );

        wp_register_script(
            self::MARQUEE_BANNER_LEGACY_SCRIPT,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/marquee-banner-legacy.js',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION,
            true
        );

        $this->scriptsRegistered = true;
    }

    private function buildFullscreenMenuConfigScript(): string
    {
        $featureState = $this->optionsRepository->getFeaturesState($this->featuresRegistry->defaults());

        return 'window.TheCoreElementorWidgetsConfig = ' . wp_json_encode(
            [
                'features' => [
                    'overlayScrollLock' => ! empty($featureState['overlay-scroll-lock']),
                ],
                'bodyLockClass' => 'thecore-elementor-widgets-lock-scroll',
            ]
        ) . ';';
    }
}
