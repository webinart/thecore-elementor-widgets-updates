# The Core - Elementor Widgets

Plugin WordPress dédié aux widgets Elementor et fonctionnalités partagées de
The Core, notamment les Forms legacy Elementor Pro.

Version courante: `0.2.0-beta.83`
Statut de maturité: beta

## Périmètre actuel

- Interface admin top-level `The Core - Widgets`
- Page `Widgets` avec activation/désactivation par widget
- Page `Features` avec activation/désactivation des fonctionnalités globales
- Module opt-in `Elementor Form Security` pour les Forms legacy Elementor Pro :
  ALTCHA auto-hébergé, anti-rejeu, quotas atomiques, déduplication et
  minimisation des métadonnées
- Widgets Atomic actuels: `Fullscreen Menu`, `Marquee Carousel`, `Text List`, `Breadcrumb`, `Icon Text`
- Système d’update distant GitHub via manifest public `beta` / `prod`
- Outillage local: Composer, PHPUnit, PHPCS

## Versioning

- Format beta: `x.x.x-beta.n`
- Format production: `x.x.x`
- Canaux visés: beta et production

## Updates

- Repo source privé: `webinart/thecore-elementor-widgets`
- Repo public de distribution: `webinart/thecore-elementor-widgets-updates`
- Branche de publication des manifests et archives: `plugin-updates`
- Secret GitHub Actions attendu dans le repo privé: `UPDATES_REPO_SSH_KEY`

## Commandes locales

```bash
composer install
composer test
composer test:js
composer cs:check
```

## Elementor Form Security

1. Activer `Elementor Form Security` dans `The Core - Widgets > Features`.
2. Ajouter une seule fois le champ
   `The Core — Protection anti-spam` dans le repeater du widget Form legacy.
3. Conserver la mention RGPD dans un champ HTML Elementor ordinaire afin que
   son texte et son lien restent propres au responsable de traitement.

La protection est entièrement locale : aucune clé SaaS et aucun appel à un
service anti-spam externe. Un formulaire qui contient le champ de protection
échoue fermé si la feature ou son schéma SQL est indisponible. Les formulaires
qui ne contiennent pas ce champ restent inchangés.

La feature est désactivée par défaut. Le plugin doit rester actif tant qu’un
formulaire publié contient ce champ ; toute désactivation nécessite un
rollback coordonné du formulaire.

Le schéma est installé à l’activation du plugin et mis à niveau depuis
l’administration. Il peut être contrôlé avec :

```bash
wp thecore form-security schema verify
wp thecore form-security status
```

Le module protège et minimise uniquement les **nouvelles** soumissions des
formulaires opt-in. Il ne définit ni les destinataires, ni les actions
Elementor, ni le texte RGPD, ni la durée de conservation des demandes et des
e-mails. Ces choix restent propres à chaque site.

La documentation technique et la procédure d’intégration sont détaillées dans
[`docs/form-security.md`](docs/form-security.md).
