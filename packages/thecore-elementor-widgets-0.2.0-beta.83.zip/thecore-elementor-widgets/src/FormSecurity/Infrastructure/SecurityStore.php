<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity\Infrastructure;

use Throwable;

final class SecurityStore
{
    private const MARKER_GRACE_SECONDS = 300;
    private const MAXIMUM_CLEANUP_BATCH = 10000;

    /**
     * @return string allowed, limited or unavailable.
     */
    public function consumeRateLimit(
        string $purpose,
        string $clientHash,
        int $window,
        int $limit,
        int $now
    ): string {
        if (
            ! Installer::isReady()
            || ! in_array($purpose, ['attempt', 'challenge', 'submission'], true)
            || ! self::isSha256($clientHash)
            || $window < 1
            || $limit < 1
            || $now < 1
            || $limit === PHP_INT_MAX
            || $now > PHP_INT_MAX - self::MARKER_GRACE_SECONDS
            || $window > PHP_INT_MAX - $now - self::MARKER_GRACE_SECONDS
        ) {
            return 'unavailable';
        }

        $tableName = Installer::tableName(Installer::TABLE_RATE);
        $wpdb = $this->database();

        if ('' === $tableName || null === $wpdb || ! method_exists($wpdb, 'get_var')) {
            return 'unavailable';
        }

        $windowStart = intdiv($now, $window) * $window;
        $expiresAt = $windowStart + $window + self::MARKER_GRACE_SECONDS;
        $bucketHash = hash('sha256', 'thecore-form-rate-v1|' . $purpose . '|' . $clientHash);
        $cap = $limit + 1;
        $previousSuppression = $this->suppressErrors($wpdb);

        try {
            $this->resetLastError($wpdb);
            $query = $wpdb->prepare(
                "INSERT INTO {$tableName} (bucket_hash, window_start, hits, expires_at)
                VALUES (UNHEX(%s), %d, LAST_INSERT_ID(1), %d)
                ON DUPLICATE KEY UPDATE
                    hits = LAST_INSERT_ID(LEAST(hits + 1, %d)),
                    expires_at = GREATEST(expires_at, %d)",
                $bucketHash,
                $windowStart,
                $expiresAt,
                $cap,
                $expiresAt
            );

            if (! is_string($query) || '' === $query) {
                return 'unavailable';
            }

            $updated = $wpdb->query($query);
            $updateError = $this->lastError($wpdb);
            $hits = null;
            $readError = '';

            if (false !== $updated && '' === $updateError) {
                $this->resetLastError($wpdb);
                $hits = $wpdb->get_var('SELECT LAST_INSERT_ID()');
                $readError = $this->lastError($wpdb);
            }

            if (
                false === $updated
                || '' !== $updateError
                || '' !== $readError
                || null === $hits
                || ! is_numeric($hits)
            ) {
                return 'unavailable';
            }

            return (int) $hits <= $limit ? 'allowed' : 'limited';
        } catch (Throwable) {
            return 'unavailable';
        } finally {
            $this->restoreErrors($wpdb, $previousSuppression);
        }
    }

    /**
     * @return string consumed, replay or unavailable.
     */
    public function consumeReplay(string $signature, int $expiresAt, int $now): string
    {
        if (
            ! Installer::isReady()
            || ! self::isSha256($signature)
            || $now < 1
            || $expiresAt <= $now
            || $expiresAt > PHP_INT_MAX - self::MARKER_GRACE_SECONDS
        ) {
            return 'unavailable';
        }

        $tableName = Installer::tableName(Installer::TABLE_REPLAY);
        $wpdb = $this->database();

        if ('' === $tableName || null === $wpdb) {
            return 'unavailable';
        }

        $proofHash = hash('sha256', 'thecore-form-replay-v1|' . $signature);
        $previousSuppression = $this->suppressErrors($wpdb);

        try {
            $this->resetLastError($wpdb);
            $query = $wpdb->prepare(
                "INSERT IGNORE INTO {$tableName} (proof_hash, expires_at, created_at)
                VALUES (%s, %d, %d)",
                $proofHash,
                $expiresAt + self::MARKER_GRACE_SECONDS,
                $now
            );

            if (! is_string($query) || '' === $query) {
                return 'unavailable';
            }

            $inserted = $wpdb->query($query);
            $lastError = $this->lastError($wpdb);

            if (1 === $inserted && '' === $lastError) {
                return 'consumed';
            }

            if (0 === $inserted && '' === $lastError) {
                return 'replay';
            }

            return 'unavailable';
        } catch (Throwable) {
            return 'unavailable';
        } finally {
            $this->restoreErrors($wpdb, $previousSuppression);
        }
    }

    /**
     * @return string acquired, duplicate or unavailable.
     */
    public function acquireDeduplication(string $fingerprint, int $ttl, int $now): string
    {
        if (
            ! Installer::isReady()
            || ! self::isSha256($fingerprint)
            || $ttl < 1
            || $now < 1
            || $ttl > PHP_INT_MAX - $now
        ) {
            return 'unavailable';
        }

        $tableName = Installer::tableName(Installer::TABLE_DEDUPLICATION);
        $wpdb = $this->database();

        if ('' === $tableName || null === $wpdb || ! method_exists($wpdb, 'get_var')) {
            return 'unavailable';
        }

        try {
            $owner = bin2hex(random_bytes(16));
        } catch (Throwable) {
            return 'unavailable';
        }

        $storedFingerprint = hash('sha256', 'thecore-form-deduplication-v1|' . $fingerprint);
        $expiresAt = $now + $ttl;
        $previousSuppression = $this->suppressErrors($wpdb);

        try {
            $this->resetLastError($wpdb);
            $query = $wpdb->prepare(
                "INSERT INTO {$tableName} (fingerprint, owner_token, expires_at, created_at)
                VALUES (UNHEX(%s), UNHEX(%s), %d, %d)
                ON DUPLICATE KEY UPDATE
                    owner_token = IF(expires_at <= %d, UNHEX(%s), owner_token),
                    created_at = IF(expires_at <= %d, %d, created_at),
                    expires_at = IF(expires_at <= %d, %d, expires_at)",
                $storedFingerprint,
                $owner,
                $expiresAt,
                $now,
                $now,
                $owner,
                $now,
                $now,
                $now,
                $expiresAt
            );

            if (! is_string($query) || '' === $query) {
                return 'unavailable';
            }

            $upserted = $wpdb->query($query);
            $upsertError = $this->lastError($wpdb);
            $storedOwner = null;
            $readError = '';

            if (false !== $upserted && '' === $upsertError) {
                $this->resetLastError($wpdb);
                $ownerQuery = $wpdb->prepare(
                    "SELECT LOWER(HEX(owner_token)) FROM {$tableName} WHERE fingerprint = UNHEX(%s)",
                    $storedFingerprint
                );

                if (is_string($ownerQuery) && '' !== $ownerQuery) {
                    $storedOwner = $wpdb->get_var($ownerQuery);
                    $readError = $this->lastError($wpdb);
                }
            }

            if (
                false === $upserted
                || '' !== $upsertError
                || '' !== $readError
                || ! is_string($storedOwner)
                || ! self::isOwnerToken($storedOwner)
            ) {
                return 'unavailable';
            }

            return hash_equals($owner, strtolower($storedOwner)) ? 'acquired' : 'duplicate';
        } catch (Throwable) {
            return 'unavailable';
        } finally {
            $this->restoreErrors($wpdb, $previousSuppression);
        }
    }

    public function cleanupExpired(int $now, int $batch): int
    {
        if (! Installer::isReady() || $now < 1 || $batch < 1) {
            return 0;
        }

        $tables = Installer::tableNames();
        $wpdb = $this->database();

        if (3 !== count($tables) || null === $wpdb) {
            return 0;
        }

        $limit = min($batch, self::MAXIMUM_CLEANUP_BATCH);
        $deletedTotal = 0;
        $previousSuppression = $this->suppressErrors($wpdb);

        try {
            foreach ($tables as $tableName) {
                $this->resetLastError($wpdb);
                $query = $wpdb->prepare(
                    "DELETE FROM {$tableName} WHERE expires_at <= %d ORDER BY expires_at ASC LIMIT %d",
                    $now,
                    $limit
                );

                if (! is_string($query) || '' === $query) {
                    continue;
                }

                $deleted = $wpdb->query($query);

                if (is_int($deleted) && $deleted > 0 && '' === $this->lastError($wpdb)) {
                    $deletedTotal += $deleted;
                }
            }
        } catch (Throwable) {
            return $deletedTotal;
        } finally {
            $this->restoreErrors($wpdb, $previousSuppression);
        }

        return $deletedTotal;
    }

    private function database(): ?object
    {
        global $wpdb;

        if (
            ! is_object($wpdb)
            || ! method_exists($wpdb, 'prepare')
            || ! method_exists($wpdb, 'query')
        ) {
            return null;
        }

        return $wpdb;
    }

    private function suppressErrors(object $wpdb): ?bool
    {
        if (! method_exists($wpdb, 'suppress_errors')) {
            return null;
        }

        return (bool) $wpdb->suppress_errors();
    }

    private function restoreErrors(object $wpdb, ?bool $previousSuppression): void
    {
        if (null !== $previousSuppression && method_exists($wpdb, 'suppress_errors')) {
            $wpdb->suppress_errors($previousSuppression);
        }
    }

    private function resetLastError(object $wpdb): void
    {
        if (property_exists($wpdb, 'last_error')) {
            $wpdb->last_error = '';
        }
    }

    private function lastError(object $wpdb): string
    {
        return isset($wpdb->last_error) ? (string) $wpdb->last_error : '';
    }

    private static function isSha256(string $value): bool
    {
        return 1 === preg_match('/\A[a-f0-9]{64}\z/D', $value);
    }

    private static function isOwnerToken(string $value): bool
    {
        return 1 === preg_match('/\A[a-f0-9]{32}\z/D', strtolower($value));
    }
}
