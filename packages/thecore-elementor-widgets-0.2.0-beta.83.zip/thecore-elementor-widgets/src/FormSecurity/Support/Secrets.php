<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity\Support;

final class Secrets
{
    public static function audience(): string
    {
        return untrailingslashit(strtolower(home_url('/')));
    }

    public static function contextSigning(): string
    {
        return hash_hmac(
            'sha256',
            'thecore-form-security-context-v1|' . self::audience(),
            wp_salt('auth')
        );
    }

    public static function challengeSigning(): string
    {
        return hash_hmac(
            'sha256',
            'thecore-form-security-challenge-v1|' . self::audience(),
            wp_salt('secure_auth')
        );
    }

    public static function challengeKeySigning(): string
    {
        return hash_hmac(
            'sha256',
            'thecore-form-security-key-v1|' . self::audience(),
            wp_salt('logged_in')
        );
    }

    public static function privacy(): string
    {
        return hash_hmac('sha256', 'thecore-form-security-privacy-v1', wp_salt('nonce'), true);
    }
}
