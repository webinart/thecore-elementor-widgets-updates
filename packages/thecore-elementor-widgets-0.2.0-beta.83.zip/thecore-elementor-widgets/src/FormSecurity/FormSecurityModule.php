<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity;

use TheCore\ElementorWidgets\Contracts\Bootable;
use TheCore\ElementorWidgets\FormSecurity\Elementor\ProtectionField;
use TheCore\ElementorWidgets\FormSecurity\Http\ChallengeController;
use TheCore\ElementorWidgets\FormSecurity\Infrastructure\SecurityStore;
use TheCore\ElementorWidgets\FormSecurity\Security\AltchaService;
use TheCore\ElementorWidgets\FormSecurity\Security\SubmissionGuard;
use TheCore\ElementorWidgets\FormSecurity\Support\ClientIdentity;
use TheCore\ElementorWidgets\FormSecurity\Support\ContextToken;
use TheCore\ElementorWidgets\FormSecurity\Support\DataMinimizer;
use TheCore\ElementorWidgets\FormSecurity\Support\DeduplicationFingerprint;
use TheCore\ElementorWidgets\FormSecurity\Support\FormContextResolver;
use TheCore\ElementorWidgets\FormSecurity\Support\Metrics;
use TheCore\ElementorWidgets\FormSecurity\Support\OriginPolicy;
use TheCore\ElementorWidgets\FormSecurity\Support\Secrets;
use TheCore\ElementorWidgets\FormSecurity\Support\SecuritySettings;

final class FormSecurityModule implements Bootable
{
    private Assets $assets;
    private ChallengeController $challengeController;
    private SubmissionGuard $submissionGuard;
    private ContextToken $contextToken;
    private SecuritySettings $settings;

    public function __construct()
    {
        $this->settings = new SecuritySettings();
        $resolver = new FormContextResolver();
        $originPolicy = new OriginPolicy();
        $store = new SecurityStore();
        $metrics = new Metrics();
        $clientIdentity = new ClientIdentity(Secrets::privacy());
        $this->contextToken = new ContextToken(Secrets::contextSigning());
        $altcha = new AltchaService(
            Secrets::challengeSigning(),
            Secrets::challengeKeySigning(),
            $this->settings->altchaCost(),
            $this->settings->counterMinimum(),
            $this->settings->counterMaximum(),
            $this->settings->challengeMinimumSeconds(),
            $this->settings->challengeMaximumSeconds()
        );
        $this->submissionGuard = new SubmissionGuard(
            $resolver,
            $originPolicy,
            $clientIdentity,
            $store,
            $altcha,
            $this->settings,
            new DataMinimizer(),
            new DeduplicationFingerprint(Secrets::privacy()),
            $metrics
        );
        $this->challengeController = new ChallengeController(
            $this->contextToken,
            $originPolicy,
            $clientIdentity,
            $store,
            $altcha,
            $this->settings,
            $metrics
        );
        $this->assets = new Assets();
    }

    public function register(): void
    {
        $this->challengeController->markRequestUncacheable();
        $this->assets->register();

        add_action('rest_api_init', [$this->challengeController, 'registerRoute']);
        add_action('elementor_pro/forms/fields/register', [$this, 'registerProtectionField']);
        add_action(
            'elementor_pro/forms/validation',
            [$this->submissionGuard, 'normalizeTelephoneFields'],
            1,
            2
        );
        add_action(
            'elementor_pro/forms/validation',
            [$this->submissionGuard, 'validateRecord'],
            PHP_INT_MAX,
            2
        );
        add_action(
            'elementor_pro/forms/process',
            [$this->submissionGuard, 'removeTechnicalFieldsFromRecord'],
            PHP_INT_MAX,
            2
        );
        add_action(
            'elementor_pro/forms/new_record',
            [$this->submissionGuard, 'recordResult'],
            10,
            2
        );
    }

    /**
     * @param object $registrar Elementor Pro form field registrar.
     */
    public function registerProtectionField(object $registrar): void
    {
        if (
            ! method_exists($registrar, 'register')
            || ! class_exists('\ElementorPro\Modules\Forms\Fields\Field_Base')
        ) {
            return;
        }

        $registrar->register(
            new ProtectionField(
                $this->contextToken,
                $this->settings
            )
        );
    }
}
