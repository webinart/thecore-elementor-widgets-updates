<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity\Security;

use TheCore\ElementorWidgets\FormSecurity\Infrastructure\Installer;
use TheCore\ElementorWidgets\FormSecurity\Infrastructure\SecurityStore;
use TheCore\ElementorWidgets\FormSecurity\Support\ChallengeContext;
use TheCore\ElementorWidgets\FormSecurity\Support\ClientIdentity;
use TheCore\ElementorWidgets\FormSecurity\Support\DataMinimizer;
use TheCore\ElementorWidgets\FormSecurity\Support\DeduplicationFingerprint;
use TheCore\ElementorWidgets\FormSecurity\Support\FormContextResolver;
use TheCore\ElementorWidgets\FormSecurity\Support\Metrics;
use TheCore\ElementorWidgets\FormSecurity\Support\OriginPolicy;
use TheCore\ElementorWidgets\FormSecurity\Support\SecuritySettings;

final class SubmissionGuard
{
    /**
     * @var array<int, true>
     */
    private array $validatedRecords = [];

    public function __construct(
        private readonly FormContextResolver $resolver,
        private readonly OriginPolicy $originPolicy,
        private readonly ClientIdentity $clientIdentity,
        private readonly SecurityStore $store,
        private readonly AltchaService $altcha,
        private readonly SecuritySettings $settings,
        private readonly DataMinimizer $minimizer,
        private readonly DeduplicationFingerprint $deduplicationFingerprint,
        private readonly Metrics $metrics
    ) {
    }

    public function validateRecord(object $record, object $ajaxHandler): void
    {
        $resolution = $this->resolver->resolve($record, $ajaxHandler);

        if (! $resolution->isProtected()) {
            return;
        }

        $context = $resolution->context();
        $this->validate(
            [
                'id' => null !== $context ? $context->fieldId() : '',
                'type' => FormContextResolver::FIELD_TYPE,
            ],
            $record,
            $ajaxHandler
        );
    }

    /**
     * Elementor rejects spaces and slashes in telephone fields before its
     * global form-validation hook runs. For an explicitly protected form,
     * accept those presentation characters only when removing them produces
     * a value accepted by Elementor's own validator.
     */
    public function normalizeTelephoneFields(object $record, object $ajaxHandler): void
    {
        if (
            ! $this->resolver->resolve($record, $ajaxHandler)->isProtected()
            || ! method_exists($record, 'get')
            || ! method_exists($record, 'update_field')
            || ! isset($ajaxHandler->errors)
            || ! is_array($ajaxHandler->errors)
        ) {
            return;
        }

        $fields = $record->get('fields');
        if (! is_array($fields)) {
            return;
        }

        $nativeError = esc_html__(
            'The field accepts only numbers and phone characters (#, -, *, etc).',
            'elementor-pro'
        );
        $removedNativeError = false;

        foreach ($fields as $field) {
            if (
                ! is_array($field)
                || 'tel' !== (string) ($field['type'] ?? '')
                || ! isset($field['id'])
                || ! is_string($field['id'])
                || '' === $field['id']
                || ! isset($field['value'])
                || ! is_scalar($field['value'])
            ) {
                continue;
            }

            $fieldId = $field['id'];
            $value = (string) $field['value'];
            $normalized = preg_replace('/[\s\/]+/u', '', $value);

            if (
                ! is_string($normalized)
                || $normalized === $value
                || 1 !== preg_match('/^[0-9()#&+*-=.]+$/', $normalized)
                || ($ajaxHandler->errors[$fieldId] ?? null) !== $nativeError
            ) {
                continue;
            }

            $record->update_field($fieldId, 'value', $normalized);
            $record->update_field($fieldId, 'raw_value', $normalized);
            unset($ajaxHandler->errors[$fieldId]);
            $removedNativeError = true;
        }

        if (
            $removedNativeError
            && [] === $ajaxHandler->errors
            && $this->ajaxMessagesAreEmpty($ajaxHandler)
            && method_exists($ajaxHandler, 'set_success')
        ) {
            $ajaxHandler->set_success(true);
        }
    }

    /**
     * @param array<string, mixed> $field
     */
    public function validate(array $field, object $record, object $ajaxHandler): void
    {
        $recordId = spl_object_id($record);

        if (isset($this->validatedRecords[$recordId])) {
            return;
        }

        $this->validatedRecords[$recordId] = true;
        $resolution = $this->resolver->resolve($record, $ajaxHandler);

        if (! $resolution->isProtected()) {
            $this->block($ajaxHandler, 'blocked_configuration');

            return;
        }

        $this->minimizer->minimize($record);

        if (! $resolution->isValid() || null === $resolution->context()) {
            $this->block($ajaxHandler, 'blocked_configuration');

            return;
        }

        $context = $resolution->context();
        $fieldId = isset($field['id']) ? (string) $field['id'] : '';

        if (
            FormContextResolver::FIELD_TYPE !== (string) ($field['type'] ?? '')
            || $fieldId !== $context->fieldId()
        ) {
            $this->block($ajaxHandler, 'blocked_configuration');

            return;
        }

        if (! $this->originPolicy->isAllowed($_SERVER, home_url('/'))) {
            $this->block($ajaxHandler, 'blocked_origin');

            return;
        }

        $clientHash = $this->clientIdentity->hash($_SERVER);
        $attemptStatus = $this->store->consumeRateLimit(
            'attempt',
            $clientHash,
            $this->settings->attemptRateWindow(),
            $this->settings->attemptRateLimit(),
            time()
        );

        if ('allowed' !== $attemptStatus) {
            $this->block(
                $ajaxHandler,
                'limited' === $attemptStatus ? 'blocked_attempt_rate' : 'blocked_store_unavailable'
            );

            return;
        }

        $contentLength = isset($_SERVER['CONTENT_LENGTH']) && is_scalar($_SERVER['CONTENT_LENGTH'])
            ? (int) $_SERVER['CONTENT_LENGTH']
            : 0;
        $maximumRequestBytes = $this->settings->maximumRequestBytes();

        if ($maximumRequestBytes > 0 && $contentLength > $maximumRequestBytes) {
            $this->block($ajaxHandler, 'blocked_payload_size');

            return;
        }

        if (
            property_exists($ajaxHandler, 'errors')
            && ! empty($ajaxHandler->errors)
        ) {
            $this->metrics->increment('blocked_elementor');

            return;
        }

        if (! $this->postedValueIsStrictlyEmpty(SecuritySettings::HONEYPOT_INPUT, 512)) {
            $this->block($ajaxHandler, 'blocked_honeypot');

            return;
        }

        if (! Installer::isReady()) {
            $this->block($ajaxHandler, 'blocked_schema_unavailable');

            return;
        }

        $submissionRateStatus = $this->store->consumeRateLimit(
            'submission',
            $clientHash,
            $this->settings->submissionRateWindow(),
            $this->settings->submissionRateLimit(),
            time()
        );

        if ('allowed' !== $submissionRateStatus) {
            $this->block(
                $ajaxHandler,
                'limited' === $submissionRateStatus
                    ? 'blocked_submission_rate'
                    : 'blocked_store_unavailable'
            );

            return;
        }

        $payload = $this->postedScalar(SecuritySettings::ALTCHA_INPUT, 16384);
        $verification = $this->altcha->verifyPayload(
            $payload,
            ChallengeContext::forForm($context)
        );

        if ('valid' !== $verification['status']) {
            $this->block($ajaxHandler, 'blocked_altcha_' . $verification['status']);

            return;
        }

        if (
            ! is_string($verification['replayKey'])
            || ! is_int($verification['expiresAt'])
        ) {
            $this->block($ajaxHandler, 'blocked_altcha_invalid');

            return;
        }

        $replayStatus = $this->store->consumeReplay(
            $verification['replayKey'],
            $verification['expiresAt'],
            time()
        );

        if ('consumed' !== $replayStatus) {
            $this->block(
                $ajaxHandler,
                'replay' === $replayStatus ? 'blocked_replay' : 'blocked_store_unavailable'
            );

            return;
        }

        $fields = method_exists($record, 'get') ? $record->get('fields') : [];
        if (! is_array($fields)) {
            $this->block($ajaxHandler, 'blocked_configuration');

            return;
        }

        $fingerprint = $this->deduplicationFingerprint->create($context, $fields);
        $deduplicationStatus = $this->store->acquireDeduplication(
            $fingerprint,
            $this->settings->deduplicationTtl(),
            time()
        );

        if ('acquired' !== $deduplicationStatus) {
            $this->block(
                $ajaxHandler,
                'duplicate' === $deduplicationStatus
                    ? 'blocked_duplicate'
                    : 'blocked_store_unavailable'
            );

            return;
        }

        $this->metrics->increment('validated');
    }

    /**
     * @param array<string, mixed> $field
     */
    public function removeTechnicalField(array $field, object $record): void
    {
        $fieldId = isset($field['id']) ? (string) $field['id'] : '';

        if (
            FormContextResolver::FIELD_TYPE === (string) ($field['type'] ?? '')
            && '' !== $fieldId
            && method_exists($record, 'remove_field')
        ) {
            $record->remove_field($fieldId);
        }

        unset(
            $_POST[SecuritySettings::ALTCHA_INPUT],
            $_POST[SecuritySettings::HONEYPOT_INPUT]
        );
    }

    public function removeTechnicalFieldsFromRecord(object $record, object $ajaxHandler): void
    {
        $resolution = $this->resolver->resolve($record, $ajaxHandler);
        $context = $resolution->context();

        if (
            $resolution->isValid()
            && null !== $context
            && method_exists($record, 'remove_field')
        ) {
            $record->remove_field($context->fieldId());
        }

        unset(
            $_POST[SecuritySettings::ALTCHA_INPUT],
            $_POST[SecuritySettings::HONEYPOT_INPUT]
        );
    }

    public function recordResult(object $record, object $ajaxHandler): void
    {
        $resolution = $this->resolver->resolve($record, $ajaxHandler);
        if (! $resolution->isValid()) {
            return;
        }

        $hasErrors = (
            property_exists($ajaxHandler, 'errors')
            && ! empty($ajaxHandler->errors)
        ) || (
            property_exists($ajaxHandler, 'messages')
            && is_array($ajaxHandler->messages)
            && (
                ! empty($ajaxHandler->messages['error'])
                || ! empty($ajaxHandler->messages['admin_error'])
            )
        );

        $this->metrics->increment($hasErrors ? 'delivery_error' : 'accepted');
    }

    private function ajaxMessagesAreEmpty(object $ajaxHandler): bool
    {
        if (! isset($ajaxHandler->messages) || ! is_array($ajaxHandler->messages)) {
            return true;
        }

        return [] === ($ajaxHandler->messages['error'] ?? [])
            && [] === ($ajaxHandler->messages['admin_error'] ?? []);
    }

    private function block(object $ajaxHandler, string $metric): void
    {
        if (method_exists($ajaxHandler, 'add_error')) {
            $ajaxHandler->add_error(
                'invalid_form',
                __(
                    'Votre demande n’a pas pu être envoyée. Actualisez la page puis réessayez.',
                    'thecore-elementor-widgets'
                )
            );
        }

        $this->metrics->increment($metric);
    }

    private function postedScalar(string $key, int $maximumBytes): string
    {
        if (
            ! isset($_POST[$key])
            || ! is_scalar($_POST[$key])
        ) {
            return '';
        }

        $value = (string) wp_unslash($_POST[$key]);

        return strlen($value) <= $maximumBytes ? trim($value) : '';
    }

    private function postedValueIsStrictlyEmpty(string $key, int $maximumBytes): bool
    {
        if (! array_key_exists($key, $_POST) || ! is_scalar($_POST[$key])) {
            return false;
        }

        $value = (string) wp_unslash($_POST[$key]);

        return strlen($value) <= $maximumBytes && '' === $value;
    }
}
