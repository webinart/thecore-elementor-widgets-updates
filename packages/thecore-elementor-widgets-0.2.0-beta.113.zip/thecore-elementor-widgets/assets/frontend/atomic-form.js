( function () {
	'use strict';
	if ( window.theCoreAtomicFormsLoaded ) { return; }
	window.theCoreAtomicFormsLoaded = true;
	const selector = 'form[data-thecore-form="1"]';
	const states = new WeakMap();
	let sequence = 0;
	let antispamLoading = null;
	const unavailable = 'Ce formulaire est momentanement indisponible. Veuillez reessayer plus tard.';
	const mediaDeliveryUncertain = 'Votre demande n’a pas pu être confirmée. Les fichiers sont conservés de manière sécurisée. Contactez-nous avant de recommencer.';

	function antispamReady() {
		return !! window.customElements?.get( 'altcha-widget' )
			&& window.$altcha?.algorithms?.has( 'PBKDF2/SHA-256' );
	}

	function loadAntispamScript( url ) {
		return new Promise( ( resolve, reject ) => {
			const script = document.createElement( 'script' );
			const timeout = window.setTimeout( () => finish( false ), 20000 );
			const finish = ( success ) => {
				window.clearTimeout( timeout );
				script.onload = script.onerror = null;
				if ( success ) { resolve(); }
				else { script.remove(); reject( new Error( unavailable ) ); }
			};
			script.async = false;
			script.src = sameOrigin( url );
			script.onload = () => finish( true );
			script.onerror = () => finish( false );
			document.head.appendChild( script );
		} );
	}

	function ensureAntispam() {
		if ( antispamReady() ) { return Promise.resolve(); }
		if ( antispamLoading ) { return antispamLoading; }
		antispamLoading = ( async () => {
			const assets = window.TheCoreAtomicFormAntispamAssets;
			if ( ! window.customElements || ! assets ) { throw new Error( unavailable ); }
			// Validate every URL before starting a partial load.
			if ( [ 'altchaUrl', 'registrationUrl', 'workerUrl' ].some( key => typeof assets[ key ] !== 'string' || ! assets[ key ].trim() ) ) {
				throw new Error( unavailable );
			}
			const altchaUrl = sameOrigin( assets.altchaUrl );
			const registrationUrl = sameOrigin( assets.registrationUrl );
			const workerUrl = sameOrigin( assets.workerUrl );
			if ( ! window.customElements.get( 'altcha-widget' ) ) { await loadAntispamScript( altchaUrl ); }
			if ( ! window.$altcha?.algorithms?.has( 'PBKDF2/SHA-256' ) ) {
				window.theCoreElementorFormSecurity = Object.assign( {}, window.theCoreElementorFormSecurity || {}, { workerUrl } );
				await loadAntispamScript( registrationUrl );
			}
			if ( ! antispamReady() ) { throw new Error( unavailable ); }
		} )().catch( error => { antispamLoading = null; throw error; } );
		return antispamLoading;
	}

	function warmAntispam( event ) {
		const form = event.target.closest?.( selector );
		if ( form && init( form )?.config ) { void ensureAntispam().catch( () => {} ); }
	}
	document.addEventListener( 'pointerdown', warmAntispam, { passive: true } );
	document.addEventListener( 'focusin', warmAntispam );

	function sameOrigin( value ) {
		const url = new URL( value, window.location.href );
		if ( url.origin !== window.location.origin || url.username || url.password || ! [ 'http:', 'https:' ].includes( url.protocol ) ) {
			throw new Error( unavailable );
		}
		return url.href;
	}

	function status( state, message, error = false ) {
		state.status.setAttribute( 'role', error ? 'alert' : 'status' );
		state.status.setAttribute( 'aria-live', error ? 'assertive' : 'polite' );
		state.status.textContent = message;
	}

	function init( form ) {
		if ( states.has( form ) ) { return states.get( form ); }
		if ( form.dataset.thecoreEditorPreview === '1' || document.body.classList.contains( 'elementor-editor-active' ) ) { return null; }
		const output = form.querySelector( '[data-thecore-form-status]' );
		if ( ! output ) { return null; }
		const state = { form, status: output, busy: false, controls: new Map(), errors: [] };
		states.set( form, state );
		try {
			state.config = JSON.parse( form.dataset.thecoreFormConfig );
			state.config.endpoint = sameOrigin( state.config.endpoint );
			state.config.challengeUrl = sameOrigin( state.config.challengeUrl );
			const suffix = '-tc-' + ( ++sequence );
			for ( const field of state.config.fields ) {
				const controls = Array.from( form.querySelectorAll( 'input,textarea,select' ) ).filter( el => el.id === field.domId );
				if ( controls.length !== 1 ) { throw new Error( unavailable ); }
				const control = controls[ 0 ];
				const labels = Array.from( form.querySelectorAll( 'label' ) ).filter( el => el.htmlFor === field.domId );
				control.id = field.domId + suffix;
				labels.forEach( label => { label.htmlFor = control.id; } );
				// Repeated templates must not share radio groups or label targets.
				if ( field.type === 'radio' ) { control.name = field.name + suffix; }
				state.controls.set( field.id, control );
			}
			attachMedia( state );
		} catch ( error ) {
			state.config = null;
			if ( ! output.textContent.trim() ) { status( state, unavailable, true ); }
		}
		return state;
	}

	function attachMedia( state ) {
		if ( state.media || ! state.config?.fields.some( field => field.type === 'media' ) ) { return; }
		if ( ! window.theCoreAtomicFormMedia ) { return; }
		state.media = window.theCoreAtomicFormMedia.init( {
			form: state.form, config: state.config, controls: state.controls,
			requestProof: signal => {
				// Multiple media fields may request sessions together. Never share a proof.
				const pending = ( state.proofQueue || Promise.resolve() ).catch( () => {} ).then( () => proof( state, signal ) );
				state.proofQueue = pending; return pending;
			},
			getWebsite: () => state.form.querySelector( '[name="thecore_form_website"]' )?.value || '',
		} );
	}
	window.addEventListener( 'thecore:form-media-ready', () => {
		document.querySelectorAll( selector ).forEach( form => {
			const state = states.get( form );
			if ( state?.config ) {
				try { attachMedia( state ); }
				catch ( error ) { state.config = null; status( state, unavailable, true ); }
			}
		} );
	} );

	function clearErrors( state ) {
		for ( const entry of state.errors ) {
			entry.node.remove();
			const ids = ( entry.control.getAttribute( 'aria-describedby' ) || '' ).split( /\s+/ ).filter( id => id && id !== entry.node.id );
			if ( ids.length ) { entry.control.setAttribute( 'aria-describedby', ids.join( ' ' ) ); }
			else { entry.control.removeAttribute( 'aria-describedby' ); }
			entry.control.removeAttribute( 'aria-invalid' );
		}
		state.errors = [];
	}

	function showErrors( state, errors ) {
		let first;
		for ( const [ id, message ] of Object.entries( errors || {} ) ) {
			const control = state.controls.get( id );
			if ( ! control || typeof message !== 'string' ) { continue; }
			const node = document.createElement( 'span' );
			node.id = control.id + '-error';
			node.dataset.thecoreFieldError = '1';
			node.textContent = message;
			control.insertAdjacentElement( 'afterend', node );
			control.setAttribute( 'aria-invalid', 'true' );
			control.setAttribute( 'aria-describedby', ( ( control.getAttribute( 'aria-describedby' ) || '' ) + ' ' + node.id ).trim() );
			state.errors.push( { node, control } );
			first ||= control;
		}
		return first;
	}

	function collect( state ) {
		const fields = Object.create( null );
		for ( const [ id, control ] of state.controls ) {
			if ( control.tagName === 'SELECT' && control.multiple ) {
				fields[ id ] = Array.from( control.selectedOptions, option => option.value );
			} else if ( [ 'checkbox', 'radio' ].includes( control.type ) ) {
				fields[ id ] = control.checked ? control.value : '';
			} else { fields[ id ] = control.value; }
		}
		if ( state.media ) { Object.assign( fields, state.media.values() ); }
		return fields;
	}

	async function proof( state, signal ) {
		if ( ! window.customElements ) { throw new Error( unavailable ); }
		await Promise.race( [
			ensureAntispam(),
			new Promise( ( resolve, reject ) => { signal.addEventListener( 'abort', () => reject( new Error( unavailable ) ), { once: true } ); } ),
		] );
		if ( signal.aborted ) { throw new Error( unavailable ); }
		const widget = document.createElement( 'altcha-widget' );
		state.form.appendChild( widget );
		try {
			// The custom element installs its imperative API asynchronously on connection.
			await new Promise( resolve => window.setTimeout( resolve, 0 ) );
			if ( signal.aborted || typeof widget.configure !== 'function' ) { throw new Error( unavailable ); }
			widget.configure( {
				auto: 'off', display: 'invisible', challenge: state.config.challengeUrl,
				name: 'thecore_atomic_proof', hideFooter: true, hideLogo: true, humanInteractionSignature: false,
				minDuration: state.config.minDuration + 1000, timeout: 45000, workers: 1,
				fetch: ( input, options ) => fetch( sameOrigin( typeof input === 'string' ? input : input.url ), {
					...options, cache: 'no-store', credentials: 'same-origin', redirect: 'error', signal,
				} ),
			} );
			return await new Promise( ( resolve, reject ) => {
				let settled = false;
				const finish = ( payload ) => {
					if ( settled ) { return; }
					settled = true;
					widget.removeEventListener( 'statechange', onState );
					signal.removeEventListener( 'abort', onAbort );
					if ( payload ) { resolve( payload ); }
					else { reject( new Error( 'Le controle anti-spam a echoue. Veuillez reessayer.' ) ); }
				};
				const onAbort = () => finish( null );
				const onState = ( event ) => {
					if ( event.detail?.state === 'verified' ) {
						window.setTimeout( () => finish( widget.querySelector( 'input[name="thecore_atomic_proof"]' )?.value ), 0 );
					} else if ( [ 'error', 'expired' ].includes( event.detail?.state ) ) { finish( null ); }
				};
				widget.addEventListener( 'statechange', onState );
				signal.addEventListener( 'abort', onAbort, { once: true } );
				try { Promise.resolve( widget.verify() ).catch( () => finish( null ) ); }
				catch ( error ) { finish( null ); }
			} );
		} finally {
			try { widget.reset?.(); } catch ( error ) { /* Always dispose of this one-use proof. */ }
			widget.remove();
		}
	}

	async function submit( state ) {
		if ( state.busy ) { return; }
		if ( state.deliveryUncertain ) { status( state, mediaDeliveryUncertain, true ); state.status.focus(); return; }
		if ( ! state.config ) { status( state, unavailable, true ); return; }
		if ( state.config.fields.some( field => field.type === 'media' ) && ! state.media ) {
			status( state, unavailable, true ); return;
		}
		if ( state.media?.isBusy() ) { status( state, 'Un transfert est en cours. Attendez sa confirmation avant d’envoyer le formulaire.', true ); state.status.focus(); return; }
		clearErrors( state );
		state.media?.validate();
		if ( ! state.form.reportValidity() ) { return; }
		const testInput = state.form.querySelector( '[name="webinart_form_check_token"]' );
		const testToken = testInput ? testInput.value : null;
		const buttons = Array.from( state.form.querySelectorAll( 'button[type="submit"],input[type="submit"]' ) );
		const original = buttons.map( button => button.disabled );
		state.busy = true;
		state.media?.setSubmitting( true );
		state.form.setAttribute( 'aria-busy', 'true' );
		buttons.forEach( button => { button.disabled = true; } );
		status( state, 'Verification et envoi en cours...' );
		const abort = new AbortController();
		const timeout = window.setTimeout( () => abort.abort(), 60000 );
		let focusTarget;
		try {
			await state.media?.prepare();
			const fields = collect( state );
			const submissionId = state.config.apiEnabled
				? await window.theCoreFormApiSubmission.prepare( state.config.apiScope, fields ) : null;
			const payload = {
				context: state.config.context, fields,
				website: state.form.querySelector( '[name="thecore_form_website"]' )?.value || '',
				proof: await proof( state, abort.signal ),
			};
			if ( state.media ) { payload.media_sessions = state.media.sessions(); }
			if ( submissionId !== null ) { payload.submission_id = submissionId; }
			if ( testToken !== null ) { payload.test_token = testToken; }
			const response = await fetch( state.config.endpoint, {
				method: 'POST', headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify( payload ), credentials: 'same-origin', cache: 'no-store', redirect: 'error', signal: abort.signal,
			} );
			const result = await response.json();
			const ok = response.ok && result.success === true;
			status( state, typeof result.message === 'string' ? result.message : unavailable, ! ok );
			if ( ! ok && result.code === 'media_delivery_uncertain' && state.media ) {
				state.deliveryUncertain = true;
				state.form.dataset.thecoreFormDeliveryUncertain = '1';
				state.media.deliveryUncertain();
				status( state, mediaDeliveryUncertain, true );
			} else if ( ! ok ) { focusTarget = showErrors( state, result.fields ); }
			else if ( result.mode === 'live' ) {
				if ( state.config.apiEnabled ) { await window.theCoreFormApiSubmission.clear( state.config.apiScope ); }
				state.media?.confirmedSuccess();
				state.form.reset();
			}
			state.form.dispatchEvent( new CustomEvent( 'thecore:form-result', { bubbles: true,
				detail: { success: ok, mode: result.mode || null, code: result.code || null, runId: result.runId || null,
					mailSent: result.mailSent ?? null, deliveryTested: result.deliveryTested ?? null,
					storageValidated: result.storageValidated ?? null, storageWritten: result.storageWritten ?? null,
					actionsValidated: result.actionsValidated || [], actionsSkipped: result.actionsSkipped || [],
					actionsExecuted: result.actionsExecuted ?? null } } ) );
		} catch ( error ) {
			console.error( 'The Core form submission failed.', error );
			status( state, 'Envoi non confirme. Verifiez votre connexion avant de reessayer.', true );
		} finally {
			window.clearTimeout( timeout );
			abort.abort();
			state.form.querySelectorAll( 'input[name="thecore_atomic_proof"]' ).forEach( input => input.remove() );
			buttons.forEach( ( button, index ) => { button.disabled = state.deliveryUncertain || original[ index ]; } );
			state.form.removeAttribute( 'aria-busy' );
			state.busy = false;
			state.media?.setSubmitting( false );
			( focusTarget || state.status ).focus();
		}
	}

	document.addEventListener( 'submit', ( event ) => {
		if ( ! event.target.matches?.( selector ) ) { return; }
		event.preventDefault();
		const state = init( event.target );
		if ( state ) { void submit( state ); }
	} );

	function scan( root ) {
		if ( root.matches?.( selector ) ) { init( root ); }
		root.querySelectorAll?.( selector ).forEach( init );
	}
	function boot() {
		scan( document );
		new MutationObserver( entries => entries.forEach( entry => entry.addedNodes.forEach( node => {
			if ( node.nodeType === 1 ) { scan( node ); }
		} ) ) ).observe( document.body, { childList: true, subtree: true } );
	}
	if ( document.readyState === 'loading' ) { document.addEventListener( 'DOMContentLoaded', boot, { once: true } ); }
	else { boot(); }
}() );
