<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Legacy\Widgets\CookieConsent;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;
use TheCore\ElementorWidgets\Assets\FrontendAssets;
use TheCore\ElementorWidgets\CookieConsent\ConfigRepository;
use TheCore\ElementorWidgets\CookieConsent\CookieConsentModule;

final class CookieConsent extends Widget_Base
{
    public function get_name(): string
    {
        return 'thecore-cookie-consent';
    }

    public function get_title(): string
    {
        return __('Cookie Consent Module', 'thecore-elementor-widgets');
    }

    public function get_icon(): string
    {
        return 'eicon-lock-user';
    }

    public function get_categories(): array
    {
        return ['general'];
    }

    public function get_keywords(): array
    {
        return ['cookie', 'consent', 'gdpr', 'privacy', 'banner', 'the core'];
    }

    public function get_style_depends(): array
    {
        return [FrontendAssets::COOKIE_CONSENT_STYLE];
    }

    public function get_script_depends(): array
    {
        return [FrontendAssets::COOKIE_CONSENT_SCRIPT];
    }

    protected function register_controls(): void
    {
        $this->start_controls_section(
            'section_module',
            [
                'label' => __('Module', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'module_notice',
            [
                'type' => Controls_Manager::RAW_HTML,
                'raw' => esc_html__(
                    'This widget renders the consent banner directly. Disable the global theme cookie module on the same site to avoid duplicate banners.',
                    'thecore-elementor-widgets'
                ),
                'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
            ]
        );

        $this->add_control(
            'theme_preset',
            [
                'label' => __('Preset', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SELECT,
                'default' => CookieConsentModule::DEFAULT_THEME_PRESET,
                'options' => [
                    'default' => __('Default', 'thecore-elementor-widgets'),
                    'labs' => __('Labs', 'thecore-elementor-widgets'),
                    'sidecar' => __('Sidecar', 'thecore-elementor-widgets'),
                    'lowkey' => __('Low-key', 'thecore-elementor-widgets'),
                ],
            ]
        );

        $this->add_control(
            'notice_text',
            [
                'label' => __('Notice Text', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::WYSIWYG,
                'default' => CookieConsentModule::DEFAULT_NOTICE_TEXT,
            ]
        );

        $this->add_control(
            'show_category_descriptions',
            [
                'label' => __('Show category descriptions', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'thecore-elementor-widgets'),
                'label_off' => __('No', 'thecore-elementor-widgets'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'reload_on_set',
            [
                'label' => __('Reload page after consent', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'thecore-elementor-widgets'),
                'label_off' => __('No', 'thecore-elementor-widgets'),
                'return_value' => 'yes',
                'default' => '',
            ]
        );

        $this->add_control(
            'cookie_expiration_days',
            [
                'label' => __('Cookie expiration (days)', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::NUMBER,
                'default' => CookieConsentModule::DEFAULT_COOKIE_EXPIRATION_DAYS,
                'min' => 1,
                'max' => 365,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_buttons',
            [
                'label' => __('Buttons', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'accept_button_label',
            [
                'label' => __('Accept button', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXT,
                'default' => CookieConsentModule::DEFAULT_ACCEPT_BUTTON_LABEL,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'confirm_choice_button_label',
            [
                'label' => __('Confirm button', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXT,
                'default' => CookieConsentModule::DEFAULT_CONFIRM_BUTTON_LABEL,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'reject_button_label',
            [
                'label' => __('Reject button', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXT,
                'default' => CookieConsentModule::DEFAULT_REJECT_BUTTON_LABEL,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'privacy_policy_button_label',
            [
                'label' => __('Privacy button', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXT,
                'default' => CookieConsentModule::DEFAULT_PRIVACY_BUTTON_LABEL,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'privacy_policy_url',
            [
                'label' => __('Privacy policy URL', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::URL,
                'label_block' => true,
                'placeholder' => __('https://example.com/privacy-policy', 'thecore-elementor-widgets'),
            ]
        );

        $this->add_control(
            'revoke_consent_button_label',
            [
                'label' => __('Revoke consent button', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXT,
                'default' => CookieConsentModule::DEFAULT_REVOKE_BUTTON_LABEL,
                'label_block' => true,
                'description' => __('Used by the revoke shortcode and global consent reset actions.', 'thecore-elementor-widgets'),
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_consent',
            [
                'label' => __('Consent & Logging', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'log_consents',
            [
                'label' => __('Log consents', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'thecore-elementor-widgets'),
                'label_off' => __('No', 'thecore-elementor-widgets'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'anonymize_consent_log_ips',
            [
                'label' => __('Anonymize consent IPs', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'thecore-elementor-widgets'),
                'label_off' => __('No', 'thecore-elementor-widgets'),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'log_consents' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'auto_purge_consents',
            [
                'label' => __('Auto-purge old consent logs', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'thecore-elementor-widgets'),
                'label_off' => __('No', 'thecore-elementor-widgets'),
                'return_value' => 'yes',
                'default' => '',
                'condition' => [
                    'log_consents' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'auto_purge_consents_interval',
            [
                'label' => __('Auto-purge interval', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SELECT,
                'default' => CookieConsentModule::DEFAULT_AUTO_PURGE_INTERVAL,
                'options' => [
                    '1 month' => __('1 month', 'thecore-elementor-widgets'),
                    '3 months' => __('3 months', 'thecore-elementor-widgets'),
                    '6 months' => __('6 months', 'thecore-elementor-widgets'),
                    '1 year' => __('1 year', 'thecore-elementor-widgets'),
                    '2 years' => __('2 years', 'thecore-elementor-widgets'),
                    '5 years' => __('5 years', 'thecore-elementor-widgets'),
                ],
                'condition' => [
                    'log_consents' => 'yes',
                    'auto_purge_consents' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'revoke_delete_all',
            [
                'label' => __('Delete all cookies on revoke', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'thecore-elementor-widgets'),
                'label_off' => __('No', 'thecore-elementor-widgets'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'block_embeds',
            [
                'label' => __('Block embeds until functional consent', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'thecore-elementor-widgets'),
                'label_off' => __('No', 'thecore-elementor-widgets'),
                'return_value' => 'yes',
                'default' => '',
                'description' => __('Replaces blocked oEmbeds with a consent placeholder until functional cookies are accepted.', 'thecore-elementor-widgets'),
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_categories',
            [
                'label' => __('Categories', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        foreach (DisplaySettings::DEFAULT_CATEGORY_SETTINGS as $slug => $definition) {
            $label = (string) $definition['label'];

            $this->add_control(
                $slug . '_active',
                [
                    'label' => sprintf(__('Enable %s', 'thecore-elementor-widgets'), $label),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => __('Yes', 'thecore-elementor-widgets'),
                    'label_off' => __('No', 'thecore-elementor-widgets'),
                    'return_value' => 'yes',
                    'default' => ! empty($definition['active']) ? 'yes' : '',
                ]
            );

            $this->add_control(
                $slug . '_label',
                [
                    'label' => __('Label', 'thecore-elementor-widgets'),
                    'type' => Controls_Manager::TEXT,
                    'default' => $label,
                    'label_block' => true,
                    'condition' => [
                        $slug . '_active' => 'yes',
                    ],
                ]
            );

            $this->add_control(
                $slug . '_description',
                [
                    'label' => __('Description', 'thecore-elementor-widgets'),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => (string) $definition['description'],
                    'rows' => 3,
                    'condition' => [
                        $slug . '_active' => 'yes',
                    ],
                ]
            );

            $this->add_control(
                $slug . '_code',
                [
                    'label' => __('Category Code', 'thecore-elementor-widgets'),
                    'type' => Controls_Manager::TEXTAREA,
                    'rows' => 8,
                    'description' => __('Scripts or markup injected once this category has been accepted.', 'thecore-elementor-widgets'),
                    'condition' => [
                        $slug . '_active' => 'yes',
                    ],
                ]
            );
        }

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_panel',
            [
                'label' => __('Panel', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'panel_width',
            [
                'label' => __('Panel Width', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'vw'],
                'range' => [
                    'px' => [
                        'min' => 280,
                        'max' => 720,
                    ],
                    'vw' => [
                        'min' => 30,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .thecore-cookie-consent' => '--thecore-cookie-consent-panel-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'overlay_background',
            [
                'label' => __('Overlay Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cookie-consent' => '--thecore-cookie-consent-overlay: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'accent_color',
            [
                'label' => __('Accent Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cookie-consent' => '--thecore-cookie-consent-accent: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'panel_background',
                'selector' => '{{WRAPPER}} .thecore-cookie-consent__container',
            ]
        );

        $this->add_control(
            'panel_text_color',
            [
                'label' => __('Text Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cookie-consent__container' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'panel_border',
                'selector' => '{{WRAPPER}} .thecore-cookie-consent__container',
            ]
        );

        $this->add_responsive_control(
            'panel_border_radius',
            [
                'label' => __('Border Radius', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .thecore-cookie-consent__container' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'panel_shadow',
                'selector' => '{{WRAPPER}} .thecore-cookie-consent__container',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_notice',
            [
                'label' => __('Notice Text', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'notice_text_color',
            [
                'label' => __('Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cookie-consent__text' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'notice_typography',
                'selector' => '{{WRAPPER}} .thecore-cookie-consent__text',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_categories',
            [
                'label' => __('Categories', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'category_label_color',
            [
                'label' => __('Label Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cookie-consent__category label' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'category_label_typography',
                'selector' => '{{WRAPPER}} .thecore-cookie-consent__category label',
            ]
        );

        $this->add_control(
            'category_description_color',
            [
                'label' => __('Description Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cookie-consent__category-description' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'category_description_typography',
                'selector' => '{{WRAPPER}} .thecore-cookie-consent__category-description',
            ]
        );

        $this->add_control(
            'category_background',
            [
                'label' => __('Card Background', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cookie-consent' => '--thecore-cookie-consent-category-background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'category_border_color',
            [
                'label' => __('Card Border', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cookie-consent' => '--thecore-cookie-consent-category-border: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_buttons',
            [
                'label' => __('Buttons', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'selector' => '{{WRAPPER}} .thecore-cookie-consent__button',
            ]
        );

        $this->add_control(
            'button_background_color',
            [
                'label' => __('Background', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cookie-consent' => '--thecore-cookie-consent-button-background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_text_color',
            [
                'label' => __('Text Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cookie-consent' => '--thecore-cookie-consent-button-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_border_color',
            [
                'label' => __('Border Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cookie-consent' => '--thecore-cookie-consent-button-border: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_border_radius',
            [
                'label' => __('Border Radius', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .thecore-cookie-consent__button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'primary_button_heading',
            [
                'label' => __('Primary Button', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'primary_button_background_color',
            [
                'label' => __('Background', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cookie-consent' => '--thecore-cookie-consent-primary-background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'primary_button_text_color',
            [
                'label' => __('Text Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cookie-consent' => '--thecore-cookie-consent-primary-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'primary_button_border_color',
            [
                'label' => __('Border Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cookie-consent' => '--thecore-cookie-consent-primary-border: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render(): void
    {
        $settings = $this->get_settings_for_display();
        $displaySettings = $this->shouldForceModuleVisible()
            ? (new DisplaySettings())->normalize($settings)
            : (new ConfigRepository())->active();

        echo CookieConsentModule::renderModule(
            [
                'id' => 'thecore-cookie-consent-' . $this->get_id(),
                'notice_text' => $displaySettings['notice_text'],
                'theme_preset' => $displaySettings['theme_preset'],
                'show_category_descriptions' => $displaySettings['show_category_descriptions'],
                'reload_on_set' => $displaySettings['reload_on_set'],
                'cookie_expiration_days' => $displaySettings['cookie_expiration_days'],
                'privacy_policy_url' => $displaySettings['privacy_policy_url'],
                'privacy_policy_external' => $displaySettings['privacy_policy_external'],
                'revoke_consent_button_label' => $displaySettings['revoke_consent_button_label'],
                'block_embeds' => $displaySettings['block_embeds'],
                'log_consents' => $displaySettings['log_consents'],
                'anonymize_consent_log_ips' => $displaySettings['anonymize_consent_log_ips'],
                'auto_purge_consents' => $displaySettings['auto_purge_consents'],
                'auto_purge_consents_interval' => $displaySettings['auto_purge_consents_interval'],
                'revoke_delete_all' => $displaySettings['revoke_delete_all'],
                'buttons' => $displaySettings['buttons'],
                'categories' => $displaySettings['categories'],
                'editor_preview' => $this->shouldForceModuleVisible(),
            ]
        );
    }

    private function shouldForceModuleVisible(): bool
    {
        if (! class_exists(\Elementor\Plugin::class) || ! isset(\Elementor\Plugin::$instance)) {
            return false;
        }

        try {
            $plugin = \Elementor\Plugin::$instance;

            if (
                isset($plugin->editor)
                && is_object($plugin->editor)
                && method_exists($plugin->editor, 'is_edit_mode')
                && $plugin->editor->is_edit_mode()
            ) {
                return true;
            }

            if (
                isset($plugin->preview)
                && is_object($plugin->preview)
                && method_exists($plugin->preview, 'is_preview_mode')
            ) {
                return (bool) $plugin->preview->is_preview_mode();
            }
        } catch (\Throwable $exception) {
            return false;
        }

        return false;
    }
}
