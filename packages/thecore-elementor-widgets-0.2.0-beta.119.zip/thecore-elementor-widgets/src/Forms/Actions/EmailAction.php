<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Actions;

use TheCore\ElementorWidgets\Forms\ConfigurationException;
use TheCore\ElementorWidgets\Forms\FormDefinition;
use TheCore\ElementorWidgets\Forms\SubmissionException;

final class EmailAction implements SubmissionAction
{
    private const MAX_RECIPIENTS = 20;

    public function name(): string
    {
        return 'email';
    }

    public function prepare(FormDefinition $form, array $values): array
    {
        $recipients = $this->recipients($form->settings['recipient'] ?: (string) get_option('admin_email'));
        $body = $form->settings['form-name'] . "\n\n";
        foreach ($form->fields as $id => $field) {
            $value = $values[$id] ?? '';
            if ($field['type'] === 'media') {
                $value = array_map(
                    static fn (array $file): string => $file['name'] . ' — ' . $file['url'],
                    $form->settings['_media-files'][$id]['files'] ?? []
                );
            }
            $body .= $field['label'] . ': ' . (is_array($value) ? implode(', ', $value) : $value) . "\n\n";
        }
        // Preserve the original wp_mail argument type for existing single-recipient forms.
        $prepared = ['recipient' => count($recipients) === 1 ? $recipients[0] : $recipients, 'body' => $body,
            'subject' => trim(str_replace(["\r", "\n"], ' ', $form->settings['subject']))];
        if (($form->settings['reply-to-field'] ?? '') !== '') {
            $id = $form->emailField('reply-to-field');
            $replyTo = $values[$id] ?? '';
            if (! is_string($replyTo) || ($replyTo !== '' && (! is_email($replyTo) || preg_match('/[\r\n]/', $replyTo)))) {
                throw new SubmissionException('validation_failed', 'Veuillez verifier votre adresse email.', 422, [$id => 'Adresse email invalide.']);
            }
            if ($replyTo !== '') {
                $prepared['replyTo'] = $replyTo;
            }
        }
        return $prepared;
    }

    /** Parse saved administrator settings only; submitted fields cannot choose recipients. */
    private function recipients(string $configured): array
    {
        if (preg_match('/[\x00-\x1F\x7F]/', $configured)) {
            throw new ConfigurationException('Invalid recipient.');
        }
        $addresses = preg_split('/[,;]/', $configured);
        if ($addresses === false || count($addresses) > self::MAX_RECIPIENTS) {
            throw new ConfigurationException('Invalid recipient.');
        }
        $recipients = [];
        foreach ($addresses as $address) {
            $address = trim($address);
            if (! is_email($address)) {
                throw new ConfigurationException('Invalid recipient.');
            }
            $key = strtolower($address);
            if (! isset($recipients[$key])) {
                $recipients[$key] = $address;
            }
        }

        return array_values($recipients);
    }

    public function execute(array $prepared): void
    {
        $headers = ['Content-Type: text/plain; charset=UTF-8'];
        if (isset($prepared['replyTo'])) {
            $headers[] = 'Reply-To: ' . $prepared['replyTo'];
        }
        if (! wp_mail($prepared['recipient'], $prepared['subject'], $prepared['body'], $headers)) {
            throw new SubmissionException('mail_failed', 'Le message n\'a pas pu etre envoye. Veuillez reessayer plus tard.', 503);
        }
    }
}
