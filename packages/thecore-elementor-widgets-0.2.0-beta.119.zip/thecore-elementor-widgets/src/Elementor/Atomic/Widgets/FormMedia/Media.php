<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\FormMedia;

use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Number_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Select_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Size_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Switch_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Text_Control;
use Elementor\Modules\AtomicWidgets\DynamicTags\Dynamic_Prop_Type;
use Elementor\Modules\AtomicWidgets\Elements\Base\Atomic_Widget_Base;
use Elementor\Modules\AtomicWidgets\Elements\Base\Has_Template;
use Elementor\Modules\AtomicWidgets\PropTypes\Classes_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Color_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Boolean_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Number_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Size_Prop_Type;
use Elementor\Modules\AtomicWidgets\Styles\Style_Definition;
use Elementor\Modules\AtomicWidgets\Styles\Style_Variant;
use Elementor\Modules\Components\PropTypes\Overridable_Prop_Type;
use TheCore\ElementorWidgets\Assets\FormMediaAssets;
use TheCore\ElementorWidgets\Elementor\Atomic\Controls\Types\ColorControl;

/** Optional child of a The Core V4 form. No media endpoint is usable without a saved field. */
final class Media extends Atomic_Widget_Base
{
    use Has_Template {
        get_templates_contents as private nativeTemplates;
    }

    public static $widget_description = 'Private photos/videos field with optional QR phone transfer for The Core V4 forms.';

    public static function get_element_type(): string
    {
        return 'thecore-form-media';
    }

    public function get_title(): string
    {
        return esc_html__('Photos et vidéos (formulaire V4)', 'thecore-elementor-widgets');
    }

    public function get_icon(): string
    {
        return 'eicon-upload';
    }

    public function get_keywords(): array
    {
        return ['form', 'photo', 'video', 'upload', 'qr', 'téléphone', 'thecore', 'atomic'];
    }

    public function get_script_depends(): array
    {
        return [FormMediaAssets::HANDLE];
    }

    public function get_style_depends(): array
    {
        return [FormMediaAssets::HANDLE];
    }

    protected static function define_props_schema(): array
    {
        $props = ['classes' => Classes_Prop_Type::make()->default([])];
        foreach (['label' => '', 'media-mode' => 'both'] as $key => $default) {
            $props[$key] = String_Prop_Type::make()->default($default)
                ->meta(Dynamic_Prop_Type::ignore())->meta(Overridable_Prop_Type::ignore());
        }
        $props['media-mode']->enum(['photos', 'videos', 'both']);
        foreach (['max-files' => 5, 'max-file-size-mb' => 25, 'retention-days' => 30] as $key => $default) {
            $props[$key] = Number_Prop_Type::make()->default($default)
                ->meta(Dynamic_Prop_Type::ignore())->meta(Overridable_Prop_Type::ignore());
        }
        foreach (['required' => false, 'mobile-transfer' => true] as $key => $default) {
            $props[$key] = Boolean_Prop_Type::make()->default($default)
                ->meta(Dynamic_Prop_Type::ignore())->meta(Overridable_Prop_Type::ignore());
        }
        $props['appearance'] = String_Prop_Type::make()->enum(['default', 'soft'])->default('default')
            ->meta(Dynamic_Prop_Type::ignore())->meta(Overridable_Prop_Type::ignore());
        foreach (Appearance::definitions() as $key => $definition) {
            $props[$key] = match ($definition['type']) {
                'size' => Size_Prop_Type::make()->units(['px', 'em', 'rem'])->default_unit('px')->default($definition['default']),
                'enum' => String_Prop_Type::make()->enum($definition['options'])->default($definition['default']),
                default => Color_Prop_Type::make()->default($definition['default']),
            };
            $props[$key]->meta(Dynamic_Prop_Type::ignore())->meta(Overridable_Prop_Type::ignore());
        }
        return $props;
    }

    protected function define_atomic_controls(): array
    {
        $appearanceControls = [Select_Control::bind_to('appearance')->set_label(__('Présentation', 'thecore-elementor-widgets'))->set_options([
            ['label' => __('Standard', 'thecore-elementor-widgets'), 'value' => 'default'],
            ['label' => __('Douce', 'thecore-elementor-widgets'), 'value' => 'soft'],
        ])];
        foreach (Appearance::definitions() as $key => $definition) {
            $control = match ($definition['type']) {
                'size' => Size_Control::bind_to($key)->set_units(['px', 'em', 'rem'])->set_default_unit('px')->set_disable_custom(true),
                'enum' => Select_Control::bind_to($key)->set_options(array_map(
                    static fn (string $value): array => ['label' => $value, 'value' => $value],
                    $definition['options']
                )),
                default => ColorControl::bind_to($key),
            };
            $appearanceControls[] = $control->set_label(__($definition['label'], 'thecore-elementor-widgets'));
        }
        return [
            Section::make()->set_label(__('Fichiers', 'thecore-elementor-widgets'))->set_items([
                Text_Control::bind_to('label')->set_label(__('Libellé du champ', 'thecore-elementor-widgets'))
                    ->set_description(__('Laisser vide pour un libellé adapté aux médias autorisés.', 'thecore-elementor-widgets')),
                Select_Control::bind_to('media-mode')->set_label(__('Médias autorisés', 'thecore-elementor-widgets'))->set_options([
                    ['label' => __('Photos uniquement', 'thecore-elementor-widgets'), 'value' => 'photos'],
                    ['label' => __('Vidéos uniquement', 'thecore-elementor-widgets'), 'value' => 'videos'],
                    ['label' => __('Photos et vidéos', 'thecore-elementor-widgets'), 'value' => 'both'],
                ]),
                Switch_Control::bind_to('required')->set_label(__('Au moins un fichier obligatoire', 'thecore-elementor-widgets')),
                self::integerControl('max-files', 'Nombre maximum de fichiers', 1, 10),
                self::integerControl('max-file-size-mb', 'Taille maximum par fichier (Mio)', 1, 150),
            ]),
            Section::make()->set_label(__('Téléphone et conservation', 'thecore-elementor-widgets'))->set_items([
                Switch_Control::bind_to('mobile-transfer')->set_label(__('Autoriser le transfert par QR code', 'thecore-elementor-widgets'))
                    ->set_description(__('Sur ordinateur : connecter un téléphone après vérification d’un code. Sur mobile : capture ou galerie directement.', 'thecore-elementor-widgets')),
                self::integerControl('retention-days', 'Conservation des fichiers reçus (jours)', 1, 365)
                    ->set_description(__('Fichiers privés uniquement. Les envois abandonnés expirent après 24 h. Définir une durée adaptée et l’indiquer dans la confidentialité du site.', 'thecore-elementor-widgets')),
            ]),
            Section::make()->set_label(__('Apparence des éléments internes', 'thecore-elementor-widgets'))
                ->set_description(__('Ces réglages s’appliquent uniquement à la présentation Douce. Le cadre et sa disposition restent réglables dans les styles natifs.', 'thecore-elementor-widgets'))
                ->set_items($appearanceControls),
            Section::make()->set_label(__('Réglages', 'thecore-elementor-widgets'))->set_id('settings')->set_items([
                Text_Control::bind_to('_cssid')->set_label(__('ID du champ', 'thecore-elementor-widgets'))
                    ->set_meta($this->get_css_id_control_meta())
                    ->set_description(__('Identifiant unique obligatoire dans le Formulaire The Core V4. Ce champ ne s’utilise pas dans un formulaire Elementor classique.', 'thecore-elementor-widgets')),
            ]),
        ];
    }

    protected function define_base_styles(): array
    {
        return ['base' => Style_Definition::make()->add_variant(Style_Variant::make()
            ->add_prop('display', String_Prop_Type::generate('flex'))
            ->add_prop('flex-direction', String_Prop_Type::generate('column'))
            ->add_prop('row-gap', Size_Prop_Type::generate(['size' => 8, 'unit' => 'px'])))];
    }

    protected function get_templates(): array
    {
        return ['thecore/elements/form-media' => __DIR__ . '/media.html.twig'];
    }

    protected function get_templates_contents()
    {
        $templates = $this->nativeTemplates();
        $key = 'thecore/elements/form-media';
        $templates[$key] = (new Appearance())->template($templates[$key]);
        return $templates;
    }

    protected function render()
    {
        $settings = $this->get_atomic_settings();
        $base = $this->get_base_styles_dictionary();
        $classes = array_merge(['tc-form-media', $base['base'] ?? ''], (array) ($settings['classes'] ?? []));
        $attributes = ['class' => implode(' ', array_unique(array_filter($classes, 'is_string'))), 'data-id' => $this->get_id()];
        if (\Elementor\Plugin::$instance->editor->is_edit_mode() || \Elementor\Plugin::$instance->preview->is_preview_mode()) {
            $attributes['data-thecore-editor-preview'] = '1';
        }
        echo (new MarkupBuilder())->build($settings, $this->get_id(), $attributes); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- MarkupBuilder escapes attributes and text.
    }

    private static function integerControl(string $key, string $label, int $min, int $max): Number_Control
    {
        $control = Number_Control::bind_to($key)->set_label(__($label, 'thecore-elementor-widgets'))
            ->set_min($min)->set_max($max)->set_step(1);
        if (method_exists($control, 'set_should_force_int')) {
            $control->set_should_force_int(true);
        }
        return $control;
    }
}
