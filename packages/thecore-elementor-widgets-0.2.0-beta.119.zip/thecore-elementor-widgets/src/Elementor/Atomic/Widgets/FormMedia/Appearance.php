<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\FormMedia;

/** Opt-in inner-part styles. The widget root remains styled by native Atomic classes. */
final class Appearance
{
    private const COLOR_PATTERN = '/^(?:#[a-f0-9]{3}|#[a-f0-9]{4}|#[a-f0-9]{6}|#[a-f0-9]{8}|(?:rgb|rgba|hsl|hsla)\([0-9.,%\s\/-]+\)|var\(--[a-z0-9_-]+\)|transparent|currentcolor|inherit)$/i';
    private const NUMBER_PATTERN = '/^[0-9]{1,4}(?:\.[0-9]{1,4})?$/';

    public static function definitions(): array
    {
        return [
            'label-size' => ['type' => 'size', 'label' => 'Taille du libellé', 'default' => ['size' => 14, 'unit' => 'px'], 'bounds' => ['px' => [10, 32], 'em' => [.625, 2], 'rem' => [.625, 2]]],
            'label-weight' => ['type' => 'enum', 'label' => 'Graisse du libellé', 'default' => '600', 'options' => ['400', '500', '600', '700', '800', '900']],
            'label-color' => ['type' => 'color', 'label' => 'Couleur du libellé', 'default' => '#243047'],
            'accent-color' => ['type' => 'color', 'label' => 'Couleur des boutons', 'default' => '#334155'],
            'button-background' => ['type' => 'color', 'label' => 'Fond des boutons', 'default' => '#f4f6f9'],
            'button-border-color' => ['type' => 'color', 'label' => 'Bordure des boutons', 'default' => '#d6dde7'],
            'helper-color' => ['type' => 'color', 'label' => 'Couleur des indications', 'default' => '#64748b'],
            'button-radius' => ['type' => 'size', 'label' => 'Arrondi des boutons', 'default' => ['size' => 9, 'unit' => 'px'], 'bounds' => ['px' => [0, 32], 'em' => [0, 2], 'rem' => [0, 2]]],
            'button-font-size' => ['type' => 'size', 'label' => 'Taille du texte des boutons', 'default' => ['size' => 14, 'unit' => 'px'], 'bounds' => ['px' => [10, 32], 'em' => [.625, 2], 'rem' => [.625, 2]]],
        ];
    }

    public function attributes(array $settings): array
    {
        if (($settings['appearance'] ?? 'default') !== 'soft') {
            return [];
        }
        $declarations = [];
        foreach (self::definitions() as $key => $definition) {
            $value = $this->value($settings[$key] ?? null, $definition);
            $declarations[] = '--tc-media-' . $key . ':' . $value;
        }
        return ['data-media-appearance' => 'soft', 'style' => implode(';', $declarations) . ';'];
    }

    /** Generate the editor fragment from the same allowlists and bounds as PHP. */
    public function template(string $template): string
    {
        $twig = '{% set media_soft = settings.appearance is same as("soft") %}{% set media_appearance_style = "" %}';
        $twig .= '{% if media_soft %}';
        foreach (self::definitions() as $key => $definition) {
            $setting = 'settings["' . $key . '"]';
            $fallback = $this->value(null, $definition);
            $twig .= '{% set media_style_value = ' . json_encode($fallback) . ' %}';
            if ($definition['type'] === 'size') {
                $size = $setting . '.size';
                $unit = $setting . '.unit';
                $conditions = [];
                foreach ($definition['bounds'] as $name => [$min, $max]) {
                    $conditions[] = '(' . $unit . ' == "' . $name . '" and ' . $size . ' >= ' . $min . ' and ' . $size . ' <= ' . $max . ')';
                }
                // Twing represents resolved size objects as JS records, not iterable maps.
                $condition = $size . ' is defined and ' . $size . ' is not iterable'
                    . ' and ' . $size . ' is not same as(true) and ' . $size . ' is not same as(false)'
                    . ' and (' . $size . ' ~ "") matches ' . json_encode(self::NUMBER_PATTERN)
                    . ' and (' . implode(' or ', $conditions) . ')';
                $output = '(' . $size . ' * 1) ~ ' . $unit;
            } elseif ($definition['type'] === 'enum') {
                $condition = $setting . ' is defined and ' . $setting . ' is not iterable'
                    . ' and (' . $setting . ' | trim) in ' . json_encode($definition['options']);
                $output = $setting . ' | trim';
            } else {
                $condition = $setting . ' is defined and ' . $setting . ' is not iterable'
                    . ' and (' . $setting . ' | trim) matches ' . json_encode(self::COLOR_PATTERN);
                $output = $setting . ' | trim';
            }
            $twig .= '{% if ' . $condition . ' %}{% set media_style_value = ' . $output . ' %}{% endif %}';
            $twig .= '{% set media_appearance_style = media_appearance_style ~ "--tc-media-' . $key . ':" ~ media_style_value ~ ";" %}';
        }
        $twig .= '{% endif %}';
        return str_replace('{# THECORE_MEDIA_APPEARANCE #}', $twig, $template);
    }

    private function value(mixed $value, array $definition): string
    {
        if ($definition['type'] === 'size') {
            $bounds = is_array($value) && is_string($value['unit'] ?? null)
                ? ($definition['bounds'][$value['unit']] ?? null) : null;
            if (
                $bounds !== null && (is_int($value['size'] ?? null) || is_float($value['size'] ?? null) || is_string($value['size'] ?? null))
                && preg_match(self::NUMBER_PATTERN, (string) $value['size'])
                && (float) $value['size'] >= $bounds[0] && (float) $value['size'] <= $bounds[1]
            ) {
                return rtrim(rtrim(sprintf('%.4F', (float) $value['size']), '0'), '.') . $value['unit'];
            }
            return (string) $definition['default']['size'] . $definition['default']['unit'];
        }
        if (! is_string($value)) {
            return $definition['default'];
        }
        $value = trim($value);
        $valid = $definition['type'] === 'enum'
            ? in_array($value, $definition['options'], true)
            : preg_match(self::COLOR_PATTERN, $value) === 1;
        return $valid ? $value : $definition['default'];
    }
}
