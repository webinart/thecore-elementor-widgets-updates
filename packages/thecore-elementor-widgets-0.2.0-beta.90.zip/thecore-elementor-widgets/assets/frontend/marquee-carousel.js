(() => {
    const ROOT_SELECTOR = '[data-thecore-marquee-carousel="true"]';
    const TRACK_SELECTOR = '[data-thecore-marquee-track="true"]';
    const TOGGLE_SELECTOR = '[data-thecore-marquee-toggle="true"]';
    const ITEM_SELECTOR = '[data-thecore-marquee-item-index]';
    const RUNTIME_CLONE_ATTRIBUTE = 'data-thecore-marquee-runtime-clone';
    const initializedRoots = new Set();
    const resizeObservers = new WeakMap();
    const refreshFrames = new WeakMap();

    const nextFrame = (callback) => {
        window.requestAnimationFrame(() => window.requestAnimationFrame(callback));
    };

    const loadTrackImages = (track) => {
        track.querySelectorAll('img[data-thecore-marquee-src]').forEach((image) => {
            const source = image.getAttribute('data-thecore-marquee-src');
            const srcset = image.getAttribute('data-thecore-marquee-srcset');
            const sizes = image.getAttribute('data-thecore-marquee-sizes');

            if (!source) {
                return;
            }

            // Every logo contributes to the loop width, including those outside the mobile viewport.
            image.setAttribute('loading', 'eager');

            if (srcset) {
                image.setAttribute('srcset', srcset);
            }

            if (sizes) {
                image.setAttribute('sizes', sizes);
            }

            image.setAttribute('src', source);
            image.removeAttribute('data-thecore-marquee-src');
            image.removeAttribute('data-thecore-marquee-srcset');
            image.removeAttribute('data-thecore-marquee-sizes');
            image.classList.remove('is-lazy');
        });
    };

    const waitForTrackImages = (track, callback) => {
        const pendingImages = Array.from(track.querySelectorAll('img')).filter(
            (image) => !image.complete
        );

        if (pendingImages.length === 0) {
            nextFrame(callback);
            return;
        }

        let pending = pendingImages.length;

        const finish = () => {
            pending -= 1;

            if (pending === 0) {
                nextFrame(callback);
            }
        };

        pendingImages.forEach((image) => {
            let imageSettled = false;
            const settleImage = () => {
                if (imageSettled) {
                    return;
                }

                imageSettled = true;
                finish();
            };

            image.addEventListener('load', settleImage, { once: true });
            image.addEventListener('error', settleImage, { once: true });

            // The request can settle between the initial check and listener registration.
            if (image.complete) {
                settleImage();
            }
        });
    };

    const getSequenceItems = (track) => {
        const items = Array.from(track.children).filter(
            (item) =>
                item instanceof HTMLElement &&
                item.matches(ITEM_SELECTOR) &&
                item.getAttribute(RUNTIME_CLONE_ATTRIBUTE) !== '1'
        );

        if (items.length === 0) {
            return [];
        }

        const firstIndex = items[0].dataset.thecoreMarqueeItemIndex;
        const repeatedStart = items.findIndex(
            (item, index) =>
                index > 0 && item.dataset.thecoreMarqueeItemIndex === firstIndex
        );

        return repeatedStart > 0 ? items.slice(0, repeatedStart) : items;
    };

    const getSequenceDistance = (track, sequenceItems) => {
        const firstItem = sequenceItems[0];

        if (!(firstItem instanceof HTMLElement)) {
            return 0;
        }

        const firstIndex = firstItem.dataset.thecoreMarqueeItemIndex;
        const secondSequenceStart = Array.from(track.children).find(
            (item) =>
                item instanceof HTMLElement &&
                item !== firstItem &&
                item.getAttribute(RUNTIME_CLONE_ATTRIBUTE) !== '1' &&
                item.dataset.thecoreMarqueeItemIndex === firstIndex
        );

        if (!(secondSequenceStart instanceof HTMLElement)) {
            return 0;
        }

        return Math.max(secondSequenceStart.offsetLeft - firstItem.offsetLeft, 0);
    };

    const appendSequenceClone = (track, sequenceItems) => {
        sequenceItems.forEach((item) => {
            const clone = item.cloneNode(true);

            if (!(clone instanceof HTMLElement)) {
                return;
            }

            clone.setAttribute(RUNTIME_CLONE_ATTRIBUTE, '1');
            clone.setAttribute('aria-hidden', 'true');
            clone.querySelectorAll('img').forEach((image) => image.setAttribute('alt', ''));
            clone
                .querySelectorAll('a, button, input, select, textarea, [tabindex]')
                .forEach((element) => element.setAttribute('tabindex', '-1'));
            track.appendChild(clone);
        });
    };

    const ensureTrackCoverage = (root, track, sequenceItems, sequenceDistance) => {
        if (!(root instanceof HTMLElement) || sequenceDistance <= 0) {
            return;
        }

        const requiredWidth = root.clientWidth + sequenceDistance;
        let appendedSequences = 0;

        while (track.scrollWidth < requiredWidth && appendedSequences < 20) {
            appendSequenceClone(track, sequenceItems);
            appendedSequences += 1;
        }
    };

    const refreshTrack = (track) => {
        if (!(track instanceof HTMLElement) || !track.isConnected) {
            return;
        }

        waitForTrackImages(track, () => {
            const root = track.closest(ROOT_SELECTOR);
            const sequenceItems = getSequenceItems(track);
            const distance = getSequenceDistance(track, sequenceItems);

            if (!distance) {
                track.classList.remove('is-ready');
                return;
            }

            ensureTrackCoverage(root, track, sequenceItems, distance);
            track.style.setProperty('--thecore-marquee-distance', `${distance}px`);
            track.classList.add('is-ready');
        });
    };

    const scheduleRefresh = (track) => {
        const previousFrame = refreshFrames.get(track);

        if (previousFrame) {
            window.cancelAnimationFrame(previousFrame);
        }

        refreshFrames.set(
            track,
            window.requestAnimationFrame(() => {
                refreshFrames.delete(track);
                track.classList.remove('is-ready');
                refreshTrack(track);
            })
        );
    };

    const updateToggle = (root, paused) => {
        const toggle = root.querySelector(TOGGLE_SELECTOR);

        if (!(toggle instanceof HTMLButtonElement)) {
            return;
        }

        toggle.setAttribute('aria-pressed', paused ? 'true' : 'false');
        toggle.setAttribute(
            'aria-label',
            paused
                ? toggle.dataset.playLabel || 'Relancer le carrousel de logos'
                : toggle.dataset.pauseLabel || 'Mettre le carrousel de logos en pause'
        );
    };

    const setupToggle = (root) => {
        const toggle = root.querySelector(TOGGLE_SELECTOR);

        if (!(toggle instanceof HTMLButtonElement)) {
            return;
        }

        toggle.addEventListener('click', () => {
            const paused = !root.classList.contains('is-paused');
            root.classList.toggle('is-paused', paused);
            updateToggle(root, paused);
        });
    };

    const setupVisibilityObserver = (root) => {
        if (!('IntersectionObserver' in window)) {
            return;
        }

        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    if (entry.target !== root) {
                        return;
                    }

                    root.dataset.thecoreMarqueeVisible = entry.isIntersecting ? '1' : '0';
                    root.classList.toggle('is-auto-paused', !entry.isIntersecting || document.hidden);
                });
            },
            { rootMargin: '200px' }
        );

        observer.observe(root);
    };

    const primeTrack = (track) => {
        loadTrackImages(track);
        scheduleRefresh(track);
    };

    const setupLazyLoading = (track) => {
        if (track.dataset.lazy !== '1') {
            scheduleRefresh(track);
            return;
        }

        if (track.dataset.lazyMethod === 'delay') {
            const parsedDelay = Number.parseInt(track.dataset.lazyDelay || '1000', 10);
            window.setTimeout(() => primeTrack(track), Number.isNaN(parsedDelay) ? 1000 : parsedDelay);
            return;
        }

        if (!('IntersectionObserver' in window)) {
            primeTrack(track);
            return;
        }

        const observer = new IntersectionObserver(
            (entries, instance) => {
                entries.forEach((entry) => {
                    if (!entry.isIntersecting) {
                        return;
                    }

                    primeTrack(track);
                    instance.unobserve(entry.target);
                });
            },
            { rootMargin: '200px' }
        );

        observer.observe(track);
    };

    const initRoot = (root) => {
        if (!(root instanceof HTMLElement) || root.dataset.thecoreMarqueeInitialized === '1') {
            return;
        }

        const track = root.querySelector(TRACK_SELECTOR);

        if (!(track instanceof HTMLElement)) {
            return;
        }

        root.dataset.thecoreMarqueeInitialized = '1';
        initializedRoots.add(root);
        setupToggle(root);
        setupVisibilityObserver(root);
        setupLazyLoading(track);

        if ('ResizeObserver' in window) {
            const observer = new ResizeObserver(() => {
                if (!track.querySelector('img[data-thecore-marquee-src]')) {
                    scheduleRefresh(track);
                }
            });
            observer.observe(root);
            resizeObservers.set(root, observer);
        }
    };

    const initWithin = (context = document) => {
        if (context instanceof HTMLElement && context.matches(ROOT_SELECTOR)) {
            initRoot(context);
        }

        if (!context || typeof context.querySelectorAll !== 'function') {
            return;
        }

        context.querySelectorAll(ROOT_SELECTOR).forEach(initRoot);
    };

    const refreshInitialized = () => {
        initializedRoots.forEach((root) => {
            if (!root.isConnected) {
                const observer = resizeObservers.get(root);
                observer?.disconnect();
                initializedRoots.delete(root);
                return;
            }

            const track = root.querySelector(TRACK_SELECTOR);

            if (track instanceof HTMLElement && !track.querySelector('img[data-thecore-marquee-src]')) {
                scheduleRefresh(track);
            }

            root.classList.toggle(
                'is-auto-paused',
                document.hidden || root.dataset.thecoreMarqueeVisible === '0'
            );
        });
    };

    const boot = () => {
        initWithin(document);

        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                mutation.addedNodes.forEach((node) => {
                    if (node instanceof HTMLElement) {
                        initWithin(node);
                    }
                });
            });
        });

        observer.observe(document.body, { childList: true, subtree: true });
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot, { once: true });
    } else {
        boot();
    }

    window.addEventListener('load', refreshInitialized);
    window.addEventListener('resize', refreshInitialized);
    window.addEventListener('orientationchange', refreshInitialized);
    document.addEventListener('visibilitychange', refreshInitialized);
})();
