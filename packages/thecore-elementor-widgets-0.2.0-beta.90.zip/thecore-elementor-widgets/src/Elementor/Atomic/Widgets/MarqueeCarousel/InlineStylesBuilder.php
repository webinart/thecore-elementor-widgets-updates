<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\MarqueeCarousel;

final class InlineStylesBuilder
{
    /**
     * @param array{
     *     items: array<int, array{item_scale: float, item_padding_left: int, item_padding_right: int}>,
     *     marquee_speed: int,
     *     image_height: int,
     *     image_opacity: int,
     *     image_gap: int,
     *     background_color: string
     * } $settings
     */
    public function build(string $scopeSelector, array $settings): string
    {
        $rules = [];
        $rules[] = $scopeSelector . '{' . implode(';', [
            '--thecore-marquee-background-color:' . (string) $settings['background_color'],
            '--thecore-marquee-speed:' . (int) $settings['marquee_speed'] . 's',
            '--thecore-marquee-image-gap:' . (int) $settings['image_gap'] . 'px',
            '--thecore-marquee-image-opacity:' . $this->formatNumber(((int) $settings['image_opacity']) / 100),
            '--thecore-marquee-base-height:' . (int) $settings['image_height'] . 'px',
        ]) . ';}';
        $rules[] = $scopeSelector . ' .thecore-marquee-carousel__image,'
            . $scopeSelector . ' .thecore-marquee-carousel__placeholder{'
            . 'height:var(--thecore-marquee-item-height,var(--thecore-marquee-base-height,80px));'
            . 'width:auto;max-height:100%;object-fit:contain;}';

        foreach ($settings['items'] as $index => $item) {
            $rules[] = sprintf(
                '%1$s [data-thecore-marquee-item-index="%2$d"]{%3$s;}',
                $scopeSelector,
                $index,
                implode(';', [
                    '--thecore-marquee-item-height:' . $this->formatNumber(
                        (float) $settings['image_height'] * (float) $item['item_scale']
                    ) . 'px',
                    '--thecore-marquee-item-padding-left:' . (int) $item['item_padding_left'] . 'px',
                    '--thecore-marquee-item-padding-right:' . (int) $item['item_padding_right'] . 'px',
                ])
            );
        }

        return implode('', $rules);
    }

    private function formatNumber(float $value): string
    {
        if ((float) (int) $value === $value) {
            return (string) (int) $value;
        }

        return rtrim(rtrim(sprintf('%.4F', $value), '0'), '.');
    }
}
