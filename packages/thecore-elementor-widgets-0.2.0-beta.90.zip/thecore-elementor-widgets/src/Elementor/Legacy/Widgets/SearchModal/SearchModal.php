<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Legacy\Widgets\SearchModal;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Widget_Base;
use TheCore\ElementorWidgets\Assets\FrontendAssets;

final class SearchModal extends Widget_Base
{
    public function get_name(): string
    {
        return 'thecore-search-modal-legacy';
    }

    public function get_title(): string
    {
        return __('Search Modal (Legacy)', 'thecore-elementor-widgets');
    }

    public function get_icon(): string
    {
        return 'eicon-search';
    }

    public function get_categories(): array
    {
        return ['basic'];
    }

    public function get_keywords(): array
    {
        return ['search', 'modal', 'header', 'legacy', 'the core'];
    }

    public function get_style_depends(): array
    {
        return [FrontendAssets::SEARCH_MODAL_LEGACY_STYLE];
    }

    public function get_script_depends(): array
    {
        return [FrontendAssets::SEARCH_MODAL_LEGACY_SCRIPT];
    }

    protected function register_controls(): void
    {
        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Content', 'thecore-elementor-widgets'),
            ]
        );

        $this->add_control(
            'trigger_label',
            [
                'label' => __('Button label', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Rechercher', 'thecore-elementor-widgets'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'placeholder',
            [
                'label' => __('Placeholder', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Rechercher une demarche, un service, un evenement...', 'thecore-elementor-widgets'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'dialog_title',
            [
                'label' => __('Accessible title', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Rechercher sur le site', 'thecore-elementor-widgets'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'results_limit',
            [
                'label' => __('Results count', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::NUMBER,
                'default' => DisplaySettings::DEFAULT_RESULTS_LIMIT,
                'min' => 1,
                'max' => 12,
            ]
        );

        $this->add_control(
            'search_post_types',
            [
                'label' => __('Content types', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'label_block' => true,
                'options' => $this->getSearchablePostTypes(),
                'default' => ['post', 'page'],
            ]
        );

        $this->add_control(
            'enable_shortcut',
            [
                'label' => __('Enable Ctrl/Cmd + K', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'thecore-elementor-widgets'),
                'label_off' => __('No', 'thecore-elementor-widgets'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_shortcut_hint',
            [
                'label' => __('Show shortcut hint', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'thecore-elementor-widgets'),
                'label_off' => __('No', 'thecore-elementor-widgets'),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'enable_shortcut' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_popular_searches',
            [
                'label' => __('Popular searches', 'thecore-elementor-widgets'),
            ]
        );

        $popularRepeater = new Repeater();
        $popularRepeater->add_control(
            'term',
            [
                'label' => __('Term', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'popular_searches',
            [
                'label' => __('Terms', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $popularRepeater->get_controls(),
                'title_field' => '{{{ term }}}',
                'default' => [
                    ['term' => 'Etat civil'],
                    ['term' => 'Permis de construire'],
                    ['term' => 'Evenements'],
                    ['term' => 'Transports'],
                    ['term' => 'Elus'],
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_quick_links',
            [
                'label' => __('Quick links', 'thecore-elementor-widgets'),
            ]
        );

        $quickLinksRepeater = new Repeater();
        $quickLinksRepeater->add_control(
            'title',
            [
                'label' => __('Title', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );
        $quickLinksRepeater->add_control(
            'url',
            [
                'label' => __('Link', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::URL,
                'label_block' => true,
                'placeholder' => home_url('/'),
            ]
        );

        $this->add_control(
            'quick_links',
            [
                'label' => __('Links', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $quickLinksRepeater->get_controls(),
                'title_field' => '{{{ title }}}',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_trigger',
            [
                'label' => __('Button Style', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'trigger_typography',
                'selector' => '{{WRAPPER}} .thecore-search-modal-legacy__trigger',
            ]
        );

        $this->add_control(
            'trigger_text_color',
            [
                'label' => __('Text color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-search-modal-legacy' => '--thecore-search-modal-legacy-trigger-text: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'trigger_bg_color',
            [
                'label' => __('Button background', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-search-modal-legacy' => '--thecore-search-modal-legacy-trigger-bg: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'trigger_border_color',
            [
                'label' => __('Button border', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-search-modal-legacy' => '--thecore-search-modal-legacy-trigger-border: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'trigger_hover_bg_color',
            [
                'label' => __('Hover background', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-search-modal-legacy' => '--thecore-search-modal-legacy-trigger-hover-bg: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'trigger_full_width',
            [
                'label' => __('Full width', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'thecore-elementor-widgets'),
                'label_off' => __('No', 'thecore-elementor-widgets'),
                'return_value' => 'yes',
                'selectors' => [
                    '{{WRAPPER}} .thecore-search-modal-legacy' => 'width: 100%;',
                    '{{WRAPPER}} .thecore-search-modal-legacy__trigger' => 'width: 100%;',
                ],
            ]
        );

        $this->add_responsive_control(
            'trigger_min_height',
            [
                'label' => __('Minimum height', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 160,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 10,
                        'step' => 0.1,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 10,
                        'step' => 0.1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .thecore-search-modal-legacy__trigger' => 'min-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'trigger_padding',
            [
                'label' => __('Padding', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', 'rem', '%'],
                'selectors' => [
                    '{{WRAPPER}} .thecore-search-modal-legacy__trigger' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'show_trigger_label_mobile',
            [
                'label' => __('Show label on mobile', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'thecore-elementor-widgets'),
                'label_off' => __('No', 'thecore-elementor-widgets'),
                'return_value' => 'yes',
                'selectors' => [
                    '{{WRAPPER}} .thecore-search-modal-legacy__trigger-label' => 'display: inline-flex;',
                ],
            ]
        );

        $this->add_responsive_control(
            'trigger_border_radius',
            [
                'label' => __('Button radius', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 999,
                ],
                'selectors' => [
                    '{{WRAPPER}} .thecore-search-modal-legacy' => '--thecore-search-modal-legacy-trigger-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_dialog',
            [
                'label' => __('Modal Style', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'dialog_typography',
                'selector' => '{{WRAPPER}} .thecore-search-modal-legacy__dialog, {{WRAPPER}} .thecore-search-modal-legacy__input',
            ]
        );

        $this->add_control(
            'dialog_bg_color',
            [
                'label' => __('Modal background', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-search-modal-legacy' => '--thecore-search-modal-legacy-surface: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'dialog_text_color',
            [
                'label' => __('Text color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-search-modal-legacy' => '--thecore-search-modal-legacy-text: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'dialog_muted_color',
            [
                'label' => __('Muted color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-search-modal-legacy' => '--thecore-search-modal-legacy-muted: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'overlay_color',
            [
                'label' => __('Overlay background', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-search-modal-legacy' => '--thecore-search-modal-legacy-overlay: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'result_hover_bg_color',
            [
                'label' => __('Active result background', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-search-modal-legacy' => '--thecore-search-modal-legacy-hover: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render(): void
    {
        $settings = (new DisplaySettings())->normalize($this->get_settings_for_display());
        $widgetId = 'thecore-search-modal-legacy-' . $this->get_id();
        $dialogId = $widgetId . '-dialog';
        $titleId = $widgetId . '-title';
        $resultsId = $widgetId . '-results';

        $this->add_render_attribute(
            'wrapper',
            [
                'class' => 'thecore-search-modal-legacy',
                'id' => $widgetId,
                'data-post-types' => wp_json_encode($settings['search_post_types']),
                'data-results-limit' => max(1, min(12, $settings['results_limit'])),
                'data-shortcut' => $settings['enable_shortcut'] ? 'yes' : 'no',
                'data-search-url' => home_url('/'),
                'data-thecore-search-modal-legacy' => 'true',
            ]
        );
        ?>
        <div <?php echo $this->get_render_attribute_string('wrapper'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
            <button
                class="thecore-search-modal-legacy__trigger"
                type="button"
                aria-expanded="false"
                aria-haspopup="dialog"
                aria-controls="<?php echo esc_attr($dialogId); ?>"
            >
                <span class="thecore-search-modal-legacy__trigger-icon" aria-hidden="true"><?php echo $this->getSvgIcon('search'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
                <span class="thecore-search-modal-legacy__trigger-label"><?php echo esc_html($settings['trigger_label']); ?></span>
                <?php if ($settings['show_shortcut_hint']) : ?>
                    <span class="thecore-search-modal-legacy__trigger-shortcut" aria-hidden="true">
                        <span class="thecore-search-modal-legacy__trigger-shortcut-key">&#8984;</span>K
                    </span>
                <?php endif; ?>
            </button>

            <div class="thecore-search-modal-legacy__modal" id="<?php echo esc_attr($dialogId); ?>" hidden>
                <div class="thecore-search-modal-legacy__backdrop" data-close-search="true"></div>
                <div class="thecore-search-modal-legacy__dialog" role="dialog" aria-modal="true" aria-labelledby="<?php echo esc_attr($titleId); ?>">
                    <h2 class="thecore-search-modal-legacy__dialog-title screen-reader-text" id="<?php echo esc_attr($titleId); ?>">
                        <?php echo esc_html($settings['dialog_title']); ?>
                    </h2>

                    <div class="thecore-search-modal-legacy__input-row">
                        <span class="thecore-search-modal-legacy__input-icon" aria-hidden="true"><?php echo $this->getSvgIcon('search'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
                        <input
                            class="thecore-search-modal-legacy__input"
                            type="search"
                            placeholder="<?php echo esc_attr($settings['placeholder']); ?>"
                            aria-label="<?php echo esc_attr($settings['dialog_title']); ?>"
                            autocomplete="off"
                        />
                        <button class="thecore-search-modal-legacy__clear" type="button" hidden aria-label="<?php echo esc_attr__('Clear search', 'thecore-elementor-widgets'); ?>">
                            <?php echo $this->getSvgIcon('close'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                        </button>
                        <button class="thecore-search-modal-legacy__close" type="button" data-close-search="true" aria-label="<?php echo esc_attr__('Close search', 'thecore-elementor-widgets'); ?>">
                            <?php echo $this->getSvgIcon('close'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                        </button>
                    </div>

                    <div class="thecore-search-modal-legacy__body">
                        <div class="thecore-search-modal-legacy__panel thecore-search-modal-legacy__panel--results" hidden>
                            <ul class="thecore-search-modal-legacy__results" id="<?php echo esc_attr($resultsId); ?>" role="listbox" aria-label="<?php echo esc_attr__('Search results', 'thecore-elementor-widgets'); ?>"></ul>
                        </div>

                        <div class="thecore-search-modal-legacy__panel thecore-search-modal-legacy__panel--empty">
                            <?php if ([] !== $settings['popular_searches']) : ?>
                                <div class="thecore-search-modal-legacy__section">
                                    <p class="thecore-search-modal-legacy__section-title"><?php echo esc_html__('Popular searches', 'thecore-elementor-widgets'); ?></p>
                                    <div class="thecore-search-modal-legacy__chips">
                                        <?php foreach ($settings['popular_searches'] as $term) : ?>
                                            <button class="thecore-search-modal-legacy__chip" type="button" data-search-term="<?php echo esc_attr($term); ?>">
                                                <?php echo esc_html($term); ?>
                                            </button>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <?php if ([] !== $settings['quick_links']) : ?>
                                <div class="thecore-search-modal-legacy__section">
                                    <p class="thecore-search-modal-legacy__section-title"><?php echo esc_html__('Quick links', 'thecore-elementor-widgets'); ?></p>
                                    <div class="thecore-search-modal-legacy__quick-links">
                                        <?php foreach ($settings['quick_links'] as $link) : ?>
                                            <a
                                                class="thecore-search-modal-legacy__quick-link"
                                                href="<?php echo esc_url($link['url']); ?>"
                                                <?php echo $link['target'] ? ' target="_blank" rel="noopener noreferrer"' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                                            >
                                                <span class="thecore-search-modal-legacy__quick-link-icon" aria-hidden="true"><?php echo $this->getSvgIcon('file'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
                                                <span class="thecore-search-modal-legacy__quick-link-title"><?php echo esc_html($link['title']); ?></span>
                                            </a>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <?php if ([] === $settings['popular_searches'] && [] === $settings['quick_links']) : ?>
                                <div class="thecore-search-modal-legacy__empty-help">
                                    <p><?php echo esc_html__('Start typing to search the site.', 'thecore-elementor-widgets'); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="thecore-search-modal-legacy__panel thecore-search-modal-legacy__panel--no-results" hidden>
                            <div class="thecore-search-modal-legacy__no-results-icon" aria-hidden="true"><?php echo $this->getSvgIcon('search-large'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
                            <p class="thecore-search-modal-legacy__no-results-title"><?php echo esc_html__('No results', 'thecore-elementor-widgets'); ?></p>
                            <p class="thecore-search-modal-legacy__no-results-text"></p>
                        </div>
                    </div>

                    <div class="thecore-search-modal-legacy__footer">
                        <div class="thecore-search-modal-legacy__footer-hints">
                            <span class="thecore-search-modal-legacy__hint">
                                <kbd>&uarr;</kbd><kbd>&darr;</kbd>
                                <span><?php echo esc_html__('Navigate', 'thecore-elementor-widgets'); ?></span>
                            </span>
                            <span class="thecore-search-modal-legacy__hint">
                                <kbd><?php echo esc_html__('Enter', 'thecore-elementor-widgets'); ?></kbd>
                                <span><?php echo esc_html__('Select', 'thecore-elementor-widgets'); ?></span>
                            </span>
                        </div>
                        <span class="thecore-search-modal-legacy__hint">
                            <kbd><?php echo esc_html__('Escape', 'thecore-elementor-widgets'); ?></kbd>
                            <span><?php echo esc_html__('Close', 'thecore-elementor-widgets'); ?></span>
                        </span>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * @return array<string, string>
     */
    private function getSearchablePostTypes(): array
    {
        $postTypes = get_post_types(
            [
                'public' => true,
                'exclude_from_search' => false,
            ],
            'objects'
        );

        $options = [];

        foreach ($postTypes as $postType) {
            if (empty($postType->name) || empty($postType->labels->singular_name)) {
                continue;
            }

            $options[$postType->name] = $postType->labels->singular_name;
        }

        return $options;
    }

    private function getSvgIcon(string $icon): string
    {
        switch ($icon) {
            case 'close':
                return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg>';
            case 'file':
                return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7z"></path><path d="M14 2v4a2 2 0 0 0 2 2h4"></path></svg>';
            case 'search-large':
                return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"></circle><path d="m21 21-4.3-4.3"></path></svg>';
            case 'search':
            default:
                return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><path d="m21 21-4.3-4.3"></path></svg>';
        }
    }
}
