<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\AssetDelivery;

final class AssetDeliverySanitizer
{
    /**
     * @param array<string, mixed> $rawSettings
     *
     * @return array{
     *     css: array{
     *         enabled: bool,
     *         trigger: string,
     *         viewport_threshold: int,
     *         fallback_enabled: bool,
     *         fallback_delay: int,
     *         override_widget_settings: bool
     *     },
     *     js: array{
     *         enabled: bool,
     *         trigger: string,
     *         viewport_threshold: int,
     *         fallback_enabled: bool,
     *         fallback_delay: int,
     *         override_widget_settings: bool
     *     }
     * }
     */
    public function normalizeGlobal(array $rawSettings): array
    {
        $defaults = AssetDeliverySettings::globalDefaults();

        return [
            'css' => $this->normalizeGlobalType($rawSettings['css'] ?? [], $defaults['css']),
            'js' => $this->normalizeGlobalType($rawSettings['js'] ?? [], $defaults['js']),
        ];
    }

    /**
     * @param array<string, mixed> $rawSettings
     *
     * @return array{
     *     css: array{
     *         use_global: bool,
     *         trigger: string,
     *         viewport_threshold: int,
     *         fallback_enabled: bool,
     *         fallback_delay: int
     *     },
     *     js: array{
     *         use_global: bool,
     *         trigger: string,
     *         viewport_threshold: int,
     *         fallback_enabled: bool,
     *         fallback_delay: int
     *     }
     * }
     */
    public function normalizeWidget(array $rawSettings): array
    {
        $defaults = AssetDeliverySettings::widgetDefaults();

        return [
            'css' => $this->normalizeWidgetType(
                [
                    'use_global' => $rawSettings['asset_css_use_global'] ?? $defaults['css']['use_global'],
                    'trigger' => $rawSettings['asset_css_trigger'] ?? $defaults['css']['trigger'],
                    'viewport_threshold' => $rawSettings['asset_css_viewport_threshold'] ?? $defaults['css']['viewport_threshold'],
                    'fallback_enabled' => $rawSettings['asset_css_fallback_enabled'] ?? $defaults['css']['fallback_enabled'],
                    'fallback_delay' => $rawSettings['asset_css_fallback_delay'] ?? $defaults['css']['fallback_delay'],
                ],
                $defaults['css']
            ),
            'js' => $this->normalizeWidgetType(
                [
                    'use_global' => $rawSettings['asset_js_use_global'] ?? $defaults['js']['use_global'],
                    'trigger' => $rawSettings['asset_js_trigger'] ?? $defaults['js']['trigger'],
                    'viewport_threshold' => $rawSettings['asset_js_viewport_threshold'] ?? $defaults['js']['viewport_threshold'],
                    'fallback_enabled' => $rawSettings['asset_js_fallback_enabled'] ?? $defaults['js']['fallback_enabled'],
                    'fallback_delay' => $rawSettings['asset_js_fallback_delay'] ?? $defaults['js']['fallback_delay'],
                ],
                $defaults['js']
            ),
        ];
    }

    /**
     * @param mixed $rawSettings
     * @param array{
     *     enabled: bool,
     *     trigger: string,
     *     viewport_threshold: int,
     *     fallback_enabled: bool,
     *     fallback_delay: int,
     *     override_widget_settings: bool
     * } $defaults
     *
     * @return array{
     *     enabled: bool,
     *     trigger: string,
     *     viewport_threshold: int,
     *     fallback_enabled: bool,
     *     fallback_delay: int,
     *     override_widget_settings: bool
     * }
     */
    private function normalizeGlobalType(mixed $rawSettings, array $defaults): array
    {
        $settings = is_array($rawSettings) ? $rawSettings : [];

        return [
            'enabled' => $this->toBool($settings['enabled'] ?? $defaults['enabled']),
            'trigger' => $this->sanitizeTrigger($settings['trigger'] ?? $defaults['trigger']),
            'viewport_threshold' => $this->clampInt(
                $settings['viewport_threshold'] ?? $defaults['viewport_threshold'],
                0,
                100,
                $defaults['viewport_threshold']
            ),
            'fallback_enabled' => $this->toBool($settings['fallback_enabled'] ?? $defaults['fallback_enabled']),
            'fallback_delay' => $this->clampInt(
                $settings['fallback_delay'] ?? $defaults['fallback_delay'],
                100,
                15000,
                $defaults['fallback_delay']
            ),
            'override_widget_settings' => $this->toBool(
                $settings['override_widget_settings'] ?? $defaults['override_widget_settings']
            ),
        ];
    }

    /**
     * @param array<string, mixed> $settings
     * @param array{
     *     use_global: bool,
     *     trigger: string,
     *     viewport_threshold: int,
     *     fallback_enabled: bool,
     *     fallback_delay: int
     * } $defaults
     *
     * @return array{
     *     use_global: bool,
     *     trigger: string,
     *     viewport_threshold: int,
     *     fallback_enabled: bool,
     *     fallback_delay: int
     * }
     */
    private function normalizeWidgetType(array $settings, array $defaults): array
    {
        return [
            'use_global' => $this->toBool($settings['use_global'] ?? $defaults['use_global']),
            'trigger' => $this->sanitizeTrigger($settings['trigger'] ?? $defaults['trigger']),
            'viewport_threshold' => $this->clampInt(
                $settings['viewport_threshold'] ?? $defaults['viewport_threshold'],
                0,
                100,
                $defaults['viewport_threshold']
            ),
            'fallback_enabled' => $this->toBool($settings['fallback_enabled'] ?? $defaults['fallback_enabled']),
            'fallback_delay' => $this->clampInt(
                $settings['fallback_delay'] ?? $defaults['fallback_delay'],
                100,
                15000,
                $defaults['fallback_delay']
            ),
        ];
    }

    private function sanitizeTrigger(mixed $value): string
    {
        if (! is_string($value)) {
            return AssetDeliverySettings::TRIGGER_VIEWPORT;
        }

        return in_array($value, AssetDeliverySettings::triggerValues(), true)
            ? $value
            : AssetDeliverySettings::TRIGGER_VIEWPORT;
    }

    private function clampInt(mixed $value, int $min, int $max, int $default): int
    {
        if (! is_numeric($value)) {
            return $default;
        }

        return max($min, min($max, (int) $value));
    }

    private function toBool(mixed $value): bool
    {
        if (is_bool($value)) {
            return $value;
        }

        if (is_numeric($value)) {
            return 1 === (int) $value;
        }

        if (! is_string($value)) {
            return false;
        }

        return in_array(strtolower(trim($value)), ['1', 'true', 'yes', 'on'], true);
    }
}
