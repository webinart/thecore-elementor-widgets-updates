<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\AssetDelivery;

final class AssetDeliverySettings
{
    public const TRIGGER_VIEWPORT = 'viewport';
    public const TRIGGER_INTERACTION = 'interaction';
    public const DEFAULT_VIEWPORT_THRESHOLD = 15;
    public const DEFAULT_FALLBACK_ENABLED = true;
    public const DEFAULT_FALLBACK_DELAY = 2000;

    /**
     * @return array{
     *     css: array{
     *         enabled: bool,
     *         trigger: string,
     *         viewport_threshold: int,
     *         fallback_enabled: bool,
     *         fallback_delay: int,
     *         override_widget_settings: bool
     *     },
     *     js: array{
     *         enabled: bool,
     *         trigger: string,
     *         viewport_threshold: int,
     *         fallback_enabled: bool,
     *         fallback_delay: int,
     *         override_widget_settings: bool
     *     }
     * }
     */
    public static function globalDefaults(): array
    {
        return [
            'css' => [
                'enabled' => false,
                'trigger' => self::TRIGGER_VIEWPORT,
                'viewport_threshold' => self::DEFAULT_VIEWPORT_THRESHOLD,
                'fallback_enabled' => self::DEFAULT_FALLBACK_ENABLED,
                'fallback_delay' => self::DEFAULT_FALLBACK_DELAY,
                'override_widget_settings' => false,
            ],
            'js' => [
                'enabled' => false,
                'trigger' => self::TRIGGER_VIEWPORT,
                'viewport_threshold' => self::DEFAULT_VIEWPORT_THRESHOLD,
                'fallback_enabled' => self::DEFAULT_FALLBACK_ENABLED,
                'fallback_delay' => self::DEFAULT_FALLBACK_DELAY,
                'override_widget_settings' => false,
            ],
        ];
    }

    /**
     * @return array{
     *     css: array{
     *         use_global: bool,
     *         trigger: string,
     *         viewport_threshold: int,
     *         fallback_enabled: bool,
     *         fallback_delay: int
     *     },
     *     js: array{
     *         use_global: bool,
     *         trigger: string,
     *         viewport_threshold: int,
     *         fallback_enabled: bool,
     *         fallback_delay: int
     *     }
     * }
     */
    public static function widgetDefaults(): array
    {
        return [
            'css' => [
                'use_global' => true,
                'trigger' => self::TRIGGER_VIEWPORT,
                'viewport_threshold' => self::DEFAULT_VIEWPORT_THRESHOLD,
                'fallback_enabled' => self::DEFAULT_FALLBACK_ENABLED,
                'fallback_delay' => self::DEFAULT_FALLBACK_DELAY,
            ],
            'js' => [
                'use_global' => true,
                'trigger' => self::TRIGGER_VIEWPORT,
                'viewport_threshold' => self::DEFAULT_VIEWPORT_THRESHOLD,
                'fallback_enabled' => self::DEFAULT_FALLBACK_ENABLED,
                'fallback_delay' => self::DEFAULT_FALLBACK_DELAY,
            ],
        ];
    }

    /**
     * @return array<int, string>
     */
    public static function triggerValues(): array
    {
        return [
            self::TRIGGER_VIEWPORT,
            self::TRIGGER_INTERACTION,
        ];
    }
}
