<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Options;

use TheCore\ElementorWidgets\AssetDelivery\AssetDeliverySanitizer;

final class OptionsRepository
{
    public const WIDGETS_OPTION = 'thecore_elementor_widgets_widgets_state';
    public const FEATURES_OPTION = 'thecore_elementor_widgets_features_state';
    public const ASSET_DELIVERY_OPTION = 'thecore_elementor_widgets_asset_delivery_settings';

    private ?AssetDeliverySanitizer $assetDeliverySanitizer = null;

    public function __construct(private readonly StateSanitizer $stateSanitizer)
    {
    }

    /**
     * @param array<string, int>                                                                 $widgetDefaults
     * @param array<string, int>                                                                 $featureDefaults
     * @param array{css: array<string, bool|int|string>, js: array<string, bool|int|string>}    $assetDeliveryDefaults
     */
    public function initializeDefaults(array $widgetDefaults, array $featureDefaults, array $assetDeliveryDefaults): void
    {
        if (false === get_option(self::WIDGETS_OPTION, false)) {
            add_option(self::WIDGETS_OPTION, $widgetDefaults);
        }

        if (false === get_option(self::FEATURES_OPTION, false)) {
            add_option(self::FEATURES_OPTION, $featureDefaults);
        }

        if (false === get_option(self::ASSET_DELIVERY_OPTION, false)) {
            add_option(self::ASSET_DELIVERY_OPTION, $assetDeliveryDefaults);
        }
    }

    /**
     * @param array<string, int> $defaults
     *
     * @return array<string, int>
     */
    public function getWidgetsState(array $defaults): array
    {
        $stored = get_option(self::WIDGETS_OPTION, []);

        return $this->stateSanitizer->normalize(is_array($stored) ? $stored : [], $defaults);
    }

    /**
     * @param array<string, mixed> $state
     * @param array<string, int>   $defaults
     */
    public function saveWidgetsState(array $state, array $defaults): void
    {
        update_option(
            self::WIDGETS_OPTION,
            $this->stateSanitizer->normalize($state, $defaults)
        );
    }

    /**
     * @param array<string, int> $defaults
     *
     * @return array<string, int>
     */
    public function getFeaturesState(array $defaults): array
    {
        $stored = get_option(self::FEATURES_OPTION, []);

        return $this->stateSanitizer->normalize(is_array($stored) ? $stored : [], $defaults);
    }

    /**
     * @param array<string, mixed> $state
     * @param array<string, int>   $defaults
     */
    public function saveFeaturesState(array $state, array $defaults): void
    {
        update_option(
            self::FEATURES_OPTION,
            $this->stateSanitizer->normalize($state, $defaults)
        );
    }

    /**
     * @param array{css: array<string, bool|int|string>, js: array<string, bool|int|string>} $defaults
     *
     * @return array{css: array<string, bool|int|string>, js: array<string, bool|int|string>}
     */
    public function getAssetDeliverySettings(array $defaults): array
    {
        $stored = get_option(self::ASSET_DELIVERY_OPTION, []);

        if (! is_array($stored)) {
            return $defaults;
        }

        return $this->assetDeliverySanitizer()->normalizeGlobal($stored);
    }

    /**
     * @param array<string, mixed>                                                              $settings
     * @param array{css: array<string, bool|int|string>, js: array<string, bool|int|string>}   $defaults
     */
    public function saveAssetDeliverySettings(array $settings, array $defaults): void
    {
        update_option(
            self::ASSET_DELIVERY_OPTION,
            $this->assetDeliverySanitizer()->normalizeGlobal($settings)
        );
    }

    private function assetDeliverySanitizer(): AssetDeliverySanitizer
    {
        if (null === $this->assetDeliverySanitizer) {
            $this->assetDeliverySanitizer = new AssetDeliverySanitizer();
        }

        return $this->assetDeliverySanitizer;
    }
}
