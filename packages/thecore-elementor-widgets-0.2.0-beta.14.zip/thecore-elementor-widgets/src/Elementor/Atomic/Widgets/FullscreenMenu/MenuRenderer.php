<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\FullscreenMenu;

final class MenuRenderer
{
    public function render(int $menuId, string $widgetId, bool $overlayOnly = false): string
    {
        if ($menuId <= 0) {
            return $this->renderEmptyState(
                __('Select a WordPress menu to render the Fullscreen Menu widget.', 'thecore-elementor-widgets')
            );
        }

        $menuObject = wp_get_nav_menu_object($menuId);

        if (! $menuObject || ! isset($menuObject->name)) {
            return $this->renderEmptyState(
                __('Select a valid WordPress menu to render the Fullscreen Menu widget.', 'thecore-elementor-widgets')
            );
        }

        $menuItems = $this->getTopLevelItems($menuId);
        $instanceId = 'thecore-fsm-' . sanitize_html_class($widgetId);
        $overlayId = $instanceId . '-overlay';
        $toggleId = $instanceId . '-toggle';
        $desktopListMarkup = $overlayOnly ? '' : $this->renderItems($menuItems);
        $overlayListMarkup = $this->renderItems($menuItems);

        if ('' === $desktopListMarkup) {
            $desktopListMarkup = $this->renderNoItemsFallback();
        }

        if ('' === $overlayListMarkup) {
            $overlayListMarkup = $this->renderNoItemsFallback();
        }

        if ('' === $desktopListMarkup && '' === $overlayListMarkup) {
            return $this->renderEmptyState(
                __('The selected WordPress menu does not contain any top-level items yet.', 'thecore-elementor-widgets')
            );
        }

        $markup = '';
        $markup .= '<button';
        $markup .= ' type="button"';
        $markup .= ' class="thecore-fullscreen-menu__toggle"';
        $markup .= ' id="' . esc_attr($toggleId) . '"';
        $markup .= ' aria-label="' . esc_attr__('Open menu', 'thecore-elementor-widgets') . '"';
        $markup .= ' aria-expanded="false"';
        $markup .= ' aria-controls="' . esc_attr($overlayId) . '"';
        $markup .= '>';
        $markup .= '<span class="thecore-fullscreen-menu__toggle-bar thecore-fullscreen-menu__toggle-bar--top"></span>';
        $markup .= '<span class="thecore-fullscreen-menu__toggle-bar thecore-fullscreen-menu__toggle-bar--middle"></span>';
        $markup .= '<span class="thecore-fullscreen-menu__toggle-bar thecore-fullscreen-menu__toggle-bar--bottom"></span>';
        $markup .= '</button>';
        if (! $overlayOnly) {
            $markup .= '<nav class="thecore-fullscreen-menu__desktop-nav" aria-label="' . esc_attr__('Desktop menu', 'thecore-elementor-widgets') . '">';
            $markup .= '<ul class="thecore-fullscreen-menu__list">';
            $markup .= $desktopListMarkup;
            $markup .= '</ul>';
            $markup .= '</nav>';
        }
        $markup .= '<div class="thecore-fullscreen-menu__overlay" id="' . esc_attr($overlayId) . '" aria-hidden="true" hidden>';
        $markup .= '<nav class="thecore-fullscreen-menu__overlay-nav" aria-label="' . esc_attr__('Fullscreen menu', 'thecore-elementor-widgets') . '">';
        $markup .= '<ul class="thecore-fullscreen-menu__list">';
        $markup .= $overlayListMarkup;
        $markup .= '</ul>';
        $markup .= '</nav>';
        $markup .= '</div>';

        return $markup;
    }

    /**
     * @return array<int, object>
     */
    private function getTopLevelItems(int $menuId): array
    {
        $items = wp_get_nav_menu_items(
            $menuId,
            [
                'update_post_term_cache' => false,
            ]
        );

        if (! is_array($items)) {
            return [];
        }

        usort(
            $items,
            static fn (object $left, object $right): int => (int) $left->menu_order <=> (int) $right->menu_order
        );

        return array_values(
            array_filter(
                $items,
                static fn (object $item): bool => isset($item->menu_item_parent) && 0 === (int) $item->menu_item_parent
            )
        );
    }

    /**
     * @param array<int, object> $menuItems
     */
    private function renderItems(array $menuItems): string
    {
        $markup = '';
        $sequence = 0;

        foreach ($menuItems as $item) {
            if (! isset($item->title)) {
                continue;
            }

            $sequence++;

            $attributes = [
                'class' => 'thecore-fullscreen-menu__anchor',
                'href' => ! empty($item->url) ? (string) $item->url : '#',
            ];

            if (! empty($item->target)) {
                $attributes['target'] = (string) $item->target;
            }

            $rel = ! empty($item->xfn) ? trim((string) $item->xfn) : '';

            if (! empty($attributes['target']) && '_blank' === $attributes['target']) {
                $rel = trim($rel . ' noopener noreferrer');
            }

            if ('' !== $rel) {
                $attributes['rel'] = $rel;
            }

            $markup .= '<li class="thecore-fullscreen-menu__item" style="--thecore-seq:' . esc_attr((string) $sequence) . ';">';
            $markup .= '<a' . $this->buildAttributes($attributes) . '>';
            $markup .= esc_html((string) apply_filters('the_title', $item->title, $item->ID ?? 0));
            $markup .= '</a>';
            $markup .= '</li>';
        }

        return $markup;
    }

    private function renderNoItemsFallback(): string
    {
        if (! current_user_can('edit_theme_options')) {
            return '';
        }

        return sprintf(
            '<li class="thecore-fullscreen-menu__item thecore-fullscreen-menu__item--notice"><a class="%1$s" href="%2$s">%3$s</a></li>',
            esc_attr('thecore-fullscreen-menu__anchor'),
            esc_url(admin_url('nav-menus.php')),
            esc_html__('No menu items found. Click here to create or assign one.', 'thecore-elementor-widgets')
        );
    }

    private function renderEmptyState(string $message): string
    {
        if (! $this->isEditorContext()) {
            return '';
        }

        return sprintf(
            '<div class="thecore-fullscreen-menu__empty">%s</div>',
            esc_html($message)
        );
    }

    /**
     * @param array<string, string> $attributes
     */
    private function buildAttributes(array $attributes): string
    {
        $markup = '';

        foreach ($attributes as $name => $value) {
            $escapedValue = 'href' === $name ? esc_url($value) : esc_attr($value);

            $markup .= sprintf(
                ' %s="%s"',
                esc_attr($name),
                $escapedValue
            );
        }

        return $markup;
    }

    private function isEditorContext(): bool
    {
        if (! class_exists('\Elementor\Plugin')) {
            return false;
        }

        return \Elementor\Plugin::$instance->editor->is_edit_mode();
    }
}
