<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Tests\Unit;

use Brain\Monkey\Functions;
use TheCore\ElementorWidgets\CookieConsent\CookieConsentModule;
use TheCore\ElementorWidgets\Elementor\Legacy\Widgets\CookieConsent\DisplaySettings;

final class CookieConsentDisplaySettingsTest extends TestCase
{
    public function testNormalizeKeepsValidValues(): void
    {
        Functions\when('get_privacy_policy_url')->justReturn('https://example.com/privacy');

        $settings = (new DisplaySettings())->normalize([
            'notice_text' => '<p>Custom notice</p>',
            'theme_preset' => 'labs',
            'show_category_descriptions' => 'yes',
            'reload_on_set' => 'yes',
            'cookie_expiration_days' => 90,
            'privacy_policy_url' => [
                'url' => 'https://example.com/policy',
                'is_external' => 'yes',
            ],
            'accept_button_label' => 'Accept all',
            'confirm_choice_button_label' => 'Save choice',
            'reject_button_label' => 'Reject all',
            'privacy_policy_button_label' => 'Privacy',
            'revoke_consent_button_label' => 'Reset cookies',
            'block_embeds' => 'yes',
            'log_consents' => 'yes',
            'anonymize_consent_log_ips' => 'yes',
            'auto_purge_consents' => 'yes',
            'auto_purge_consents_interval' => '1 year',
            'revoke_delete_all' => 'yes',
            'category_essential_active' => 'yes',
            'category_essential_label' => 'Necessary',
            'category_essential_description' => 'Needed',
            'category_essential_code' => '<script>console.log("essential")</script>',
            'category_functional_active' => 'yes',
            'category_functional_label' => 'Functional',
            'category_functional_description' => 'Optional helpers',
            'category_functional_code' => '<script>console.log("functional")</script>',
            'category_marketing_active' => '',
            'category_marketing_label' => 'Ads',
            'category_marketing_description' => 'Tracking',
            'category_marketing_code' => '<script>console.log("marketing")</script>',
        ]);

        self::assertSame('<p>Custom notice</p>', $settings['notice_text']);
        self::assertSame('labs', $settings['theme_preset']);
        self::assertTrue($settings['show_category_descriptions']);
        self::assertTrue($settings['reload_on_set']);
        self::assertSame(90, $settings['cookie_expiration_days']);
        self::assertSame('https://example.com/policy', $settings['privacy_policy_url']);
        self::assertTrue($settings['privacy_policy_external']);
        self::assertSame('Accept all', $settings['buttons']['accept']);
        self::assertSame('Save choice', $settings['buttons']['confirm']);
        self::assertSame('Reject all', $settings['buttons']['reject']);
        self::assertSame('Privacy', $settings['buttons']['privacy']);
        self::assertSame('Reset cookies', $settings['revoke_consent_button_label']);
        self::assertTrue($settings['block_embeds']);
        self::assertTrue($settings['log_consents']);
        self::assertTrue($settings['anonymize_consent_log_ips']);
        self::assertTrue($settings['auto_purge_consents']);
        self::assertSame('1 year', $settings['auto_purge_consents_interval']);
        self::assertTrue($settings['revoke_delete_all']);
        self::assertSame('Necessary', $settings['categories'][0]['label']);
        self::assertSame('Needed', $settings['categories'][0]['description']);
        self::assertSame('<script>console.log("essential")</script>', $settings['categories'][0]['code']);
        self::assertTrue($settings['categories'][0]['required']);
        self::assertTrue($settings['categories'][1]['active']);
        self::assertSame('<script>console.log("functional")</script>', $settings['categories'][1]['code']);
        self::assertFalse($settings['categories'][2]['active']);
        self::assertSame('<script>console.log("marketing")</script>', $settings['categories'][2]['code']);
    }

    public function testNormalizeFallsBackForInvalidValues(): void
    {
        Functions\when('get_privacy_policy_url')->justReturn('https://example.com/privacy');

        $settings = (new DisplaySettings())->normalize([
            'notice_text' => [],
            'theme_preset' => 'weird',
            'show_category_descriptions' => false,
            'reload_on_set' => [],
            'cookie_expiration_days' => 9999,
            'privacy_policy_url' => 'javascript:alert(1)',
            'accept_button_label' => [],
            'confirm_choice_button_label' => [],
            'reject_button_label' => [],
            'privacy_policy_button_label' => [],
            'revoke_consent_button_label' => [],
            'block_embeds' => [],
            'log_consents' => [],
            'anonymize_consent_log_ips' => [],
            'auto_purge_consents' => [],
            'auto_purge_consents_interval' => 'never',
            'revoke_delete_all' => [],
            'category_essential_label' => '',
            'category_functional_label' => [],
            'category_marketing_description' => [],
            'category_marketing_code' => [],
        ]);

        self::assertSame(CookieConsentModule::DEFAULT_NOTICE_TEXT, $settings['notice_text']);
        self::assertSame(CookieConsentModule::DEFAULT_THEME_PRESET, $settings['theme_preset']);
        self::assertFalse($settings['show_category_descriptions']);
        self::assertFalse($settings['reload_on_set']);
        self::assertSame(365, $settings['cookie_expiration_days']);
        self::assertSame('', $settings['privacy_policy_url']);
        self::assertFalse($settings['privacy_policy_external']);
        self::assertSame('', $settings['buttons']['accept']);
        self::assertSame('', $settings['buttons']['confirm']);
        self::assertSame('', $settings['buttons']['reject']);
        self::assertSame('', $settings['buttons']['privacy']);
        self::assertSame('', $settings['revoke_consent_button_label']);
        self::assertFalse($settings['block_embeds']);
        self::assertFalse($settings['log_consents']);
        self::assertFalse($settings['anonymize_consent_log_ips']);
        self::assertFalse($settings['auto_purge_consents']);
        self::assertSame(CookieConsentModule::DEFAULT_AUTO_PURGE_INTERVAL, $settings['auto_purge_consents_interval']);
        self::assertFalse($settings['revoke_delete_all']);
        self::assertSame(DisplaySettings::DEFAULT_CATEGORY_SETTINGS['category_essential']['label'], $settings['categories'][0]['label']);
        self::assertSame(DisplaySettings::DEFAULT_CATEGORY_SETTINGS['category_functional']['label'], $settings['categories'][1]['label']);
        self::assertSame('', $settings['categories'][2]['description']);
        self::assertSame('', $settings['categories'][2]['code']);
    }

    public function testNormalizePresentationKeepsPresetAndPreviewFlags(): void
    {
        $settings = (new DisplaySettings())->normalizePresentation([
            'theme_preset' => 'sidecar',
            'preview_show_category_descriptions' => '',
            'preview_category_essential' => 'yes',
            'preview_category_functional' => '',
            'preview_category_marketing' => 'yes',
        ]);

        self::assertSame('sidecar', $settings['theme_preset']);
        self::assertFalse($settings['preview_show_category_descriptions']);
        self::assertTrue($settings['preview_categories']['category_essential']);
        self::assertFalse($settings['preview_categories']['category_functional']);
        self::assertTrue($settings['preview_categories']['category_marketing']);
    }

    public function testNormalizePresentationFallsBackToSafeDefaults(): void
    {
        $settings = (new DisplaySettings())->normalizePresentation([
            'theme_preset' => 'unknown',
            'preview_show_category_descriptions' => [],
            'preview_category_essential' => [],
            'preview_category_functional' => [],
            'preview_category_marketing' => [],
        ]);

        self::assertSame(CookieConsentModule::DEFAULT_THEME_PRESET, $settings['theme_preset']);
        self::assertFalse($settings['preview_show_category_descriptions']);
        self::assertFalse($settings['preview_categories']['category_essential']);
        self::assertFalse($settings['preview_categories']['category_functional']);
        self::assertFalse($settings['preview_categories']['category_marketing']);
    }
}
