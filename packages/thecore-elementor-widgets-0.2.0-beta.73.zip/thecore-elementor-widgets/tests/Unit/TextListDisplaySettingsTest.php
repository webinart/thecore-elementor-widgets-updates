<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Tests\Unit;

use TheCore\ElementorWidgets\Elementor\Atomic\Widgets\TextList\DisplaySettings;

final class TextListDisplaySettingsTest extends TestCase
{
    public function testNormalizeKeepsValidValues(): void
    {
        $settings = (new DisplaySettings())->normalize([
            'items_text' => "Premier item\nSecond item\nTroisieme item",
            'list_mode' => 'plain',
            'plain_container_tag' => 'section',
            'plain_item_tag' => 'p',
            'text_color' => '#111111',
            'font_family' => '"DM Sans", sans-serif',
            'font_size' => ['size' => 18, 'unit' => 'px'],
            'font_weight' => '700',
            'line_height' => ['size' => 1.8, 'unit' => 'em'],
            'letter_spacing' => ['size' => 0.5, 'unit' => 'px'],
            'font_style' => 'italic',
            'text_decoration' => 'underline',
            'text_transform' => 'uppercase',
            'gap' => 24,
        ]);

        self::assertSame(['Premier item', 'Second item', 'Troisieme item'], $settings['items']);
        self::assertSame('plain', $settings['list_mode']);
        self::assertSame('section', $settings['container_tag']);
        self::assertSame('p', $settings['item_tag']);
        self::assertSame('#111111', $settings['text_color']);
        self::assertSame('"DM Sans", sans-serif', $settings['font_family']);
        self::assertSame(['size' => 18.0, 'unit' => 'px'], $settings['font_size']);
        self::assertSame('700', $settings['font_weight']);
        self::assertSame(['size' => 1.8, 'unit' => 'em'], $settings['line_height']);
        self::assertSame(['size' => 0.5, 'unit' => 'px'], $settings['letter_spacing']);
        self::assertSame('italic', $settings['font_style']);
        self::assertSame('underline', $settings['text_decoration']);
        self::assertSame('uppercase', $settings['text_transform']);
        self::assertSame(24, $settings['gap']);
    }

    public function testNormalizeFallsBackForInvalidValues(): void
    {
        $settings = (new DisplaySettings())->normalize([
            'items_text' => "<strong>Premier</strong>\n \nSecond<script>alert(1)</script>",
            'list_mode' => 'bad',
            'plain_container_tag' => 'script',
            'plain_item_tag' => 'article',
            'text_color' => '</style>',
            'font_family' => '";}</style><script>alert(1)</script>',
            'font_size' => ['size' => 200, 'unit' => 'vh'],
            'font_weight' => '950',
            'line_height' => ['size' => 10, 'unit' => 'vh'],
            'letter_spacing' => ['size' => -40, 'unit' => 'vh'],
            'font_style' => 'slanted',
            'text_decoration' => 'blink',
            'text_transform' => 'random',
            'gap' => -5,
        ]);

        self::assertSame(['Premier', 'Secondalert(1)'], $settings['items']);
        self::assertSame(DisplaySettings::DEFAULT_LIST_MODE, $settings['list_mode']);
        self::assertSame('ul', $settings['container_tag']);
        self::assertSame('li', $settings['item_tag']);
        self::assertSame(DisplaySettings::DEFAULT_TEXT_COLOR, $settings['text_color']);
        self::assertSame('"/stylescriptalert(1)/script', $settings['font_family']);
        self::assertSame(DisplaySettings::DEFAULT_FONT_SIZE, $settings['font_size']);
        self::assertSame(DisplaySettings::DEFAULT_FONT_WEIGHT, $settings['font_weight']);
        self::assertSame(DisplaySettings::DEFAULT_LINE_HEIGHT, $settings['line_height']);
        self::assertSame(DisplaySettings::DEFAULT_LETTER_SPACING, $settings['letter_spacing']);
        self::assertSame(DisplaySettings::DEFAULT_FONT_STYLE, $settings['font_style']);
        self::assertSame(DisplaySettings::DEFAULT_TEXT_DECORATION, $settings['text_decoration']);
        self::assertSame(DisplaySettings::DEFAULT_TEXT_TRANSFORM, $settings['text_transform']);
        self::assertSame(0, $settings['gap']);
    }
}
