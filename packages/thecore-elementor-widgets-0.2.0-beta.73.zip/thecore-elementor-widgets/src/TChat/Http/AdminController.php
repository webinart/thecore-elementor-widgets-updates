<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\TChat\Http;

use TheCore\ElementorWidgets\TChat\Support\RealtimeRelay;
use WP_REST_Request;
use WP_REST_Server;

final class AdminController
{
    public static function register(): void
    {
        register_rest_route(
            'tchat/v1',
            '/admin/conversations',
            [
                'methods' => WP_REST_Server::READABLE,
                'permission_callback' => static fn(): bool => current_user_can('edit_posts'),
                'args' => [
                    'filter' => [
                        'required' => false,
                        'type' => 'string',
                    ],
                ],
                'callback' => [self::class, 'getConversations'],
            ]
        );

        register_rest_route(
            'tchat/v1',
            '/admin/message',
            [
                'methods' => WP_REST_Server::CREATABLE,
                'permission_callback' => static fn(): bool => current_user_can('edit_posts'),
                'callback' => [self::class, 'reply'],
                'args' => [
                    'conversation_id' => ['required' => true, 'type' => 'integer'],
                    'content' => ['required' => true, 'type' => 'string'],
                ],
            ]
        );

        register_rest_route(
            'tchat/v1',
            '/admin/conversations/(?P<id>\d+)',
            [
                'methods' => WP_REST_Server::EDITABLE,
                'permission_callback' => static fn(): bool => current_user_can('edit_posts'),
                'callback' => [self::class, 'updateConversation'],
                'args' => [
                    'title' => ['required' => false, 'type' => 'string'],
                    'unread_count' => ['required' => false, 'type' => 'integer'],
                    'is_active' => ['required' => false, 'type' => 'integer'],
                ],
            ]
        );

        register_rest_route(
            'tchat/v1',
            '/admin/conversations/(?P<id>\d+)',
            [
                'methods' => WP_REST_Server::DELETABLE,
                'permission_callback' => static fn(): bool => current_user_can('delete_posts'),
                'callback' => [self::class, 'deleteConversation'],
            ]
        );
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public static function getConversations(WP_REST_Request $request): array
    {
        global $wpdb;

        $filter = sanitize_key((string) $request->get_param('filter'));
        $where = '';

        if ($filter === 'archived') {
            $where = 'WHERE COALESCE(is_active, 1) = 0';
        } elseif ($filter === 'all') {
            $where = '';
        } else {
            $where = 'WHERE COALESCE(is_active, 1) = 1';
        }

        return $wpdb->get_results(
            "SELECT id, title, unread_count, customer_uuid, status, is_active, updated_at, created_at
             FROM {$wpdb->prefix}tchat_conversations
             {$where}
             ORDER BY updated_at DESC
             LIMIT 100",
            ARRAY_A
        );
    }

    /**
     * @return array<string, mixed>
     */
    public static function reply(WP_REST_Request $request): array
    {
        global $wpdb;

        $conversation_id = (int) $request['conversation_id'];
        $content = wp_kses_post((string) $request['content']);
        $created_at = current_time('mysql', true);

        $wpdb->insert(
            "{$wpdb->prefix}tchat_messages",
            [
                'conversation_id' => $conversation_id,
                'sender_type' => 'agent',
                'sender_id' => get_current_user_id(),
                'visitor_uuid' => '',
                'content' => $content,
                'created_at' => $created_at,
            ],
            ['%d', '%s', '%d', '%s', '%s', '%s']
        );

        $wpdb->update(
            "{$wpdb->prefix}tchat_conversations",
            ['updated_at' => $created_at],
            ['id' => $conversation_id],
            ['%s'],
            ['%d']
        );

        $message = [
            'id' => (int) $wpdb->insert_id,
            'conversation_id' => $conversation_id,
            'sender_type' => 'agent',
            'sender_id' => get_current_user_id(),
            'visitor_uuid' => '',
            'content' => $content,
            'created_at' => $created_at,
        ];

        RealtimeRelay::dispatchMessage($message);

        return [
            'success' => true,
            'message' => $message,
        ];
    }

    /**
     * @return array<string, mixed>|\WP_Error
     */
    public static function updateConversation(WP_REST_Request $request)
    {
        global $wpdb;

        $conversation_id = (int) $request['id'];
        $data = [];

        if (null !== $request->get_param('title')) {
            $data['title'] = sanitize_text_field((string) $request['title']);
        }

        if (null !== $request->get_param('unread_count')) {
            $data['unread_count'] = (int) $request['unread_count'];
        }

        if (null !== $request->get_param('is_active')) {
            $is_active = (int) $request['is_active'];
            $data['is_active'] = $is_active;
            $data['status'] = $is_active === 0 ? 'closed' : 'open';
        }

        if (! $data) {
            return new \WP_Error('empty', 'No data', ['status' => 400]);
        }

        $wpdb->update("{$wpdb->prefix}tchat_conversations", $data, ['id' => $conversation_id]);

        return ['success' => true];
    }

    /**
     * @return array<string, mixed>
     */
    public static function deleteConversation(WP_REST_Request $request): array
    {
        global $wpdb;

        $conversation_id = (int) $request['id'];
        $wpdb->delete("{$wpdb->prefix}tchat_messages", ['conversation_id' => $conversation_id]);
        $wpdb->delete("{$wpdb->prefix}tchat_conversations", ['id' => $conversation_id]);

        return ['success' => true];
    }
}
