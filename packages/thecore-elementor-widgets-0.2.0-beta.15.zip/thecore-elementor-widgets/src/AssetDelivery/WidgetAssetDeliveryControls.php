<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\AssetDelivery;

use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Number_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Select_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Switch_Control;
use Elementor\Modules\AtomicWidgets\DynamicTags\Dynamic_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Boolean_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Number_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\Components\PropTypes\Overridable_Prop_Type;

final class WidgetAssetDeliveryControls
{
    /**
     * @return array<string, mixed>
     */
    public static function definePropsSchema(): array
    {
        return [
            'asset_css_use_global' => self::booleanProp()->default(AssetDeliverySettings::widgetDefaults()['css']['use_global']),
            'asset_css_trigger' => self::stringProp()->enum(AssetDeliverySettings::triggerValues())->default(AssetDeliverySettings::widgetDefaults()['css']['trigger']),
            'asset_css_viewport_threshold' => self::numberProp()->default(AssetDeliverySettings::widgetDefaults()['css']['viewport_threshold']),
            'asset_css_fallback_enabled' => self::booleanProp()->default(AssetDeliverySettings::widgetDefaults()['css']['fallback_enabled']),
            'asset_css_fallback_delay' => self::numberProp()->default(AssetDeliverySettings::widgetDefaults()['css']['fallback_delay']),
            'asset_js_use_global' => self::booleanProp()->default(AssetDeliverySettings::widgetDefaults()['js']['use_global']),
            'asset_js_trigger' => self::stringProp()->enum(AssetDeliverySettings::triggerValues())->default(AssetDeliverySettings::widgetDefaults()['js']['trigger']),
            'asset_js_viewport_threshold' => self::numberProp()->default(AssetDeliverySettings::widgetDefaults()['js']['viewport_threshold']),
            'asset_js_fallback_enabled' => self::booleanProp()->default(AssetDeliverySettings::widgetDefaults()['js']['fallback_enabled']),
            'asset_js_fallback_delay' => self::numberProp()->default(AssetDeliverySettings::widgetDefaults()['js']['fallback_delay']),
        ];
    }

    /**
     * @return array<int, Section>
     */
    public static function buildSections(): array
    {
        return [
            Section::make()
                ->set_label(__('CSS Delivery', 'thecore-elementor-widgets'))
                ->set_items([
                    Switch_Control::bind_to('asset_css_use_global')
                        ->set_label(__('Use global settings', 'thecore-elementor-widgets'))
                        ->set_description(__('When enabled, this widget inherits the global CSS delay strategy.', 'thecore-elementor-widgets')),
                    Select_Control::bind_to('asset_css_trigger')
                        ->set_label(__('Trigger', 'thecore-elementor-widgets'))
                        ->set_options(self::triggerOptions()),
                    Number_Control::bind_to('asset_css_viewport_threshold')
                        ->set_label(__('Viewport threshold (%)', 'thecore-elementor-widgets'))
                        ->set_min(0)
                        ->set_max(100)
                        ->set_step(1)
                        ->set_should_force_int(true),
                    Switch_Control::bind_to('asset_css_fallback_enabled')
                        ->set_label(__('Enable fallback delay', 'thecore-elementor-widgets')),
                    Number_Control::bind_to('asset_css_fallback_delay')
                        ->set_label(__('Fallback delay (ms)', 'thecore-elementor-widgets'))
                        ->set_min(100)
                        ->set_max(15000)
                        ->set_step(100)
                        ->set_should_force_int(true),
                ]),
            Section::make()
                ->set_label(__('JS Delivery', 'thecore-elementor-widgets'))
                ->set_items([
                    Switch_Control::bind_to('asset_js_use_global')
                        ->set_label(__('Use global settings', 'thecore-elementor-widgets'))
                        ->set_description(__('When enabled, this widget inherits the global JS delay strategy.', 'thecore-elementor-widgets')),
                    Select_Control::bind_to('asset_js_trigger')
                        ->set_label(__('Trigger', 'thecore-elementor-widgets'))
                        ->set_options(self::triggerOptions()),
                    Number_Control::bind_to('asset_js_viewport_threshold')
                        ->set_label(__('Viewport threshold (%)', 'thecore-elementor-widgets'))
                        ->set_min(0)
                        ->set_max(100)
                        ->set_step(1)
                        ->set_should_force_int(true),
                    Switch_Control::bind_to('asset_js_fallback_enabled')
                        ->set_label(__('Enable fallback delay', 'thecore-elementor-widgets')),
                    Number_Control::bind_to('asset_js_fallback_delay')
                        ->set_label(__('Fallback delay (ms)', 'thecore-elementor-widgets'))
                        ->set_min(100)
                        ->set_max(15000)
                        ->set_step(100)
                        ->set_should_force_int(true),
                ]),
        ];
    }

    /**
     * @return array<int, array{label: string, value: string}>
     */
    private static function triggerOptions(): array
    {
        return [
            [
                'label' => __('Element in viewport', 'thecore-elementor-widgets'),
                'value' => AssetDeliverySettings::TRIGGER_VIEWPORT,
            ],
            [
                'label' => __('Page interaction', 'thecore-elementor-widgets'),
                'value' => AssetDeliverySettings::TRIGGER_INTERACTION,
            ],
            [
                'label' => __('Fallback only', 'thecore-elementor-widgets'),
                'value' => AssetDeliverySettings::TRIGGER_FALLBACK_ONLY,
            ],
        ];
    }

    private static function booleanProp(): Boolean_Prop_Type
    {
        return Boolean_Prop_Type::make()
            ->meta(Dynamic_Prop_Type::ignore())
            ->meta(Overridable_Prop_Type::ignore());
    }

    private static function numberProp(): Number_Prop_Type
    {
        return Number_Prop_Type::make()
            ->meta(Dynamic_Prop_Type::ignore())
            ->meta(Overridable_Prop_Type::ignore());
    }

    private static function stringProp(): String_Prop_Type
    {
        return String_Prop_Type::make()
            ->meta(Dynamic_Prop_Type::ignore())
            ->meta(Overridable_Prop_Type::ignore());
    }
}
