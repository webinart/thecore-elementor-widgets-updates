<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Legacy\Widgets\TChat;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use TheCore\ElementorWidgets\Assets\FrontendAssets;
use TheCore\ElementorWidgets\TChat\TChatModule;

final class TChat extends Widget_Base
{
    public function get_name(): string
    {
        return 'thecore-tchat';
    }

    public function get_title(): string
    {
        return __('TChat', 'thecore-elementor-widgets');
    }

    public function get_icon(): string
    {
        return 'eicon-comments';
    }

    public function get_categories(): array
    {
        return ['basic'];
    }

    public function get_keywords(): array
    {
        return ['chat', 'tchat', 'support', 'messaging', 'the core'];
    }

    public function get_style_depends(): array
    {
        return [FrontendAssets::TCHAT_WIDGET_STYLE];
    }

    public function get_script_depends(): array
    {
        return [FrontendAssets::TCHAT_WIDGET_SCRIPT];
    }

    protected function register_controls(): void
    {
        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Content', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'info',
            [
                'type' => Controls_Manager::RAW_HTML,
                'raw' => esc_html__(
                    'This widget mounts the global TChat frontend. Transport, polling and SSE settings are managed in TChat > Settings.',
                    'thecore-elementor-widgets'
                ),
                'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
            ]
        );

        $this->end_controls_section();
    }

    protected function render(): void
    {
        echo TChatModule::renderMount(
            [
                'id' => 'tchat-root-' . $this->get_id(),
                'class' => 'thecore-tchat-widget',
                'data-tchat-source' => 'elementor',
            ]
        );
    }
}
