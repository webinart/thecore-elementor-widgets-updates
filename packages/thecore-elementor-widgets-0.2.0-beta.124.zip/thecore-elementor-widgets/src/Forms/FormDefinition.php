<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms;

use TheCore\ElementorWidgets\Forms\Media\Policy;
use TheCore\ElementorWidgets\Forms\Flow\Compiler;

/** Compiles only saved, static rules. Browser metadata never defines validation. */
final class FormDefinition
{
    public const TYPE = 'thecore-form';
    public const SECURITY_FIELD = 'thecore_atomic_security';
    public const MAX_FIELDS = 50;

    public function __construct(
        public readonly array $settings,
        public readonly array $fields,
        public readonly array $flow = []
    ) {
    }

    public static function fromElement(array $element): self
    {
        if (($element['elType'] ?? '') !== self::TYPE) {
            throw new ConfigurationException('Not a The Core form.');
        }

        $settings = self::settings($element['settings'] ?? []);
        $settings += [
            'form-name' => 'Contact',
            'recipient' => '',
            'subject' => 'Contact',
            'success-message' => 'Votre message a bien ete envoye.',
            'allow-tests' => false,
            'actions-after-submit' => ['email'],
            'api-connection' => '',
            'api-mapping' => '',
            'reply-to-field' => '',
            'autoresponder-email-field' => '',
            'autoresponder-subject' => 'Votre demande a bien ete recue',
            'autoresponder-message' => "Bonjour,\n\nNous avons bien recu votre demande et vous recontacterons prochainement.",
            'store-submissions' => false,
            'log-blocked-submissions' => false,
            'submission-retention-days' => 90,
            'mailpoet-lists' => [],
            'mailpoet-email-field' => 'thecore-field-email',
            'mailpoet-first-name-field' => '',
            'mailpoet-last-name-field' => '',
            'mailpoet-consent-field' => '',
        ];
        foreach (['form-name', 'recipient', 'subject', 'success-message'] as $key) {
            if (! is_string($settings[$key]) || strlen($settings[$key]) > 1000) {
                throw new ConfigurationException('Invalid form setting: ' . $key);
            }
        }
        if (! is_bool($settings['allow-tests'])) {
            throw new ConfigurationException('Invalid test setting.');
        }
        if (isset($settings['flow-smooth-transitions']) && ! is_bool($settings['flow-smooth-transitions'])) {
            throw new ConfigurationException('Invalid form transition setting.');
        }
        if (array_key_exists('flow-pending-submit', $settings) && ! is_bool($settings['flow-pending-submit'])) {
            throw new ConfigurationException('Invalid pending submit setting.');
        }
        if (! is_bool($settings['store-submissions'])) {
            throw new ConfigurationException('Invalid submission storage setting.');
        }
        if (! is_bool($settings['log-blocked-submissions'])) {
            throw new ConfigurationException('Invalid blocked submission log setting.');
        }
        if (
            ! is_int($settings['submission-retention-days'])
            || $settings['submission-retention-days'] < 1 || $settings['submission-retention-days'] > 365
        ) {
            throw new ConfigurationException('Submission retention must be between 1 and 365 days.');
        }
        foreach (['reply-to-field', 'autoresponder-email-field', 'autoresponder-subject', 'autoresponder-message'] as $key) {
            if (! is_string($settings[$key]) || strlen($settings[$key]) > ($key === 'autoresponder-message' ? 10000 : 1000)) {
                throw new ConfigurationException('Invalid form setting: ' . $key);
            }
        }
        $actions = $settings['actions-after-submit'];
        if (! is_array($actions) || ! array_is_list($actions) || $actions === [] || count($actions) > 4) {
            throw new ConfigurationException('Select at least one submission action.');
        }
        foreach ($actions as $action) {
            if (! in_array($action, ['email', 'mailpoet', 'autoresponder', 'api'], true)) {
                throw new ConfigurationException('Unknown submission action.');
            }
        }
        if (count(array_unique($actions)) !== count($actions)) {
            throw new ConfigurationException('Duplicate submission action.');
        }
        if (in_array('api', $actions, true)) {
            if (! is_string($settings['api-connection']) || ! preg_match('/\A[a-z][a-z0-9_-]{0,63}\z/', $settings['api-connection'])) {
                throw new ConfigurationException('Select a saved API connection.');
            }
            if (! is_string($settings['api-mapping']) || $settings['api-mapping'] === '' || strlen($settings['api-mapping']) > 32768) {
                throw new ConfigurationException('Invalid API field mapping.');
            }
        }
        if (in_array('mailpoet', $actions, true)) {
            $lists = $settings['mailpoet-lists'];
            if (! is_array($lists) || ! array_is_list($lists) || $lists === [] || count($lists) > 20) {
                throw new ConfigurationException('Select between 1 and 20 MailPoet lists.');
            }
            foreach ($lists as $list) {
                if (! is_string($list) || ! preg_match('/\A[1-9][0-9]{0,10}\z/', $list)) {
                    throw new ConfigurationException('Invalid MailPoet list ID.');
                }
            }
            $settings['mailpoet-lists'] = array_values(array_unique($lists));
        }

        $nodes = [];
        self::flatten($element['elements'] ?? [], $nodes);
        $labels = [];
        foreach ($nodes as $node) {
            if (($node['widgetType'] ?? '') === 'e-form-label') {
                $props = self::settings($node['settings'] ?? []);
                $text = $props['text'] ?? '';
                $labels[(string) ($props['input-id'] ?? '')] = trim(strip_tags(
                    is_array($text) ? (string) ($text['content'] ?? '') : (string) $text
                ));
            }
        }

        $fields = [];
        $domIds = [];
        foreach ($nodes as $node) {
            $widget = $node['widgetType'] ?? $node['elType'] ?? '';
            $isMedia = $widget === 'thecore-form-media';
            if ((! $isMedia && ! str_starts_with($widget, 'e-form-')) || in_array($widget, ['e-form-label', 'e-form-submit-button'], true)) {
                continue;
            }
            $type = match ($widget) {
                'e-form-input' => 'text',
                'e-form-textarea' => 'textarea',
                'e-form-checkbox' => 'checkbox',
                'e-form-select' => 'select',
                'e-form-radio-button' => 'radio',
                'thecore-form-media' => 'media',
                default => throw new ConfigurationException('Unsupported field: ' . $widget),
            };
            $props = self::settings($node['settings'] ?? []);
            if ($widget === 'e-form-input') {
                $type = $props['type'] ?? 'text';
                if (! in_array($type, ['text', 'email', 'tel', 'url', 'number'], true)) {
                    throw new ConfigurationException('Unsupported input type.');
                }
            }
            $id = $node['id'] ?? '';
            $domId = $props['_cssid'] ?? '';
            if (! is_string($id) || ! preg_match('/\A[A-Za-z0-9_-]{1,128}\z/', $id) || isset($fields[$id])) {
                throw new ConfigurationException('Invalid or duplicate field ID.');
            }
            if (! is_string($domId) || $domId === '' || isset($domIds[$domId])) {
                throw new ConfigurationException('Fields need unique CSS IDs.');
            }
            $mediaPolicy = $isMedia ? Policy::fromProps($props) : null;
            $label = $isMedia ? ($props['label'] ?? '') : ($labels[$domId] ?? '');
            if (! is_string($label) || strlen($label) > 1000) {
                throw new ConfigurationException('Invalid field label.');
            }
            $label = trim(strip_tags($label));
            if ($isMedia && $label === '') {
                $label = match ($mediaPolicy['mode']) {
                    'photos' => 'Photos', 'videos' => 'Vidéos', default => 'Photos et vidéos',
                };
            }
            if ($label === '') {
                throw new ConfigurationException('Each field needs an associated label.');
            }
            $domIds[$domId] = true;
            $options = [];
            foreach (($props['options'] ?? []) as $option) {
                if (! is_array($option) || ! isset($option['value']) || ! is_string($option['value'])) {
                    throw new ConfigurationException('Invalid select option.');
                }
                $options[] = $option['value'] === '' ? (string) ($option['key'] ?? '') : $option['value'];
            }
            $attributes = [];
            foreach (($props['attributes'] ?? []) as $attribute) {
                if (is_array($attribute) && isset($attribute['key'], $attribute['value'])) {
                    $attributes[strtolower((string) $attribute['key'])] = $attribute['value'];
                }
            }
            // HTML overrides must not silently change the server-side contract.
            foreach (['name', 'type', 'value', 'required', 'readonly', 'disabled', 'multiple', 'form', 'id', 'pattern'] as $key) {
                if (array_key_exists($key, $attributes)) {
                    throw new ConfigurationException('Unsupported field attribute: ' . $key);
                }
            }
            $fields[$id] = [
                'id' => $id,
                'domId' => $domId,
                'name' => (string) (($props['name'] ?? '') ?: $domId),
                'label' => $label,
                'type' => $type,
                'required' => ($props['required'] ?? false) === true,
                'readonly' => ($props['readonly'] ?? false) === true,
                'value' => (string) ($props['value'] ?? ''),
                'multiple' => ($props['multiple'] ?? false) === true,
                'options' => $options,
                'minLength' => max(0, (int) ($props['length']['min'] ?? $props['minlength'] ?? $attributes['minlength'] ?? 0)),
                'maxLength' => min(10000, max(1, (int) ($props['length']['max'] ?? $props['maxlength'] ?? $attributes['maxlength'] ?? 10000))),
                'min' => $attributes['min'] ?? null,
                'max' => $attributes['max'] ?? null,
                'step' => $attributes['step'] ?? null,
            ];
            if ($isMedia) {
                if (isset($props['required']) && ! is_bool($props['required'])) {
                    throw new ConfigurationException('Invalid media required setting.');
                }
                $fields[$id]['media'] = $mediaPolicy;
                $fields[$id]['value'] = '';
                $fields[$id]['readonly'] = false;
                $fields[$id]['multiple'] = true;
            }
        }
        if ($fields === [] || count($fields) > self::MAX_FIELDS) {
            throw new ConfigurationException('A form must contain between 1 and 50 supported fields.');
        }
        $flow = Compiler::compile($element, $fields);
        if ($flow !== [] && ($settings['flow-smooth-transitions'] ?? false) === true) {
            $flow['smoothTransitions'] = true;
        }
        if ($flow !== [] && ($settings['flow-pending-submit'] ?? false) === true) {
            $flow['pendingSubmit'] = true;
        }
        $form = new self($settings, $fields, $flow);
        if (in_array('mailpoet', $actions, true)) {
            $form->mailPoetMapping();
        }
        if (in_array('email', $actions, true) && $settings['reply-to-field'] !== '') {
            $form->emailField('reply-to-field');
        }
        if (in_array('autoresponder', $actions, true)) {
            $form->emailField('autoresponder-email-field');
            if (trim($settings['autoresponder-subject']) === '' || trim($settings['autoresponder-message']) === '') {
                throw new ConfigurationException('The autoresponder needs a subject and a static message.');
            }
        }
        return $form;
    }

    /** Resolve a notification address only from a saved, declared email field. */
    public function emailField(string $setting): string
    {
        $cssId = $this->settings[$setting] ?? '';
        if (! is_string($cssId) || $cssId === '' || strlen($cssId) > 128) {
            throw new ConfigurationException('Invalid email field mapping: ' . $setting);
        }
        foreach ($this->fields as $id => $field) {
            if ($field['domId'] === $cssId && $field['type'] === 'email') {
                return $id;
            }
        }
        throw new ConfigurationException('Mapped email field not found: ' . $cssId);
    }

    /** Resolve the saved CSS IDs, not the prefixed IDs emitted in browser markup. */
    public function mailPoetMapping(): array
    {
        $mapping = [];
        foreach (['email' => 'email', 'first_name' => 'first-name', 'last_name' => 'last-name', 'consent' => 'consent'] as $remote => $key) {
            $cssId = $this->settings['mailpoet-' . $key . '-field'] ?? '';
            if (! is_string($cssId) || strlen($cssId) > 128 || ($remote === 'email' && $cssId === '')) {
                throw new ConfigurationException('Invalid MailPoet field mapping.');
            }
            if ($cssId === '') {
                continue;
            }
            foreach ($this->fields as $id => $field) {
                if ($field['domId'] !== $cssId) {
                    continue;
                }
                $type = match ($remote) {
                    'email' => 'email', 'consent' => 'checkbox', default => 'text'
                };
                if ($field['type'] !== $type || ($remote === 'consent' && $field['readonly'])) {
                    throw new ConfigurationException('Incompatible MailPoet field type.');
                }
                $mapping[$remote] = $id;
            }
            if (! isset($mapping[$remote])) {
                throw new ConfigurationException('Mapped MailPoet field not found: ' . $cssId);
            }
        }
        if (count(array_unique($mapping)) !== count($mapping)) {
            throw new ConfigurationException('MailPoet fields must have distinct mappings.');
        }
        return $mapping;
    }

    public function publicFields(): array
    {
        return array_values(array_map(static function (array $field): array {
            $public = array_intersect_key($field, array_flip(['id', 'domId', 'name', 'label', 'type', 'required', 'multiple']));
            if (($field['conditions'] ?? []) !== []) {
                $public['conditions'] = $field['conditions'];
            }
            if ($field['type'] === 'media') {
                $public['media'] = ['mode' => $field['media']['mode'], 'maxFiles' => $field['media']['max_files'],
                    'maxBytes' => $field['media']['max_file_size_mb'] * 1048576,
                    'mobileTransfer' => $field['media']['mobile_transfer']];
            }
            return $public;
        }, $this->fields));
    }

    /** Resolve branches from the saved policy, never browser visibility or posted metadata. */
    public function activeFor(array $submitted): self
    {
        if ($this->flow === []) {
            return $this;
        }
        $fields = array_filter($this->fields, fn (array $field): bool => Compiler::matches($field['conditions'] ?? [], $this->fields, $submitted));
        foreach ($this->flow['requiredRules'] as $rule) {
            if (isset($fields[$rule['field']]) && Compiler::matches($rule['conditions'], $this->fields, $submitted)) {
                $fields[$rule['field']]['required'] = true;
            }
        }
        return new self($this->settings, $fields);
    }

    /** Progressive first paint may expose only the first unconditional saved step. */
    public function initiallyVisibleStep(): string
    {
        foreach ($this->flow['groups'] ?? [] as $group) {
            if ($group['step'] && $group['conditions'] === []) {
                return $group['id'];
            }
        }
        return '';
    }

    public static function settings(array $settings): array
    {
        // Layout props may contain global/dynamic styles and are irrelevant here.
        $result = [];
        $keys = ['form-name', 'recipient', 'subject', 'success-message', 'allow-tests', 'actions-after-submit',
            'reply-to-field', 'autoresponder-email-field', 'autoresponder-subject', 'autoresponder-message',
            'store-submissions', 'log-blocked-submissions', 'submission-retention-days', 'api-connection', 'api-mapping',
            'mailpoet-lists', 'mailpoet-email-field', 'mailpoet-first-name-field', 'mailpoet-last-name-field', 'mailpoet-consent-field',
            '_cssid', 'input-id', 'text', 'type', 'name', 'value', 'required', 'readonly',
            'multiple', 'options', 'length', 'minlength', 'maxlength', 'attributes', 'label', 'media-mode',
            'max-files', 'max-file-size-mb', 'mobile-transfer', 'retention-days',
            'is-step', 'condition-field', 'condition-value', 'require-field', 'flow-smooth-transitions', 'flow-pending-submit'];
        foreach ($keys as $key) {
            if (array_key_exists($key, $settings)) {
                $result[$key] = self::unwrap($settings[$key]);
            }
        }
        return $result;
    }

    private static function unwrap(mixed $value, int $depth = 0): mixed
    {
        if ($depth > 12) {
            throw new ConfigurationException('Property nesting too deep.');
        }
        if (! is_array($value)) {
            return $value;
        }
        if (isset($value['$$type'])) {
            if (! in_array($value['$$type'], ['string', 'string-array', 'boolean', 'number', 'html-v3', 'escaped-html', 'key-value', 'options', 'attributes', 'number-range'], true)) {
                throw new ConfigurationException('Dynamic form rules are not supported.');
            }
            return self::unwrap($value['value'] ?? null, $depth + 1);
        }
        return array_map(static fn($item) => self::unwrap($item, $depth + 1), $value);
    }

    private static function flatten(array $children, array &$nodes, int $depth = 0): void
    {
        if ($depth > 20) {
            throw new ConfigurationException('Form nesting too deep.');
        }
        foreach ($children as $child) {
            if (! is_array($child) || count($nodes) >= 500) {
                throw new ConfigurationException('Invalid form structure.');
            }
            if (in_array($child['elType'] ?? '', [self::TYPE, 'e-form'], true)) {
                throw new ConfigurationException('Nested forms are not supported.');
            }
            $nodes[] = $child;
            self::flatten($child['elements'] ?? [], $nodes, $depth + 1);
        }
    }
}
