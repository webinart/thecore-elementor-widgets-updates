(() => {
    if (window.__TheCoreFullscreenMenuBooted) {
        return;
    }

    window.__TheCoreFullscreenMenuBooted = true;

    const config = window.TheCoreElementorWidgetsConfig || {};
    const bodyLockClass = config.bodyLockClass || 'thecore-elementor-widgets-lock-scroll';
    const overlayScrollLockEnabled = Boolean(config.features && config.features.overlayScrollLock);

    const bindMediaListener = (mediaQueryList, listener) => {
        if (typeof mediaQueryList.addEventListener === 'function') {
            mediaQueryList.addEventListener('change', listener);
            return;
        }

        if (typeof mediaQueryList.addListener === 'function') {
            mediaQueryList.addListener(listener);
        }
    };

    const syncCustomProperties = (root, target) => {
        if (!root || !target || typeof window.getComputedStyle !== 'function') {
            return;
        }

        const computedStyles = window.getComputedStyle(root);

        for (let index = 0; index < computedStyles.length; index += 1) {
            const propertyName = computedStyles[index];

            if (!propertyName || !propertyName.startsWith('--thecore-fsm-')) {
                continue;
            }

            target.style.setProperty(propertyName, computedStyles.getPropertyValue(propertyName));
        }
    };

    const findClosestMatchingElement = (root, selector) => {
        if (!root || typeof root.closest !== 'function') {
            return null;
        }

        try {
            return root.closest(selector);
        } catch (error) {
            return null;
        }
    };

    const findDocumentMatchingElement = (selector) => {
        if (!document || typeof document.querySelector !== 'function') {
            return null;
        }

        try {
            return document.querySelector(selector);
        } catch (error) {
            return null;
        }
    };

    const resolveOverlayMountTarget = (root, mode, selector) => {
        if (!root || !document.body) {
            return null;
        }

        if (mode === 'body') {
            return document.body;
        }

        if (mode === 'custom') {
            const normalizedSelector = typeof selector === 'string' ? selector.trim() : '';

            if (normalizedSelector) {
                return (
                    findClosestMatchingElement(root, normalizedSelector) ||
                    findDocumentMatchingElement(normalizedSelector) ||
                    document.body
                );
            }
        }

        return findClosestMatchingElement(root, 'header') || document.body;
    };

    const initInstance = (root) => {
        if (!root || root.dataset.thecoreFullscreenMenuInitialized === '1') {
            return;
        }

        const toggle = root.querySelector('.thecore-fullscreen-menu__toggle');
        const overlay = root.querySelector('.thecore-fullscreen-menu__overlay');

        if (!toggle || !overlay) {
            return;
        }

        root.dataset.thecoreFullscreenMenuInitialized = '1';

        const linkNodes = overlay.querySelectorAll('.thecore-fullscreen-menu__anchor');
        const scrollLockAllowed = overlayScrollLockEnabled && root.dataset.scrollLock === '1';
        const overlayOnly = root.dataset.overlayOnly === '1';
        const overlayMountMode = root.dataset.overlayMountMode || 'header';
        const overlayMountSelector = root.dataset.overlayMountSelector || '';
        const breakpoint = Number.parseInt(root.dataset.mobileBreakpoint || '768', 10);
        const mediaQueryList = window.matchMedia(`(max-width: ${Number.isFinite(breakpoint) ? breakpoint : 768}px)`);
        let mountedToggle = null;
        let isOpen = false;
        let lastFocused = null;

        const isOverlayMode = () => overlayOnly || mediaQueryList.matches;

        const mountOverlay = () => {
            const mountTarget = resolveOverlayMountTarget(root, overlayMountMode, overlayMountSelector);

            if (!mountTarget || overlay.parentNode === mountTarget) {
                return;
            }

            mountTarget.appendChild(overlay);
        };

        const syncToggleState = (button) => {
            if (!button) {
                return;
            }

            button.classList.toggle('is-open', isOpen);
            button.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        };

        const updateMountedTogglePosition = () => {
            if (!mountedToggle) {
                return;
            }

            const rect = toggle.getBoundingClientRect();

            mountedToggle.style.setProperty('--thecore-fsm-mounted-top', `${rect.top}px`);
            mountedToggle.style.setProperty('--thecore-fsm-mounted-left', `${rect.left}px`);
            mountedToggle.style.width = `${rect.width}px`;
        };

        const unmountToggle = () => {
            toggle.classList.remove('is-source-hidden');
            toggle.removeAttribute('aria-hidden');
            toggle.removeAttribute('tabindex');

            if (!mountedToggle) {
                return;
            }

            mountedToggle.remove();
            mountedToggle = null;
        };

        const mountToggle = () => {
            const mountTarget = resolveOverlayMountTarget(root, overlayMountMode, overlayMountSelector);

            if (!mountTarget) {
                return;
            }

            if (!mountedToggle) {
                mountedToggle = toggle.cloneNode(true);
                mountedToggle.removeAttribute('id');
                mountedToggle.dataset.thecoreFullscreenMenuMountedToggle = '1';
                mountedToggle.addEventListener('click', () => {
                    if (isOpen) {
                        close();
                        return;
                    }

                    open();
                });
            }

            if (mountedToggle.parentNode !== mountTarget) {
                mountTarget.appendChild(mountedToggle);
            }

            syncCustomProperties(root, mountedToggle);
            mountedToggle.classList.add('is-mounted');
            toggle.classList.add('is-source-hidden');
            toggle.setAttribute('aria-hidden', 'true');
            toggle.setAttribute('tabindex', '-1');
            updateMountedTogglePosition();
            syncToggleState(mountedToggle);
        };

        const lockBody = () => {
            if (scrollLockAllowed) {
                document.body.classList.add(bodyLockClass);
            }
        };

        const unlockBody = () => {
            if (scrollLockAllowed) {
                document.body.classList.remove(bodyLockClass);
            }
        };

        const syncMode = () => {
            mountOverlay();
            syncCustomProperties(root, overlay);

            if (!isOverlayMode()) {
                isOpen = false;
                root.classList.remove('is-open');
                overlay.classList.remove('is-open');
                syncToggleState(toggle);
                unmountToggle();
                overlay.hidden = true;
                overlay.setAttribute('aria-hidden', 'true');
                unlockBody();
                return;
            }

            if (isOpen) {
                mountToggle();
            } else {
                unmountToggle();
            }

            overlay.hidden = !isOpen;
            overlay.setAttribute('aria-hidden', isOpen ? 'false' : 'true');
            overlay.classList.toggle('is-open', isOpen);
            syncToggleState(toggle);
        };

        const open = () => {
            if (!isOverlayMode()) {
                return;
            }

            mountOverlay();
            syncCustomProperties(root, overlay);
            lastFocused = document.activeElement;
            isOpen = true;
            root.classList.add('is-open');
            overlay.classList.add('is-open');
            syncToggleState(toggle);
            mountToggle();
            overlay.hidden = false;
            overlay.setAttribute('aria-hidden', 'false');
            lockBody();

            const firstLink = linkNodes[0];

            if (firstLink && typeof firstLink.focus === 'function') {
                firstLink.focus({ preventScroll: true });
            }
        };

        const close = (restoreFocus = true) => {
            if (!isOverlayMode()) {
                return;
            }

            isOpen = false;
            root.classList.remove('is-open');
            overlay.classList.remove('is-open');
            syncToggleState(toggle);
            overlay.setAttribute('aria-hidden', 'true');
            unlockBody();
            unmountToggle();

            window.setTimeout(() => {
                if (!isOpen && isOverlayMode()) {
                    overlay.hidden = true;
                }
            }, 350);

            if (
                restoreFocus &&
                lastFocused &&
                typeof lastFocused.focus === 'function'
            ) {
                lastFocused.focus({ preventScroll: true });
            }
        };

        toggle.addEventListener('click', () => {
            if (isOpen) {
                close();
                return;
            }

            open();
        });

        overlay.addEventListener('click', (event) => {
            if (event.target === overlay) {
                close(false);
            }
        });

        document.addEventListener('keydown', (event) => {
            if ('Escape' === event.key && isOpen) {
                close();
            }
        });

        linkNodes.forEach((linkNode) => {
            linkNode.addEventListener('click', () => {
                close(false);
            });
        });

        bindMediaListener(mediaQueryList, syncMode);
        window.addEventListener('resize', updateMountedTogglePosition);
        window.addEventListener('scroll', updateMountedTogglePosition, { passive: true });
        syncMode();
    };

    const initWithin = (scope) => {
        if (!scope || !(scope instanceof Element || scope instanceof Document)) {
            return;
        }

        if (scope instanceof Element && scope.matches('[data-thecore-fullscreen-menu]')) {
            initInstance(scope);
        }

        scope.querySelectorAll('[data-thecore-fullscreen-menu]').forEach((root) => {
            initInstance(root);
        });
    };

    const onReady = () => {
        initWithin(document);

        if (!document.body || typeof MutationObserver !== 'function') {
            return;
        }

        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                mutation.addedNodes.forEach((node) => {
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        initWithin(node);
                    }
                });
            });
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true,
        });
    };

    if ('loading' === document.readyState) {
        document.addEventListener('DOMContentLoaded', onReady, { once: true });
    } else {
        onReady();
    }
})();
