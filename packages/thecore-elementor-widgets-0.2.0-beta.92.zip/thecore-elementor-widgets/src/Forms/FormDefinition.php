<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms;

/** Compiles only saved, static rules. Browser metadata never defines validation. */
final class FormDefinition
{
    public const TYPE = 'thecore-form';
    public const SECURITY_FIELD = 'thecore_atomic_security';
    public const MAX_FIELDS = 50;

    public function __construct(
        public readonly array $settings,
        public readonly array $fields
    ) {
    }

    public static function fromElement(array $element): self
    {
        if (($element['elType'] ?? '') !== self::TYPE) {
            throw new ConfigurationException('Not a The Core form.');
        }

        $settings = self::settings($element['settings'] ?? []);
        $settings += [
            'form-name' => 'Contact',
            'recipient' => '',
            'subject' => 'Contact',
            'success-message' => 'Votre message a bien ete envoye.',
            'allow-tests' => false,
        ];
        foreach (['form-name', 'recipient', 'subject', 'success-message'] as $key) {
            if (! is_string($settings[$key]) || strlen($settings[$key]) > 1000) {
                throw new ConfigurationException('Invalid form setting: ' . $key);
            }
        }
        if (! is_bool($settings['allow-tests'])) {
            throw new ConfigurationException('Invalid test setting.');
        }

        $nodes = [];
        self::flatten($element['elements'] ?? [], $nodes);
        $labels = [];
        foreach ($nodes as $node) {
            if (($node['widgetType'] ?? '') === 'e-form-label') {
                $props = self::settings($node['settings'] ?? []);
                $text = $props['text'] ?? '';
                $labels[(string) ($props['input-id'] ?? '')] = trim(strip_tags(
                    is_array($text) ? (string) ($text['content'] ?? '') : (string) $text
                ));
            }
        }

        $fields = [];
        $domIds = [];
        foreach ($nodes as $node) {
            $widget = $node['widgetType'] ?? '';
            if (! str_starts_with($widget, 'e-form-') || in_array($widget, ['e-form-label', 'e-form-submit-button'], true)) {
                continue;
            }
            $type = match ($widget) {
                'e-form-input' => 'text',
                'e-form-textarea' => 'textarea',
                'e-form-checkbox' => 'checkbox',
                'e-form-select' => 'select',
                'e-form-radio-button' => 'radio',
                default => throw new ConfigurationException('Unsupported field: ' . $widget),
            };
            $props = self::settings($node['settings'] ?? []);
            if ($widget === 'e-form-input') {
                $type = $props['type'] ?? 'text';
                if (! in_array($type, ['text', 'email', 'tel', 'url', 'number'], true)) {
                    throw new ConfigurationException('Unsupported input type.');
                }
            }
            $id = $node['id'] ?? '';
            $domId = $props['_cssid'] ?? '';
            if (! is_string($id) || ! preg_match('/\A[A-Za-z0-9_-]{1,128}\z/', $id) || isset($fields[$id])) {
                throw new ConfigurationException('Invalid or duplicate field ID.');
            }
            if (! is_string($domId) || $domId === '' || isset($domIds[$domId])) {
                throw new ConfigurationException('Fields need unique CSS IDs.');
            }
            if (empty($labels[$domId])) {
                throw new ConfigurationException('Each field needs an associated label.');
            }
            $domIds[$domId] = true;
            $options = [];
            foreach (($props['options'] ?? []) as $option) {
                if (! is_array($option) || ! isset($option['value']) || ! is_string($option['value'])) {
                    throw new ConfigurationException('Invalid select option.');
                }
                $options[] = $option['value'] === '' ? (string) ($option['key'] ?? '') : $option['value'];
            }
            $attributes = [];
            foreach (($props['attributes'] ?? []) as $attribute) {
                if (is_array($attribute) && isset($attribute['key'], $attribute['value'])) {
                    $attributes[strtolower((string) $attribute['key'])] = $attribute['value'];
                }
            }
            // HTML overrides must not silently change the server-side contract.
            foreach (['name', 'type', 'value', 'required', 'readonly', 'disabled', 'multiple', 'form', 'id', 'pattern'] as $key) {
                if (array_key_exists($key, $attributes)) {
                    throw new ConfigurationException('Unsupported field attribute: ' . $key);
                }
            }
            $fields[$id] = [
                'id' => $id,
                'domId' => $domId,
                'name' => (string) (($props['name'] ?? '') ?: $domId),
                'label' => $labels[$domId],
                'type' => $type,
                'required' => ($props['required'] ?? false) === true,
                'readonly' => ($props['readonly'] ?? false) === true,
                'value' => (string) ($props['value'] ?? ''),
                'multiple' => ($props['multiple'] ?? false) === true,
                'options' => $options,
                'minLength' => max(0, (int) ($props['length']['min'] ?? $props['minlength'] ?? $attributes['minlength'] ?? 0)),
                'maxLength' => min(10000, max(1, (int) ($props['length']['max'] ?? $props['maxlength'] ?? $attributes['maxlength'] ?? 10000))),
                'min' => $attributes['min'] ?? null,
                'max' => $attributes['max'] ?? null,
                'step' => $attributes['step'] ?? null,
            ];
        }
        if ($fields === [] || count($fields) > self::MAX_FIELDS) {
            throw new ConfigurationException('A form must contain between 1 and 50 supported fields.');
        }
        return new self($settings, $fields);
    }

    public function publicFields(): array
    {
        return array_values(array_map(static fn(array $field): array => array_intersect_key(
            $field,
            array_flip(['id', 'domId', 'name', 'label', 'type', 'required', 'multiple'])
        ), $this->fields));
    }

    public static function settings(array $settings): array
    {
        // Layout props may contain global/dynamic styles and are irrelevant here.
        $result = [];
        $keys = ['form-name', 'recipient', 'subject', 'success-message', 'allow-tests',
            '_cssid', 'input-id', 'text', 'type', 'name', 'value', 'required', 'readonly',
            'multiple', 'options', 'length', 'minlength', 'maxlength', 'attributes'];
        foreach ($keys as $key) {
            if (array_key_exists($key, $settings)) {
                $result[$key] = self::unwrap($settings[$key]);
            }
        }
        return $result;
    }

    private static function unwrap(mixed $value, int $depth = 0): mixed
    {
        if ($depth > 12) {
            throw new ConfigurationException('Property nesting too deep.');
        }
        if (! is_array($value)) {
            return $value;
        }
        if (isset($value['$$type'])) {
            if (! in_array($value['$$type'], ['string', 'boolean', 'number', 'html-v3', 'key-value', 'options', 'attributes', 'number-range'], true)) {
                throw new ConfigurationException('Dynamic form rules are not supported.');
            }
            return self::unwrap($value['value'] ?? null, $depth + 1);
        }
        return array_map(static fn($item) => self::unwrap($item, $depth + 1), $value);
    }

    private static function flatten(array $children, array &$nodes, int $depth = 0): void
    {
        if ($depth > 20) {
            throw new ConfigurationException('Form nesting too deep.');
        }
        foreach ($children as $child) {
            if (! is_array($child) || count($nodes) >= 500) {
                throw new ConfigurationException('Invalid form structure.');
            }
            if (in_array($child['elType'] ?? '', [self::TYPE, 'e-form'], true)) {
                throw new ConfigurationException('Nested forms are not supported.');
            }
            $nodes[] = $child;
            self::flatten($child['elements'] ?? [], $nodes, $depth + 1);
        }
    }
}
