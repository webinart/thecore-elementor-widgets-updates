<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms;

use TheCore\ElementorWidgets\FormSecurity\Support\ContextToken;
use Throwable;

final class SubmissionService
{
    public function __construct(
        private readonly FormProvider $forms,
        private readonly SubmissionProtection $security,
        private readonly FleetMonitor $fleet,
        private readonly ContextToken $tokens
    ) {
    }

    public function submit(array $request): array
    {
        if (array_diff(array_keys($request), ['context', 'fields', 'proof', 'website', 'test_token'])) {
            throw new SubmissionException('invalid_request', 'Parametres inconnus.');
        }
        $context = is_string($request['context'] ?? null) ? $this->tokens->decode($request['context']) : null;
        if (! $context || $context->fieldId() !== FormDefinition::SECURITY_FIELD) {
            throw new SubmissionException('invalid_context', 'Formulaire invalide.');
        }
        $definition = $this->forms->find($context->postId(), $context->widgetId());
        $claims = null;
        // A requested test must never fall back to a real submission.
        if (array_key_exists('test_token', $request)) {
            if (! $definition->settings['allow-tests'] || ! is_string($request['test_token']) || $request['test_token'] === '') {
                throw new SubmissionException('test_forbidden', 'Les tests sont desactives ou le jeton est invalide.', 403);
            }
            $claims = $this->fleet->authorize($request['test_token'], $context->postId(), $context->widgetId());
        }
        try {
            $recipient = $definition->settings['recipient'] ?: (string) get_option('admin_email');
            if (! is_email($recipient) || preg_match('/[\r\n]/', $recipient)) {
                throw new ConfigurationException('Invalid recipient.');
            }
            $this->security->check($context, $request);
            $fields = $request['fields'] ?? null;
            if (! is_array($fields) || count($fields) > FormDefinition::MAX_FIELDS) {
                throw new SubmissionException('invalid_fields', 'Champs invalides.');
            }
            $validation = (new FieldValidator())->validate($definition, $fields);
            if ($validation['errors'] !== []) {
                throw new SubmissionException('validation_failed', 'Veuillez corriger les champs indiques.', 422, $validation['errors']);
            }
            $this->security->reserve($context, $validation['values'], $claims['runId'] ?? null);
            if ($claims !== null) {
                $this->report($claims, 'submission_succeeded', ['formIdentifier' => $context->widgetId(), 'postId' => $context->postId()]);
                return ['success' => true, 'mode' => 'dry-run', 'runId' => $claims['runId'],
                    'mailSent' => false, 'deliveryTested' => false,
                    'message' => 'Test reussi : validation effectuee, aucun email envoye.'];
            }
            $body = $definition->settings['form-name'] . "\n\n";
            foreach ($definition->fields as $id => $field) {
                $value = $validation['values'][$id] ?? '';
                $body .= $field['label'] . ': ' . (is_array($value) ? implode(', ', $value) : $value) . "\n\n";
            }
            $subject = trim(str_replace(["\r", "\n"], ' ', $definition->settings['subject']));
            if (! wp_mail($recipient, $subject, $body, ['Content-Type: text/plain; charset=UTF-8'])) {
                throw new SubmissionException('mail_failed', 'Le message n\'a pas pu etre envoye. Veuillez reessayer plus tard.', 503);
            }
            return ['success' => true, 'mode' => 'live', 'message' => $definition->settings['success-message']];
        } catch (Throwable $error) {
            if ($claims !== null) {
                $this->report($claims, 'validation_failed', [
                    'formIdentifier' => $context->widgetId(),
                    'errorCode' => $error instanceof SubmissionException ? $error->errorCode : 'configuration_error',
                    'fieldIds' => $error instanceof SubmissionException ? array_keys($error->fields) : [],
                ]);
            }
            throw $error;
        }
    }

    private function report(array $claims, string $event, array $details): void
    {
        try {
            $this->fleet->report($claims, $event, $details);
        } catch (Throwable) {
            // Monitoring delivery must not change the submission result.
        }
    }
}
