# AGENTS

## Scope

Ce dépôt porte uniquement le plugin `thecore-elementor-widgets`.

## Standards

- PHP orienté objet, namespace `TheCore\\ElementorWidgets\\`
- Structure PSR-4
- Style de code PSR-12 sur `src/` et `tests/`
- Pas de dépendance runtime obligatoire à Composer pour l’exécution du plugin

## Reference Docs

- Investigation Elementor V4 / Atomic: `docs/elementor-v4-atomic-investigation.md`

## Release Notes

- Format beta: `x.x.x-beta.n`
- Format production: `x.x.x`
- Maturité projet: beta puis production
- Le système d’update distant devra reprendre le mécanisme déjà utilisé par le thème `The Core Elementor`
- Secret GitHub Actions attendu pour la publication des updates: `UPDATES_REPO_SSH_KEY`
