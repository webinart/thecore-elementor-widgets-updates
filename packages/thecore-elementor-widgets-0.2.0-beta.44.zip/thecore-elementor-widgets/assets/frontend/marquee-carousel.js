(() => {
    const SELECTOR = '[data-thecore-marquee-track="true"]';

    const loadTrackImages = (track) => {
        track.querySelectorAll('img[data-thecore-marquee-src]').forEach((image) => {
            const source = image.getAttribute('data-thecore-marquee-src');

            if (!source) {
                return;
            }

            image.setAttribute('src', source);
            image.removeAttribute('data-thecore-marquee-src');
            image.classList.remove('is-lazy');
        });
    };

    const initTrack = (track) => {
        if (!(track instanceof HTMLElement) || track.dataset.thecoreMarqueeInitialized === 'true') {
            return;
        }

        track.dataset.thecoreMarqueeInitialized = 'true';

        if (track.dataset.lazy !== '1') {
            return;
        }

        const method = track.dataset.lazyMethod || 'scroll';
        const delay = Number.parseInt(track.dataset.lazyDelay || '1000', 10);

        if (method === 'delay') {
            window.setTimeout(() => {
                loadTrackImages(track);
            }, Number.isNaN(delay) ? 1000 : delay);

            return;
        }

        if ('IntersectionObserver' in window) {
            const observer = new IntersectionObserver(
                (entries) => {
                    entries.forEach((entry) => {
                        if (!entry.isIntersecting) {
                            return;
                        }

                        loadTrackImages(track);
                        observer.unobserve(entry.target);
                    });
                },
                {
                    rootMargin: '200px',
                }
            );

            observer.observe(track);

            return;
        }

        loadTrackImages(track);
    };

    const initTracks = (root = document) => {
        if (!(root instanceof Document) && !(root instanceof HTMLElement)) {
            return;
        }

        root.querySelectorAll(SELECTOR).forEach((track) => {
            initTrack(track);
        });
    };

    const boot = () => {
        initTracks(document);

        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                mutation.addedNodes.forEach((node) => {
                    if (!(node instanceof HTMLElement)) {
                        return;
                    }

                    if (node.matches(SELECTOR)) {
                        initTrack(node);
                        return;
                    }

                    initTracks(node);
                });
            });
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true,
        });
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot, { once: true });
        return;
    }

    boot();
})();
