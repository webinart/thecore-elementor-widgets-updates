(function () {
    var TRACK_SELECTOR = '[data-thecore-marquee-banner-legacy-track="true"]';
    var initializedTracks = [];

    function forEachNode(list, callback) {
        Array.prototype.forEach.call(list, callback);
    }

    function nextFrame(callback) {
        if ('requestAnimationFrame' in window) {
            window.requestAnimationFrame(function () {
                window.requestAnimationFrame(callback);
            });

            return;
        }

        window.setTimeout(callback, 32);
    }

    function loadTrackImages(track) {
        var lazyImages = track.querySelectorAll('img.is-lazy[data-thecore-marquee-src]');

        if (!lazyImages.length) {
            return;
        }

        forEachNode(lazyImages, function (image) {
            var source = image.getAttribute('data-thecore-marquee-src');

            if (!source) {
                return;
            }

            image.src = source;
            image.classList.remove('is-lazy');
            image.removeAttribute('data-thecore-marquee-src');
        });
    }

    function waitForTrackImages(track, callback) {
        var images = track.querySelectorAll('img');
        var pending = 0;
        var resolved = false;

        function finish() {
            if (resolved) {
                return;
            }

            resolved = true;
            nextFrame(callback);
        }

        forEachNode(images, function (image) {
            if (image.complete && image.naturalWidth > 0) {
                return;
            }

            pending++;

            var settle = function () {
                image.removeEventListener('load', settle);
                image.removeEventListener('error', settle);
                pending--;

                if (pending <= 0) {
                    finish();
                }
            };

            image.addEventListener('load', settle);
            image.addEventListener('error', settle);
        });

        if (pending === 0) {
            finish();
        }
    }

    function refreshTrack(track) {
        if (!track || !track.isConnected) {
            return;
        }

        waitForTrackImages(track, function () {
            var distance = Math.max(track.scrollWidth / 2, 0);

            if (!distance) {
                track.classList.remove('is-ready');
                return;
            }

            track.style.setProperty('--thecore-marquee-distance', distance + 'px');
            track.classList.add('is-ready');
        });
    }

    function primeTrack(track) {
        loadTrackImages(track);
        refreshTrack(track);
    }

    function observeTrack(track) {
        if ('IntersectionObserver' in window) {
            var observer = new IntersectionObserver(function (entries, instance) {
                forEachNode(entries, function (entry) {
                    if (!entry.isIntersecting) {
                        return;
                    }

                    primeTrack(track);
                    instance.unobserve(entry.target);
                });
            }, { rootMargin: '200px' });

            observer.observe(track);

            return;
        }

        primeTrack(track);
    }

    function initTrack(track) {
        if (!track || track.dataset.thecoreMarqueeLegacyInitialized === '1') {
            return;
        }

        track.dataset.thecoreMarqueeLegacyInitialized = '1';
        initializedTracks.push(track);

        if (track.dataset.lazy !== '1') {
            refreshTrack(track);
            return;
        }

        if (track.dataset.lazyMethod === 'delay') {
            window.setTimeout(function () {
                primeTrack(track);
            }, parseInt(track.dataset.lazyDelay || '1000', 10));

            return;
        }

        observeTrack(track);
    }

    function boot(context) {
        if (!context || !context.querySelectorAll) {
            return;
        }

        forEachNode(context.querySelectorAll(TRACK_SELECTOR), initTrack);
    }

    function refreshInitializedTracks() {
        initializedTracks = initializedTracks.filter(function (track) {
            return !!track && track.isConnected;
        });

        forEachNode(initializedTracks, function (track) {
            if (!track.classList.contains('is-ready')) {
                return;
            }

            track.classList.remove('is-ready');
            refreshTrack(track);
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () {
            boot(document);
        });
    } else {
        boot(document);
    }

    window.addEventListener('load', function () {
        refreshInitializedTracks();
    });
    window.addEventListener('resize', refreshInitializedTracks);
    window.addEventListener('orientationchange', refreshInitializedTracks);

    if (window.elementorFrontend && window.elementorFrontend.hooks) {
        window.elementorFrontend.hooks.addAction(
            'frontend/element_ready/thecore-marquee-banner-legacy.default',
            function ($scope) {
                if ($scope && $scope[0]) {
                    boot($scope[0]);
                }
            }
        );
    }
})();
