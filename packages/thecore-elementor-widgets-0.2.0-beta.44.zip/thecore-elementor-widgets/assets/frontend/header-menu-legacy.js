(() => {
	'use strict';

	const HEADER_MENU_SELECTOR = '.thecore-header-menu-legacy';
	const initializedWidgets = new WeakSet();

	const setExpanded = (element, state) => {
		element.setAttribute('aria-expanded', state ? 'true' : 'false');
	};

	const closeAllSubmenus = (root) => {
		const openItems = root.querySelectorAll('.menu-item-has-children.is-submenu-open');
		openItems.forEach((item) => item.classList.remove('is-submenu-open'));

		const expandedButtons = root.querySelectorAll('.thecore-header-menu-legacy__submenu-toggle[aria-expanded="true"]');
		expandedButtons.forEach((button) => setExpanded(button, false));
	};

	const initMenu = (root) => {
		if (!(root instanceof HTMLElement) || initializedWidgets.has(root)) {
			return;
		}

		initializedWidgets.add(root);

		const toggle = root.querySelector('.thecore-header-menu-legacy__toggle');
		const nav = root.querySelector('.thecore-header-menu-legacy__nav');
		const breakpoint = parseInt(root.getAttribute('data-breakpoint'), 10) || 1024;
		const submenuButtons = root.querySelectorAll('.thecore-header-menu-legacy__submenu-toggle');

		if (toggle && nav && !nav.id) {
			nav.id = `thecore-header-menu-legacy-nav-${Math.random().toString(36).slice(2, 10)}`;
			toggle.setAttribute('aria-controls', nav.id);
		}

		submenuButtons.forEach((button) => {
			button.addEventListener('click', (event) => {
				event.preventDefault();
				event.stopPropagation();

				const item = button.closest('.menu-item-has-children');
				if (!item) {
					return;
				}

				const isOpen = item.classList.toggle('is-submenu-open');
				setExpanded(button, isOpen);
			});
		});

		const resetDesktopState = () => {
			if (window.innerWidth > breakpoint) {
				root.classList.remove('is-open');
				closeAllSubmenus(root);

				if (toggle) {
					setExpanded(toggle, false);
				}
			}
		};

		if (toggle) {
			toggle.addEventListener('click', () => {
				const isOpen = root.classList.toggle('is-open');
				setExpanded(toggle, isOpen);
			});
		}

		root.addEventListener('keydown', (event) => {
			if (event.key !== 'Escape') {
				return;
			}

			root.classList.remove('is-open');
			closeAllSubmenus(root);

			if (toggle) {
				setExpanded(toggle, false);
				toggle.focus();
			}
		});

		resetDesktopState();
		window.addEventListener('resize', resetDesktopState);
	};

	const initMenusInScope = (scope) => {
		if (!(scope instanceof HTMLElement || scope instanceof Document)) {
			return;
		}

		if (scope instanceof HTMLElement && scope.matches(HEADER_MENU_SELECTOR)) {
			if (!initializedWidgets.has(scope)) {
				initMenu(scope);
			}
		}

		const menus = scope.querySelectorAll(HEADER_MENU_SELECTOR);
		menus.forEach((menu) => {
			if (!initializedWidgets.has(menu)) {
				initMenu(menu);
			}
		});
	};

	const boot = () => {
		initMenusInScope(document);

		const observer = new MutationObserver((mutations) => {
			mutations.forEach((mutation) => {
				mutation.addedNodes.forEach((node) => {
					if (node instanceof HTMLElement) {
						initMenusInScope(node);
					}
				});
			});
		});

		observer.observe(document.documentElement, {
			childList: true,
			subtree: true,
		});
	};

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', boot);
	} else {
		boot();
	}
})();
