(function () {
	"use strict";

	let shortcutBound = false;

	function getConfig() {
		return window.TheCoreElementorWidgetsSearchModal || {};
	}

	function escapeHtml(value) {
		return String(value || "")
			.replace(/&/g, "&amp;")
			.replace(/</g, "&lt;")
			.replace(/>/g, "&gt;")
			.replace(/"/g, "&quot;")
			.replace(/'/g, "&#039;");
	}

	function getIconMarkup(icon) {
		switch (icon) {
			case "file":
				return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7z"></path><path d="M14 2v4a2 2 0 0 0 2 2h4"></path></svg>';
			case "calendar":
				return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 2v4"></path><path d="M16 2v4"></path><rect width="18" height="18" x="3" y="4" rx="2"></rect><path d="M3 10h18"></path></svg>';
			case "arrow":
				return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"></path><path d="m13 5 7 7-7 7"></path></svg>';
			case "search":
			default:
				return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><path d="m21 21-4.3-4.3"></path></svg>';
		}
	}

	class TheCoreSearchModalLegacy {
		constructor(root) {
			this.root = root;
			this.root.__thecoreSearchModalLegacy = this;
			this.modal = root.querySelector(".thecore-search-modal-legacy__modal");
			this.trigger = root.querySelector(".thecore-search-modal-legacy__trigger");
			this.input = root.querySelector(".thecore-search-modal-legacy__input");
			this.clearButton = root.querySelector(".thecore-search-modal-legacy__clear");
			this.closeButtons = Array.from(root.querySelectorAll("[data-close-search='true']"));
			this.resultsList = root.querySelector(".thecore-search-modal-legacy__results");
			this.resultsPanel = root.querySelector(".thecore-search-modal-legacy__panel--results");
			this.emptyPanel = root.querySelector(".thecore-search-modal-legacy__panel--empty");
			this.noResultsPanel = root.querySelector(".thecore-search-modal-legacy__panel--no-results");
			this.noResultsText = root.querySelector(".thecore-search-modal-legacy__no-results-text");
			this.chips = Array.from(root.querySelectorAll("[data-search-term]"));
			this.postTypes = this.parsePostTypes(root.dataset.postTypes);
			this.resultsLimit = parseInt(root.dataset.resultsLimit || "8", 10);
			this.searchUrl = root.dataset.searchUrl || window.location.origin + "/";
			this.results = [];
			this.selectedIndex = 0;
			this.abortController = null;
			this.searchTimer = null;
			this.lastFocusedElement = null;
			this.bindEvents();
		}

		parsePostTypes(postTypesJson) {
			try {
				const parsed = JSON.parse(postTypesJson || "[]");
				return Array.isArray(parsed) ? parsed : ["post", "page"];
			} catch (error) {
				return ["post", "page"];
			}
		}

		bindEvents() {
			if (this.trigger) {
				this.trigger.addEventListener("click", () => this.open());
			}

			this.closeButtons.forEach((button) => {
				button.addEventListener("click", () => this.close());
			});

			if (this.clearButton) {
				this.clearButton.addEventListener("click", () => {
					this.input.value = "";
					this.updateClearButton();
					this.showEmptyState();
					this.input.focus();
				});
			}

			if (this.input) {
				this.input.addEventListener("input", () => this.handleInput());
				this.input.addEventListener("keydown", (event) => this.handleKeyDown(event));
			}

			this.chips.forEach((chip) => {
				chip.addEventListener("click", () => {
					const term = chip.getAttribute("data-search-term") || "";
					this.input.value = term;
					this.updateClearButton();
					this.performSearch(term);
					this.input.focus();
				});
			});
		}

		open() {
			document.querySelectorAll(".thecore-search-modal-legacy.is-open").forEach((node) => {
				if (node !== this.root && node.__thecoreSearchModalLegacy) {
					node.__thecoreSearchModalLegacy.close(false);
				}
			});

			this.lastFocusedElement = document.activeElement;
			this.root.classList.add("is-open");
			this.modal.hidden = false;
			document.body.classList.add("thecore-search-modal-legacy-lock");

			if (this.trigger) {
				this.trigger.setAttribute("aria-expanded", "true");
			}

			window.setTimeout(() => {
				if (this.input) {
					this.input.focus();
				}
			}, 10);
		}

		close(restoreFocus = true) {
			this.root.classList.remove("is-open");
			this.modal.hidden = true;
			document.body.classList.remove("thecore-search-modal-legacy-lock");

			if (this.trigger) {
				this.trigger.setAttribute("aria-expanded", "false");
			}

			if (this.abortController) {
				this.abortController.abort();
				this.abortController = null;
			}

			window.clearTimeout(this.searchTimer);
			if (this.input) {
				this.input.value = "";
			}
			this.updateClearButton();
			this.showEmptyState();

			if (restoreFocus && this.lastFocusedElement && typeof this.lastFocusedElement.focus === "function") {
				this.lastFocusedElement.focus();
			}
		}

		handleInput() {
			const query = this.input.value.trim();
			this.updateClearButton();

			if (!query) {
				this.showEmptyState();
				return;
			}

			window.clearTimeout(this.searchTimer);
			this.searchTimer = window.setTimeout(() => {
				this.performSearch(query);
			}, 180);
		}

		handleKeyDown(event) {
			if (event.key === "Escape") {
				event.preventDefault();
				this.close();
				return;
			}

			if (event.key === "ArrowDown") {
				if (!this.results.length) {
					return;
				}

				event.preventDefault();
				this.selectedIndex = Math.min(this.selectedIndex + 1, this.results.length - 1);
				this.syncActiveResult();
				return;
			}

			if (event.key === "ArrowUp") {
				if (!this.results.length) {
					return;
				}

				event.preventDefault();
				this.selectedIndex = Math.max(this.selectedIndex - 1, 0);
				this.syncActiveResult();
				return;
			}

			if (event.key === "Enter") {
				const query = this.input.value.trim();
				if (!query) {
					return;
				}

				event.preventDefault();

				if (this.results[this.selectedIndex]) {
					window.location.assign(this.results[this.selectedIndex].url);
					return;
				}

				const targetUrl = new URL(this.searchUrl, window.location.origin);
				targetUrl.searchParams.set("s", query);
				window.location.assign(targetUrl.toString());
			}
		}

		updateClearButton() {
			if (!this.clearButton || !this.input) {
				return;
			}

			this.clearButton.hidden = !this.input.value.trim();
		}

		showEmptyState() {
			this.results = [];
			this.selectedIndex = 0;
			this.resultsList.innerHTML = "";
			this.resultsPanel.hidden = true;
			this.noResultsPanel.hidden = true;
			this.emptyPanel.hidden = false;
		}

		showNoResults(query) {
			this.results = [];
			this.selectedIndex = 0;
			this.resultsList.innerHTML = "";
			this.resultsPanel.hidden = true;
			this.emptyPanel.hidden = true;
			this.noResultsPanel.hidden = false;

			if (this.noResultsText) {
				this.noResultsText.textContent = 'Aucun resultat pour "' + query + '". Essayez avec d autres mots-cles.';
			}
		}

		renderResults(results) {
			this.results = Array.isArray(results) ? results : [];
			this.selectedIndex = 0;

			if (!this.results.length) {
				this.showNoResults(this.input.value.trim());
				return;
			}

			const markup = this.results
				.map((result, index) => {
					const badge = result.typeLabel ? '<span class="thecore-search-modal-legacy__result-badge">' + escapeHtml(result.typeLabel) + "</span>" : "";
					const description = result.description ? '<p class="thecore-search-modal-legacy__result-description">' + escapeHtml(result.description) + "</p>" : "";

					return (
						'<li class="thecore-search-modal-legacy__result-item" role="option" aria-selected="' + (index === this.selectedIndex ? "true" : "false") + '">' +
							'<button class="thecore-search-modal-legacy__result' + (index === this.selectedIndex ? " is-active" : "") + '" type="button" data-result-index="' + index + '" data-result-url="' + escapeHtml(result.url) + '">' +
								'<span class="thecore-search-modal-legacy__result-icon" aria-hidden="true">' + getIconMarkup(result.icon) + "</span>" +
								'<span class="thecore-search-modal-legacy__result-content">' +
									'<span class="thecore-search-modal-legacy__result-meta">' +
										'<span class="thecore-search-modal-legacy__result-title">' + escapeHtml(result.title) + "</span>" +
										badge +
									"</span>" +
									description +
								"</span>" +
								'<span class="thecore-search-modal-legacy__result-arrow" aria-hidden="true">' + getIconMarkup("arrow") + "</span>" +
							"</button>" +
						"</li>"
					);
				})
				.join("");

			this.resultsList.innerHTML = markup;
			this.resultsPanel.hidden = false;
			this.emptyPanel.hidden = true;
			this.noResultsPanel.hidden = true;

			this.resultsList.querySelectorAll(".thecore-search-modal-legacy__result").forEach((button) => {
				button.addEventListener("mouseenter", () => {
					this.selectedIndex = parseInt(button.getAttribute("data-result-index") || "0", 10);
					this.syncActiveResult();
				});

				button.addEventListener("click", () => {
					const url = button.getAttribute("data-result-url");
					if (url) {
						window.location.assign(url);
					}
				});
			});
		}

		syncActiveResult() {
			const items = Array.from(this.resultsList.querySelectorAll(".thecore-search-modal-legacy__result-item"));
			items.forEach((item, index) => {
				const button = item.querySelector(".thecore-search-modal-legacy__result");
				const isActive = index === this.selectedIndex;
				item.setAttribute("aria-selected", isActive ? "true" : "false");

				if (button) {
					button.classList.toggle("is-active", isActive);
					if (isActive) {
						button.scrollIntoView({ block: "nearest" });
					}
				}
			});
		}

		async performSearch(query) {
			const trimmedQuery = (query || "").trim();
			if (!trimmedQuery) {
				this.showEmptyState();
				return;
			}

			if (this.abortController) {
				this.abortController.abort();
			}

			this.abortController = new AbortController();

			const params = new URLSearchParams();
			params.append("action", getConfig().action || "thecore_elementor_widgets_search_modal");
			params.append("nonce", getConfig().nonce || "");
			params.append("query", trimmedQuery);
			params.append("limit", String(this.resultsLimit || 8));
			params.append("post_types", JSON.stringify(this.postTypes));

			try {
				const response = await fetch(getConfig().ajaxUrl, {
					method: "POST",
					credentials: "same-origin",
					headers: {
						"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
					},
					body: params.toString(),
					signal: this.abortController.signal
				});

				const payload = await response.json();
				const results = payload && payload.success && payload.data ? payload.data.results : [];
				this.renderResults(results);
			} catch (error) {
				if (error && error.name === "AbortError") {
					return;
				}

				this.showNoResults(trimmedQuery);
			}
		}
	}

	function bindGlobalShortcut() {
		if (shortcutBound) {
			return;
		}

		document.addEventListener("keydown", function (event) {
			if (!((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k")) {
				return;
			}

			const activeElement = document.activeElement;
			if (
				activeElement &&
				!activeElement.closest(".thecore-search-modal-legacy") &&
				(activeElement.tagName === "INPUT" ||
					activeElement.tagName === "TEXTAREA" ||
					activeElement.tagName === "SELECT" ||
					activeElement.isContentEditable)
			) {
				return;
			}

			const root = document.querySelector(".thecore-search-modal-legacy[data-shortcut='yes']");
			if (root && root.__thecoreSearchModalLegacy) {
				event.preventDefault();
				root.__thecoreSearchModalLegacy.open();
			}
		});

		shortcutBound = true;
	}

	function init(scope) {
		const context = scope || document;
		context.querySelectorAll(".thecore-search-modal-legacy").forEach((root) => {
			if (!root.__thecoreSearchModalLegacy) {
				new TheCoreSearchModalLegacy(root);
			}
		});

		bindGlobalShortcut();
	}

	function bindElementorHook(attempt) {
		const currentAttempt = attempt || 0;

		if (window.elementorFrontend && window.elementorFrontend.hooks) {
			window.elementorFrontend.hooks.addAction("frontend/element_ready/thecore-search-modal-legacy.default", function ($scope) {
				const scopeNode = $scope && $scope[0] ? $scope[0] : $scope;
				if (scopeNode && typeof scopeNode.querySelectorAll === "function") {
					init(scopeNode);
				}
			});
			return;
		}

		if (currentAttempt < 20) {
			window.setTimeout(function () {
				bindElementorHook(currentAttempt + 1);
			}, 300);
		}
	}

	if (document.readyState === "loading") {
		document.addEventListener("DOMContentLoaded", function () {
			init(document);
		});
	} else {
		init(document);
	}

	bindElementorHook();
})();
