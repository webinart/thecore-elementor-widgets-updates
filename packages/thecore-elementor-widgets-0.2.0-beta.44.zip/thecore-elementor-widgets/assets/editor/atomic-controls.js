(() => {
    const registerControls = () => {
        const elementorV2 = window.elementorV2 || {};
        const registry = elementorV2.editorEditingPanel && elementorV2.editorEditingPanel.controlsRegistry;
        const controls = elementorV2.editorControls;
        const props = elementorV2.editorProps;

        if (!registry || !controls || !props) {
            return false;
        }

        const hasColorControl =
            typeof registry.get === 'function' ? Boolean(registry.get('thecore-color')) : false;
        const hasFontFamilyControl =
            typeof registry.get === 'function' ? Boolean(registry.get('thecore-font-family')) : false;
        const hasZeroDefaultSizeControl =
            typeof registry.get === 'function' ? Boolean(registry.get('thecore-size-zero-default')) : false;
        const hasMarqueeItemsControl =
            typeof registry.get === 'function' ? Boolean(registry.get('thecore-marquee-items')) : false;

        if (!hasColorControl) {
            registry.register('thecore-color', controls.ColorControl, 'full', props.colorPropTypeUtil);
        }

        if (!hasFontFamilyControl) {
            const React = window.React;

            const FontFamilyControl = (controlProps) => {
                const { value, setValue } = controls.useBoundProp(props.stringPropTypeUtil);
                const options = Array.isArray(controlProps.options) ? controlProps.options : [];
                const normalizedValue = typeof value === 'string' ? value : '';
                const hasPreset = options.some((option) => option && option.value === normalizedValue);
                const customOptionValue = '__custom__';
                const [selectedValue, setSelectedValue] = React.useState(
                    hasPreset ? normalizedValue : customOptionValue
                );

                React.useEffect(() => {
                    setSelectedValue(hasPreset ? normalizedValue : customOptionValue);
                }, [hasPreset, normalizedValue]);

                return React.createElement(
                    'div',
                    {
                        style: {
                            display: 'grid',
                            gap: '8px',
                        },
                    },
                    React.createElement(
                        'select',
                        {
                            value: selectedValue,
                            onChange: (event) => {
                                const nextValue = event.target.value;
                                setSelectedValue(nextValue);

                                if (customOptionValue === nextValue) {
                                    return;
                                }

                                setValue(nextValue);
                            },
                            style: {
                                width: '100%',
                                minHeight: '34px',
                                border: '1px solid #d5d8dc',
                                borderRadius: '6px',
                                padding: '0 10px',
                                backgroundColor: '#fff',
                                color: '#1c1f23',
                            },
                        },
                            options.map((option) =>
                                React.createElement(
                                    'option',
                                    {
                                    key: option.value,
                                    value: option.value,
                                },
                                option.label
                            )
                        ),
                        React.createElement(
                            'option',
                            {
                                value: customOptionValue,
                            },
                            'Custom value'
                        )
                    ),
                    selectedValue === customOptionValue
                        ? React.createElement('input', {
                            type: 'text',
                            value: normalizedValue,
                            placeholder: controlProps.placeholder || 'Enter a custom font-family value',
                            onChange: (event) => {
                                setValue(event.target.value);
                            },
                            style: {
                                width: '100%',
                                minHeight: '34px',
                                border: '1px solid #d5d8dc',
                                borderRadius: '6px',
                                padding: '0 10px',
                                backgroundColor: '#fff',
                                color: '#1c1f23',
                            },
                        })
                        : null
                );
            };

            registry.register('thecore-font-family', FontFamilyControl, 'full', props.stringPropTypeUtil);
        }

        if (!hasZeroDefaultSizeControl) {
            const React = window.React;

            const normalizeSizeValue = (value, defaultUnit, units) => {
                const fallbackUnit =
                    typeof defaultUnit === 'string' && units.includes(defaultUnit) ? defaultUnit : units[0] || 'px';

                if (!value || typeof value !== 'object') {
                    return {
                        size: 0,
                        unit: fallbackUnit,
                    };
                }

                const nextUnit =
                    typeof value.unit === 'string' && value.unit.trim() !== '' && units.includes(value.unit)
                        ? value.unit
                        : fallbackUnit;

                const size = value.size;

                if (typeof size === 'number' && !Number.isNaN(size)) {
                    return {
                        size,
                        unit: nextUnit,
                    };
                }

                if (typeof size === 'string' && size.trim() !== '' && !Number.isNaN(Number(size))) {
                    return {
                        size: Number(size),
                        unit: nextUnit,
                    };
                }

                return {
                    size: 0,
                    unit: nextUnit,
                };
            };

            const isValidSizeValue = (value, units) => {
                if (!value || typeof value !== 'object') {
                    return false;
                }

                if (typeof value.unit !== 'string' || !units.includes(value.unit)) {
                    return false;
                }

                return typeof value.size === 'number' && !Number.isNaN(value.size);
            };

            const ZeroDefaultSizeControl = (controlProps) => {
                const { value, setValue } = controls.useBoundProp(props.sizePropTypeUtil);
                const units = Array.isArray(controlProps.units) && controlProps.units.length > 0
                    ? controlProps.units
                    : ['px'];
                const defaultUnit = typeof controlProps.defaultUnit === 'string' ? controlProps.defaultUnit : units[0];
                const normalizedValue = React.useMemo(
                    () => normalizeSizeValue(value, defaultUnit, units),
                    [value, defaultUnit, units]
                );

                React.useEffect(() => {
                    if (!isValidSizeValue(value, units)) {
                        setValue(normalizedValue);
                    }
                }, [normalizedValue, setValue, units, value]);

                return React.createElement(controls.SizeControl, {
                    ...controlProps,
                });
            };

            registry.register(
                'thecore-size-zero-default',
                ZeroDefaultSizeControl,
                'full',
                props.sizePropTypeUtil
            );
        }

        if (!hasMarqueeItemsControl) {
            const React = window.React;
            const wpMedia = window.wp && window.wp.media ? window.wp.media : null;
            const i18n = window.wp && window.wp.i18n ? window.wp.i18n : { __: (value) => value };
            const __ = i18n.__;

            const isTransformable = (value) =>
                Boolean(value) &&
                typeof value === 'object' &&
                typeof value.$$type === 'string' &&
                Object.prototype.hasOwnProperty.call(value, 'value');

            const extractPlainValue = (value, fallback = null) => {
                if (isTransformable(value)) {
                    return value.value;
                }

                return value ?? fallback;
            };

            const toStringValue = (value, fallback = '') => {
                const plainValue = extractPlainValue(value, fallback);

                return typeof plainValue === 'string' ? plainValue : fallback;
            };

            const toNumberValue = (value, fallback = 0) => {
                const plainValue = extractPlainValue(value, fallback);

                return typeof plainValue === 'number' && !Number.isNaN(plainValue)
                    ? plainValue
                    : Number.isFinite(Number(plainValue))
                      ? Number(plainValue)
                      : fallback;
            };

            const toBooleanValue = (value, fallback = false) => {
                const plainValue = extractPlainValue(value, fallback);

                return typeof plainValue === 'boolean'
                    ? plainValue
                    : plainValue === 1 || plainValue === '1' || plainValue === 'true';
            };

            const createStringProp = (value) => ({
                $$type: 'string',
                value: value,
            });

            const createNumberProp = (value) => ({
                $$type: 'number',
                value: value,
            });

            const createBooleanProp = (value) => ({
                $$type: 'boolean',
                value: value,
            });

            const createDefaultItem = () => ({
                imageId: 0,
                imageUrl: '',
                alt: '',
                linkUrl: '',
                linkExternal: false,
                linkNofollow: false,
                itemScale: 1,
                itemPaddingLeft: 0,
                itemPaddingRight: 0,
            });

            const toBoundNumber = (value, fallback, min, max) => {
                const parsedValue = Number(value);

                if (!Number.isFinite(parsedValue)) {
                    return fallback;
                }

                return Math.min(max, Math.max(min, parsedValue));
            };

            const extractItems = (value) => {
                const plainValue = extractPlainValue(value, []);
                const items = Array.isArray(plainValue) ? plainValue : [];

                return items.map((item) => {
                    const plainItem = extractPlainValue(item, {});

                    return {
                        imageId: toNumberValue(plainItem.image_id, 0),
                        imageUrl: toStringValue(plainItem.image_url, ''),
                        alt: toStringValue(plainItem.alt, ''),
                        linkUrl: toStringValue(plainItem.link_url, ''),
                        linkExternal: toBooleanValue(plainItem.link_external, false),
                        linkNofollow: toBooleanValue(plainItem.link_nofollow, false),
                        itemScale: toNumberValue(plainItem.item_scale, 1),
                        itemPaddingLeft: toNumberValue(plainItem.item_padding_left, 0),
                        itemPaddingRight: toNumberValue(plainItem.item_padding_right, 0),
                    };
                });
            };

            const createItemsValue = (items) => ({
                $$type: 'thecore-marquee-items',
                value: items.map((item) => ({
                    $$type: 'thecore-marquee-item',
                    value: {
                        image_id: createNumberProp(item.imageId),
                        image_url: createStringProp(item.imageUrl),
                        alt: createStringProp(item.alt),
                        link_url: createStringProp(item.linkUrl),
                        link_external: createBooleanProp(item.linkExternal),
                        link_nofollow: createBooleanProp(item.linkNofollow),
                        item_scale: createNumberProp(item.itemScale),
                        item_padding_left: createNumberProp(item.itemPaddingLeft),
                        item_padding_right: createNumberProp(item.itemPaddingRight),
                    },
                })),
            });

            const marqueeItemsPropTypeUtil = {
                key: 'thecore-marquee-items',
                schema: null,
                isValid: (value) => value === null || Array.isArray(value),
                extract: (value) => extractItems(value),
                create: (value) => createItemsValue(Array.isArray(value) ? value : []),
            };

            const panelStyles = {
                display: 'grid',
                gap: '12px',
            };

            const cardStyles = {
                border: '1px solid #d5d8dc',
                borderRadius: '8px',
                backgroundColor: '#fff',
                padding: '12px',
                display: 'grid',
                gap: '12px',
            };

            const sectionTitleStyles = {
                fontSize: '12px',
                fontWeight: 600,
                color: '#1c1f23',
                margin: 0,
            };

            const labelStyles = {
                display: 'grid',
                gap: '6px',
                fontSize: '12px',
                color: '#1c1f23',
            };

            const textFieldStyles = {
                width: '100%',
                minHeight: '34px',
                border: '1px solid #d5d8dc',
                borderRadius: '6px',
                padding: '0 10px',
                backgroundColor: '#fff',
                color: '#1c1f23',
                boxSizing: 'border-box',
            };

            const checkboxRowStyles = {
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                fontSize: '12px',
                color: '#1c1f23',
            };

            const buttonBaseStyles = {
                minHeight: '32px',
                borderRadius: '6px',
                border: '1px solid #d5d8dc',
                backgroundColor: '#fff',
                color: '#1c1f23',
                padding: '0 12px',
                cursor: 'pointer',
            };

            const previewStyles = {
                width: '100%',
                aspectRatio: '16 / 9',
                borderRadius: '6px',
                backgroundColor: '#f6f7f7',
                border: '1px solid #d5d8dc',
                display: 'grid',
                placeItems: 'center',
                overflow: 'hidden',
            };

            const MarqueeItemsControl = () => {
                const { value, setValue } = controls.useBoundProp(marqueeItemsPropTypeUtil);
                const items = Array.isArray(value) ? value : [];

                const updateItems = React.useCallback(
                    (nextItems) => {
                        setValue(nextItems);
                    },
                    [setValue]
                );

                const updateItem = React.useCallback(
                    (index, partialItem) => {
                        updateItems(
                            items.map((item, itemIndex) =>
                                itemIndex === index ? { ...item, ...partialItem } : item
                            )
                        );
                    },
                    [items, updateItems]
                );

                const addItem = React.useCallback(() => {
                    updateItems([...items, createDefaultItem()]);
                }, [items, updateItems]);

                const removeItem = React.useCallback(
                    (index) => {
                        updateItems(items.filter((_, itemIndex) => itemIndex !== index));
                    },
                    [items, updateItems]
                );

                const openMediaFrame = React.useCallback(
                    (index) => {
                        if (!wpMedia) {
                            return;
                        }

                        const frame = wpMedia({
                            title: __('Select image', 'thecore-elementor-widgets'),
                            button: {
                                text: __('Use image', 'thecore-elementor-widgets'),
                            },
                            multiple: false,
                            library: {
                                type: 'image',
                            },
                        });

                        frame.on('select', () => {
                            const selection = frame.state().get('selection').first();

                            if (!selection) {
                                return;
                            }

                            const attachment = selection.toJSON();

                            updateItem(index, {
                                imageId: Number.isFinite(Number(attachment.id)) ? Number(attachment.id) : 0,
                                imageUrl: typeof attachment.url === 'string' ? attachment.url : '',
                                alt:
                                    typeof attachment.alt === 'string' && attachment.alt
                                        ? attachment.alt
                                        : typeof attachment.title === 'string'
                                          ? attachment.title
                                          : '',
                            });
                        });

                        frame.open();
                    },
                    [updateItem]
                );

                return React.createElement(
                    'div',
                    {
                        style: panelStyles,
                    },
                    items.length === 0
                        ? React.createElement(
                            'div',
                            {
                                style: {
                                    ...cardStyles,
                                    color: '#50575e',
                                },
                            },
                            __('No items added yet.', 'thecore-elementor-widgets')
                        )
                        : null,
                    items.map((item, index) =>
                        React.createElement(
                            'div',
                            {
                                key: `${index}-${item.imageId}-${item.imageUrl}`,
                                style: cardStyles,
                            },
                            React.createElement(
                                'div',
                                {
                                    style: {
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'space-between',
                                        gap: '12px',
                                    },
                                },
                                React.createElement(
                                    'p',
                                    {
                                        style: sectionTitleStyles,
                                    },
                                    `${__('Item', 'thecore-elementor-widgets')} ${index + 1}`
                                ),
                                React.createElement(
                                    'button',
                                    {
                                        type: 'button',
                                        onClick: () => removeItem(index),
                                        style: {
                                            ...buttonBaseStyles,
                                            borderColor: '#d63638',
                                            color: '#d63638',
                                        },
                                    },
                                    __('Remove', 'thecore-elementor-widgets')
                                )
                            ),
                            React.createElement(
                                'div',
                                {
                                    style: {
                                        display: 'grid',
                                        gap: '10px',
                                    },
                                },
                                React.createElement(
                                    'div',
                                    {
                                        style: previewStyles,
                                    },
                                    item.imageUrl
                                        ? React.createElement('img', {
                                            src: item.imageUrl,
                                            alt: item.alt || '',
                                            style: {
                                                width: '100%',
                                                height: '100%',
                                                objectFit: 'cover',
                                            },
                                        })
                                        : React.createElement(
                                            'span',
                                            {
                                                style: {
                                                    fontSize: '12px',
                                                    color: '#50575e',
                                                },
                                            },
                                            __('No image selected', 'thecore-elementor-widgets')
                                        )
                                ),
                                React.createElement(
                                    'div',
                                    {
                                        style: {
                                            display: 'flex',
                                            gap: '8px',
                                            flexWrap: 'wrap',
                                        },
                                    },
                                    React.createElement(
                                        'button',
                                        {
                                            type: 'button',
                                            onClick: () => openMediaFrame(index),
                                            style: buttonBaseStyles,
                                        },
                                        item.imageUrl
                                            ? __('Replace image', 'thecore-elementor-widgets')
                                            : __('Select image', 'thecore-elementor-widgets')
                                    ),
                                    item.imageUrl
                                        ? React.createElement(
                                            'button',
                                            {
                                                type: 'button',
                                                onClick: () =>
                                                    updateItem(index, {
                                                        imageId: 0,
                                                        imageUrl: '',
                                                        alt: '',
                                                    }),
                                                style: buttonBaseStyles,
                                            },
                                            __('Clear image', 'thecore-elementor-widgets')
                                        )
                                        : null
                                )
                            ),
                            React.createElement(
                                'label',
                                {
                                    style: labelStyles,
                                },
                                __('Alt text', 'thecore-elementor-widgets'),
                                React.createElement('input', {
                                    type: 'text',
                                    value: item.alt,
                                    onChange: (event) => updateItem(index, { alt: event.target.value }),
                                    style: textFieldStyles,
                                })
                            ),
                            React.createElement(
                                'label',
                                {
                                    style: labelStyles,
                                },
                                __('Link URL', 'thecore-elementor-widgets'),
                                React.createElement('input', {
                                    type: 'text',
                                    value: item.linkUrl,
                                    placeholder: 'https://',
                                    onChange: (event) => updateItem(index, { linkUrl: event.target.value }),
                                    style: textFieldStyles,
                                })
                            ),
                            React.createElement(
                                'label',
                                {
                                    style: checkboxRowStyles,
                                },
                                React.createElement('input', {
                                    type: 'checkbox',
                                    checked: item.linkExternal,
                                    onChange: (event) =>
                                        updateItem(index, { linkExternal: event.target.checked }),
                                }),
                                __('Open in new tab', 'thecore-elementor-widgets')
                            ),
                            React.createElement(
                                'label',
                                {
                                    style: checkboxRowStyles,
                                },
                                React.createElement('input', {
                                    type: 'checkbox',
                                    checked: item.linkNofollow,
                                    onChange: (event) =>
                                        updateItem(index, { linkNofollow: event.target.checked }),
                                }),
                                __('Add nofollow', 'thecore-elementor-widgets')
                            ),
                            React.createElement(
                                'div',
                                {
                                    style: {
                                        display: 'grid',
                                        gap: '10px',
                                        gridTemplateColumns: 'repeat(3, minmax(0, 1fr))',
                                    },
                                },
                                React.createElement(
                                    'label',
                                    {
                                        style: labelStyles,
                                    },
                                    __('Scale', 'thecore-elementor-widgets'),
                                    React.createElement('input', {
                                        type: 'number',
                                        min: '0.1',
                                        max: '5',
                                        step: '0.1',
                                        value: item.itemScale,
                                        onChange: (event) =>
                                            updateItem(index, {
                                                itemScale: toBoundNumber(event.target.value, 1, 0.1, 5),
                                            }),
                                        style: textFieldStyles,
                                    })
                                ),
                                React.createElement(
                                    'label',
                                    {
                                        style: labelStyles,
                                    },
                                    __('Padding left', 'thecore-elementor-widgets'),
                                    React.createElement('input', {
                                        type: 'number',
                                        min: '0',
                                        max: '40',
                                        step: '1',
                                        value: item.itemPaddingLeft,
                                        onChange: (event) =>
                                            updateItem(index, {
                                                itemPaddingLeft: toBoundNumber(event.target.value, 0, 0, 40),
                                            }),
                                        style: textFieldStyles,
                                    })
                                ),
                                React.createElement(
                                    'label',
                                    {
                                        style: labelStyles,
                                    },
                                    __('Padding right', 'thecore-elementor-widgets'),
                                    React.createElement('input', {
                                        type: 'number',
                                        min: '0',
                                        max: '40',
                                        step: '1',
                                        value: item.itemPaddingRight,
                                        onChange: (event) =>
                                            updateItem(index, {
                                                itemPaddingRight: toBoundNumber(event.target.value, 0, 0, 40),
                                            }),
                                        style: textFieldStyles,
                                    })
                                )
                            )
                        )
                    ),
                    React.createElement(
                        'button',
                        {
                            type: 'button',
                            onClick: addItem,
                            style: {
                                ...buttonBaseStyles,
                                justifySelf: 'start',
                            },
                        },
                        __('Add item', 'thecore-elementor-widgets')
                    )
                );
            };

            registry.register(
                'thecore-marquee-items',
                MarqueeItemsControl,
                'full',
                marqueeItemsPropTypeUtil
            );
        }

        return true;
    };

    const boot = () => {
        if (registerControls()) {
            return;
        }

        let attempts = 0;
        const maxAttempts = 40;
        const timer = window.setInterval(() => {
            attempts += 1;

            if (registerControls() || attempts >= maxAttempts) {
                window.clearInterval(timer);
            }
        }, 250);
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot, { once: true });
        return;
    }

    boot();
})();
