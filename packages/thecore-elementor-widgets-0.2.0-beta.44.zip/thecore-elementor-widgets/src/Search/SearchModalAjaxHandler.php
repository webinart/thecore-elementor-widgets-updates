<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Search;

use TheCore\ElementorWidgets\Contracts\Bootable;

final class SearchModalAjaxHandler implements Bootable
{
    public const ACTION = 'thecore_elementor_widgets_search_modal';
    public const NONCE_ACTION = 'thecore_elementor_widgets_search_modal';

    public function register(): void
    {
        add_action('wp_ajax_' . self::ACTION, [$this, 'handle']);
        add_action('wp_ajax_nopriv_' . self::ACTION, [$this, 'handle']);
    }

    public function handle(): void
    {
        check_ajax_referer(self::NONCE_ACTION, 'nonce');

        $query = isset($_POST['query']) ? sanitize_text_field(wp_unslash($_POST['query'])) : '';
        $limit = isset($_POST['limit']) ? absint($_POST['limit']) : 8;

        if ('' === trim($query)) {
            wp_send_json_success(
                [
                    'results' => [],
                ]
            );
        }

        $postTypes = $this->sanitizeRequestedPostTypes(
            isset($_POST['post_types']) ? wp_unslash($_POST['post_types']) : ''
        );

        $searchQuery = new \WP_Query(
            [
                'post_type' => $postTypes,
                'post_status' => 'publish',
                'posts_per_page' => max(1, min(12, $limit)),
                's' => $query,
                'ignore_sticky_posts' => true,
                'no_found_rows' => true,
            ]
        );

        $results = [];

        if ($searchQuery->have_posts()) {
            foreach ($searchQuery->posts as $post) {
                if (! $post instanceof \WP_Post) {
                    continue;
                }

                $results[] = $this->prepareSearchResult($post);
            }
        }

        wp_send_json_success(
            [
                'results' => $results,
            ]
        );
    }

    /**
     * @param string|array<mixed> $rawPostTypes
     *
     * @return array<int, string>
     */
    private function sanitizeRequestedPostTypes(string|array $rawPostTypes): array
    {
        $decoded = [];

        if (is_string($rawPostTypes) && '' !== $rawPostTypes) {
            $maybeJson = json_decode($rawPostTypes, true);
            if (is_array($maybeJson)) {
                $decoded = $maybeJson;
            } else {
                $decoded = explode(',', $rawPostTypes);
            }
        } elseif (is_array($rawPostTypes)) {
            $decoded = $rawPostTypes;
        }

        $decoded = array_map(
            static fn (mixed $postType): string => sanitize_key((string) $postType),
            $decoded
        );
        $decoded = array_values(array_filter(array_unique($decoded)));

        $allowed = get_post_types(
            [
                'public' => true,
                'exclude_from_search' => false,
            ],
            'names'
        );

        $allowed = is_array($allowed) ? $allowed : [];
        $postTypes = array_values(array_intersect($decoded, $allowed));

        if ([] === $postTypes) {
            return ['post', 'page'];
        }

        return $postTypes;
    }

    /**
     * @return array{id: int, title: string, description: string, url: string, type: string, typeLabel: string, icon: string}
     */
    private function prepareSearchResult(\WP_Post $post): array
    {
        $postType = (string) get_post_type($post);
        $postTypeObject = get_post_type_object($postType);
        $typeLabel = $postTypeObject && ! empty($postTypeObject->labels->singular_name)
            ? (string) $postTypeObject->labels->singular_name
            : ucfirst($postType);

        return [
            'id' => (int) $post->ID,
            'title' => get_the_title($post),
            'description' => $this->getSearchResultDescription($post),
            'url' => (string) get_permalink($post),
            'type' => $postType,
            'typeLabel' => $typeLabel,
            'icon' => $this->getSearchResultIcon($postType),
        ];
    }

    private function getSearchResultDescription(\WP_Post $post): string
    {
        $excerpt = trim((string) wp_strip_all_tags(get_the_excerpt($post)));

        if ('' !== $excerpt) {
            return wp_trim_words($excerpt, 18, '...');
        }

        $content = get_post_field('post_content', $post);
        $content = strip_shortcodes((string) $content);
        $content = wp_strip_all_tags($content);
        $content = preg_replace('/\s+/', ' ', $content);
        $content = trim((string) $content);

        if ('' === $content) {
            return '';
        }

        return wp_trim_words($content, 18, '...');
    }

    private function getSearchResultIcon(string $postType): string
    {
        return match ($postType) {
            'page' => 'file',
            'post' => 'calendar',
            default => 'search',
        };
    }
}
