<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Support;

final class RequirementsChecker
{
    private const ATOMIC_MODULE_CLASS = '\Elementor\Modules\AtomicWidgets\Module';

    public function isElementorLoaded(): bool
    {
        return defined('ELEMENTOR_VERSION') && did_action('elementor/loaded') > 0;
    }

    public function isAtomicModuleAvailable(): bool
    {
        return $this->isElementorLoaded() && class_exists(self::ATOMIC_MODULE_CLASS);
    }

    public function canRegisterClassicWidgets(): bool
    {
        return $this->isElementorLoaded();
    }

    public function isAtomicExperimentEnabled(): bool
    {
        if (! $this->isAtomicModuleAvailable()) {
            return false;
        }

        if (! class_exists('\Elementor\Plugin')) {
            return false;
        }

        $moduleClass = self::ATOMIC_MODULE_CLASS;

        return \Elementor\Plugin::$instance->experiments->is_feature_active($moduleClass::EXPERIMENT_NAME);
    }

    public function canRegisterAtomicWidgets(): bool
    {
        return $this->isAtomicModuleAvailable() && $this->isAtomicExperimentEnabled();
    }

    public function atomicExperimentName(): string
    {
        if (! class_exists(self::ATOMIC_MODULE_CLASS)) {
            return 'e_atomic_elements';
        }

        $moduleClass = self::ATOMIC_MODULE_CLASS;

        return $moduleClass::EXPERIMENT_NAME;
    }
}
