<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Support;

use TheCore\ElementorWidgets\Contracts\Bootable;

final class ElementorDocumentSaveSanitizer implements Bootable
{
    private const TARGET_WIDGET_TYPE = 'thecore-classic-menu';

    /**
     * @var string[]
     */
    private const LETTER_SPACING_KEYS = [
        'desktop_letter_spacing',
        'overlay_letter_spacing',
    ];

    /**
     * @var string[]
     */
    private const ALLOWED_UNITS = [
        'px',
        'em',
        'rem',
    ];

    public function register(): void
    {
        add_filter('elementor/document/save/data', [$this, 'normalizeFullscreenMenuSettings'], 10, 2);
    }

    /**
     * @param array<string, mixed> $data
     * @param mixed                $document
     *
     * @return array<string, mixed>
     */
    public function normalizeFullscreenMenuSettings(array $data, $document): array
    {
        unset($document);

        if (empty($data['elements']) || ! is_array($data['elements'])) {
            return $data;
        }

        if (! $this->containsTargetWidget($data['elements'])) {
            return $data;
        }

        $data['elements'] = $this->normalizeElements($data['elements']);

        return $data;
    }

    /**
     * @param array<int|string, mixed> $elements
     *
     * @return array<int|string, mixed>
     */
    private function normalizeElements(array $elements): array
    {
        foreach ($elements as $index => $element) {
            if (! is_array($element)) {
                continue;
            }

            if ($this->isTargetWidget($element)) {
                $settings = $element['settings'] ?? [];
                $element['settings'] = $this->normalizeWidgetSettings(is_array($settings) ? $settings : []);
            }

            if (! empty($element['elements']) && is_array($element['elements'])) {
                $element['elements'] = $this->normalizeElements($element['elements']);
            }

            $elements[$index] = $element;
        }

        return $elements;
    }

    /**
     * @param array<int|string, mixed> $elements
     */
    private function containsTargetWidget(array $elements): bool
    {
        foreach ($elements as $element) {
            if (! is_array($element)) {
                continue;
            }

            if ($this->isTargetWidget($element)) {
                return true;
            }

            if (! empty($element['elements']) && is_array($element['elements']) && $this->containsTargetWidget($element['elements'])) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param array<string, mixed> $element
     */
    private function isTargetWidget(array $element): bool
    {
        return self::TARGET_WIDGET_TYPE === ($element['widgetType'] ?? null);
    }

    /**
     * @param array<string, mixed> $settings
     *
     * @return array<string, mixed>
     */
    public function normalizeWidgetSettings(array $settings): array
    {
        foreach (self::LETTER_SPACING_KEYS as $key) {
            $settings[$key] = $this->normalizeSizeTransformable($settings[$key] ?? null);
        }

        return $settings;
    }

    /**
     * @param mixed $value
     *
     * @return array<string, mixed>
     */
    public function normalizeSizeTransformable(mixed $value): array
    {
        $normalized = [
            '$$type' => 'size',
            'value' => $this->normalizeSizeValue(null),
        ];

        if (! is_array($value)) {
            return $normalized;
        }

        if (array_key_exists('disabled', $value) && is_bool($value['disabled'])) {
            $normalized['disabled'] = $value['disabled'];
        }

        $rawValue = $value['value'] ?? $value;

        $normalized['value'] = $this->normalizeSizeValue($rawValue);

        return $normalized;
    }

    /**
     * @param mixed $value
     *
     * @return array<string, float|string>
     */
    private function normalizeSizeValue(mixed $value): array
    {
        if (! is_array($value)) {
            return [
                'size' => 0.0,
                'unit' => 'px',
            ];
        }

        return [
            'size' => $this->normalizeSizeNumber($value['size'] ?? null),
            'unit' => $this->normalizeUnit($value['unit'] ?? null),
        ];
    }

    private function normalizeSizeNumber(mixed $value): float
    {
        if (is_int($value) || is_float($value)) {
            return (float) $value;
        }

        if (is_string($value)) {
            $trimmed = trim($value);

            if ('' !== $trimmed && is_numeric($trimmed)) {
                return (float) $trimmed;
            }
        }

        return 0.0;
    }

    private function normalizeUnit(mixed $value): string
    {
        if (! is_string($value)) {
            return 'px';
        }

        $normalized = strtolower(trim($value));

        if (in_array($normalized, self::ALLOWED_UNITS, true)) {
            return $normalized;
        }

        return 'px';
    }
}
