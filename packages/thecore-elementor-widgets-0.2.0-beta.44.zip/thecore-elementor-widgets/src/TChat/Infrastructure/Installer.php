<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\TChat\Infrastructure;

use function dbDelta;

final class Installer
{
    public static function install(): void
    {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $sql1 = "CREATE TABLE {$wpdb->prefix}tchat_conversations (
            id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            title         VARCHAR(190) NULL,
            unread_count  INT UNSIGNED NOT NULL DEFAULT 0,
            is_active     TINYINT(1) NOT NULL DEFAULT 1,
            customer_uuid CHAR(36) NOT NULL,
            status        ENUM('open','closed') DEFAULT 'open',
            created_at    DATETIME NOT NULL,
            updated_at    DATETIME NOT NULL,
            PRIMARY KEY (id)
        ) {$charset};";
        dbDelta($sql1);

        $sql2 = "CREATE TABLE {$wpdb->prefix}tchat_messages (
            id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            conversation_id BIGINT UNSIGNED NOT NULL,
            sender_type     ENUM('visitor','agent') NOT NULL,
            sender_id       BIGINT UNSIGNED NULL,
            visitor_uuid    CHAR(36) NULL,
            content         TEXT NOT NULL,
            created_at      DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY conv_idx (conversation_id),
            KEY uuid_idx (visitor_uuid)
        ) {$charset};";
        dbDelta($sql2);
    }
}
