<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\TChat\Http;

use WP_REST_Request;
use WP_REST_Server;

final class MessageController
{
    public static function register(): void
    {
        register_rest_route(
            'tchat/v1',
            '/messages',
            [
                'methods' => WP_REST_Server::READABLE,
                'permission_callback' => static fn(): bool => current_user_can('edit_posts'),
                'args' => [
                    'conversation' => [
                        'type' => 'integer',
                        'required' => true,
                    ],
                ],
                'callback' => [self::class, 'get'],
            ]
        );
    }

    /**
     * @return array<int, array<string, mixed>>|\WP_Error
     */
    public static function get(WP_REST_Request $request)
    {
        global $wpdb;

        $conversation_id = (int) $request->get_param('conversation');
        if (! $conversation_id) {
            return new \WP_Error('no_conv', 'Conversation ID manquant', ['status' => 400]);
        }

        $since_sql = '';
        $args = [$conversation_id];

        if ($request->get_param('since')) {
            $since_sql = ' AND created_at > %s';
            $args[] = sanitize_text_field((string) $request['since']);
        }

        $messages = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id,
                        sender_type,
                        sender_id,
                        visitor_uuid,
                        content,
                        created_at
                 FROM {$wpdb->prefix}tchat_messages
                 WHERE conversation_id = %d{$since_sql}
                 ORDER BY created_at ASC",
                $args
            ),
            ARRAY_A
        );

        if (current_user_can('edit_posts')) {
            $wpdb->update(
                "{$wpdb->prefix}tchat_conversations",
                ['unread_count' => 0],
                ['id' => $conversation_id],
                ['%d'],
                ['%d']
            );
        }

        return $messages;
    }
}
