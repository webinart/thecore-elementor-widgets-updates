<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\TChat\Http;

use TheCore\ElementorWidgets\TChat\Support\RealtimeRelay;
use WP_REST_Request;
use WP_REST_Server;

final class PersistController
{
    public static function register(): void
    {
        register_rest_route(
            'tchat/v1',
            '/persist',
            [
                'methods' => WP_REST_Server::CREATABLE,
                'permission_callback' => [self::class, 'permission'],
                'args' => [
                    'conversation_id' => ['type' => 'integer', 'required' => true],
                    'sender_type' => ['type' => 'string', 'required' => true],
                    'sender_id' => ['type' => 'integer'],
                    'content' => ['type' => 'string', 'required' => true],
                ],
                'callback' => [self::class, 'handle'],
            ]
        );
    }

    public static function permission(WP_REST_Request $request): bool
    {
        if (current_user_can('edit_posts')) {
            return true;
        }

        $uuid = sanitize_text_field((string) $request->get_param('visitor_uuid'));
        $conversation_id = (int) $request->get_param('conversation_id');

        return $uuid !== '' && $conversation_id > 0 && self::visitorOwnsConversation($uuid, $conversation_id);
    }

    public static function visitorOwnsConversation(string $visitor_uuid, int $conversation_id): bool
    {
        global $wpdb;

        if ($visitor_uuid === '' || $conversation_id <= 0) {
            return false;
        }

        $customer_uuid = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT customer_uuid
                 FROM {$wpdb->prefix}tchat_conversations
                 WHERE id = %d
                   AND status = 'open'
                   AND COALESCE(is_active, 1) = 1
                 LIMIT 1",
                $conversation_id
            )
        );

        if (! is_string($customer_uuid) || $customer_uuid === '') {
            return false;
        }

        return hash_equals($customer_uuid, $visitor_uuid);
    }

    /**
     * @return array<string, mixed>|\WP_Error
     */
    public static function handle(WP_REST_Request $request)
    {
        global $wpdb;

        $conversation_id = (int) $request['conversation_id'];
        $sender_type = sanitize_key((string) ($request['sender_type'] ?? 'visitor'));
        if (! in_array($sender_type, ['visitor', 'agent'], true)) {
            return new \WP_Error('invalid_sender_type', 'Invalid sender_type', ['status' => 400]);
        }

        $visitor_uuid = sanitize_text_field((string) ($request['visitor_uuid'] ?? ''));
        if ($sender_type === 'visitor' && ! self::visitorOwnsConversation($visitor_uuid, $conversation_id)) {
            return new \WP_Error('invalid_conversation', 'Conversation mismatch', ['status' => 403]);
        }

        $created_at = current_time('mysql', true);

        $data = [
            'conversation_id' => $conversation_id,
            'sender_type' => $sender_type,
            'sender_id' => isset($request['sender_id']) && $request['sender_id'] !== '' ? (int) $request['sender_id'] : null,
            'visitor_uuid' => $visitor_uuid,
            'content' => wp_kses_post((string) $request['content']),
            'created_at' => $created_at,
        ];

        $wpdb->insert(
            "{$wpdb->prefix}tchat_messages",
            $data,
            ['%d', '%s', '%d', '%s', '%s', '%s']
        );

        if ($sender_type === 'visitor') {
            $wpdb->query(
                $wpdb->prepare(
                    "UPDATE {$wpdb->prefix}tchat_conversations
                     SET unread_count = unread_count + 1,
                         updated_at   = %s
                     WHERE id = %d",
                    $created_at,
                    $conversation_id
                )
            );
        } else {
            $wpdb->update(
                "{$wpdb->prefix}tchat_conversations",
                ['updated_at' => $created_at],
                ['id' => $conversation_id],
                ['%s'],
                ['%d']
            );
        }

        $message = [
            'id' => (int) $wpdb->insert_id,
            'conversation_id' => $conversation_id,
            'sender_type' => $sender_type,
            'sender_id' => $data['sender_id'],
            'visitor_uuid' => $visitor_uuid,
            'content' => $data['content'],
            'created_at' => $created_at,
        ];

        RealtimeRelay::dispatchMessage($message);

        return [
            'success' => true,
            'message' => $message,
        ];
    }
}
