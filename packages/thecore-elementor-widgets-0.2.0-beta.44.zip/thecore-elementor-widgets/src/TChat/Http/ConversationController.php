<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\TChat\Http;

use WP_REST_Request;
use WP_REST_Server;

final class ConversationController
{
    public static function register(): void
    {
        register_rest_route(
            'tchat/v1',
            '/conversations',
            [
                'methods' => WP_REST_Server::CREATABLE,
                'permission_callback' => '__return_true',
                'callback' => [self::class, 'create'],
            ]
        );
    }

    /**
     * @return array<string, int>|\WP_Error
     */
    public static function create(WP_REST_Request $request)
    {
        global $wpdb;

        $uuid = sanitize_text_field((string) ($request['uuid'] ?? ''));
        if ($uuid === '') {
            return new \WP_Error('missing_uuid', 'UUID required', ['status' => 400]);
        }

        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT id
                 FROM {$wpdb->prefix}tchat_conversations
                 WHERE customer_uuid = %s
                   AND status = 'open'
                   AND COALESCE(is_active, 1) = 1
                 LIMIT 1",
                $uuid
            ),
            ARRAY_A
        );

        if ($row) {
            return ['id' => (int) $row['id']];
        }

        $wpdb->insert(
            "{$wpdb->prefix}tchat_conversations",
            [
                'customer_uuid' => $uuid,
                'is_active' => 1,
                'status' => 'open',
                'created_at' => current_time('mysql', true),
                'updated_at' => current_time('mysql', true),
            ],
            ['%s', '%d', '%s', '%s', '%s']
        );

        return ['id' => (int) $wpdb->insert_id];
    }
}
