<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\TChat\Support;

final class ModuleSettings
{
    public const OPTION_KEY = 'tchat_module_settings';

    /**
     * @return array<string, mixed>
     */
    public static function defaults(): array
    {
        return [
            'transport_mode' => 'polling',
            'sse_events_url' => '',
            'sse_send_url' => '',
            'visitor_poll_open_ms' => 3000,
            'visitor_poll_idle_ms' => 10000,
            'admin_poll_list_ms' => 5000,
            'admin_poll_conversation_ms' => 3000,
        ];
    }

    public static function register(): void
    {
        register_setting(
            'tchat_module_settings_group',
            self::OPTION_KEY,
            [
                'type' => 'array',
                'sanitize_callback' => [self::class, 'sanitize'],
                'default' => self::defaults(),
            ]
        );
    }

    /**
     * @param mixed $value
     * @return array<string, mixed>
     */
    public static function sanitize($value): array
    {
        $defaults = self::defaults();
        $settings = is_array($value) ? $value : [];

        $transport_mode = isset($settings['transport_mode']) ? sanitize_key((string) $settings['transport_mode']) : $defaults['transport_mode'];
        if (! in_array($transport_mode, ['polling', 'sse', 'auto'], true)) {
            $transport_mode = $defaults['transport_mode'];
        }

        return [
            'transport_mode' => $transport_mode,
            'sse_events_url' => self::sanitizeUrl((string) ($settings['sse_events_url'] ?? '')),
            'sse_send_url' => self::sanitizeUrl((string) ($settings['sse_send_url'] ?? '')),
            'visitor_poll_open_ms' => self::sanitizePositiveInt($settings['visitor_poll_open_ms'] ?? $defaults['visitor_poll_open_ms'], (int) $defaults['visitor_poll_open_ms']),
            'visitor_poll_idle_ms' => self::sanitizePositiveInt($settings['visitor_poll_idle_ms'] ?? $defaults['visitor_poll_idle_ms'], (int) $defaults['visitor_poll_idle_ms']),
            'admin_poll_list_ms' => self::sanitizePositiveInt($settings['admin_poll_list_ms'] ?? $defaults['admin_poll_list_ms'], (int) $defaults['admin_poll_list_ms']),
            'admin_poll_conversation_ms' => self::sanitizePositiveInt($settings['admin_poll_conversation_ms'] ?? $defaults['admin_poll_conversation_ms'], (int) $defaults['admin_poll_conversation_ms']),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function get(): array
    {
        $stored = get_option(self::OPTION_KEY, []);
        $settings = self::sanitize($stored);

        return array_merge(self::defaults(), $settings);
    }

    public static function shouldDispatchRealtime(?array $settings = null): bool
    {
        $settings = $settings ?? self::get();

        if (($settings['transport_mode'] ?? 'polling') === 'polling') {
            return false;
        }

        return (string) ($settings['sse_send_url'] ?? '') !== '';
    }

    /**
     * @return array<string, mixed>
     */
    public static function getFrontendSettings(): array
    {
        $settings = self::get();

        return [
            'mode' => (string) $settings['transport_mode'],
            'sseEventsUrl' => (string) $settings['sse_events_url'],
            'polling' => [
                'visitorOpenMs' => (int) $settings['visitor_poll_open_ms'],
                'visitorIdleMs' => (int) $settings['visitor_poll_idle_ms'],
                'adminListMs' => (int) $settings['admin_poll_list_ms'],
                'adminConversationMs' => (int) $settings['admin_poll_conversation_ms'],
            ],
        ];
    }

    private static function sanitizeUrl(string $url): string
    {
        $url = trim($url);
        if ($url === '') {
            return '';
        }

        return esc_url_raw($url);
    }

    /**
     * @param mixed $value
     */
    private static function sanitizePositiveInt($value, int $fallback): int
    {
        if (! is_numeric($value)) {
            return $fallback;
        }

        return max(250, (int) $value);
    }
}
