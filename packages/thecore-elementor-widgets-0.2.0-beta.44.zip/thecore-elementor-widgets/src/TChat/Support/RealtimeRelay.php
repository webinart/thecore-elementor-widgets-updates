<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\TChat\Support;

final class RealtimeRelay
{
    /**
     * @param array<string, mixed> $payload
     */
    public static function dispatchMessage(array $payload): void
    {
        $settings = ModuleSettings::get();
        if (! ModuleSettings::shouldDispatchRealtime($settings)) {
            return;
        }

        $endpoint = (string) ($settings['sse_send_url'] ?? '');
        if ($endpoint === '') {
            return;
        }

        $response = wp_remote_post(
            $endpoint,
            [
                'body' => wp_json_encode($payload),
                'headers' => [
                    'Content-Type' => 'application/json',
                ],
                'timeout' => 3,
                'sslverify' => self::shouldVerifySsl($endpoint),
            ]
        );

        if (! is_wp_error($response)) {
            return;
        }

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[TChat] Realtime relay error: ' . $response->get_error_message());
        }
    }

    private static function shouldVerifySsl(string $url): bool
    {
        $host = (string) wp_parse_url($url, PHP_URL_HOST);
        if ($host === '') {
            return true;
        }

        if ($host === 'localhost' || $host === '127.0.0.1' || str_ends_with($host, '.local')) {
            return false;
        }

        return true;
    }
}
