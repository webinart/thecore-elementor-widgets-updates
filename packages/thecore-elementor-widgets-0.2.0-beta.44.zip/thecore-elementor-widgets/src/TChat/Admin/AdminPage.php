<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\TChat\Admin;

use TheCore\ElementorWidgets\TChat\Support\ModuleSettings;

final class AdminPage
{
    public static function register(): void
    {
        add_action('admin_menu', [self::class, 'menu']);
        add_action('admin_enqueue_scripts', [self::class, 'assets']);
        add_action('admin_init', [ModuleSettings::class, 'register']);
    }

    public static function menu(): void
    {
        add_menu_page(
            'TChat Conversations',
            'TChat',
            'edit_posts',
            'tchat',
            [self::class, 'renderChat'],
            'dashicons-format-chat',
            55
        );

        add_submenu_page(
            'tchat',
            'Conversations',
            'Conversations',
            'edit_posts',
            'tchat',
            [self::class, 'renderChat']
        );

        add_submenu_page(
            'tchat',
            'TChat Settings',
            'Settings',
            'manage_options',
            'tchat-settings',
            [self::class, 'renderSettings']
        );
    }

    public static function renderChat(): void
    {
        echo '<div id="tchat-admin-root"></div>';
    }

    public static function renderSettings(): void
    {
        $settings = ModuleSettings::get();
        ?>
        <div class="wrap">
            <h1>TChat Settings</h1>
            <form action="options.php" method="post">
                <?php settings_fields('tchat_module_settings_group'); ?>
                <table class="form-table" role="presentation">
                    <tbody>
                    <tr>
                        <th scope="row"><label for="tchat-transport-mode">Transport mode</label></th>
                        <td>
                            <select id="tchat-transport-mode" name="<?php echo esc_attr(ModuleSettings::OPTION_KEY); ?>[transport_mode]">
                                <option value="polling" <?php selected($settings['transport_mode'], 'polling'); ?>>Polling only</option>
                                <option value="sse" <?php selected($settings['transport_mode'], 'sse'); ?>>SSE only</option>
                                <option value="auto" <?php selected($settings['transport_mode'], 'auto'); ?>>Auto (prefer SSE, fallback polling)</option>
                            </select>
                            <p class="description">Polling fonctionne partout. SSE et Auto nécessitent un endpoint d’événements et un endpoint de diffusion.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="tchat-sse-events-url">SSE events URL</label></th>
                        <td>
                            <input id="tchat-sse-events-url" class="regular-text code" type="url" name="<?php echo esc_attr(ModuleSettings::OPTION_KEY); ?>[sse_events_url]" value="<?php echo esc_attr((string) $settings['sse_events_url']); ?>" placeholder="https://tchat.example.com/sse">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="tchat-sse-send-url">SSE send URL</label></th>
                        <td>
                            <input id="tchat-sse-send-url" class="regular-text code" type="url" name="<?php echo esc_attr(ModuleSettings::OPTION_KEY); ?>[sse_send_url]" value="<?php echo esc_attr((string) $settings['sse_send_url']); ?>" placeholder="https://tchat.example.com/send">
                            <p class="description">Le plugin persiste toujours les messages dans WordPress, puis relaie l’événement vers cet endpoint si le transport temps réel est actif.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="tchat-visitor-poll-open-ms">Visitor poll interval (open)</label></th>
                        <td>
                            <input id="tchat-visitor-poll-open-ms" class="small-text" type="number" min="250" step="250" name="<?php echo esc_attr(ModuleSettings::OPTION_KEY); ?>[visitor_poll_open_ms]" value="<?php echo esc_attr((string) $settings['visitor_poll_open_ms']); ?>"> ms
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="tchat-visitor-poll-idle-ms">Visitor poll interval (closed)</label></th>
                        <td>
                            <input id="tchat-visitor-poll-idle-ms" class="small-text" type="number" min="250" step="250" name="<?php echo esc_attr(ModuleSettings::OPTION_KEY); ?>[visitor_poll_idle_ms]" value="<?php echo esc_attr((string) $settings['visitor_poll_idle_ms']); ?>"> ms
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="tchat-admin-poll-list-ms">Admin poll interval (list)</label></th>
                        <td>
                            <input id="tchat-admin-poll-list-ms" class="small-text" type="number" min="250" step="250" name="<?php echo esc_attr(ModuleSettings::OPTION_KEY); ?>[admin_poll_list_ms]" value="<?php echo esc_attr((string) $settings['admin_poll_list_ms']); ?>"> ms
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="tchat-admin-poll-conversation-ms">Admin poll interval (conversation)</label></th>
                        <td>
                            <input id="tchat-admin-poll-conversation-ms" class="small-text" type="number" min="250" step="250" name="<?php echo esc_attr(ModuleSettings::OPTION_KEY); ?>[admin_poll_conversation_ms]" value="<?php echo esc_attr((string) $settings['admin_poll_conversation_ms']); ?>"> ms
                        </td>
                    </tr>
                    </tbody>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    public static function assets(string $hook): void
    {
        if ($hook !== 'toplevel_page_tchat') {
            return;
        }

        $js_file = THECORE_ELEMENTOR_WIDGETS_PATH . 'assets/admin/tchat-admin.js';
        $css_file = THECORE_ELEMENTOR_WIDGETS_PATH . 'assets/admin/tchat-admin.css';
        $version = (string) max(
            @filemtime($js_file) ?: 0,
            @filemtime($css_file) ?: 0,
            @filemtime(THECORE_ELEMENTOR_WIDGETS_FILE) ?: 0
        );

        wp_enqueue_script(
            'tchat-admin',
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/admin/tchat-admin.js',
            ['wp-element', 'wp-api-fetch'],
            $version,
            true
        );

        wp_localize_script(
            'tchat-admin',
            'TCHAT_ADMIN',
            [
                'restUrl' => rest_url('tchat/v1'),
                'nonce' => wp_create_nonce('wp_rest'),
                'userId' => get_current_user_id(),
                'transport' => ModuleSettings::getFrontendSettings(),
            ]
        );

        wp_enqueue_style(
            'tchat-admin',
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/admin/tchat-admin.css',
            [],
            $version
        );
    }
}
