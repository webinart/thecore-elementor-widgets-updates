<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Contracts;

interface Bootable
{
    public function register(): void;
}
