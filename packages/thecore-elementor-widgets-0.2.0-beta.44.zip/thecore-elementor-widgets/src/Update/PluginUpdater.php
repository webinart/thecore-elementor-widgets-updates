<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Update;

use TheCore\ElementorWidgets\Contracts\Bootable;

final class PluginUpdater implements Bootable
{
    protected const DEFAULT_BRANCH = 'main';
    protected const DEFAULT_MANIFEST_BRANCH = 'plugin-updates';
    protected const DEFAULT_REPOSITORY = 'webinart/thecore-elementor-widgets';
    protected const DEFAULT_DISTRIBUTION_REPOSITORY = 'webinart/thecore-elementor-widgets-updates';

    protected static bool $bootstrapped = false;

    public function register(): void
    {
        self::setup();
    }

    public static function setup(): void
    {
        if (self::$bootstrapped) {
            return;
        }

        self::$bootstrapped = true;

        $context = self::getContext();

        if (null === $context || '' === $context['hostname']) {
            return;
        }

        add_filter('update_plugins_' . $context['hostname'], [__CLASS__, 'filterUpdateResponse'], 10, 4);
        add_filter('upgrader_source_selection', [__CLASS__, 'normalizePackageSource'], 10, 4);
    }

    /**
     * @param false|array<string, mixed> $update
     * @param array<string, mixed>       $pluginData
     * @param array<int, string>         $locales
     *
     * @return false|array<string, mixed>
     */
    public static function filterUpdateResponse($update, array $pluginData, string $pluginFile, array $locales = [])
    {
        $context = self::getContext();

        if (null === $context) {
            return $update;
        }

        if ($pluginFile !== $context['plugin']) {
            return $update;
        }

        $updateUri = isset($pluginData['UpdateURI']) ? trim((string) $pluginData['UpdateURI']) : '';

        if ('' === $updateUri || self::normalizeUrl($updateUri) !== self::normalizeUrl($context['update_uri'])) {
            return $update;
        }

        $manifest = self::fetchRemoteManifest($context['manifest_url']);

        if (null !== $manifest) {
            $payload = self::buildUpdatePayloadFromManifest($context, $manifest);

            if (false !== $payload) {
                return $payload;
            }
        }

        $remoteHeaders = self::fetchRemotePluginHeaders(
            $context['repository'],
            $context['branch'],
            $context['entry_file']
        );

        if (null === $remoteHeaders) {
            return $update;
        }

        $payload = self::buildUpdatePayloadFromHeaders($context, $remoteHeaders);

        return false !== $payload ? $payload : $update;
    }

    /**
     * @param mixed                $upgrader
     * @param array<string, mixed> $hookExtra
     *
     * @return string|false
     */
    public static function normalizePackageSource($source, string $remoteSource, $upgrader, array $hookExtra = [])
    {
        if (! is_string($source) || '' === $source || '' === $remoteSource) {
            return $source;
        }

        $context = self::getContext();

        if (null === $context) {
            return $source;
        }

        if (($hookExtra['type'] ?? '') !== 'plugin') {
            return $source;
        }

        $matchesPlugin = ($hookExtra['plugin'] ?? '') === $context['plugin'];
        $matchesBulkUpdate = isset($hookExtra['plugins']) && is_array($hookExtra['plugins']) && in_array($context['plugin'], $hookExtra['plugins'], true);

        if (! $matchesPlugin && ! $matchesBulkUpdate) {
            return $source;
        }

        $expectedDir = $context['slug'];
        $currentDir = basename(rtrim($source, '/\\'));

        if ($currentDir === $expectedDir) {
            return $source;
        }

        global $wp_filesystem;

        if ((! is_object($wp_filesystem) || ! method_exists($wp_filesystem, 'move')) && function_exists('WP_Filesystem')) {
            WP_Filesystem();
        }

        if (! is_object($wp_filesystem) || ! method_exists($wp_filesystem, 'move')) {
            return $source;
        }

        $normalizedRemoteSource = rtrim($remoteSource, '/\\');
        $target = $normalizedRemoteSource . DIRECTORY_SEPARATOR . $expectedDir;

        if (method_exists($wp_filesystem, 'exists') && $wp_filesystem->exists($target) && method_exists($wp_filesystem, 'delete')) {
            $wp_filesystem->delete($target, true);
        }

        $moved = $wp_filesystem->move($source, $target, true);

        if (! $moved) {
            return $source;
        }

        return $target;
    }

    public static function parseRepositoryFromUpdateUri(string $updateUri): string
    {
        $updateUri = trim($updateUri);

        if ('' === $updateUri) {
            return '';
        }

        $parts = parse_url($updateUri);

        if (! is_array($parts) || empty($parts['host']) || empty($parts['path'])) {
            return '';
        }

        if ('github.com' !== strtolower((string) $parts['host'])) {
            return '';
        }

        $segments = array_values(array_filter(explode('/', trim((string) $parts['path'], '/'))));

        if (count($segments) < 2) {
            return '';
        }

        return $segments[0] . '/' . $segments[1];
    }

    public static function normalizeBranch(string $branch): string
    {
        $branch = trim($branch);

        if ('' === $branch) {
            return self::DEFAULT_BRANCH;
        }

        if (0 === strpos($branch, 'refs/heads/')) {
            $branch = substr($branch, strlen('refs/heads/'));
        }

        $branch = trim($branch, '/');

        return '' !== $branch ? $branch : self::DEFAULT_BRANCH;
    }

    public static function normalizeChannel(string $channel): string
    {
        $channel = trim(strtolower($channel));
        $channel = preg_replace('/[^a-z0-9._-]+/', '-', $channel);

        if (! is_string($channel)) {
            return 'prod';
        }

        $channel = trim($channel, '-');
        $channel = preg_replace('/-+/', '-', $channel);

        return is_string($channel) && '' !== $channel ? $channel : 'prod';
    }

    public static function defaultChannelForVersion(string $version): string
    {
        return str_contains(strtolower($version), 'beta') ? 'beta' : 'prod';
    }

    public static function buildPackageUrl(string $repository, string $branch): string
    {
        $repository = trim($repository, '/');
        $branch = self::normalizeBranch($branch);

        if ('' === $repository) {
            return '';
        }

        return 'https://github.com/' . $repository . '/archive/refs/heads/' . self::encodePathSegments($branch) . '.zip';
    }

    public static function buildManifestUrl(string $repository, string $manifestBranch, string $channel): string
    {
        $repository = trim($repository, '/');
        $manifestBranch = self::normalizeBranch($manifestBranch);
        $channel = self::normalizeChannel($channel);

        if ('' === $repository || '' === $manifestBranch || '' === $channel) {
            return '';
        }

        return 'https://raw.githubusercontent.com/' . $repository . '/' . self::encodePathSegments($manifestBranch) . '/' . rawurlencode($channel) . '.json';
    }

    public static function buildReleaseIndexUrl(string $repository): string
    {
        $repository = trim($repository, '/');

        if ('' === $repository) {
            return '';
        }

        return 'https://github.com/' . $repository;
    }

    /**
     * @param array<string, string> $context
     * @param array<string, mixed>  $manifest
     *
     * @return false|array<string, string>
     */
    public static function buildUpdatePayloadFromManifest(array $context, array $manifest)
    {
        $localVersion = isset($context['version']) ? (string) $context['version'] : '';
        $remoteVersion = isset($manifest['version']) ? trim((string) $manifest['version']) : '';
        $package = isset($manifest['package']) ? trim((string) $manifest['package']) : '';

        if ('' === $localVersion || '' === $remoteVersion || '' === $package) {
            return false;
        }

        if (version_compare($remoteVersion, $localVersion, '<=')) {
            return false;
        }

        $payload = [
            'slug' => isset($context['slug']) ? (string) $context['slug'] : '',
            'version' => $remoteVersion,
            'new_version' => $remoteVersion,
            'url' => self::pickManifestString($manifest, ['details_url', 'url'], isset($context['details_url']) ? (string) $context['details_url'] : ''),
            'package' => $package,
        ];

        $requiresPhp = self::pickManifestString($manifest, ['requires_php'], '');

        if ('' !== $requiresPhp) {
            $payload['requires_php'] = $requiresPhp;
        }

        $requiresWp = self::pickManifestString($manifest, ['requires_wp', 'requires'], '');

        if ('' !== $requiresWp) {
            $payload['requires'] = $requiresWp;
        }

        $tested = self::pickManifestString($manifest, ['tested'], '');

        if ('' !== $tested) {
            $payload['tested'] = $tested;
        }

        return $payload;
    }

    /**
     * @param array<string, string> $context
     * @param array<string, string> $remoteHeaders
     *
     * @return false|array<string, string>
     */
    public static function buildUpdatePayloadFromHeaders(array $context, array $remoteHeaders)
    {
        $localVersion = isset($context['version']) ? (string) $context['version'] : '';
        $remoteVersion = isset($remoteHeaders['Version']) ? (string) $remoteHeaders['Version'] : '';

        if ('' === $localVersion || '' === $remoteVersion || version_compare($remoteVersion, $localVersion, '<=')) {
            return false;
        }

        $payload = [
            'slug' => isset($context['slug']) ? (string) $context['slug'] : '',
            'version' => $remoteVersion,
            'new_version' => $remoteVersion,
            'url' => isset($context['source_details_url']) ? (string) $context['source_details_url'] : (isset($context['details_url']) ? (string) $context['details_url'] : ''),
            'package' => self::buildPackageUrl(
                isset($context['repository']) ? (string) $context['repository'] : '',
                isset($context['branch']) ? (string) $context['branch'] : self::DEFAULT_BRANCH
            ),
        ];

        if (! empty($remoteHeaders['RequiresPHP'])) {
            $payload['requires_php'] = (string) $remoteHeaders['RequiresPHP'];
        }

        if (! empty($remoteHeaders['RequiresWP'])) {
            $payload['requires'] = (string) $remoteHeaders['RequiresWP'];
        }

        if (! empty($remoteHeaders['TestedUpTo'])) {
            $payload['tested'] = (string) $remoteHeaders['TestedUpTo'];
        }

        return $payload;
    }

    /**
     * @return array<string, string>|null
     */
    protected static function getContext(): ?array
    {
        $headers = self::readPluginHeaders();
        $updateUri = trim($headers['UpdateURI'] ?? '');
        $parsedRepository = self::parseRepositoryFromUpdateUri($updateUri);
        $repository = self::constantValue('THECORE_ELEMENTOR_WIDGETS_UPDATE_REPOSITORY', '' !== $parsedRepository ? $parsedRepository : self::DEFAULT_REPOSITORY);
        $repository = self::filterValue('thecore_elementor_widgets_update_repository', $repository, $updateUri);
        $repository = trim($repository, '/');

        if ('' === $updateUri || '' === $repository) {
            return null;
        }

        $distributionRepository = self::constantValue(
            'THECORE_ELEMENTOR_WIDGETS_UPDATE_DISTRIBUTION_REPOSITORY',
            self::DEFAULT_DISTRIBUTION_REPOSITORY
        );
        $distributionRepository = self::filterValue(
            'thecore_elementor_widgets_update_distribution_repository',
            $distributionRepository,
            $repository,
            $updateUri
        );
        $distributionRepository = trim($distributionRepository, '/');

        if ('' === $distributionRepository) {
            $distributionRepository = $repository;
        }

        $branch = self::constantValue('THECORE_ELEMENTOR_WIDGETS_UPDATE_BRANCH', self::DEFAULT_BRANCH);
        $branch = self::filterValue('thecore_elementor_widgets_update_branch', $branch, $repository);
        $branch = self::normalizeBranch($branch);

        $channel = self::constantValue(
            'THECORE_ELEMENTOR_WIDGETS_UPDATE_CHANNEL',
            self::defaultChannelForVersion(trim((string) ($headers['Version'] ?? '')))
        );
        $channel = self::filterValue('thecore_elementor_widgets_update_channel', $channel, $branch, $repository);
        $channel = self::normalizeChannel($channel);

        $manifestBranch = self::constantValue(
            'THECORE_ELEMENTOR_WIDGETS_UPDATE_MANIFEST_BRANCH',
            self::DEFAULT_MANIFEST_BRANCH
        );
        $manifestBranch = self::filterValue(
            'thecore_elementor_widgets_update_manifest_branch',
            $manifestBranch,
            $distributionRepository,
            $repository,
            $channel
        );
        $manifestBranch = self::normalizeBranch($manifestBranch);

        $manifestUrl = self::constantValue(
            'THECORE_ELEMENTOR_WIDGETS_UPDATE_MANIFEST_URL',
            self::buildManifestUrl($distributionRepository, $manifestBranch, $channel)
        );
        $manifestUrl = self::filterValue(
            'thecore_elementor_widgets_update_manifest_url',
            $manifestUrl,
            $distributionRepository,
            $channel,
            $manifestBranch,
            $repository
        );

        $slug = dirname(THECORE_ELEMENTOR_WIDGETS_BASENAME);

        return [
            'plugin' => THECORE_ELEMENTOR_WIDGETS_BASENAME,
            'entry_file' => basename(THECORE_ELEMENTOR_WIDGETS_BASENAME),
            'slug' => $slug,
            'version' => trim((string) ($headers['Version'] ?? '')),
            'update_uri' => $updateUri,
            'repository' => $repository,
            'distribution_repository' => $distributionRepository,
            'branch' => $branch,
            'channel' => $channel,
            'manifest_branch' => $manifestBranch,
            'manifest_url' => trim($manifestUrl),
            'hostname' => (string) parse_url($updateUri, PHP_URL_HOST),
            'details_url' => self::buildReleaseIndexUrl($distributionRepository),
            'source_details_url' => 'https://github.com/' . $repository . '/tree/' . self::encodePathSegments($branch),
        ];
    }

    /**
     * @return array<string, string>
     */
    protected static function readPluginHeaders(): array
    {
        $headers = get_file_data(
            THECORE_ELEMENTOR_WIDGETS_FILE,
            [
                'Version' => 'Version',
                'UpdateURI' => 'Update URI',
                'RequiresPHP' => 'Requires PHP',
                'RequiresWP' => 'Requires at least',
                'TestedUpTo' => 'Tested up to',
            ],
            'plugin'
        );

        return is_array($headers) ? array_map('trim', $headers) : [];
    }

    /**
     * @return array<string, mixed>|null
     */
    protected static function fetchRemoteManifest(string $manifestUrl): ?array
    {
        if ('' === $manifestUrl || ! function_exists('wp_remote_get') || ! function_exists('wp_remote_retrieve_response_code') || ! function_exists('wp_remote_retrieve_body')) {
            return null;
        }

        $response = wp_remote_get(
            $manifestUrl,
            [
                'timeout' => 15,
                'headers' => [
                    'Accept' => 'application/json',
                    'User-Agent' => self::buildUserAgent(),
                ],
            ]
        );

        if (! is_array($response) || 200 !== wp_remote_retrieve_response_code($response)) {
            return null;
        }

        $body = wp_remote_retrieve_body($response);

        if (! is_string($body) || '' === $body) {
            return null;
        }

        $manifest = json_decode($body, true);

        return is_array($manifest) ? $manifest : null;
    }

    /**
     * @return array<string, string>|null
     */
    protected static function fetchRemotePluginHeaders(string $repository, string $branch, string $entryFile): ?array
    {
        if (! function_exists('wp_remote_get') || ! function_exists('wp_remote_retrieve_response_code') || ! function_exists('wp_remote_retrieve_body')) {
            return null;
        }

        $url = 'https://api.github.com/repos/' . trim($repository, '/') . '/contents/' . rawurlencode($entryFile) . '?ref=' . rawurlencode(self::normalizeBranch($branch));

        $response = wp_remote_get(
            $url,
            [
                'timeout' => 15,
                'headers' => [
                    'Accept' => 'application/vnd.github+json',
                    'User-Agent' => self::buildUserAgent(),
                ],
            ]
        );

        if (! is_array($response) || 200 !== wp_remote_retrieve_response_code($response)) {
            return null;
        }

        $body = wp_remote_retrieve_body($response);

        if (! is_string($body) || '' === $body) {
            return null;
        }

        $data = json_decode($body, true);

        if (! is_array($data) || empty($data['content']) || ! is_string($data['content'])) {
            return null;
        }

        $encoded = str_replace(["\r", "\n"], '', $data['content']);
        $pluginFile = base64_decode($encoded, true);

        if (! is_string($pluginFile) || '' === $pluginFile) {
            return null;
        }

        return self::parsePluginHeaders($pluginFile);
    }

    /**
     * @return array<string, string>
     */
    public static function parsePluginHeaders(string $pluginFile): array
    {
        $headers = [];
        $patterns = [
            'Version' => '/^[ \t\/*#@]*Version:\s*(.+)$/mi',
            'RequiresPHP' => '/^[ \t\/*#@]*Requires PHP:\s*(.+)$/mi',
            'RequiresWP' => '/^[ \t\/*#@]*Requires at least:\s*(.+)$/mi',
            'TestedUpTo' => '/^[ \t\/*#@]*Tested up to:\s*(.+)$/mi',
        ];

        foreach ($patterns as $key => $pattern) {
            if (1 === preg_match($pattern, $pluginFile, $matches) && isset($matches[1])) {
                $headers[$key] = trim((string) $matches[1]);
            }
        }

        return $headers;
    }

    /**
     * @param array<string, mixed> $manifest
     * @param array<int, string>   $keys
     */
    protected static function pickManifestString(array $manifest, array $keys, string $default = ''): string
    {
        foreach ($keys as $key) {
            if (! isset($manifest[$key])) {
                continue;
            }

            $value = trim((string) $manifest[$key]);

            if ('' !== $value) {
                return $value;
            }
        }

        return $default;
    }

    protected static function buildUserAgent(): string
    {
        $blogVersion = function_exists('get_bloginfo') ? (string) get_bloginfo('version') : 'unknown';
        $home = function_exists('home_url') ? (string) home_url('/') : 'http://localhost';

        return 'WordPress/' . $blogVersion . '; ' . $home . '; The Core Elementor Widgets Updater';
    }

    protected static function encodePathSegments(string $value): string
    {
        $segments = explode('/', trim($value, '/'));
        $segments = array_map('rawurlencode', $segments);

        return implode('/', $segments);
    }

    protected static function normalizeUrl(string $url): string
    {
        return rtrim(trim($url), '/');
    }

    protected static function constantValue(string $constantName, string $default): string
    {
        if (defined($constantName)) {
            $value = constant($constantName);

            if (is_string($value) && '' !== trim($value)) {
                return trim($value);
            }
        }

        return $default;
    }

    private static function filterValue(string $hookName, string $value, mixed ...$args): string
    {
        if (! function_exists('apply_filters')) {
            return $value;
        }

        $filtered = apply_filters($hookName, $value, ...$args);

        return is_string($filtered) ? trim($filtered) : $value;
    }
}
