<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Infrastructure;

final class Autoloader
{
    private const NAMESPACE_PREFIX = 'TheCore\\ElementorWidgets\\';

    private string $baseDirectory;

    public function __construct()
    {
        $this->baseDirectory = dirname(__DIR__) . DIRECTORY_SEPARATOR;
    }

    public function register(): void
    {
        spl_autoload_register([$this, 'loadClass']);
    }

    private function loadClass(string $className): void
    {
        if (! str_starts_with($className, self::NAMESPACE_PREFIX)) {
            return;
        }

        $relativeClass = substr($className, strlen(self::NAMESPACE_PREFIX));
        $relativePath = str_replace('\\', DIRECTORY_SEPARATOR, $relativeClass) . '.php';
        $filePath = $this->baseDirectory . $relativePath;

        if (is_readable($filePath)) {
            require_once $filePath;
        }
    }
}
