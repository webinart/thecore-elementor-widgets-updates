<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Options;

final class OptionsRepository
{
    public const WIDGETS_OPTION = 'thecore_elementor_widgets_widgets_state';
    public const FEATURES_OPTION = 'thecore_elementor_widgets_features_state';

    public function __construct(private readonly StateSanitizer $stateSanitizer)
    {
    }

    /**
     * @param array<string, int> $widgetDefaults
     * @param array<string, int> $featureDefaults
     */
    public function initializeDefaults(array $widgetDefaults, array $featureDefaults): void
    {
        if (false === get_option(self::WIDGETS_OPTION, false)) {
            add_option(self::WIDGETS_OPTION, $widgetDefaults);
        }

        if (false === get_option(self::FEATURES_OPTION, false)) {
            add_option(self::FEATURES_OPTION, $featureDefaults);
        }
    }

    /**
     * @param array<string, int> $defaults
     *
     * @return array<string, int>
     */
    public function getWidgetsState(array $defaults): array
    {
        $stored = get_option(self::WIDGETS_OPTION, []);

        return $this->stateSanitizer->normalize(is_array($stored) ? $stored : [], $defaults);
    }

    /**
     * @param array<string, mixed> $state
     * @param array<string, int>   $defaults
     */
    public function saveWidgetsState(array $state, array $defaults): void
    {
        update_option(
            self::WIDGETS_OPTION,
            $this->stateSanitizer->normalize($state, $defaults)
        );
    }

    /**
     * @param array<string, int> $defaults
     *
     * @return array<string, int>
     */
    public function getFeaturesState(array $defaults): array
    {
        $stored = get_option(self::FEATURES_OPTION, []);

        return $this->stateSanitizer->normalize(is_array($stored) ? $stored : [], $defaults);
    }

    /**
     * @param array<string, mixed> $state
     * @param array<string, int>   $defaults
     */
    public function saveFeaturesState(array $state, array $defaults): void
    {
        update_option(
            self::FEATURES_OPTION,
            $this->stateSanitizer->normalize($state, $defaults)
        );
    }
}
