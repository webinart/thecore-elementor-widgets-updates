<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Options;

final class StateSanitizer
{
    /**
     * @param array<string, mixed> $rawState
     * @param array<string, int>   $defaults
     *
     * @return array<string, int>
     */
    public function normalize(array $rawState, array $defaults): array
    {
        $normalized = [];

        foreach ($defaults as $itemId => $defaultValue) {
            $normalized[$itemId] = $this->toFlag($rawState[$itemId] ?? $defaultValue);
        }

        return $normalized;
    }

    private function toFlag(mixed $value): int
    {
        if (is_bool($value)) {
            return $value ? 1 : 0;
        }

        if (is_numeric($value)) {
            return ((int) $value) === 1 ? 1 : 0;
        }

        if (is_string($value)) {
            return in_array(strtolower($value), ['1', 'true', 'yes', 'on'], true) ? 1 : 0;
        }

        return 0;
    }
}
