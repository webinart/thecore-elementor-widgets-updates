<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Notice;

use TheCore\ElementorWidgets\Contracts\Bootable;
use TheCore\ElementorWidgets\Support\RequirementsChecker;

final class AdminNoticeManager implements Bootable
{
    public function __construct(private readonly RequirementsChecker $requirementsChecker)
    {
    }

    public function register(): void
    {
        add_action('admin_notices', [$this, 'render']);
    }

    public function render(): void
    {
        if (! current_user_can('manage_options')) {
            return;
        }

        if (! $this->requirementsChecker->isElementorLoaded()) {
            $this->printNotice(
                __('The Core - Elementor Widgets requires Elementor to be installed and active.', 'thecore-elementor-widgets'),
                'error'
            );

            return;
        }

        if (! $this->requirementsChecker->isAtomicExperimentEnabled()) {
            $experiment = $this->requirementsChecker->atomicExperimentName();

            $this->printNotice(
                sprintf(
                    /* translators: %s: Elementor experiment key. */
                    __('Atomic widgets are enabled in this plugin, but the Elementor experiment `%s` is not active in the current environment. Atomic widgets will stay unavailable until this experiment is enabled.', 'thecore-elementor-widgets'),
                    $experiment
                ),
                'warning'
            );
        }
    }

    private function printNotice(string $message, string $type): void
    {
        printf(
            '<div class="notice notice-%1$s"><p>%2$s</p></div>',
            esc_attr($type),
            esc_html($message)
        );
    }
}
