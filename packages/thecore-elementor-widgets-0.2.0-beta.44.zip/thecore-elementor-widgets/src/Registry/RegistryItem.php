<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Registry;

final class RegistryItem
{
    public function __construct(
        private readonly string $id,
        private readonly string $title,
        private readonly string $description,
        private readonly bool $enabledByDefault = true
    ) {
    }

    public function id(): string
    {
        return $this->id;
    }

    public function title(): string
    {
        return $this->title;
    }

    public function description(): string
    {
        return $this->description;
    }

    public function enabledByDefault(): bool
    {
        return $this->enabledByDefault;
    }
}
