<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Registry;

final class WidgetsRegistry
{
    /**
     * @return array<string, array{title: string, description: string, enabled_by_default: bool}>
     */
    private function definitions(): array
    {
        return [
            'classic-menu' => [
                'title' => __('Fullscreen Menu', 'thecore-elementor-widgets'),
                'description' => __(
                    'Portage V4 du fullscreen menu legacy avec rendu inline sur desktop, overlay mobile et lecture des items de premier niveau d’un menu WordPress.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => true,
            ],
            'marquee-carousel' => [
                'title' => __('Marquee Carousel', 'thecore-elementor-widgets'),
                'description' => __(
                    'Portage V4 du marquee banner legacy avec défilement infini, items dupliqués pour la boucle continue, réglages par image et lazy loading.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => true,
            ],
            'marquee-banner-legacy' => [
                'title' => __('Marquee Banner (Legacy)', 'thecore-elementor-widgets'),
                'description' => __(
                    'Version Elementor classique du marquee banner historique, avec repeater natif complet pour réordonner et éditer les items plus confortablement.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => true,
            ],
            'header-menu-legacy' => [
                'title' => __('Header Menu (Legacy)', 'thecore-elementor-widgets'),
                'description' => __(
                    'Portage legacy du menu Bellevue avec dropdown desktop, accordéons mobile et lecture directe d’un menu WordPress.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => true,
            ],
            'search-modal-legacy' => [
                'title' => __('Search Modal (Legacy)', 'thecore-elementor-widgets'),
                'description' => __(
                    'Portage legacy de la recherche modale Bellevue avec AJAX, raccourci clavier, recherches populaires et accès rapides.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => true,
            ],
            'accessibility-module-legacy' => [
                'title' => __('Accessibility Module (Legacy)', 'thecore-elementor-widgets'),
                'description' => __(
                    'Portage legacy du panneau d’accessibilité The Core avec cartes d’actions, mask de lecture, contrastes et skip link configurable.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => true,
            ],
            'accessibility-trigger-legacy' => [
                'title' => __('Accessibility Trigger (Legacy)', 'thecore-elementor-widgets'),
                'description' => __(
                    'Portage legacy du bouton de déclenchement du module d’accessibilité The Core.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => true,
            ],
            'tchat' => [
                'title' => __('TChat Module', 'thecore-elementor-widgets'),
                'description' => __(
                    'Module TChat avec modale stylable, transport polling/SSE, et trigger par défaut optionnel.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => true,
            ],
            'tchat-trigger' => [
                'title' => __('TChat Trigger', 'thecore-elementor-widgets'),
                'description' => __(
                    'Bouton de déclenchement séparé du TChat, avec les mêmes contrôles que le trigger du panneau d’accessibilité.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => true,
            ],
        ];
    }

    /**
     * @return array<string, RegistryItem>
     */
    public function all(): array
    {
        $items = [];

        foreach ($this->definitions() as $id => $definition) {
            $item = new RegistryItem(
                $id,
                $definition['title'],
                $definition['description'],
                $definition['enabled_by_default']
            );

            $items[$item->id()] = $item;
        }

        return $items;
    }

    /**
     * @return array<string, int>
     */
    public function defaults(): array
    {
        return [
            'classic-menu' => 1,
            'marquee-carousel' => 1,
            'marquee-banner-legacy' => 1,
            'header-menu-legacy' => 1,
            'search-modal-legacy' => 1,
            'accessibility-module-legacy' => 1,
            'accessibility-trigger-legacy' => 1,
            'tchat' => 1,
            'tchat-trigger' => 1,
        ];
    }
}
