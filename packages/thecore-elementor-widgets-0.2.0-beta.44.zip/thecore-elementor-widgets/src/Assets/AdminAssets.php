<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Assets;

use TheCore\ElementorWidgets\Contracts\Bootable;

final class AdminAssets implements Bootable
{
    private const STYLE_HANDLE = 'thecore-elementor-widgets-admin';

    public function register(): void
    {
        add_action('admin_enqueue_scripts', [$this, 'enqueue']);
    }

    public function enqueue(string $hookSuffix = ''): void
    {
        if (! $this->isPluginPage()) {
            return;
        }

        wp_enqueue_style(
            self::STYLE_HANDLE,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/admin/admin.css',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION
        );
    }

    private function isPluginPage(): bool
    {
        $page = isset($_GET['page']) ? sanitize_key((string) $_GET['page']) : '';

        return in_array($page, ['thecore-elementor-widgets', 'thecore-elementor-features'], true);
    }
}
