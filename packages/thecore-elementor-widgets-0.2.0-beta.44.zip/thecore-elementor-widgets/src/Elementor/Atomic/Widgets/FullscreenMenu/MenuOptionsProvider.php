<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\FullscreenMenu;

final class MenuOptionsProvider
{
    /**
     * @return array<int, array{label: string, value: string}>
     */
    public function getOptions(): array
    {
        $menus = wp_get_nav_menus();

        if (! is_array($menus)) {
            return [];
        }

        $options = [];

        foreach ($menus as $menu) {
            if (! isset($menu->term_id, $menu->name)) {
                continue;
            }

            $options[] = [
                'label' => (string) $menu->name,
                'value' => (string) $menu->term_id,
            ];
        }

        return $options;
    }
}
