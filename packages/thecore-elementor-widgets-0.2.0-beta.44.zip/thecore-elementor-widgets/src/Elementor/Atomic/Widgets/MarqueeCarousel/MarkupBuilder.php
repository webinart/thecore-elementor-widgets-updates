<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\MarqueeCarousel;

final class MarkupBuilder
{
    private const PLACEHOLDER_IMAGE = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==';

    /**
     * @param array<int, array{
     *     image_id: int,
     *     image_url: string,
     *     alt: string,
     *     link_url: string,
     *     link_external: bool,
     *     link_nofollow: bool,
     *     item_scale: float,
     *     item_padding_left: int,
     *     item_padding_right: int
     * }> $items
     */
    public function build(array $items, string $widgetId, bool $lazyLoad, string $lazyMethod, int $lazyDelay): string
    {
        if ([] === $items) {
            return $this->renderEmptyState(
                __('Add at least one image item to render the Marquee Carousel widget.', 'thecore-elementor-widgets')
            );
        }

        $trackId = 'thecore-marquee-track-' . sanitize_html_class($widgetId);
        $markup = '';
        $markup .= '<div';
        $markup .= ' id="' . esc_attr($trackId) . '"';
        $markup .= ' class="thecore-marquee-carousel__track"';
        $markup .= ' data-thecore-marquee-track="true"';
        $markup .= ' data-lazy="' . ($lazyLoad ? '1' : '0') . '"';
        $markup .= ' data-lazy-method="' . esc_attr($lazyMethod) . '"';
        $markup .= ' data-lazy-delay="' . esc_attr((string) $lazyDelay) . '"';
        $markup .= '>';

        for ($loopIndex = 0; $loopIndex < 2; $loopIndex++) {
            $isClone = 1 === $loopIndex;

            foreach ($items as $index => $item) {
                $markup .= $this->renderItem($item, $index, $lazyLoad, $isClone);
            }
        }

        $markup .= '</div>';

        return $markup;
    }

    /**
     * @param array{
     *     image_id: int,
     *     image_url: string,
     *     alt: string,
     *     link_url: string,
     *     link_external: bool,
     *     link_nofollow: bool,
     *     item_scale: float,
     *     item_padding_left: int,
     *     item_padding_right: int
     * } $item
     */
    private function renderItem(array $item, int $index, bool $lazyLoad, bool $isClone): string
    {
        $attributes = [
            'class' => 'thecore-marquee-carousel__item',
            'data-thecore-marquee-item-index' => (string) $index,
        ];

        if ($isClone) {
            $attributes['aria-hidden'] = 'true';
        }

        $markup = '<div' . $this->buildAttributes($attributes) . '>';
        $hasLink = '' !== $item['link_url'];

        if ($hasLink) {
            $markup .= '<a' . $this->buildAttributes($this->buildLinkAttributes($item, $isClone)) . '>';
        }

        $imageAttributes = [
            'class' => 'thecore-marquee-carousel__image' . ($lazyLoad ? ' is-lazy' : ''),
            'alt' => $item['alt'],
            'loading' => 'lazy',
            'decoding' => 'async',
        ];

        if ($lazyLoad) {
            $imageAttributes['src'] = self::PLACEHOLDER_IMAGE;
            $imageAttributes['data-thecore-marquee-src'] = $item['image_url'];
        } else {
            $imageAttributes['src'] = $item['image_url'];
        }

        $markup .= '<img' . $this->buildAttributes($imageAttributes) . ' />';

        if ($hasLink) {
            $markup .= '</a>';
        }

        $markup .= '</div>';

        return $markup;
    }

    /**
     * @param array{
     *     image_id: int,
     *     image_url: string,
     *     alt: string,
     *     link_url: string,
     *     link_external: bool,
     *     link_nofollow: bool,
     *     item_scale: float,
     *     item_padding_left: int,
     *     item_padding_right: int
     * } $item
     *
     * @return array<string, string>
     */
    private function buildLinkAttributes(array $item, bool $isClone): array
    {
        $attributes = [
            'class' => 'thecore-marquee-carousel__link',
            'href' => $item['link_url'],
        ];

        if ($item['link_external']) {
            $attributes['target'] = '_blank';
        }

        $rel = [];

        if ($item['link_nofollow']) {
            $rel[] = 'nofollow';
        }

        if ($item['link_external']) {
            $rel[] = 'noopener';
            $rel[] = 'noreferrer';
        }

        if ([] !== $rel) {
            $attributes['rel'] = implode(' ', array_unique($rel));
        }

        if ($isClone) {
            $attributes['tabindex'] = '-1';
            $attributes['aria-hidden'] = 'true';
        }

        return $attributes;
    }

    private function renderEmptyState(string $message): string
    {
        if (! $this->isElementorEditingContext()) {
            return '';
        }

        return sprintf(
            '<div class="thecore-marquee-carousel__empty">%s</div>',
            esc_html($message)
        );
    }

    /**
     * @param array<string, string> $attributes
     */
    private function buildAttributes(array $attributes): string
    {
        $markup = '';

        foreach ($attributes as $name => $value) {
            $escapedValue = 'href' === $name
                ? esc_url($value)
                : esc_attr($value);

            $markup .= sprintf(
                ' %s="%s"',
                esc_attr($name),
                $escapedValue
            );
        }

        return $markup;
    }

    private function isElementorEditingContext(): bool
    {
        if (! class_exists('\Elementor\Plugin')) {
            return false;
        }

        return \Elementor\Plugin::$instance->editor->is_edit_mode()
            || \Elementor\Plugin::$instance->preview->is_preview_mode();
    }
}
