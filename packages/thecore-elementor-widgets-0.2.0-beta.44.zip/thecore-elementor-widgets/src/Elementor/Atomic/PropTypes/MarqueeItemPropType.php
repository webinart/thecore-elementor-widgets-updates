<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\PropTypes;

use Elementor\Modules\AtomicWidgets\PropTypes\Base\Object_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Boolean_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Number_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;

final class MarqueeItemPropType extends Object_Prop_Type
{
    public static function get_key(): string
    {
        return 'thecore-marquee-item';
    }

    protected function define_shape(): array
    {
        return [
            'image_id' => Number_Prop_Type::make()->default(0),
            'image_url' => String_Prop_Type::make()->default(''),
            'alt' => String_Prop_Type::make()->default(''),
            'link_url' => String_Prop_Type::make()->default(''),
            'link_external' => Boolean_Prop_Type::make()->default(false),
            'link_nofollow' => Boolean_Prop_Type::make()->default(false),
            'item_scale' => Number_Prop_Type::make()->default(1),
            'item_padding_left' => Number_Prop_Type::make()->default(0),
            'item_padding_right' => Number_Prop_Type::make()->default(0),
        ];
    }
}
