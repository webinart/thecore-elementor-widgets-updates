<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\PropTypes;

use Elementor\Modules\AtomicWidgets\PropTypes\Size_Prop_Type;
use Elementor\Modules\AtomicWidgets\Styles\Size_Constants;

final class ZeroableSizePropType extends Size_Prop_Type
{
    public function validate($value): bool
    {
        if ($this->isNormalizableValue($value)) {
            return true;
        }

        return parent::validate($value);
    }

    public function sanitize($value): array
    {
        if (! $this->isNormalizableValue($value)) {
            /** @var array<string, mixed> $sanitized */
            $sanitized = parent::sanitize($value);

            return $sanitized;
        }

        $sanitized = [
            '$$type' => static::get_key(),
            'value' => $this->normalizeSizeValue($this->extractRawValue($value)),
        ];

        if (is_array($value) && array_key_exists('disabled', $value) && is_bool($value['disabled'])) {
            $sanitized['disabled'] = $value['disabled'];
        }

        return $sanitized;
    }

    protected function validate_value($value): bool
    {
        if ($this->isEmptyValue($value)) {
            return true;
        }

        return parent::validate_value($value);
    }

    public function sanitize_value($value): array
    {
        if ($this->isEmptyValue($value)) {
            return $this->normalizeSizeValue($value);
        }

        return parent::sanitize_value($value);
    }

    private function isNormalizableValue(mixed $value): bool
    {
        if (null === $value) {
            return true;
        }

        if (is_int($value) || is_float($value)) {
            return true;
        }

        if (is_string($value)) {
            $trimmed = trim($value);

            return '' === $trimmed || is_numeric($trimmed);
        }

        if (! is_array($value)) {
            return false;
        }

        if (array_key_exists('$$type', $value) || array_key_exists('value', $value)) {
            return true;
        }

        return array_key_exists('size', $value) || array_key_exists('unit', $value);
    }

    /**
     * @param mixed $value
     */
    private function extractRawValue(mixed $value): mixed
    {
        if (! is_array($value)) {
            return $value;
        }

        return $value['value'] ?? $value;
    }

    /**
     * @param mixed $value
     *
     * @return array<string, float|string>
     */
    private function normalizeSizeValue(mixed $value): array
    {
        if (! is_array($value)) {
            return [
                'size' => $this->normalizeSizeNumber($value),
                'unit' => $this->resolveUnit(null),
            ];
        }

        return [
            'size' => $this->normalizeSizeNumber($value['size'] ?? null),
            'unit' => $this->resolveUnit($value['unit'] ?? null),
        ];
    }

    private function normalizeSizeNumber(mixed $value): float
    {
        if (is_int($value) || is_float($value)) {
            return (float) $value;
        }

        if (is_string($value)) {
            $trimmed = trim($value);

            if ('' !== $trimmed && is_numeric($trimmed)) {
                return (float) $trimmed;
            }
        }

        return 0.0;
    }

    private function isEmptyValue(mixed $value): bool
    {
        if (! is_array($value)) {
            return null === $value || (is_string($value) && '' === trim($value));
        }

        if (! array_key_exists('size', $value)) {
            return false;
        }

        $size = $value['size'] ?? null;

        if (! $this->isEmptySize($size)) {
            return false;
        }

        if (! array_key_exists('unit', $value)) {
            return true;
        }

        $unit = $value['unit'];

        if (null === $unit) {
            return true;
        }

        if (! is_string($unit)) {
            return false;
        }

        if ('' === trim($unit)) {
            return true;
        }

        return $this->isAllowedStandardUnit($unit);
    }

    private function isEmptySize(mixed $size): bool
    {
        if (null === $size) {
            return true;
        }

        return is_string($size) && '' === trim($size);
    }

    private function isAllowedStandardUnit(string $unit): bool
    {
        if (in_array($unit, [Size_Constants::UNIT_AUTO, Size_Constants::UNIT_CUSTOM], true)) {
            return false;
        }

        /** @var mixed $availableUnits */
        $availableUnits = $this->get_settings()['available_units'] ?? Size_Constants::standard_units();

        if (! is_array($availableUnits)) {
            return false;
        }

        return in_array($unit, $availableUnits, true);
    }

    private function resolveUnit(mixed $unit): string
    {
        if (is_string($unit) && $this->isAllowedStandardUnit($unit)) {
            return $unit;
        }

        /** @var mixed $defaultUnit */
        $defaultUnit = $this->get_settings()['default_unit'] ?? null;

        if (is_string($defaultUnit) && $this->isAllowedStandardUnit($defaultUnit)) {
            return $defaultUnit;
        }

        /** @var mixed $availableUnits */
        $availableUnits = $this->get_settings()['available_units'] ?? Size_Constants::standard_units();

        if (is_array($availableUnits)) {
            foreach ($availableUnits as $availableUnit) {
                if (is_string($availableUnit) && $this->isAllowedStandardUnit($availableUnit)) {
                    return $availableUnit;
                }
            }
        }

        return 'px';
    }
}
