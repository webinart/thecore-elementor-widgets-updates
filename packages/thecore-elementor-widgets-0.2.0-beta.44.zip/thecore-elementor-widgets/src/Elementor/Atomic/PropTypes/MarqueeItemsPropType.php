<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\PropTypes;

use Elementor\Modules\AtomicWidgets\PropTypes\Base\Array_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Contracts\Prop_Type;

final class MarqueeItemsPropType extends Array_Prop_Type
{
    public static function get_key(): string
    {
        return 'thecore-marquee-items';
    }

    protected function define_item_type(): Prop_Type
    {
        return MarqueeItemPropType::make();
    }
}
