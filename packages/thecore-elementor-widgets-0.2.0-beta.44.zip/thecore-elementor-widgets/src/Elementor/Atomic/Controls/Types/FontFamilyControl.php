<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Controls\Types;

use Elementor\Modules\AtomicWidgets\Controls\Base\Atomic_Control_Base;

final class FontFamilyControl extends Atomic_Control_Base
{
    /**
     * @var array<int, array{label: string, value: string}>
     */
    private array $options = [
        [
            'label' => 'Inherit',
            'value' => 'inherit',
        ],
        [
            'label' => 'Primary Global Font',
            'value' => 'var(--e-global-typography-primary-font-family)',
        ],
        [
            'label' => 'Secondary Global Font',
            'value' => 'var(--e-global-typography-secondary-font-family)',
        ],
        [
            'label' => 'Text Global Font',
            'value' => 'var(--e-global-typography-text-font-family)',
        ],
        [
            'label' => 'Accent Global Font',
            'value' => 'var(--e-global-typography-accent-font-family)',
        ],
        [
            'label' => 'System UI',
            'value' => 'system-ui, sans-serif',
        ],
        [
            'label' => 'Arial',
            'value' => 'Arial, sans-serif',
        ],
        [
            'label' => 'Helvetica Neue',
            'value' => '"Helvetica Neue", Arial, sans-serif',
        ],
        [
            'label' => 'Georgia',
            'value' => 'Georgia, serif',
        ],
        [
            'label' => 'Times New Roman',
            'value' => '"Times New Roman", serif',
        ],
        [
            'label' => 'DM Sans',
            'value' => '"DM Sans", sans-serif',
        ],
        [
            'label' => 'Poppins',
            'value' => 'Poppins, sans-serif',
        ],
    ];

    public function get_type(): string
    {
        return 'thecore-font-family';
    }

    /**
     * @param array<int, array{label: string, value: string}> $options
     */
    public function set_options(array $options): self
    {
        $this->options = $options;

        return $this;
    }

    public function get_props(): array
    {
        return [
            'options' => $this->options,
            'placeholder' => 'Enter a custom font-family value',
        ];
    }
}
