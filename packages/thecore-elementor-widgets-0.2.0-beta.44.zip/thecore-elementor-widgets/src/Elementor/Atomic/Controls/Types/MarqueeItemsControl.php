<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Controls\Types;

use Elementor\Modules\AtomicWidgets\Controls\Base\Atomic_Control_Base;

final class MarqueeItemsControl extends Atomic_Control_Base
{
    public function get_type(): string
    {
        return 'thecore-marquee-items';
    }

    public function get_props(): array
    {
        return [];
    }
}
