<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Controls\Types;

use Elementor\Modules\AtomicWidgets\Controls\Base\Atomic_Control_Base;

final class ZeroDefaultSizeControl extends Atomic_Control_Base
{
    private ?string $placeholder = null;
    private ?string $variant = 'length';
    private ?array $units = null;
    private ?string $defaultUnit = null;
    private ?bool $disableCustom = false;
    private ?float $min = null;

    public function get_type(): string
    {
        return 'thecore-size-zero-default';
    }

    public function set_placeholder(string $placeholder): self
    {
        $this->placeholder = $placeholder;

        return $this;
    }

    public function set_variant(string $variant): self
    {
        $this->variant = $variant;

        return $this;
    }

    /**
     * @param array<int, string> $units
     */
    public function set_units(array $units): self
    {
        $this->units = $units;

        return $this;
    }

    public function set_default_unit(string $defaultUnit): self
    {
        $this->defaultUnit = $defaultUnit;

        return $this;
    }

    public function set_disable_custom(bool $disableCustom): self
    {
        $this->disableCustom = $disableCustom;

        return $this;
    }

    public function set_min(float $min): self
    {
        $this->min = $min;

        return $this;
    }

    public function get_props(): array
    {
        return [
            'placeholder' => $this->placeholder,
            'variant' => $this->variant,
            'units' => $this->units,
            'defaultUnit' => $this->defaultUnit,
            'disableCustom' => $this->disableCustom,
            'min' => $this->min,
        ];
    }
}
