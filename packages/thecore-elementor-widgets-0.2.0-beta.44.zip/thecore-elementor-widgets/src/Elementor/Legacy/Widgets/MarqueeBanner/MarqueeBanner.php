<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Legacy\Widgets\MarqueeBanner;

use Elementor\Plugin as ElementorPlugin;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Widget_Base;
use TheCore\ElementorWidgets\Assets\FrontendAssets;

final class MarqueeBanner extends Widget_Base
{
    public function get_name(): string
    {
        return 'thecore-marquee-banner-legacy';
    }

    public function get_title(): string
    {
        return __('Marquee Banner (Legacy)', 'thecore-elementor-widgets');
    }

    public function get_icon(): string
    {
        return 'eicon-slider-push';
    }

    public function get_categories(): array
    {
        return ['basic'];
    }

    public function get_keywords(): array
    {
        return ['marquee', 'carousel', 'legacy', 'logos', 'ticker'];
    }

    public function get_style_depends(): array
    {
        return [FrontendAssets::MARQUEE_BANNER_LEGACY_STYLE];
    }

    public function get_script_depends(): array
    {
        return [FrontendAssets::MARQUEE_BANNER_LEGACY_SCRIPT];
    }

    protected function register_controls(): void
    {
        $this->registerContentControls();
        $this->registerStyleControls();
    }

    protected function render(): void
    {
        $settings = (new DisplaySettings())->normalize($this->get_settings_for_display());
        $images = $settings['images'];

        if ([] === $images) {
            if ($this->isElementorEditingContext()) {
                echo '<div class="thecore-marquee-banner-legacy__empty">'
                    . esc_html__('Add at least one image to render the legacy marquee.', 'thecore-elementor-widgets')
                    . '</div>';
            }

            return;
        }

        $scope = 'thecore-marquee-banner-legacy-' . sanitize_html_class($this->get_id());

        echo '<style>' . $this->buildScopedStyles(
            $scope,
            (float) $settings['marquee_speed'],
            (float) $settings['opacity'],
            (float) $settings['image_gap'],
            (string) $settings['background_color']
        ) . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

        echo '<div class="thecore-marquee-banner-legacy" data-thecore-marquee-banner-legacy-scope="' . esc_attr($scope) . '">';
        echo '<div class="thecore-marquee-banner-legacy__track"'
            . ' data-thecore-marquee-banner-legacy-track="true"'
            . ' data-lazy="' . ($settings['lazy_load'] ? '1' : '0') . '"'
            . ' data-lazy-method="' . esc_attr((string) $settings['lazy_method']) . '"'
            . ' data-lazy-delay="' . esc_attr((string) $settings['lazy_delay']) . '">';

        for ($loopIndex = 0; $loopIndex < 2; $loopIndex++) {
            $isClone = 1 === $loopIndex;

            foreach ($images as $item) {
                echo $this->renderItem($item, (float) $settings['image_size'], (bool) $settings['lazy_load'], $isClone); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            }
        }

        echo '</div>';
        echo '</div>';
    }

    private function registerContentControls(): void
    {
        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Images à faire défiler', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'image',
            [
                'label' => __('Image', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::MEDIA,
                'dynamic' => ['active' => true],
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'item_size',
            [
                'label' => __('Taille individuelle (x)', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::NUMBER,
                'min' => 0.1,
                'max' => 5,
                'step' => 0.1,
                'default' => 1,
                'description' => __('Si vide, la taille globale sera utilisée.', 'thecore-elementor-widgets'),
            ]
        );

        $repeater->add_control(
            'item_padding_left',
            [
                'label' => __('Padding left (px)', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'min' => 0,
                'max' => 40,
                'step' => 1,
                'default' => [
                    'size' => 0,
                ],
            ]
        );

        $repeater->add_control(
            'item_padding_right',
            [
                'label' => __('Padding right (px)', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'min' => 0,
                'max' => 40,
                'step' => 1,
                'default' => [
                    'size' => 0,
                ],
            ]
        );

        $repeater->add_control(
            'alt',
            [
                'label' => __('Texte alternatif', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXT,
                'default' => '',
            ]
        );

        $repeater->add_control(
            'link',
            [
                'label' => __('Lien (optionnel)', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::URL,
                'placeholder' => 'https://',
                'show_external' => true,
            ]
        );

        $this->add_control(
            'images',
            [
                'label' => __('Images', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ alt || image.url || "Item" }}}',
                'default' => [],
            ]
        );

        $this->end_controls_section();
    }

    private function registerStyleControls(): void
    {
        $this->start_controls_section(
            'section_style',
            [
                'label' => __('Style', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'marquee_speed',
            [
                'label' => __('Vitesse du défilement (secondes)', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'min' => 5,
                'max' => 60,
                'step' => 1,
                'default' => [
                    'size' => 18,
                ],
            ]
        );

        $this->add_control(
            'image_size',
            [
                'label' => __('Taille des images (px)', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'min' => 24,
                'max' => 180,
                'step' => 4,
                'default' => [
                    'size' => 80,
                ],
            ]
        );

        $this->add_control(
            'opacity',
            [
                'label' => __('Opacité', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 1,
                'step' => 0.1,
                'default' => 1,
            ]
        );

        $this->add_control(
            'image_gap',
            [
                'label' => __('Gap (px)', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'default' => [
                    'size' => 0,
                ],
            ]
        );

        $this->add_control(
            'background_color',
            [
                'label' => __('Couleur de fond', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'default' => '#FFFBE9',
            ]
        );

        $this->add_control(
            'lazy_load',
            [
                'label' => __('Activer le lazy loading', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' => __('Oui', 'thecore-elementor-widgets'),
                'label_off' => __('Non', 'thecore-elementor-widgets'),
            ]
        );

        $this->add_control(
            'lazy_method',
            [
                'label' => __('Méthode de lazy loading', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'scroll' => __('Au scroll (Intersection Observer)', 'thecore-elementor-widgets'),
                    'delay' => __('Après délai', 'thecore-elementor-widgets'),
                ],
                'default' => 'scroll',
                'condition' => [
                    'lazy_load' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'lazy_delay',
            [
                'label' => __('Délai de chargement (ms)', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::NUMBER,
                'min' => 100,
                'max' => 5000,
                'step' => 100,
                'default' => 1000,
                'condition' => [
                    'lazy_load' => 'yes',
                    'lazy_method' => 'delay',
                ],
            ]
        );

        $this->end_controls_section();
    }

    /**
     * @param array{
     *     image_id: int,
     *     image_url: string,
     *     alt: string,
     *     link_url: string,
     *     link_external: bool,
     *     link_nofollow: bool,
     *     item_scale: float,
     *     item_padding_left: int,
     *     item_padding_right: int
     * } $item
     */
    private function renderItem(array $item, float $globalImageSize, bool $lazy, bool $isClone): string
    {
        $itemScale = $item['item_scale'];
        $paddingLeft = $item['item_padding_left'];
        $paddingRight = $item['item_padding_right'];
        $imageUrl = $item['image_url'];

        if ('' === $imageUrl) {
            return '';
        }

        $attributes = [
            'class' => 'thecore-marquee-banner-legacy__image' . ($lazy ? ' is-lazy' : ''),
            'alt' => $item['alt'],
            'style' => sprintf(
                'height:%spx;width:auto;padding-left:%spx;padding-right:%spx;',
                $this->formatFloat($globalImageSize * $itemScale),
                $this->formatFloat($paddingLeft),
                $this->formatFloat($paddingRight)
            ),
            'decoding' => 'async',
        ];

        if ($lazy) {
            $attributes['src'] = self::placeholderImage();
            $attributes['data-thecore-marquee-src'] = $imageUrl;
        } else {
            $attributes['src'] = $imageUrl;
            $attributes['loading'] = 'eager';
        }

        $markup = '<div class="thecore-marquee-banner-legacy__item">';
        $linkUrl = $item['link_url'];

        if ('' !== $linkUrl) {
            $markup .= '<a' . $this->buildAttributes($this->buildLinkAttributes($item, $isClone)) . '>';
        }

        $markup .= '<img' . $this->buildAttributes($attributes) . ' />';

        if ('' !== $linkUrl) {
            $markup .= '</a>';
        }

        $markup .= '</div>';

        return $markup;
    }

    /**
     * @param array{
     *     link_url: string,
     *     link_external: bool,
     *     link_nofollow: bool
     * } $link
     *
     * @return array<string, string>
     */
    private function buildLinkAttributes(array $link, bool $isClone): array
    {
        $attributes = [
            'class' => 'thecore-marquee-banner-legacy__link',
            'href' => $link['link_url'],
        ];

        if ($link['link_external']) {
            $attributes['target'] = '_blank';
        }

        $rel = [];

        if ($link['link_nofollow']) {
            $rel[] = 'nofollow';
        }

        if ($link['link_external']) {
            $rel[] = 'noopener';
            $rel[] = 'noreferrer';
        }

        if ([] !== $rel) {
            $attributes['rel'] = implode(' ', array_unique($rel));
        }

        if ($isClone) {
            $attributes['tabindex'] = '-1';
            $attributes['aria-hidden'] = 'true';
        }

        return $attributes;
    }

    private function buildScopedStyles(
        string $scope,
        float $speed,
        float $opacity,
        float $imageGap,
        string $backgroundColor
    ): string {
        return sprintf(
            '[data-thecore-marquee-banner-legacy-scope="%1$s"]{background:%2$s;}'
            . '[data-thecore-marquee-banner-legacy-scope="%1$s"] .thecore-marquee-banner-legacy__track{animation-duration:%3$ss;}'
            . '[data-thecore-marquee-banner-legacy-scope="%1$s"] .thecore-marquee-banner-legacy__image{margin-right:%4$spx;opacity:%5$s;}',
            esc_attr($scope),
            esc_attr($backgroundColor),
            esc_attr($this->formatFloat($speed)),
            esc_attr($this->formatFloat($imageGap)),
            esc_attr($this->formatFloat($opacity))
        );
    }

    /**
     * @param array<string, string> $attributes
     */
    private function buildAttributes(array $attributes): string
    {
        $markup = '';

        foreach ($attributes as $name => $value) {
            $escapedValue = 'href' === $name || 'src' === $name || 'data-thecore-marquee-src' === $name
                ? esc_url($value)
                : esc_attr($value);

            $markup .= sprintf(
                ' %s="%s"',
                esc_attr($name),
                $escapedValue
            );
        }

        return $markup;
    }

    private function formatFloat(float $value): string
    {
        return rtrim(rtrim(sprintf('%.3F', $value), '0'), '.');
    }

    private function isElementorEditingContext(): bool
    {
        if (! class_exists('\Elementor\Plugin')) {
            return false;
        }

        return ElementorPlugin::$instance->editor->is_edit_mode()
            || ElementorPlugin::$instance->preview->is_preview_mode();
    }

    private static function placeholderImage(): string
    {
        return 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==';
    }
}
