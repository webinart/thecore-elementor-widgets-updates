<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Legacy\Widgets\AccessibilityTrigger;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Widget_Base;
use TheCore\ElementorWidgets\Assets\FrontendAssets;

final class AccessibilityTrigger extends Widget_Base
{
    public function get_name(): string
    {
        return 'thecore-accessibility-trigger-legacy';
    }

    public function get_title(): string
    {
        return esc_html__('Accessibility Trigger (Legacy)', 'thecore-elementor-widgets');
    }

    public function get_icon(): string
    {
        return 'eicon-button';
    }

    public function get_categories(): array
    {
        return ['basic'];
    }

    public function get_keywords(): array
    {
        return ['accessibility', 'a11y', 'ally', 'trigger', 'elementor'];
    }

    public function get_style_depends(): array
    {
        return [FrontendAssets::ACCESSIBILITY_LEGACY_STYLE];
    }

    public function get_script_depends(): array
    {
        return [FrontendAssets::ACCESSIBILITY_LEGACY_SCRIPT];
    }

    protected function register_controls(): void
    {
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'text',
            [
                'label' => esc_html__('Label', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Open accessibility tools', 'thecore-elementor-widgets'),
                'placeholder' => esc_html__('Open accessibility tools', 'thecore-elementor-widgets'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'aria_label',
            [
                'label' => esc_html__('Aria Label', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXT,
                'default' => '',
                'placeholder' => esc_html__('Open accessibility tools', 'thecore-elementor-widgets'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'show_icon',
            [
                'label' => esc_html__('Show Icon', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'thecore-elementor-widgets'),
                'label_off' => esc_html__('No', 'thecore-elementor-widgets'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'icon_position',
            [
                'label' => esc_html__('Icon Position', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'before' => [
                        'title' => esc_html__('Before', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-h-align-left',
                    ],
                    'after' => [
                        'title' => esc_html__('After', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-h-align-right',
                    ],
                ],
                'default' => 'before',
                'condition' => [
                    'show_icon' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'selected_icon',
            [
                'label' => esc_html__('Icon', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::ICONS,
                'skin' => 'inline',
                'label_block' => false,
                'condition' => [
                    'show_icon' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'alignment',
            [
                'label' => esc_html__('Alignment', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'left',
                'selectors' => [
                    '{{WRAPPER}} .thecore-accessibility-trigger-legacy__wrapper' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'size',
            [
                'label' => esc_html__('Size', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SELECT,
                'default' => 'sm',
                'options' => [
                    'xs' => esc_html__('Extra Small', 'thecore-elementor-widgets'),
                    'sm' => esc_html__('Small', 'thecore-elementor-widgets'),
                    'md' => esc_html__('Medium', 'thecore-elementor-widgets'),
                    'lg' => esc_html__('Large', 'thecore-elementor-widgets'),
                    'xl' => esc_html__('Extra Large', 'thecore-elementor-widgets'),
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style',
            [
                'label' => esc_html__('Button', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'typography',
                'selector' => '{{WRAPPER}} .thecore-accessibility-trigger-legacy',
            ]
        );

        $this->add_control(
            'text_color',
            [
                'label' => esc_html__('Text Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-accessibility-trigger-legacy' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'background_color',
            [
                'label' => esc_html__('Background Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-accessibility-trigger-legacy' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'hover_text_color',
            [
                'label' => esc_html__('Hover Text Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-accessibility-trigger-legacy:hover, {{WRAPPER}} .thecore-accessibility-trigger-legacy:focus' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'hover_background_color',
            [
                'label' => esc_html__('Hover Background Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-accessibility-trigger-legacy:hover, {{WRAPPER}} .thecore-accessibility-trigger-legacy:focus' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'border',
                'selector' => '{{WRAPPER}} .thecore-accessibility-trigger-legacy',
            ]
        );

        $this->add_responsive_control(
            'border_radius',
            [
                'label' => esc_html__('Border Radius', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem'],
                'selectors' => [
                    '{{WRAPPER}} .thecore-accessibility-trigger-legacy' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'padding',
            [
                'label' => esc_html__('Padding', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', 'rem', '%'],
                'selectors' => [
                    '{{WRAPPER}} .thecore-accessibility-trigger-legacy' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_size',
            [
                'label' => esc_html__('Icon Size', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => [
                        'min' => 12,
                        'max' => 64,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .thecore-accessibility-trigger-legacy .elementor-button-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .thecore-accessibility-trigger-legacy .elementor-button-icon svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_gap',
            [
                'label' => esc_html__('Icon Gap', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 40,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .thecore-accessibility-trigger-legacy .elementor-button-content-wrapper' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render(): void
    {
        $settings = $this->get_settings_for_display();
        $text = isset($settings['text']) && is_string($settings['text']) && $settings['text'] !== ''
            ? $settings['text']
            : esc_html__('Open accessibility tools', 'thecore-elementor-widgets');
        $ariaLabel = isset($settings['aria_label']) && is_string($settings['aria_label']) && $settings['aria_label'] !== ''
            ? $settings['aria_label']
            : wp_strip_all_tags($text);
        $showIcon = ($settings['show_icon'] ?? '') === 'yes';
        $iconPosition = ($settings['icon_position'] ?? 'before') === 'after' ? 'after' : 'before';
        $size = isset($settings['size']) && is_string($settings['size']) ? $settings['size'] : 'sm';
        $icon = isset($settings['selected_icon']) && is_array($settings['selected_icon'])
            ? $settings['selected_icon']
            : [];

        $this->add_render_attribute(
            'trigger',
            [
                'class' => [
                    'elementor-button-link',
                    'elementor-button',
                    'elementor-size-' . $size,
                    'thecore-accessibility-trigger-legacy',
                ],
                'href' => '#thecore-accessibility-open',
                'role' => 'button',
                'aria-label' => $ariaLabel,
                'data-thecore-accessibility-trigger' => 'open',
            ]
        );
        ?>
        <div class="elementor-button-wrapper thecore-accessibility-trigger-legacy__wrapper">
            <a <?php $this->print_render_attribute_string('trigger'); ?>>
                <span class="elementor-button-content-wrapper">
                    <?php if ($showIcon && $iconPosition === 'before') : ?>
                        <?php $this->renderIcon($icon); ?>
                    <?php endif; ?>
                    <span class="elementor-button-text"><?php echo esc_html($text); ?></span>
                    <?php if ($showIcon && $iconPosition === 'after') : ?>
                        <?php $this->renderIcon($icon); ?>
                    <?php endif; ?>
                </span>
            </a>
        </div>
        <?php
    }

    private function renderIcon(array $icon = []): void
    {
        ?>
        <span class="elementor-button-icon" aria-hidden="true">
            <?php if (! empty($icon['library'])) : ?>
                <?php Icons_Manager::render_icon($icon, ['aria-hidden' => 'true']); ?>
            <?php else : ?>
                <svg viewBox="0 0 24 24" focusable="false" xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M12 2.5a2.25 2.25 0 1 0 0 4.5a2.25 2.25 0 0 0 0-4.5Zm0 5.75a.75.75 0 0 1 .75.75v4.5h2.625a.75.75 0 0 1 0 1.5H12.75v5.25a.75.75 0 0 1-1.5 0V15H8.625a.75.75 0 0 1 0-1.5h2.625V9a.75.75 0 0 1 .75-.75Z"
                        fill="currentColor"
                    />
                </svg>
            <?php endif; ?>
        </span>
        <?php
    }
}
