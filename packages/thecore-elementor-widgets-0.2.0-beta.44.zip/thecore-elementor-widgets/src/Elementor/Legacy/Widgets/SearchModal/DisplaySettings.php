<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Legacy\Widgets\SearchModal;

final class DisplaySettings
{
    public const DEFAULT_TRIGGER_LABEL = 'Rechercher';
    public const DEFAULT_PLACEHOLDER = 'Rechercher une demarche, un service, un evenement...';
    public const DEFAULT_DIALOG_TITLE = 'Rechercher sur le site';
    public const DEFAULT_RESULTS_LIMIT = 8;

    /**
     * @param array<string, mixed> $settings
     *
     * @return array{
     *     trigger_label: string,
     *     placeholder: string,
     *     dialog_title: string,
     *     results_limit: int,
     *     search_post_types: array<int, string>,
     *     popular_searches: array<int, string>,
     *     quick_links: array<int, array{title: string, url: string, target: bool}>,
     *     enable_shortcut: bool,
     *     show_shortcut_hint: bool
     * }
     */
    public function normalize(array $settings): array
    {
        $searchPostTypes = $this->sanitizeSelectedPostTypes($settings['search_post_types'] ?? []);
        $enableShortcut = $this->toBool($settings['enable_shortcut'] ?? 'yes');

        return [
            'trigger_label' => $this->sanitizeText($settings['trigger_label'] ?? self::DEFAULT_TRIGGER_LABEL, self::DEFAULT_TRIGGER_LABEL),
            'placeholder' => $this->sanitizeText($settings['placeholder'] ?? self::DEFAULT_PLACEHOLDER, self::DEFAULT_PLACEHOLDER),
            'dialog_title' => $this->sanitizeText($settings['dialog_title'] ?? self::DEFAULT_DIALOG_TITLE, self::DEFAULT_DIALOG_TITLE),
            'results_limit' => $this->clampInt($settings['results_limit'] ?? self::DEFAULT_RESULTS_LIMIT, 1, 12, self::DEFAULT_RESULTS_LIMIT),
            'search_post_types' => $searchPostTypes,
            'popular_searches' => $this->sanitizePopularSearches($settings['popular_searches'] ?? []),
            'quick_links' => $this->sanitizeQuickLinks($settings['quick_links'] ?? []),
            'enable_shortcut' => $enableShortcut,
            'show_shortcut_hint' => $enableShortcut && $this->toBool($settings['show_shortcut_hint'] ?? 'yes'),
        ];
    }

    /**
     * @param mixed $selectedPostTypes
     *
     * @return array<int, string>
     */
    private function sanitizeSelectedPostTypes(mixed $selectedPostTypes): array
    {
        $selectedPostTypes = is_array($selectedPostTypes) ? $selectedPostTypes : [];
        $selectedPostTypes = array_map('sanitize_key', $selectedPostTypes);
        $selectedPostTypes = array_values(array_filter(array_unique($selectedPostTypes)));

        $allowed = get_post_types(
            [
                'public' => true,
                'exclude_from_search' => false,
            ],
            'names'
        );

        $allowed = is_array($allowed) ? array_values($allowed) : [];
        $selectedPostTypes = array_values(array_intersect($selectedPostTypes, $allowed));

        if ([] === $selectedPostTypes) {
            return ['post', 'page'];
        }

        return $selectedPostTypes;
    }

    /**
     * @param mixed $popularSearches
     *
     * @return array<int, string>
     */
    private function sanitizePopularSearches(mixed $popularSearches): array
    {
        if (! is_array($popularSearches)) {
            return [];
        }

        $terms = [];

        foreach ($popularSearches as $item) {
            if (! is_array($item)) {
                continue;
            }

            $term = $this->sanitizeText($item['term'] ?? '', '');

            if ('' === $term) {
                continue;
            }

            $terms[] = $term;
        }

        return array_values(array_unique($terms));
    }

    /**
     * @param mixed $quickLinks
     *
     * @return array<int, array{title: string, url: string, target: bool}>
     */
    private function sanitizeQuickLinks(mixed $quickLinks): array
    {
        if (! is_array($quickLinks)) {
            return [];
        }

        $links = [];

        foreach ($quickLinks as $item) {
            if (! is_array($item)) {
                continue;
            }

            $title = $this->sanitizeText($item['title'] ?? '', '');
            $url = '';
            $target = false;

            if (isset($item['url']) && is_array($item['url'])) {
                $url = isset($item['url']['url']) ? esc_url_raw((string) $item['url']['url']) : '';
                $target = ! empty($item['url']['is_external']);
            }

            if ('' === $title || '' === $url) {
                continue;
            }

            $links[] = [
                'title' => $title,
                'url' => $url,
                'target' => $target,
            ];
        }

        return $links;
    }

    private function clampInt(mixed $value, int $min, int $max, int $default): int
    {
        if (! is_numeric($value)) {
            return $default;
        }

        return max($min, min($max, (int) $value));
    }

    private function toBool(mixed $value): bool
    {
        if (is_bool($value)) {
            return $value;
        }

        if (is_numeric($value)) {
            return 1 === (int) $value;
        }

        return is_string($value) && in_array(strtolower($value), ['yes', 'true', 'on'], true);
    }

    private function sanitizeText(mixed $value, string $default): string
    {
        if (! is_scalar($value)) {
            return $default;
        }

        $sanitized = sanitize_text_field((string) $value);

        return '' !== $sanitized ? $sanitized : $default;
    }
}
