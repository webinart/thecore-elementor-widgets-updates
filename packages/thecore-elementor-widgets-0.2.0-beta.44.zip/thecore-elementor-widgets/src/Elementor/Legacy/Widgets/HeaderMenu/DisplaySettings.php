<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Legacy\Widgets\HeaderMenu;

final class DisplaySettings
{
    public const DEFAULT_MODEL = 'home-inspired';
    public const DEFAULT_BREAKPOINT = '1024';

    /**
     * @param array<string, mixed> $settings
     *
     * @return array{
     *     menu_id: int,
     *     menu_model: string,
     *     mobile_breakpoint: string
     * }
     */
    public function normalize(array $settings): array
    {
        return [
            'menu_id' => isset($settings['menu_id']) ? absint($settings['menu_id']) : 0,
            'menu_model' => $this->sanitizeModel($settings['menu_model'] ?? self::DEFAULT_MODEL),
            'mobile_breakpoint' => $this->sanitizeBreakpoint($settings['mobile_breakpoint'] ?? self::DEFAULT_BREAKPOINT),
        ];
    }

    private function sanitizeModel(mixed $value): string
    {
        if (! is_string($value)) {
            return self::DEFAULT_MODEL;
        }

        return in_array($value, ['home-inspired', 'minimal-light'], true)
            ? $value
            : self::DEFAULT_MODEL;
    }

    private function sanitizeBreakpoint(mixed $value): string
    {
        if (! is_scalar($value)) {
            return self::DEFAULT_BREAKPOINT;
        }

        $value = (string) $value;

        return in_array($value, ['768', '1024'], true)
            ? $value
            : self::DEFAULT_BREAKPOINT;
    }
}
