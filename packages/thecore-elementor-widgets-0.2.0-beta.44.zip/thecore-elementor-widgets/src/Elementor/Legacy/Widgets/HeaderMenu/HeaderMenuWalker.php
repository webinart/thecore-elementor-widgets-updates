<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Legacy\Widgets\HeaderMenu;

final class HeaderMenuWalker extends \Walker_Nav_Menu
{
    /**
     * @param object|null $args
     */
    public function start_lvl(&$output, $depth = 0, $args = null): void
    {
        $indent = str_repeat("\t", (int) $depth);

        if (0 === (int) $depth) {
            $output .= "\n{$indent}<div class=\"thecore-header-menu-legacy__submenu-panel\"><ul class=\"sub-menu\">\n";

            return;
        }

        $output .= "\n{$indent}<ul class=\"sub-menu\">\n";
    }

    /**
     * @param object|null $args
     */
    public function end_lvl(&$output, $depth = 0, $args = null): void
    {
        $indent = str_repeat("\t", (int) $depth);

        if (0 === (int) $depth) {
            $output .= "{$indent}</ul></div>\n";

            return;
        }

        $output .= "{$indent}</ul>\n";
    }

    /**
     * @param \WP_Post $dataObject
     * @param object|null $args
     */
    public function start_el(&$output, $dataObject, $depth = 0, $args = null, $currentObjectId = 0): void
    {
        $menuItem = $dataObject;
        $indent = 0 < (int) $depth ? str_repeat("\t", (int) $depth) : '';

        $classes = empty($menuItem->classes) ? [] : (array) $menuItem->classes;
        $classes[] = 'menu-item-' . $menuItem->ID;
        $hasChildren = in_array('menu-item-has-children', $classes, true);

        $args = apply_filters('nav_menu_item_args', $args, $menuItem, $depth);

        $classNames = implode(
            ' ',
            apply_filters('nav_menu_css_class', array_filter($classes), $menuItem, $args, $depth)
        );

        $id = apply_filters('nav_menu_item_id', 'menu-item-' . $menuItem->ID, $menuItem, $args, $depth);

        $liAttributes = [
            'id' => ! empty($id) ? $id : '',
            'class' => ! empty($classNames) ? $classNames : '',
        ];

        $liAttributes = apply_filters('nav_menu_item_attributes', $liAttributes, $menuItem, $args, $depth);

        $output .= $indent . '<li' . $this->build_atts($liAttributes) . '>';

        $title = apply_filters('the_title', $menuItem->title, $menuItem->ID);
        $filteredTitle = $title;
        $title = apply_filters('nav_menu_item_title', $title, $menuItem, $args, $depth);

        $attributes = [
            'target' => ! empty($menuItem->target) ? $menuItem->target : '',
            'rel' => ! empty($menuItem->xfn) ? $menuItem->xfn : '',
            'href' => ! empty($menuItem->url) ? $menuItem->url : '',
            'aria-current' => $menuItem->current ? 'page' : '',
        ];

        if (
            ! empty($menuItem->attr_title)
            && trim(strtolower($menuItem->attr_title)) !== trim(strtolower((string) $menuItem->title))
            && trim(strtolower($menuItem->attr_title)) !== trim(strtolower((string) $filteredTitle))
            && trim(strtolower($menuItem->attr_title)) !== trim(strtolower((string) $title))
        ) {
            $attributes['title'] = $menuItem->attr_title;
        }

        $attributes = apply_filters('nav_menu_link_attributes', $attributes, $menuItem, $args, $depth);

        $itemOutput = $args->before ?? '';
        $itemOutput .= '<a' . $this->build_atts($attributes) . '>';
        $itemOutput .= ($args->link_before ?? '') . $title . ($args->link_after ?? '');
        $itemOutput .= '</a>';

        if ($hasChildren) {
            $itemOutput .= sprintf(
                '<button class="thecore-header-menu-legacy__submenu-toggle" type="button" aria-expanded="false" aria-label="%s"></button>',
                esc_attr(
                    sprintf(
                        /* translators: %s is the menu item title. */
                        __('Toggle submenu %s', 'thecore-elementor-widgets'),
                        wp_strip_all_tags((string) $title)
                    )
                )
            );
        }

        $itemOutput .= $args->after ?? '';

        $output .= apply_filters('walker_nav_menu_start_el', $itemOutput, $menuItem, $depth, $args);
    }
}
