<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Legacy\Widgets\HeaderMenu;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;
use TheCore\ElementorWidgets\Assets\FrontendAssets;

final class HeaderMenu extends Widget_Base
{
    public function get_name(): string
    {
        return 'thecore-header-menu-legacy';
    }

    public function get_title(): string
    {
        return __('Header Menu (Legacy)', 'thecore-elementor-widgets');
    }

    public function get_icon(): string
    {
        return 'eicon-nav-menu';
    }

    public function get_categories(): array
    {
        return ['basic'];
    }

    public function get_keywords(): array
    {
        return ['menu', 'navigation', 'header', 'legacy', 'the core'];
    }

    public function get_style_depends(): array
    {
        return [FrontendAssets::HEADER_MENU_LEGACY_STYLE];
    }

    public function get_script_depends(): array
    {
        return [FrontendAssets::HEADER_MENU_LEGACY_SCRIPT];
    }

    protected function register_controls(): void
    {
        $menus = $this->getAvailableMenus();

        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Content', 'thecore-elementor-widgets'),
            ]
        );

        if ([] === $menus) {
            $this->add_control(
                'menu_notice',
                [
                    'type' => Controls_Manager::RAW_HTML,
                    'raw' => __('No menu found. Create one in Appearance > Menus.', 'thecore-elementor-widgets'),
                    'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
                ]
            );
        }

        $defaultMenuId = '';
        if ([] !== $menus) {
            $firstMenuId = array_key_first($menus);
            $defaultMenuId = null !== $firstMenuId ? (string) $firstMenuId : '';
        }

        $this->add_control(
            'menu_id',
            [
                'label' => __('WordPress Menu', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SELECT,
                'options' => $menus,
                'default' => $defaultMenuId,
            ]
        );

        $this->add_control(
            'menu_model',
            [
                'label' => __('Model', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SELECT,
                'default' => DisplaySettings::DEFAULT_MODEL,
                'options' => [
                    'home-inspired' => __('Default', 'thecore-elementor-widgets'),
                    'minimal-light' => __('Minimal', 'thecore-elementor-widgets'),
                ],
            ]
        );

        $this->add_responsive_control(
            'menu_alignment',
            [
                'label' => __('Alignment', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => __('Left', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'flex-end' => [
                        'title' => __('Right', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .thecore-header-menu-legacy .thecore-header-menu-legacy__list' => 'justify-content: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'mobile_breakpoint',
            [
                'label' => __('Mobile breakpoint', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SELECT,
                'default' => DisplaySettings::DEFAULT_BREAKPOINT,
                'options' => [
                    '768' => __('<= 768px', 'thecore-elementor-widgets'),
                    '1024' => __('<= 1024px', 'thecore-elementor-widgets'),
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_menu',
            [
                'label' => __('Menu Style', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'menu_typography',
                'selector' => '{{WRAPPER}} .thecore-header-menu-legacy .thecore-header-menu-legacy__list > li > a, {{WRAPPER}} .thecore-header-menu-legacy .sub-menu > li > a',
            ]
        );

        $this->add_control(
            'menu_link_color',
            [
                'label' => __('Link color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-header-menu-legacy' => '--thecore-header-menu-legacy-link-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'menu_hover_color',
            [
                'label' => __('Hover color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-header-menu-legacy' => '--thecore-header-menu-legacy-link-hover: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'menu_active_color',
            [
                'label' => __('Active color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-header-menu-legacy' => '--thecore-header-menu-legacy-link-active: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'submenu_bg',
            [
                'label' => __('Submenu background', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-header-menu-legacy' => '--thecore-header-menu-legacy-submenu-bg: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'menu_gap',
            [
                'label' => __('Link spacing', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 80,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 26,
                ],
                'selectors' => [
                    '{{WRAPPER}} .thecore-header-menu-legacy .thecore-header-menu-legacy__list' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'submenu_panel_padding_top',
            [
                'label' => __('Submenu top spacing', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 80,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 10,
                ],
                'selectors' => [
                    '{{WRAPPER}} .thecore-header-menu-legacy .thecore-header-menu-legacy__submenu-panel' => 'padding-top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render(): void
    {
        $settings = (new DisplaySettings())->normalize($this->get_settings_for_display());
        $menuId = $settings['menu_id'];
        $menuModel = $settings['menu_model'];
        $scope = 'thecore-header-menu-legacy-' . $this->get_id();

        $navId = 'thecore-header-menu-legacy-nav-' . $this->get_id();

        $this->add_render_attribute(
            'wrapper',
            [
                'class' => ['thecore-header-menu-legacy', 'thecore-header-menu-legacy--' . $menuModel],
                'data-breakpoint' => $settings['mobile_breakpoint'],
                'data-thecore-header-menu-legacy-scope' => $scope,
            ]
        );

        $menuMarkup = wp_nav_menu(
            [
                'menu' => $menuId,
                'container' => 'nav',
                'container_class' => 'thecore-header-menu-legacy__nav',
                'container_id' => $navId,
                'menu_class' => 'thecore-header-menu-legacy__list',
                'fallback_cb' => false,
                'depth' => 3,
                'walker' => new HeaderMenuWalker(),
                'echo' => false,
            ]
        );

        if (empty($menuMarkup)) {
            echo '<div class="thecore-header-menu-legacy__notice">';
            echo esc_html__('Please select a valid WordPress menu.', 'thecore-elementor-widgets');
            echo '</div>';

            return;
        }

        ?>
        <style>
            <?php echo $this->buildResponsiveInlineStyles($scope, $settings['mobile_breakpoint']); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
        </style>
        <div <?php echo $this->get_render_attribute_string('wrapper'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
            <div class="thecore-header-menu-legacy__inner">
                <button
                    class="thecore-header-menu-legacy__toggle"
                    type="button"
                    aria-expanded="false"
                    aria-controls="<?php echo esc_attr($navId); ?>"
                    aria-label="<?php echo esc_attr__('Toggle navigation', 'thecore-elementor-widgets'); ?>"
                >
                    <span class="thecore-header-menu-legacy__toggle-icon" aria-hidden="true">
                        <span></span>
                        <span></span>
                        <span></span>
                    </span>
                </button>

                <?php echo $menuMarkup; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
            </div>
        </div>
        <?php
    }

    private function buildResponsiveInlineStyles(string $scope, string $breakpoint): string
    {
        $breakpoint = in_array($breakpoint, ['768', '1024'], true)
            ? $breakpoint
            : DisplaySettings::DEFAULT_BREAKPOINT;

        $scopeSelector = '[data-thecore-header-menu-legacy-scope="' . $scope . '"]';

        return sprintf(
            '@media (max-width: %1$spx) {' .
                '%2$s .thecore-header-menu-legacy__inner {flex-wrap: wrap; gap: 0;}' .
                '%2$s .thecore-header-menu-legacy__toggle {display: inline-flex;}' .
                '%2$s .thecore-header-menu-legacy__nav {order: 4; width: 100%%; display: none; padding-top: 8px;}' .
                '%2$s.is-open .thecore-header-menu-legacy__nav {display: block;}' .
                '%2$s .thecore-header-menu-legacy__list {display: block;}' .
                '%2$s .thecore-header-menu-legacy__list > li {padding: 0; border-bottom: 0; position: relative;}' .
                '%2$s .thecore-header-menu-legacy__list > li > a {display: block; padding: 12px 28px 12px 0;}' .
                '%2$s .menu-item-has-children > a::after {display: none;}' .
                '%2$s .thecore-header-menu-legacy__submenu-toggle {display: inline-flex;}' .
                '%2$s .thecore-header-menu-legacy__submenu-panel {position: static; top: auto; left: auto; right: auto; width: auto; min-width: 0; opacity: 1; visibility: visible; pointer-events: auto; transition: none; display: none; padding: 0 0 8px 12px;}' .
                '%2$s .thecore-header-menu-legacy__submenu-panel > .sub-menu {display: block;}' .
                '%2$s .thecore-header-menu-legacy__list > li > .thecore-header-menu-legacy__submenu-panel > .sub-menu > li > a {padding: 8px 0;}' .
                '%2$s .menu-item-has-children.is-submenu-open > .thecore-header-menu-legacy__submenu-panel {display: block;}' .
                '%2$s .menu-item-has-children.is-submenu-open > .thecore-header-menu-legacy__submenu-toggle::after {transform: rotate(0deg);}' .
            '}',
            $breakpoint,
            $scopeSelector
        );
    }

    /**
     * @return array<string, string>
     */
    private function getAvailableMenus(): array
    {
        $menus = wp_get_nav_menus();
        $options = [];

        if (empty($menus)) {
            return $options;
        }

        foreach ($menus as $menu) {
            if (! isset($menu->term_id, $menu->name)) {
                continue;
            }

            $options[(string) $menu->term_id] = (string) $menu->name;
        }

        return $options;
    }
}
