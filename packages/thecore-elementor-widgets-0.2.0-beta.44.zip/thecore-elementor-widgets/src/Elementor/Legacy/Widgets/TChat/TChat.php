<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Legacy\Widgets\TChat;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;
use TheCore\ElementorWidgets\Assets\FrontendAssets;
use TheCore\ElementorWidgets\TChat\TChatModule;

final class TChat extends Widget_Base
{
    use TriggerControlsTrait;

    public function get_name(): string
    {
        return 'thecore-tchat';
    }

    public function get_title(): string
    {
        return __('TChat Module', 'thecore-elementor-widgets');
    }

    public function get_icon(): string
    {
        return 'eicon-comments';
    }

    public function get_categories(): array
    {
        return ['general'];
    }

    public function get_keywords(): array
    {
        return ['chat', 'tchat', 'support', 'messaging', 'module', 'the core'];
    }

    public function get_style_depends(): array
    {
        return [FrontendAssets::TCHAT_WIDGET_STYLE];
    }

    public function get_script_depends(): array
    {
        return [FrontendAssets::TCHAT_WIDGET_SCRIPT];
    }

    protected function register_controls(): void
    {
        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Module', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'info',
            [
                'type' => Controls_Manager::RAW_HTML,
                'raw' => esc_html__(
                    'This widget renders the TChat modal. Use the dedicated TChat Trigger widget, or keep the default trigger enabled below.',
                    'thecore-elementor-widgets'
                ),
                'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
            ]
        );

        $this->add_control(
            'render_default_trigger',
            [
                'label' => __('Render default trigger', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'thecore-elementor-widgets'),
                'label_off' => __('No', 'thecore-elementor-widgets'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => __('Title', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXT,
                'default' => TChatModule::DEFAULT_TITLE,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'subtitle',
            [
                'label' => __('Subtitle', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => TChatModule::DEFAULT_SUBTITLE,
                'rows' => 3,
            ]
        );

        $this->add_control(
            'placeholder',
            [
                'label' => __('Input Placeholder', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXT,
                'default' => TChatModule::DEFAULT_PLACEHOLDER,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'module_horizontal_position',
            [
                'label' => __('Horizontal Position', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-h-align-left',
                    ],
                    'right' => [
                        'title' => __('Right', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-h-align-right',
                    ],
                ],
                'default' => 'right',
                'toggle' => false,
            ]
        );

        $this->add_control(
            'module_vertical_position',
            [
                'label' => __('Vertical Position', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'top' => [
                        'title' => __('Top', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-v-align-top',
                    ],
                    'center' => [
                        'title' => __('Center', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-v-align-middle',
                    ],
                    'bottom' => [
                        'title' => __('Bottom', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-v-align-bottom',
                    ],
                ],
                'default' => 'bottom',
                'toggle' => false,
            ]
        );

        $this->end_controls_section();

        $this->registerTChatTriggerContentControls(
            'section_default_trigger_content',
            __('Default Trigger', 'thecore-elementor-widgets'),
            'trigger_',
            [
                'render_default_trigger' => 'yes',
            ],
            'TChat',
            'right'
        );

        $this->start_controls_section(
            'section_style_panel',
            [
                'label' => __('Panel', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'panel_width',
            [
                'label' => __('Width', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'vw'],
                'range' => [
                    'px' => [
                        'min' => 280,
                        'max' => 640,
                    ],
                    'vw' => [
                        'min' => 30,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .thecore-tchat-module__dialog' => '--thecore-tchat-panel-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'panel_height',
            [
                'label' => __('Height', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'vh'],
                'range' => [
                    'px' => [
                        'min' => 320,
                        'max' => 900,
                    ],
                    'vh' => [
                        'min' => 40,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .thecore-tchat-module__dialog' => '--thecore-tchat-panel-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'panel_top_gap',
            [
                'label' => __('Top Margin', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'vh'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                    ],
                    'vh' => [
                        'min' => 0,
                        'max' => 30,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 16,
                ],
                'selectors' => [
                    '{{WRAPPER}} .thecore-tchat-module' => '--thecore-tchat-viewport-gap-top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'panel_bottom_gap',
            [
                'label' => __('Bottom Margin', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'vh'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                    ],
                    'vh' => [
                        'min' => 0,
                        'max' => 30,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 16,
                ],
                'selectors' => [
                    '{{WRAPPER}} .thecore-tchat-module' => '--thecore-tchat-viewport-gap-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'backdrop_color',
            [
                'label' => __('Backdrop Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-tchat-module__backdrop' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'panel_background_color',
            [
                'label' => __('Background Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-tchat-module__dialog' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'panel_border',
                'selector' => '{{WRAPPER}} .thecore-tchat-module__dialog',
            ]
        );

        $this->add_responsive_control(
            'panel_border_radius',
            [
                'label' => __('Border Radius', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem'],
                'selectors' => [
                    '{{WRAPPER}} .thecore-tchat-module__dialog' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'panel_shadow',
                'selector' => '{{WRAPPER}} .thecore-tchat-module__dialog',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_header',
            [
                'label' => __('Header', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'header_background',
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .thecore-tchat-module__header',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .thecore-tchat-module__title',
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __('Title Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-tchat-module__title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'subtitle_typography',
                'selector' => '{{WRAPPER}} .thecore-tchat-module__subtitle',
            ]
        );

        $this->add_control(
            'subtitle_color',
            [
                'label' => __('Subtitle Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-tchat-module__subtitle' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'close_color',
            [
                'label' => __('Close Icon Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-tchat-module__close' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'close_background_color',
            [
                'label' => __('Close Background', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-tchat-module__close' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_messages',
            [
                'label' => __('Messages', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'messages_background_color',
            [
                'label' => __('Messages Background', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-tchat-module__log' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'messages_typography',
                'selector' => '{{WRAPPER}} .thecore-tchat-module__message',
            ]
        );

        $this->add_control(
            'incoming_background_color',
            [
                'label' => __('Incoming Background', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-tchat-module__message.is-in' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'incoming_text_color',
            [
                'label' => __('Incoming Text', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-tchat-module__message.is-in' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'outgoing_background_color',
            [
                'label' => __('Outgoing Background', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-tchat-module__message.is-out' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'outgoing_text_color',
            [
                'label' => __('Outgoing Text', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-tchat-module__message.is-out' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'message_border_radius',
            [
                'label' => __('Bubble Radius', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem'],
                'selectors' => [
                    '{{WRAPPER}} .thecore-tchat-module__message' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_input',
            [
                'label' => __('Input', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'footer_background_color',
            [
                'label' => __('Footer Background', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-tchat-module__footer' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'footer_border_color',
            [
                'label' => __('Footer Border Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-tchat-module__footer' => 'border-top-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'input_typography',
                'selector' => '{{WRAPPER}} .thecore-tchat-module__input',
            ]
        );

        $this->add_control(
            'input_text_color',
            [
                'label' => __('Input Text Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-tchat-module__input' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'input_placeholder_color',
            [
                'label' => __('Placeholder Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-tchat-module__input::placeholder' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'input_background_color',
            [
                'label' => __('Input Background', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-tchat-module__input' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'input_border',
                'selector' => '{{WRAPPER}} .thecore-tchat-module__input',
            ]
        );

        $this->add_responsive_control(
            'input_border_radius',
            [
                'label' => __('Border Radius', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem'],
                'selectors' => [
                    '{{WRAPPER}} .thecore-tchat-module__input' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'input_padding',
            [
                'label' => __('Padding', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem'],
                'selectors' => [
                    '{{WRAPPER}} .thecore-tchat-module__input' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->registerTChatTriggerStyleControls(
            'section_style_default_trigger',
            __('Default Trigger', 'thecore-elementor-widgets'),
            '{{WRAPPER}} .thecore-tchat-trigger',
            '{{WRAPPER}} .thecore-tchat-module__trigger-wrap',
            [
                'render_default_trigger' => 'yes',
            ]
        );
    }

    protected function render(): void
    {
        $settings = $this->get_settings_for_display();
        $triggerMarkup = '';

        if (($settings['render_default_trigger'] ?? '') === 'yes') {
            $triggerMarkup = $this->renderTChatTrigger(
                $this->getTChatTriggerDisplaySettings('trigger_'),
                [
                    'wrapper_classes' => ['thecore-tchat-module__trigger-wrap'],
                ]
            );
        }

        echo TChatModule::renderModule(
            [
                'id' => 'tchat-root-' . $this->get_id(),
                'title' => isset($settings['title']) && is_string($settings['title']) ? $settings['title'] : TChatModule::DEFAULT_TITLE,
                'subtitle' => isset($settings['subtitle']) && is_string($settings['subtitle']) ? $settings['subtitle'] : TChatModule::DEFAULT_SUBTITLE,
                'placeholder' => isset($settings['placeholder']) && is_string($settings['placeholder']) ? $settings['placeholder'] : TChatModule::DEFAULT_PLACEHOLDER,
                'horizontal_position' => isset($settings['module_horizontal_position']) && is_string($settings['module_horizontal_position']) ? $settings['module_horizontal_position'] : 'right',
                'vertical_position' => isset($settings['module_vertical_position']) && is_string($settings['module_vertical_position']) ? $settings['module_vertical_position'] : 'bottom',
                'force_open' => $this->shouldForceModuleOpen(),
                'editor_preview' => $this->shouldForceModuleOpen(),
            ],
            $triggerMarkup
        );
    }

    private function shouldForceModuleOpen(): bool
    {
        if (! class_exists(\Elementor\Plugin::class) || ! isset(\Elementor\Plugin::$instance)) {
            return false;
        }

        try {
            $plugin = \Elementor\Plugin::$instance;

            if (
                isset($plugin->editor)
                && is_object($plugin->editor)
                && method_exists($plugin->editor, 'is_edit_mode')
                && $plugin->editor->is_edit_mode()
            ) {
                return true;
            }

            if (
                isset($plugin->preview)
                && is_object($plugin->preview)
                && method_exists($plugin->preview, 'is_preview_mode')
            ) {
                return (bool) $plugin->preview->is_preview_mode();
            }
        } catch (\Throwable $exception) {
            return false;
        }

        return false;
    }
}
