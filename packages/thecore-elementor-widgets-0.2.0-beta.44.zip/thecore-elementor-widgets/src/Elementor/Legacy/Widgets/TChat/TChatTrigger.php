<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Legacy\Widgets\TChat;

use Elementor\Widget_Base;
use TheCore\ElementorWidgets\Assets\FrontendAssets;

final class TChatTrigger extends Widget_Base
{
    use TriggerControlsTrait;

    public function get_name(): string
    {
        return 'thecore-tchat-trigger';
    }

    public function get_title(): string
    {
        return __('TChat Trigger', 'thecore-elementor-widgets');
    }

    public function get_icon(): string
    {
        return 'eicon-button';
    }

    public function get_categories(): array
    {
        return ['basic'];
    }

    public function get_keywords(): array
    {
        return ['chat', 'tchat', 'trigger', 'support', 'button', 'the core'];
    }

    public function get_style_depends(): array
    {
        return [FrontendAssets::TCHAT_WIDGET_STYLE];
    }

    public function get_script_depends(): array
    {
        return [FrontendAssets::TCHAT_WIDGET_SCRIPT];
    }

    protected function register_controls(): void
    {
        $this->registerTChatTriggerContentControls(
            'section_content',
            __('Content', 'thecore-elementor-widgets')
        );

        $this->registerTChatTriggerStyleControls(
            'section_style',
            __('Button', 'thecore-elementor-widgets'),
            '{{WRAPPER}} .thecore-tchat-trigger',
            '{{WRAPPER}} .thecore-tchat-trigger__wrapper'
        );
    }

    protected function render(): void
    {
        echo $this->renderTChatTrigger($this->getTChatTriggerDisplaySettings());
    }
}
