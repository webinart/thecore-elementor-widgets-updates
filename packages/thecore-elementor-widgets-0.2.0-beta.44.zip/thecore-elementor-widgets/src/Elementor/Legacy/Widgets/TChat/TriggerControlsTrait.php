<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Legacy\Widgets\TChat;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;

trait TriggerControlsTrait
{
    /**
     * @param array<string, string> $condition
     */
    protected function registerTChatTriggerContentControls(
        string $sectionId,
        string $label,
        string $prefix = '',
        array $condition = [],
        string $defaultText = 'Open TChat',
        string $defaultAlignment = 'left'
    ): void {
        $this->start_controls_section(
            $sectionId,
            [
                'label' => $label,
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            $prefix . 'text',
            [
                'label' => esc_html__('Label', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXT,
                'default' => $defaultText,
                'placeholder' => $defaultText,
                'label_block' => true,
                'condition' => $condition,
            ]
        );

        $this->add_control(
            $prefix . 'aria_label',
            [
                'label' => esc_html__('Aria Label', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXT,
                'default' => '',
                'placeholder' => esc_html__('Open TChat', 'thecore-elementor-widgets'),
                'label_block' => true,
                'condition' => $condition,
            ]
        );

        $this->add_control(
            $prefix . 'show_icon',
            [
                'label' => esc_html__('Show Icon', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'thecore-elementor-widgets'),
                'label_off' => esc_html__('No', 'thecore-elementor-widgets'),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => $condition,
            ]
        );

        $this->add_control(
            $prefix . 'icon_position',
            [
                'label' => esc_html__('Icon Position', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'before' => [
                        'title' => esc_html__('Before', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-h-align-left',
                    ],
                    'after' => [
                        'title' => esc_html__('After', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-h-align-right',
                    ],
                ],
                'default' => 'before',
                'condition' => array_merge(
                    $condition,
                    [
                        $prefix . 'show_icon' => 'yes',
                    ]
                ),
            ]
        );

        $this->add_control(
            $prefix . 'selected_icon',
            [
                'label' => esc_html__('Icon', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::ICONS,
                'skin' => 'inline',
                'label_block' => false,
                'condition' => array_merge(
                    $condition,
                    [
                        $prefix . 'show_icon' => 'yes',
                    ]
                ),
            ]
        );

        $this->add_responsive_control(
            $prefix . 'alignment',
            [
                'label' => esc_html__('Alignment', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => $defaultAlignment,
                'selectors' => [
                    '{{WRAPPER}} .thecore-tchat-trigger__wrapper' => 'text-align: {{VALUE}};',
                ],
                'condition' => $condition,
            ]
        );

        $this->add_control(
            $prefix . 'size',
            [
                'label' => esc_html__('Size', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SELECT,
                'default' => 'sm',
                'options' => [
                    'xs' => esc_html__('Extra Small', 'thecore-elementor-widgets'),
                    'sm' => esc_html__('Small', 'thecore-elementor-widgets'),
                    'md' => esc_html__('Medium', 'thecore-elementor-widgets'),
                    'lg' => esc_html__('Large', 'thecore-elementor-widgets'),
                    'xl' => esc_html__('Extra Large', 'thecore-elementor-widgets'),
                ],
                'condition' => $condition,
            ]
        );

        $this->end_controls_section();
    }

    /**
     * @param array<string, string> $condition
     */
    protected function registerTChatTriggerStyleControls(
        string $sectionId,
        string $label,
        string $buttonSelector,
        string $wrapperSelector,
        array $condition = []
    ): void {
        $this->start_controls_section(
            $sectionId,
            [
                'label' => $label,
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => $condition,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => $sectionId . '_typography',
                'selector' => $buttonSelector,
            ]
        );

        $this->add_control(
            $sectionId . '_text_color',
            [
                'label' => esc_html__('Text Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    $buttonSelector => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            $sectionId . '_background_color',
            [
                'label' => esc_html__('Background Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    $buttonSelector => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            $sectionId . '_hover_text_color',
            [
                'label' => esc_html__('Hover Text Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    $buttonSelector . ':hover, ' . $buttonSelector . ':focus' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            $sectionId . '_hover_background_color',
            [
                'label' => esc_html__('Hover Background Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    $buttonSelector . ':hover, ' . $buttonSelector . ':focus' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => $sectionId . '_border',
                'selector' => $buttonSelector,
            ]
        );

        $this->add_responsive_control(
            $sectionId . '_border_radius',
            [
                'label' => esc_html__('Border Radius', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem'],
                'selectors' => [
                    $buttonSelector => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            $sectionId . '_padding',
            [
                'label' => esc_html__('Padding', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', 'rem', '%'],
                'selectors' => [
                    $buttonSelector => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            $sectionId . '_icon_size',
            [
                'label' => esc_html__('Icon Size', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => [
                        'min' => 12,
                        'max' => 64,
                    ],
                ],
                'selectors' => [
                    $buttonSelector . ' .elementor-button-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
                    $buttonSelector . ' .elementor-button-icon svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            $sectionId . '_icon_gap',
            [
                'label' => esc_html__('Icon Gap', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 40,
                    ],
                ],
                'selectors' => [
                    $buttonSelector . ' .elementor-button-content-wrapper' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    /**
     * @return array{text: string, aria_label: string, show_icon: bool, icon_position: string, size: string, icon: array<string, mixed>}
     */
    protected function getTChatTriggerDisplaySettings(string $prefix = ''): array
    {
        $settings = $this->get_settings_for_display();
        $text = isset($settings[$prefix . 'text']) && is_string($settings[$prefix . 'text']) && $settings[$prefix . 'text'] !== ''
            ? $settings[$prefix . 'text']
            : esc_html__('Open TChat', 'thecore-elementor-widgets');

        return [
            'text' => $text,
            'aria_label' => isset($settings[$prefix . 'aria_label']) && is_string($settings[$prefix . 'aria_label']) && $settings[$prefix . 'aria_label'] !== ''
                ? $settings[$prefix . 'aria_label']
                : wp_strip_all_tags($text),
            'show_icon' => ($settings[$prefix . 'show_icon'] ?? '') === 'yes',
            'icon_position' => ($settings[$prefix . 'icon_position'] ?? 'before') === 'after' ? 'after' : 'before',
            'size' => isset($settings[$prefix . 'size']) && is_string($settings[$prefix . 'size']) ? $settings[$prefix . 'size'] : 'sm',
            'icon' => isset($settings[$prefix . 'selected_icon']) && is_array($settings[$prefix . 'selected_icon'])
                ? $settings[$prefix . 'selected_icon']
                : [],
        ];
    }

    /**
     * @param array{text: string, aria_label: string, show_icon: bool, icon_position: string, size: string, icon: array<string, mixed>} $settings
     * @param array{wrapper_classes?: array<int, string>, button_classes?: array<int, string>, button_attributes?: array<string, string>} $options
     */
    protected function renderTChatTrigger(array $settings, array $options = []): string
    {
        $wrapperClasses = array_merge(
            ['elementor-button-wrapper', 'thecore-tchat-trigger__wrapper'],
            $options['wrapper_classes'] ?? []
        );

        $buttonClasses = array_merge(
            [
                'elementor-button-link',
                'elementor-button',
                'elementor-size-' . $settings['size'],
                'thecore-tchat-trigger',
            ],
            $options['button_classes'] ?? []
        );

        $buttonAttributes = array_merge(
            [
                'href' => '#thecore-tchat-open',
                'role' => 'button',
                'aria-controls' => 'thecore-tchat-dialog',
                'aria-expanded' => 'false',
                'aria-label' => $settings['aria_label'],
                'data-thecore-tchat-trigger' => 'open',
            ],
            $options['button_attributes'] ?? []
        );

        $attributeChunks = [];

        foreach ($buttonAttributes as $name => $value) {
            $attributeChunks[] = sprintf('%s="%s"', esc_attr($name), esc_attr($value));
        }

        ob_start();
        ?>
        <div class="<?php echo esc_attr(implode(' ', array_unique($wrapperClasses))); ?>">
            <a class="<?php echo esc_attr(implode(' ', array_unique($buttonClasses))); ?>" <?php echo implode(' ', $attributeChunks); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
                <span class="elementor-button-content-wrapper">
                    <?php if ($settings['show_icon'] && $settings['icon_position'] === 'before') : ?>
                        <?php echo $this->renderTChatTriggerIcon($settings['icon']); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                    <?php endif; ?>
                    <span class="elementor-button-text"><?php echo esc_html($settings['text']); ?></span>
                    <?php if ($settings['show_icon'] && $settings['icon_position'] === 'after') : ?>
                        <?php echo $this->renderTChatTriggerIcon($settings['icon']); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                    <?php endif; ?>
                </span>
            </a>
        </div>
        <?php

        return (string) ob_get_clean();
    }

    /**
     * @param array<string, mixed> $icon
     */
    private function renderTChatTriggerIcon(array $icon = []): string
    {
        ob_start();
        ?>
        <span class="elementor-button-icon" aria-hidden="true">
            <?php if (! empty($icon['library'])) : ?>
                <?php Icons_Manager::render_icon($icon, ['aria-hidden' => 'true']); ?>
            <?php else : ?>
                <svg viewBox="0 0 24 24" focusable="false" xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M6 4.75C4.48122 4.75 3.25 5.98122 3.25 7.5V13C3.25 14.5188 4.48122 15.75 6 15.75H7.77028C8.07431 15.75 8.36646 15.8663 8.58731 16.0751L11.7424 19.0587C12.2265 19.5163 13.0312 19.1732 13.0312 18.507V16.5C13.0312 16.0858 13.367 15.75 13.7812 15.75H18C19.5188 15.75 20.75 14.5188 20.75 13V7.5C20.75 5.98122 19.5188 4.75 18 4.75H6ZM4.75 7.5C4.75 6.80964 5.30964 6.25 6 6.25H18C18.6904 6.25 19.25 6.80964 19.25 7.5V13C19.25 13.6904 18.6904 14.25 18 14.25H13.7812C12.5386 14.25 11.5312 15.2574 11.5312 16.5V16.7686L9.61747 14.9593C9.11967 14.4888 8.46146 14.25 7.77028 14.25H6C5.30964 14.25 4.75 13.6904 4.75 13V7.5Z"
                        fill="currentColor"
                    />
                </svg>
            <?php endif; ?>
        </span>
        <?php

        return (string) ob_get_clean();
    }
}
