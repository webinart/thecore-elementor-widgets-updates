(() => {
    if (window.__TheCoreFullscreenMenuBooted) {
        return;
    }

    window.__TheCoreFullscreenMenuBooted = true;

    const config = window.TheCoreElementorWidgetsConfig || {};
    const bodyLockClass = config.bodyLockClass || 'thecore-elementor-widgets-lock-scroll';
    const overlayScrollLockEnabled = Boolean(config.features && config.features.overlayScrollLock);

    const bindMediaListener = (mediaQueryList, listener) => {
        if (typeof mediaQueryList.addEventListener === 'function') {
            mediaQueryList.addEventListener('change', listener);
            return;
        }

        if (typeof mediaQueryList.addListener === 'function') {
            mediaQueryList.addListener(listener);
        }
    };

    const syncOverlayCustomProperties = (root, overlay) => {
        if (!root || !overlay || typeof window.getComputedStyle !== 'function') {
            return;
        }

        const computedStyles = window.getComputedStyle(root);

        for (let index = 0; index < computedStyles.length; index += 1) {
            const propertyName = computedStyles[index];

            if (!propertyName || !propertyName.startsWith('--thecore-fsm-')) {
                continue;
            }

            overlay.style.setProperty(propertyName, computedStyles.getPropertyValue(propertyName));
        }
    };

    const resolveOverlayMountTarget = (root) => {
        if (!root || !document.body) {
            return null;
        }

        return root.closest('header') || document.body;
    };

    const initInstance = (root) => {
        if (!root || root.dataset.thecoreFullscreenMenuInitialized === '1') {
            return;
        }

        const toggle = root.querySelector('.thecore-fullscreen-menu__toggle');
        const overlay = root.querySelector('.thecore-fullscreen-menu__overlay');

        if (!toggle || !overlay) {
            return;
        }

        root.dataset.thecoreFullscreenMenuInitialized = '1';

        const linkNodes = overlay.querySelectorAll('.thecore-fullscreen-menu__anchor');
        const scrollLockAllowed = overlayScrollLockEnabled && root.dataset.scrollLock === '1';
        const overlayOnly = root.dataset.overlayOnly === '1';
        const breakpoint = Number.parseInt(root.dataset.mobileBreakpoint || '768', 10);
        const mediaQueryList = window.matchMedia(`(max-width: ${Number.isFinite(breakpoint) ? breakpoint : 768}px)`);
        const mountTarget = resolveOverlayMountTarget(root);
        let isOpen = false;
        let lastFocused = null;

        const isOverlayMode = () => overlayOnly || mediaQueryList.matches;

        const mountOverlay = () => {
            if (!mountTarget || overlay.parentNode === mountTarget) {
                return;
            }

            mountTarget.appendChild(overlay);
        };

        const lockBody = () => {
            if (scrollLockAllowed) {
                document.body.classList.add(bodyLockClass);
            }
        };

        const unlockBody = () => {
            if (scrollLockAllowed) {
                document.body.classList.remove(bodyLockClass);
            }
        };

        const syncMode = () => {
            mountOverlay();
            syncOverlayCustomProperties(root, overlay);

            if (!isOverlayMode()) {
                isOpen = false;
                root.classList.remove('is-open');
                overlay.classList.remove('is-open');
                toggle.setAttribute('aria-expanded', 'false');
                overlay.hidden = true;
                overlay.setAttribute('aria-hidden', 'true');
                unlockBody();
                return;
            }

            overlay.hidden = !isOpen;
            overlay.setAttribute('aria-hidden', isOpen ? 'false' : 'true');
            overlay.classList.toggle('is-open', isOpen);
            toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        };

        const open = () => {
            if (!isOverlayMode()) {
                return;
            }

            mountOverlay();
            syncOverlayCustomProperties(root, overlay);
            lastFocused = document.activeElement;
            isOpen = true;
            root.classList.add('is-open');
            overlay.classList.add('is-open');
            toggle.setAttribute('aria-expanded', 'true');
            overlay.hidden = false;
            overlay.setAttribute('aria-hidden', 'false');
            lockBody();

            const firstLink = linkNodes[0];

            if (firstLink && typeof firstLink.focus === 'function') {
                firstLink.focus({ preventScroll: true });
            }
        };

        const close = (restoreFocus = true) => {
            if (!isOverlayMode()) {
                return;
            }

            isOpen = false;
            root.classList.remove('is-open');
            overlay.classList.remove('is-open');
            toggle.setAttribute('aria-expanded', 'false');
            overlay.setAttribute('aria-hidden', 'true');
            unlockBody();

            window.setTimeout(() => {
                if (!isOpen && isOverlayMode()) {
                    overlay.hidden = true;
                }
            }, 350);

            if (
                restoreFocus &&
                lastFocused &&
                typeof lastFocused.focus === 'function'
            ) {
                lastFocused.focus({ preventScroll: true });
            }
        };

        toggle.addEventListener('click', () => {
            if (isOpen) {
                close();
                return;
            }

            open();
        });

        overlay.addEventListener('click', (event) => {
            if (event.target === overlay) {
                close(false);
            }
        });

        document.addEventListener('keydown', (event) => {
            if ('Escape' === event.key && isOpen) {
                close();
            }
        });

        linkNodes.forEach((linkNode) => {
            linkNode.addEventListener('click', () => {
                close(false);
            });
        });

        bindMediaListener(mediaQueryList, syncMode);
        syncMode();
    };

    const initWithin = (scope) => {
        if (!scope || !(scope instanceof Element || scope instanceof Document)) {
            return;
        }

        if (scope instanceof Element && scope.matches('[data-thecore-fullscreen-menu]')) {
            initInstance(scope);
        }

        scope.querySelectorAll('[data-thecore-fullscreen-menu]').forEach((root) => {
            initInstance(root);
        });
    };

    const onReady = () => {
        initWithin(document);

        if (!document.body || typeof MutationObserver !== 'function') {
            return;
        }

        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                mutation.addedNodes.forEach((node) => {
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        initWithin(node);
                    }
                });
            });
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true,
        });
    };

    if ('loading' === document.readyState) {
        document.addEventListener('DOMContentLoaded', onReady, { once: true });
    } else {
        onReady();
    }
})();
