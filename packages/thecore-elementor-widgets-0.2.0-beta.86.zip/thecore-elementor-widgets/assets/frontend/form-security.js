/* The Core Elementor form security controller. */
( function () {
	'use strict';

	var WRAPPER_SELECTOR = '[data-thecore-form-security]';
	var WIDGET_SELECTOR = '[data-thecore-altcha]';
	var STATUS_SELECTOR = '[data-thecore-form-security-status]';
	var states = new WeakMap();

	function workerCount() {
		return window.navigator.hardwareConcurrency > 1 ? 2 : 1;
	}

	function minimumDuration( value ) {
		var duration = Number( value );

		if ( ! Number.isFinite( duration ) ) {
			duration = 3;
		}

		return Math.max( 1, Math.min( 30, duration ) ) * 1000;
	}

	function readConfig( wrapper ) {
		return {
			altchaInput: wrapper.getAttribute( 'data-altcha-input' ) || '',
			challengeUrl: wrapper.getAttribute( 'data-challenge-url' ) || '',
			honeypotInput: wrapper.getAttribute( 'data-honeypot-input' ) || '',
			messageError: wrapper.getAttribute( 'data-message-error' )
				|| 'Le contrôle anti-spam n\u2019a pas pu se charger. Actualisez la page puis réessayez.',
			messageLoading: wrapper.getAttribute( 'data-message-loading' )
				|| 'Préparation du contrôle anti-spam…',
			messageVerification: wrapper.getAttribute( 'data-message-verification' )
				|| 'Le contrôle anti-spam doit être terminé avant l\u2019envoi.',
			minDuration: minimumDuration( wrapper.getAttribute( 'data-min-duration' ) ),
		};
	}

	function setStatus( state, message, isError ) {
		var content = message || '';

		state.wrapper.classList.toggle( 'is-error', Boolean( isError ) );
		state.wrapper.classList.toggle( 'is-loading', Boolean( content ) && ! isError );

		if ( state.status ) {
			state.status.textContent = content;
			state.status.classList.toggle( 'is-error', Boolean( isError ) );
			state.status.classList.toggle( 'is-loading', Boolean( content ) && ! isError );
			state.wrapper.removeAttribute( 'data-visible-error' );
			return;
		}

		if ( isError && content ) {
			state.wrapper.setAttribute( 'data-visible-error', content );
		} else {
			state.wrapper.removeAttribute( 'data-visible-error' );
		}
	}

	function setBusy( state, busy ) {
		if ( busy ) {
			state.form.setAttribute( 'aria-busy', 'true' );
		} else {
			state.form.removeAttribute( 'aria-busy' );
		}
	}

	function formHasNamedControl( form, name ) {
		if ( ! name || ! form.elements ) {
			return false;
		}

		return Array.prototype.some.call( form.elements, function ( control ) {
			return control && control.name === name;
		} );
	}

	function normalizeTelephoneInputs( form ) {
		Array.prototype.forEach.call(
			form.querySelectorAll( 'input[type="tel"][pattern]' ),
			function ( input ) {
				if ( '[0-9()#&+*-=.]+' !== input.getAttribute( 'pattern' ) ) {
					return;
				}

				input.removeAttribute( 'pattern' );
				input.removeAttribute( 'title' );
			}
		);
	}

	function payloadIsPresent( state ) {
		try {
			var value = new window.FormData( state.form ).get( state.config.altchaInput );

			return 'string' === typeof value && value.length > 0 && value.length <= 16384;
		} catch ( error ) {
			return false;
		}
	}

	function isReady( state ) {
		return state.verified && payloadIsPresent( state );
	}

	function challengeUrlIsAllowed( value ) {
		try {
			var expected = new window.URL( value, window.location.href );

			return expected.origin === window.location.origin
				&& ( 'http:' === expected.protocol || 'https:' === expected.protocol )
				&& ! expected.hash
				&& ! expected.username
				&& ! expected.password;
		} catch ( error ) {
			return false;
		}
	}

	function safeChallengeFetch( state, input, init ) {
		var expected;
		var requested;
		var requestedValue = input;
		var requestedMethod = init && init.method ? init.method : 'GET';

		try {
			expected = new window.URL( state.config.challengeUrl, window.location.href );

			if ( window.Request && input instanceof window.Request ) {
				requestedValue = input.url;
				requestedMethod = init && init.method ? init.method : input.method;
			}

			requested = new window.URL( String( requestedValue ), window.location.href );
		} catch ( error ) {
			return Promise.reject( new Error( 'Invalid anti-spam challenge URL.' ) );
		}

		if (
			! challengeUrlIsAllowed( expected.toString() )
			|| requested.origin !== expected.origin
			|| requested.pathname !== expected.pathname
			|| requested.search !== expected.search
			|| requested.hash
			|| requested.username
			|| requested.password
			|| 'GET' !== String( requestedMethod || 'GET' ).toUpperCase()
		) {
			return Promise.reject( new Error( 'Unauthorized anti-spam challenge request.' ) );
		}

		return window.fetch( expected.toString(), {
			cache: 'no-store',
			credentials: 'same-origin',
			headers: {
				Accept: 'application/json',
			},
			method: 'GET',
			mode: 'same-origin',
			redirect: 'error',
			signal: init && init.signal ? init.signal : undefined,
		} );
	}

	function clearPendingSubmission( state ) {
		state.pendingSubmit = false;
		state.submitter = null;
	}

	function markFailure( state, permanent ) {
		state.failed = true;
		state.unavailable = state.unavailable || Boolean( permanent );
		state.verified = false;
		state.verifying = false;
		state.startWhenConfigured = false;
		clearPendingSubmission( state );
		setBusy( state, false );
		setStatus( state, state.config.messageError, true );
	}

	function resumePendingSubmission( state ) {
		var submitter;

		if ( ! state.pendingSubmit || ! isReady( state ) ) {
			return;
		}

		submitter = state.submitter;
		clearPendingSubmission( state );
		setBusy( state, false );
		setStatus( state, '', false );

		try {
			if ( 'function' === typeof state.form.requestSubmit ) {
				if ( submitter && submitter.form === state.form && ! submitter.disabled ) {
					state.form.requestSubmit( submitter );
				} else {
					state.form.requestSubmit();
				}
				return;
			}

			if (
				submitter
				&& submitter.form === state.form
				&& ! submitter.disabled
				&& 'function' === typeof submitter.click
			) {
				submitter.click();
				return;
			}

			markFailure( state, true );
		} catch ( error ) {
			markFailure( state, false );
		}
	}

	function startVerification( state ) {
		if ( state.unavailable ) {
			setBusy( state, false );
			setStatus( state, state.config.messageError, true );
			return;
		}

		if ( state.verifying || isReady( state ) ) {
			return;
		}

		if ( ! state.configured ) {
			state.startWhenConfigured = true;
			setBusy( state, true );
			setStatus( state, state.config.messageLoading, false );
			return;
		}

		if ( ! state.widget || 'function' !== typeof state.widget.verify ) {
			markFailure( state, true );
			return;
		}

		if ( state.failed && 'function' === typeof state.widget.reset ) {
			try {
				state.widget.reset();
			} catch ( error ) {
				markFailure( state, false );
				return;
			}
		}

		state.failed = false;
		state.startWhenConfigured = false;
		state.verifying = true;
		state.verified = false;
		setBusy( state, true );
		setStatus( state, state.config.messageLoading, false );

		try {
			Promise.resolve( state.widget.verify() ).then(
				function ( result ) {
					state.verifying = false;
					if ( ! result && ! isReady( state ) && ! state.failed ) {
						markFailure( state, false );
					}
				},
				function () {
					markFailure( state, false );
				}
			);
		} catch ( error ) {
			markFailure( state, false );
		}
	}

	function configureWidget( state ) {
		if (
			! state.widget
			|| 'function' !== typeof state.widget.configure
			|| ! challengeUrlIsAllowed( state.config.challengeUrl )
		) {
			markFailure( state, true );
			return;
		}

		try {
			state.widget.configure( {
				auto: 'off',
				challenge: state.config.challengeUrl,
				display: 'invisible',
				fetch: function ( input, init ) {
					return safeChallengeFetch( state, input, init );
				},
				hideFooter: true,
				hideLogo: true,
				humanInteractionSignature: false,
				minDuration: state.config.minDuration,
				name: state.config.altchaInput,
				timeout: 45000,
				workers: workerCount(),
			} );
		} catch ( error ) {
			markFailure( state, true );
			return;
		}

		state.configured = true;
		setStatus( state, '', false );

		if ( state.startWhenConfigured || state.pendingSubmit ) {
			startVerification( state );
		}
	}

	function scheduleReset( state, reverify ) {
		window.clearTimeout( state.resetTimer );
		state.verified = false;
		state.verifying = false;
		state.failed = false;
		setBusy( state, Boolean( reverify || state.pendingSubmit ) );

		state.resetTimer = window.setTimeout( function () {
			if ( ! state.widget || 'function' !== typeof state.widget.reset ) {
				markFailure( state, true );
				return;
			}

			try {
				state.widget.reset();
			} catch ( error ) {
				markFailure( state, false );
				return;
			}

			if ( reverify || state.pendingSubmit ) {
				window.setTimeout( function () {
					startVerification( state );
				}, 0 );
			} else {
				setStatus( state, '', false );
			}
		}, 100 );
	}

	function syncAfterNativeReset( state ) {
		window.clearTimeout( state.resetTimer );
		state.verified = false;
		state.verifying = false;
		state.failed = state.unavailable;
		state.startWhenConfigured = false;
		clearPendingSubmission( state );
		setBusy( state, false );
		setStatus(
			state,
			state.unavailable ? state.config.messageError : '',
			state.unavailable
		);
	}

	function bindWidgetEvents( state ) {
		state.widget.addEventListener( 'statechange', function ( event ) {
			var widgetState = event && event.detail ? event.detail.state : '';

			if ( 'verified' === widgetState ) {
				state.failed = false;
				state.verifying = false;
				state.verified = true;

				window.setTimeout( function () {
					if ( ! isReady( state ) ) {
						markFailure( state, false );
						return;
					}

					setBusy( state, false );
					setStatus( state, '', false );
					resumePendingSubmission( state );
				}, 0 );
				return;
			}

			if ( 'verifying' === widgetState ) {
				state.failed = false;
				state.verifying = true;
				state.verified = false;
				setBusy( state, true );
				setStatus( state, state.config.messageLoading, false );
				return;
			}

			state.verified = false;

			if ( 'expired' === widgetState ) {
				scheduleReset( state, state.pendingSubmit );
			} else if ( 'error' === widgetState ) {
				markFailure( state, false );
			}
		} );

		state.widget.addEventListener( 'expired', function () {
			scheduleReset( state, state.pendingSubmit );
		} );
	}

	function bindFormEvents( state ) {
		if ( window.jQuery ) {
			window.jQuery( state.form ).on( 'error.thecoreFormSecurity', function () {
				scheduleReset( state, true );
			} );
		}

		state.form.addEventListener( 'focusin', function () {
			startVerification( state );
		} );

		state.form.addEventListener( 'input', function () {
			startVerification( state );
		} );

		state.form.addEventListener( 'pointerdown', function () {
			startVerification( state );
		} );

		state.form.addEventListener( 'reset', function () {
			syncAfterNativeReset( state );
		} );

		state.form.addEventListener( 'submit', function ( event ) {
			if ( isReady( state ) ) {
				return;
			}

			event.preventDefault();
			event.stopImmediatePropagation();
			state.pendingSubmit = true;
			state.submitter = event.submitter || null;

			if ( state.unavailable ) {
				clearPendingSubmission( state );
				setBusy( state, false );
				setStatus( state, state.config.messageError, true );
				return;
			}

			setBusy( state, true );
			setStatus( state, state.config.messageVerification, false );
			startVerification( state );
		}, true );
	}

	function initialiseWrapper( wrapper ) {
		var config;
		var existingState;
		var form;
		var state;

		if ( ! wrapper || ! wrapper.closest ) {
			return;
		}

		form = wrapper.closest( 'form.elementor-form' );
		if ( ! form ) {
			return;
		}

		existingState = states.get( form );
		if ( existingState ) {
			if ( existingState.wrapper !== wrapper ) {
				markFailure( existingState, true );
			}
			return;
		}

		normalizeTelephoneInputs( form );
		config = readConfig( wrapper );
		state = {
			config: config,
			configured: false,
			failed: false,
			form: form,
			pendingSubmit: false,
			resetTimer: null,
			startWhenConfigured: false,
			status: wrapper.querySelector( STATUS_SELECTOR ),
			submitter: null,
			unavailable: false,
			verified: false,
			verifying: false,
			widget: wrapper.querySelector( WIDGET_SELECTOR ),
			wrapper: wrapper,
		};

		states.set( form, state );
		bindFormEvents( state );
		setBusy( state, false );

		if (
			! state.widget
			|| ! state.status
			|| ! config.challengeUrl
			|| ! config.altchaInput
			|| ! config.honeypotInput
			|| ! formHasNamedControl( form, config.honeypotInput )
			|| ! challengeUrlIsAllowed( config.challengeUrl )
		) {
			markFailure( state, true );
			return;
		}

		setStatus( state, '', false );
		bindWidgetEvents( state );

		if ( window.customElements && window.customElements.get( 'altcha-widget' ) ) {
			configureWidget( state );
			return;
		}

		if ( window.customElements && 'function' === typeof window.customElements.whenDefined ) {
			var completed = false;
			var failureTimer = window.setTimeout( function () {
				if ( completed ) {
					return;
				}

				completed = true;
				markFailure( state, true );
			}, 5000 );

			window.customElements.whenDefined( 'altcha-widget' ).then( function () {
				if ( completed ) {
					return;
				}

				completed = true;
				window.clearTimeout( failureTimer );
				configureWidget( state );
			} );
			return;
		}

		markFailure( state, true );
	}

	function initialiseAll( root ) {
		var wrappers = [];

		if ( ! root ) {
			return;
		}

		if ( root.nodeType === 1 && root.matches( WRAPPER_SELECTOR ) ) {
			wrappers.push( root );
		}

		if ( root.querySelectorAll ) {
			wrappers = wrappers.concat( Array.prototype.slice.call( root.querySelectorAll( WRAPPER_SELECTOR ) ) );
		}

		wrappers.forEach( initialiseWrapper );
	}

	function observeInjectedContent() {
		if ( ! window.MutationObserver || ! document.documentElement ) {
			return;
		}

		var observer = new window.MutationObserver( function ( mutations ) {
			mutations.forEach( function ( mutation ) {
				Array.prototype.forEach.call( mutation.addedNodes, function ( node ) {
					if ( 1 === node.nodeType ) {
						initialiseAll( node );
					}
				} );
			} );
		} );

		observer.observe( document.documentElement, {
			childList: true,
			subtree: true,
		} );
	}

	function boot() {
		initialiseAll( document );
		observeInjectedContent();
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', boot, { once: true } );
	} else {
		boot();
	}

	window.addEventListener( 'pageshow', function ( event ) {
		if ( ! event.persisted ) {
			return;
		}

		initialiseAll( document );
		document.querySelectorAll( WRAPPER_SELECTOR ).forEach( function ( wrapper ) {
			var form = wrapper.closest( 'form.elementor-form' );
			var state = form ? states.get( form ) : null;

			if ( state ) {
				syncAfterNativeReset( state );
			}
		} );
	} );

	window.addEventListener( 'elementor/frontend/init', function () {
		initialiseAll( document );

		if ( window.elementorFrontend && window.elementorFrontend.hooks ) {
			window.elementorFrontend.hooks.addAction(
				'frontend/element_ready/form.default',
				function ( scope ) {
					var root = scope && scope[ 0 ] ? scope[ 0 ] : scope;

					initialiseAll( root || document );
				}
			);
		}
	} );
}() );
