/* ------------------------------------------------------------
   TChat – interface agent (admin)
------------------------------------------------------------ */
const { createElement: h, useState, useEffect, useRef } = wp.element;
const { apiFetch } = wp;

apiFetch.use(apiFetch.createNonceMiddleware(TCHAT_ADMIN.nonce));

function App() {
	const transport = TCHAT_ADMIN.transport || {};
	const pollingCfg = transport.polling || {};
	const mode = transport.mode || 'polling';
	const listPollMs = Number(pollingCfg.adminListMs || 5000);
	const conversationPollMs = Number(pollingCfg.adminConversationMs || 3000);

	const [list, setList] = useState([]);
	const [listFilter, setListFilter] = useState('open');
	const [current, setCurrent] = useState(null);
	const [log, setLog] = useState([]);

	const currentRef = useRef(null);
	const listFilterRef = useRef('open');
	const lastTSRef = useRef('1970-01-01 00:00:00');
	const listTimerRef = useRef(null);
	const conversationTimerRef = useRef(null);
	const eventSourceRef = useRef(null);

	const refreshList = async () => {
		const filter = listFilterRef.current || 'open';
		const conversations = await apiFetch({ path: `/tchat/v1/admin/conversations?filter=${encodeURIComponent(filter)}` });
		setList(Array.isArray(conversations) ? conversations : []);
	};

	const refreshCurrentMessages = async (conversationId, since) => {
		if (!conversationId) {
			return [];
		}

		const path = since
			? `/tchat/v1/messages?conversation=${conversationId}&since=${encodeURIComponent(since)}`
			: `/tchat/v1/messages?conversation=${conversationId}`;

		const messages = await apiFetch({ path });
		return Array.isArray(messages) ? messages : [];
	};

	const updateLastTS = (messages) => {
		if (!Array.isArray(messages) || !messages.length) {
			return;
		}

		const last = messages[messages.length - 1];
		if (last && last.created_at) {
			lastTSRef.current = last.created_at;
		}
	};

	const patchConv = (id, data) => apiFetch({
		path: `/tchat/v1/admin/conversations/${id}`,
		method: 'PATCH',
		data,
	});

	const openConv = async (id) => {
		currentRef.current = id;
		setCurrent(id);
		lastTSRef.current = '1970-01-01 00:00:00';

		await patchConv(id, { unread_count: 0 });

		const messages = await refreshCurrentMessages(id);
		setLog(messages);
		updateLastTS(messages);
		refreshList();
	};

	const renameConv = async (id, title) => {
		await patchConv(id, { title });
		refreshList();
	};

	const archiveConv = async (id) => {
		if (!window.confirm('Archiver cette conversation ?')) {
			return;
		}

		await patchConv(id, { is_active: 0 });
		if (currentRef.current === id) {
			currentRef.current = null;
			lastTSRef.current = '1970-01-01 00:00:00';
			setCurrent(null);
			setLog([]);
		}
		refreshList();
	};

	const restoreConv = async (id) => {
		await patchConv(id, { is_active: 1 });
		refreshList();
	};

	const deleteConv = async (id) => {
		if (!window.confirm('Supprimer définitivement ?')) {
			return;
		}

		await apiFetch({
			path: `/tchat/v1/admin/conversations/${id}`,
			method: 'DELETE',
		});

		if (currentRef.current === id) {
			currentRef.current = null;
			lastTSRef.current = '1970-01-01 00:00:00';
			setCurrent(null);
			setLog([]);
		}
		refreshList();
	};

	const send = async (txt) => {
		if (!txt.trim() || currentRef.current === null) {
			return;
		}

		const response = await apiFetch({
			path: '/tchat/v1/admin/message',
			method: 'POST',
			data: {
				conversation_id: currentRef.current,
				content: txt.trim(),
			},
		});

		if (response && response.message) {
			setLog((items) => [...items, response.message]);
			updateLastTS([response.message]);
		}

		refreshList();
	};

	const clearListPolling = () => {
		if (listTimerRef.current) {
			window.clearTimeout(listTimerRef.current);
			listTimerRef.current = null;
		}
	};

	const clearConversationPolling = () => {
		if (conversationTimerRef.current) {
			window.clearTimeout(conversationTimerRef.current);
			conversationTimerRef.current = null;
		}
	};

	const pollList = async () => {
		try {
			await refreshList();
		} finally {
			listTimerRef.current = window.setTimeout(pollList, listPollMs);
		}
	};

	const pollConversation = async () => {
		if (!currentRef.current) {
			clearConversationPolling();
			return;
		}

		try {
			const messages = await refreshCurrentMessages(currentRef.current, lastTSRef.current);
			if (messages.length) {
				setLog((items) => [...items, ...messages]);
				updateLastTS(messages);
			}
		} finally {
			conversationTimerRef.current = window.setTimeout(pollConversation, conversationPollMs);
		}
	};

	const startPolling = () => {
		clearListPolling();
		clearConversationPolling();
		listTimerRef.current = window.setTimeout(pollList, 0);
		conversationTimerRef.current = window.setTimeout(pollConversation, conversationPollMs);
	};

	const stopRealtime = () => {
		if (eventSourceRef.current) {
			eventSourceRef.current.close();
			eventSourceRef.current = null;
		}
	};

	const startSse = () => {
		if (!transport.sseEventsUrl || typeof window.EventSource !== 'function') {
			return false;
		}

		stopRealtime();

		const source = new window.EventSource(transport.sseEventsUrl);
		source.addEventListener('message', (event) => {
			try {
				const message = JSON.parse(event.data);

				if (!message || !message.conversation_id) {
					return;
				}

				refreshList();

				if (message.sender_type === 'agent') {
					return;
				}

				if (+message.conversation_id === +currentRef.current) {
					setLog((items) => [...items, message]);
					updateLastTS([message]);
				}
			} catch (error) {
				console.warn('TChat SSE parse error', error);
			}
		});

		source.onerror = () => {
			stopRealtime();
			if (mode === 'auto') {
				startPolling();
			}
		};

		eventSourceRef.current = source;
		return true;
	};

	useEffect(() => {
		refreshList();

		if ((mode === 'sse' || mode === 'auto') && startSse()) {
			return () => {
				stopRealtime();
			};
		}

		startPolling();

		return () => {
			clearListPolling();
			clearConversationPolling();
			stopRealtime();
		};
	}, []);

	useEffect(() => {
		listFilterRef.current = listFilter;
		refreshList();
	}, [listFilter]);

	useEffect(() => {
		if (mode !== 'polling' && mode !== 'auto') {
			return;
		}

		if (!current) {
			clearConversationPolling();
			return;
		}

		clearConversationPolling();
		conversationTimerRef.current = window.setTimeout(pollConversation, conversationPollMs);
	}, [current]);

	const renderConvButton = (conversation) => {
		const isActive = current === conversation.id;
		const hasUnread = Number(conversation.unread_count || 0) > 0;
		const isArchived = Number(conversation.is_active || 0) === 0;

		return h(
			'li',
			{
				key: conversation.id,
				className: `tchat-admin__conversation ${isActive ? 'is-active' : ''}`,
				'data-unread': hasUnread ? 'true' : 'false',
			},
			[
				h(
					'button',
					{
						type: 'button',
						onClick: () => openConv(conversation.id),
					},
					[
						conversation.title || `#${conversation.id}`,
						hasUnread && h('span', { className: 'badge' }, conversation.unread_count),
						isArchived && h('span', { className: 'status-badge' }, 'Archivée'),
					]
				),
				h('div', { className: 'actions' }, [
					h('span', {
						title: 'Renommer',
						className: 'dashicons dashicons-edit',
						onClick: () => {
							const title = prompt('Nouveau titre :', conversation.title || '');
							if (title !== null) {
								renameConv(conversation.id, title);
							}
						},
					}),
					isArchived
						? h('span', {
							title: 'Restaurer',
							className: 'dashicons dashicons-undo',
							onClick: () => restoreConv(conversation.id),
						})
						: h('span', {
							title: 'Archiver',
							className: 'dashicons dashicons-archive',
							onClick: () => archiveConv(conversation.id),
						}),
					h('span', {
						title: 'Supprimer',
						className: 'dashicons dashicons-trash',
						onClick: () => deleteConv(conversation.id),
					}),
				]),
			]
		);
	};

	const renderFilterButton = (value, label) => h(
		'button',
		{
			type: 'button',
			className: `tchat-admin__filter-button ${listFilter === value ? 'is-active' : ''}`,
			onClick: () => setListFilter(value),
		},
		label
	);

	return h('div', { className: 'tchat-admin' }, [
		h('aside', { key: 'sidebar' }, [
			h('div', { className: 'tchat-admin__filters' }, [
				renderFilterButton('open', 'Ouvertes'),
				renderFilterButton('archived', 'Archivées'),
				renderFilterButton('all', 'Toutes'),
			]),
			h('ul', {}, list.map(renderConvButton)),
		]
		),
		current !== null && h('section', { key: 'conversation' }, [
			h('div', { className: 'log' },
				log.map((message, index) => h('p', { key: message.id || index, className: message.sender_type }, message.content))
			),
			h('input', {
				placeholder: 'Répondre…',
				onKeyDown: async (event) => {
					if (event.key === 'Enter') {
						const value = event.target.value;
						event.target.value = '';
						await send(value);
					}
				},
			}),
		]),
	]);
}

wp.element.render(h(App), document.getElementById('tchat-admin-root'));
