<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Registry;

final class FeaturesRegistry
{
    /**
     * @return array<string, array{title: string, description: string, enabled_by_default: bool}>
     */
    private function definitions(): array
    {
        return [
            'overlay-scroll-lock' => [
                'title' => __('Overlay Scroll Lock', 'thecore-elementor-widgets'),
                'description' => __(
                    'Verrouille le scroll du document lorsque des overlays compatibles, comme le Fullscreen Menu mobile, sont ouverts.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => true,
            ],
            'form-security' => [
                'title' => __('Elementor Form Security', 'thecore-elementor-widgets'),
                'description' => __(
                    'Ajoute au formulaire legacy Elementor Pro un champ de protection opt-in avec ALTCHA auto-hébergé, anti-rejeu, limitation, déduplication et minimisation des métadonnées.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => false,
            ],
        ];
    }

    /**
     * @return array<string, RegistryItem>
     */
    public function all(): array
    {
        $items = [];

        foreach ($this->definitions() as $id => $definition) {
            $item = new RegistryItem(
                $id,
                $definition['title'],
                $definition['description'],
                $definition['enabled_by_default']
            );

            $items[$item->id()] = $item;
        }

        return $items;
    }

    /**
     * @return array<string, int>
     */
    public function defaults(): array
    {
        return [
            'overlay-scroll-lock' => 1,
            'form-security' => 0,
        ];
    }
}
