<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\TChat\Support;

final class MessageSanitizer
{
    public static function plainText(string $content): string
    {
        $content = wp_check_invalid_utf8($content, true);
        $content = str_replace("\0", '', $content);

        $sanitized = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]+/u', '', $content);

        if (! is_string($sanitized)) {
            return $content;
        }

        return $sanitized;
    }
}
