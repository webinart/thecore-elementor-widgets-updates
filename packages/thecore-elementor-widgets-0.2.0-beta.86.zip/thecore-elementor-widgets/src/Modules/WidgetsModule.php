<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Modules;

use TheCore\ElementorWidgets\Contracts\Bootable;
use TheCore\ElementorWidgets\Elementor\Atomic\Widgets\Breadcrumb\Breadcrumb;
use TheCore\ElementorWidgets\Elementor\Atomic\Widgets\FullscreenMenu\FullscreenMenu;
use TheCore\ElementorWidgets\Elementor\Atomic\Widgets\IconText\IconText;
use TheCore\ElementorWidgets\Elementor\Atomic\Widgets\MarqueeCarousel\MarqueeCarousel;
use TheCore\ElementorWidgets\Elementor\Atomic\Widgets\TextList\TextList;
use TheCore\ElementorWidgets\Elementor\Legacy\Widgets\AccessibilityModule\AccessibilityModule;
use TheCore\ElementorWidgets\Elementor\Legacy\Widgets\AccessibilityTrigger\AccessibilityTrigger;
use TheCore\ElementorWidgets\Elementor\Legacy\Widgets\CookieConsent\CookieConsent;
use TheCore\ElementorWidgets\Elementor\Legacy\Widgets\HeaderMenu\HeaderMenu;
use TheCore\ElementorWidgets\Elementor\Legacy\Widgets\MarqueeBanner\MarqueeBanner;
use TheCore\ElementorWidgets\Elementor\Legacy\Widgets\SearchModal\SearchModal;
use TheCore\ElementorWidgets\Elementor\Legacy\Widgets\TChat\TChat;
use TheCore\ElementorWidgets\Elementor\Legacy\Widgets\TChat\TChatTrigger;
use TheCore\ElementorWidgets\Options\OptionsRepository;
use TheCore\ElementorWidgets\Registry\WidgetsRegistry;
use TheCore\ElementorWidgets\Support\RequirementsChecker;

final class WidgetsModule implements Bootable
{
    public function __construct(
        private readonly WidgetsRegistry $widgetsRegistry,
        private readonly OptionsRepository $optionsRepository,
        private readonly RequirementsChecker $requirementsChecker
    ) {
    }

    public function register(): void
    {
        add_action('elementor/widgets/register', [$this, 'registerWidgets']);
    }

    public function registerWidgets(object $widgetsManager): void
    {
        if (! $this->requirementsChecker->canRegisterClassicWidgets()) {
            return;
        }

        $state = $this->optionsRepository->getWidgetsState($this->widgetsRegistry->defaults());
        $tchatEnabled = ! empty($state['tchat']);

        if (method_exists($widgetsManager, 'register')) {
            if (! empty($state['classic-menu']) && $this->requirementsChecker->canRegisterAtomicWidgets()) {
                $widgetsManager->register(new FullscreenMenu());
            }

            if (! empty($state['marquee-carousel']) && $this->requirementsChecker->canRegisterAtomicWidgets()) {
                $widgetsManager->register(new MarqueeCarousel());
            }

            if (! empty($state['text-list']) && $this->requirementsChecker->canRegisterAtomicWidgets()) {
                $widgetsManager->register(new TextList());
            }

            if (! empty($state['breadcrumb']) && $this->requirementsChecker->canRegisterAtomicWidgets()) {
                $widgetsManager->register(new Breadcrumb());
            }

            if (! empty($state['icon-text']) && $this->requirementsChecker->canRegisterAtomicWidgets()) {
                $widgetsManager->register(new IconText());
            }

            if (! empty($state['marquee-banner-legacy'])) {
                $widgetsManager->register(new MarqueeBanner());
            }

            if (! empty($state['header-menu-legacy'])) {
                $widgetsManager->register(new HeaderMenu());
            }

            if (! empty($state['search-modal-legacy'])) {
                $widgetsManager->register(new SearchModal());
            }

            if (! empty($state['accessibility-module-legacy'])) {
                $widgetsManager->register(new AccessibilityModule());
            }

            if (! empty($state['accessibility-trigger-legacy'])) {
                $widgetsManager->register(new AccessibilityTrigger());
            }

            if (! empty($state['cookie-consent'])) {
                $widgetsManager->register(new CookieConsent());
            }

            if ($tchatEnabled) {
                $widgetsManager->register(new TChat());
            }

            if ($tchatEnabled && ! empty($state['tchat-trigger'])) {
                $widgetsManager->register(new TChatTrigger());
            }
        }
    }
}
