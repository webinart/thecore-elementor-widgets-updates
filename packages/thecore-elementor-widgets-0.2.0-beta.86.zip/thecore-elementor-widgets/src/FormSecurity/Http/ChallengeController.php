<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity\Http;

use TheCore\ElementorWidgets\FormSecurity\Infrastructure\Installer;
use TheCore\ElementorWidgets\FormSecurity\Infrastructure\SecurityStore;
use TheCore\ElementorWidgets\FormSecurity\Security\AltchaService;
use TheCore\ElementorWidgets\FormSecurity\Support\ChallengeContext;
use TheCore\ElementorWidgets\FormSecurity\Support\ClientIdentity;
use TheCore\ElementorWidgets\FormSecurity\Support\ContextToken;
use TheCore\ElementorWidgets\FormSecurity\Support\Metrics;
use TheCore\ElementorWidgets\FormSecurity\Support\OriginPolicy;
use TheCore\ElementorWidgets\FormSecurity\Support\SecuritySettings;
use Throwable;
use WP_REST_Response;

final class ChallengeController
{
    public const REST_NAMESPACE = 'thecore-elementor-widgets/v1';
    public const REST_ROUTE = '/form-security/challenge';

    public function __construct(
        private readonly ContextToken $contextToken,
        private readonly OriginPolicy $originPolicy,
        private readonly ClientIdentity $clientIdentity,
        private readonly SecurityStore $store,
        private readonly AltchaService $altcha,
        private readonly SecuritySettings $settings,
        private readonly Metrics $metrics
    ) {
    }

    public function markRequestUncacheable(): void
    {
        $requestUri = isset($_SERVER['REQUEST_URI']) && is_scalar($_SERVER['REQUEST_URI'])
            ? (string) wp_unslash($_SERVER['REQUEST_URI'])
            : '';
        $requestPath = (string) wp_parse_url($requestUri, PHP_URL_PATH);
        $restRoute = isset($_GET['rest_route']) && is_scalar($_GET['rest_route'])
            ? (string) wp_unslash($_GET['rest_route'])
            : '';
        $routeSuffix = '/' . self::REST_NAMESPACE . self::REST_ROUTE;
        $isChallenge = $routeSuffix === $restRoute
            || (
                strlen($requestPath) >= strlen($routeSuffix)
                && $routeSuffix === substr($requestPath, -strlen($routeSuffix))
            );

        if (! $isChallenge) {
            return;
        }

        if (! defined('DONOTCACHEPAGE')) {
            define('DONOTCACHEPAGE', true);
        }

        add_filter('w3tc_can_cache', '__return_false', PHP_INT_MAX);
    }

    public function registerRoute(): void
    {
        register_rest_route(
            self::REST_NAMESPACE,
            self::REST_ROUTE,
            [
                'methods' => 'GET',
                'callback' => [$this, 'serve'],
                'permission_callback' => '__return_true',
            ]
        );
    }

    /**
     * @param object $request WP_REST_Request at runtime.
     */
    public function serve(object $request): WP_REST_Response
    {
        if (! $this->originPolicy->isAllowed($_SERVER, home_url('/'))) {
            $this->metrics->increment('challenge_forbidden');

            return $this->error(
                'thecore_form_security_forbidden',
                __('Requête de contrôle anti-spam non autorisée.', 'thecore-elementor-widgets'),
                403
            );
        }

        if (! Installer::isOperationallyReady()) {
            $this->metrics->increment('challenge_schema_unavailable');

            return $this->unavailable();
        }

        $rateStatus = $this->store->consumeRateLimit(
            'challenge',
            $this->clientIdentity->hash($_SERVER),
            $this->settings->challengeRateWindow(),
            $this->settings->challengeRateLimit(),
            time()
        );

        if ('limited' === $rateStatus) {
            $this->metrics->increment('challenge_rate_limited');

            return $this->error(
                'thecore_form_security_rate_limited',
                __('Trop de contrôles ont été demandés. Réessayez dans quelques minutes.', 'thecore-elementor-widgets'),
                429
            );
        }

        if ('allowed' !== $rateStatus) {
            $this->metrics->increment('challenge_store_unavailable');

            return $this->unavailable();
        }

        $token = method_exists($request, 'get_param')
            ? $request->get_param('context')
            : null;
        $context = is_string($token) ? $this->contextToken->decode($token) : null;

        if (null === $context) {
            $this->metrics->increment('challenge_context_invalid');

            return $this->error(
                'thecore_form_security_invalid_context',
                __('Contexte de contrôle anti-spam invalide.', 'thecore-elementor-widgets'),
                400
            );
        }

        try {
            $challenge = $this->altcha->createChallenge(
                ChallengeContext::forForm($context)
            );
        } catch (Throwable) {
            $this->metrics->increment('challenge_generation_error');

            return $this->unavailable();
        }

        return $this->response($challenge, 200);
    }

    private function unavailable(): WP_REST_Response
    {
        return $this->error(
            'thecore_form_security_unavailable',
            __('Le contrôle anti-spam est momentanément indisponible.', 'thecore-elementor-widgets'),
            503
        );
    }

    private function error(string $code, string $message, int $status): WP_REST_Response
    {
        return $this->response(
            [
                'code' => $code,
                'message' => $message,
                'data' => ['status' => $status],
            ],
            $status
        );
    }

    /**
     * @param array<string, mixed> $data
     */
    private function response(array $data, int $status): WP_REST_Response
    {
        $response = new WP_REST_Response($data, $status);
        $response->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $response->header('Pragma', 'no-cache');
        $response->header('Expires', '0');
        $response->header('X-Robots-Tag', 'noindex, nofollow');
        $response->header('X-Content-Type-Options', 'nosniff');

        return $response;
    }
}
