<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity\Infrastructure;

use JsonException;
use Throwable;

final class BlockedSubmissionStore
{
    private const DEFAULT_LIST_LIMIT = 50;
    private const MAXIMUM_LIST_LIMIT = 200;
    private const MAXIMUM_CLEANUP_BATCH = 10000;
    private const MAXIMUM_FORM_NAME_CHARACTERS = 191;
    private const MAXIMUM_PAGE_URL_BYTES = 4096;
    private const MAXIMUM_FIELDS_JSON_BYTES = 32768;
    private const MAXIMUM_SEARCH_BYTES = 191;

    private bool $lastOperationSucceeded = false;

    public function lastOperationSucceeded(): bool
    {
        return $this->lastOperationSucceeded;
    }

    /**
     * @param array<string, mixed> $event
     *
     * @return int|false Inserted identifier, or false when validation/storage fails.
     */
    public function insert(array $event): int|false
    {
        $this->lastOperationSucceeded = false;

        if (! Installer::isReady()) {
            return false;
        }

        $normalized = $this->normalizeEvent($event);
        $tableName = Installer::tableName(Installer::TABLE_BLOCKED_SUBMISSIONS);
        $wpdb = $this->database(['prepare', 'query']);

        if (null === $normalized || '' === $tableName || null === $wpdb) {
            return false;
        }

        $previousSuppression = $this->suppressErrors($wpdb);

        try {
            $this->resetLastError($wpdb);
            $query = $wpdb->prepare(
                "INSERT INTO {$tableName}
                    (reason, post_id, widget_id, form_name, page_url, fields_json, email_hash, created_at, expires_at)
                VALUES (%s, %d, %s, %s, %s, %s, %s, %d, %d)",
                $normalized['reason'],
                $normalized['post_id'],
                $normalized['widget_id'],
                $normalized['form_name'],
                $normalized['page_url'],
                $normalized['fields_json'],
                $normalized['email_hash'],
                $normalized['created_at'],
                $normalized['expires_at']
            );

            if (! is_string($query) || '' === $query) {
                return false;
            }

            $inserted = $wpdb->query($query);
            $insertId = isset($wpdb->insert_id) && is_numeric($wpdb->insert_id)
                ? (int) $wpdb->insert_id
                : 0;

            if (1 !== $inserted || '' !== $this->lastError($wpdb) || $insertId < 1) {
                return false;
            }

            $this->lastOperationSucceeded = true;

            return $insertId;
        } catch (Throwable) {
            return false;
        } finally {
            $this->restoreErrors($wpdb, $previousSuppression);
        }
    }

    /**
     * Supported filters: reason, search, email_hash, offset, limit and order.
     * The email_hash filter is primarily used by listByEmailHash().
     *
     * @param array<string, mixed> $args
     *
     * @return array<int, array{
     *     id: int,
     *     reason: string,
     *     post_id: int,
     *     widget_id: string,
     *     form_name: string,
     *     page_url: string,
     *     fields: array<mixed>,
     *     fields_json: string,
     *     email_hash: string,
     *     created_at: int,
     *     expires_at: int
     * }>
     */
    public function list(array $args = []): array
    {
        $this->lastOperationSucceeded = false;

        if (! Installer::isReady()) {
            return [];
        }

        $tableName = Installer::tableName(Installer::TABLE_BLOCKED_SUBMISSIONS);
        $wpdb = $this->database(['prepare', 'get_results']);

        if ('' === $tableName || null === $wpdb) {
            return [];
        }

        $filters = $this->normalizeFilters($args, true);
        if (null === $filters) {
            return [];
        }

        $where = $this->buildWhere($filters, $wpdb);
        $direction = $filters['order'];
        $sql = "SELECT id, reason, post_id, widget_id, form_name, page_url, fields_json, email_hash, created_at, expires_at
            FROM {$tableName}{$where['sql']}
            ORDER BY created_at {$direction}, id {$direction}
            LIMIT %d OFFSET %d";
        $values = array_merge($where['values'], [$filters['limit'], $filters['offset']]);
        $previousSuppression = $this->suppressErrors($wpdb);

        try {
            $this->resetLastError($wpdb);
            $query = $wpdb->prepare($sql, ...$values);
            if (! is_string($query) || '' === $query) {
                return [];
            }

            $rows = $wpdb->get_results($query, 'ARRAY_A');
            if ('' !== $this->lastError($wpdb) || ! is_array($rows)) {
                return [];
            }

            $events = [];
            foreach ($rows as $row) {
                if (! is_array($row)) {
                    return [];
                }

                $event = $this->hydrate($row);
                if (null === $event) {
                    return [];
                }

                $events[] = $event;
            }

            $this->lastOperationSucceeded = true;

            return $events;
        } catch (Throwable) {
            return [];
        } finally {
            $this->restoreErrors($wpdb, $previousSuppression);
        }
    }

    /**
     * @param array<string, mixed> $args
     */
    public function count(array $args = []): int
    {
        $this->lastOperationSucceeded = false;

        if (! Installer::isReady()) {
            return 0;
        }

        $tableName = Installer::tableName(Installer::TABLE_BLOCKED_SUBMISSIONS);
        $wpdb = $this->database(['prepare', 'get_var']);

        if ('' === $tableName || null === $wpdb) {
            return 0;
        }

        $filters = $this->normalizeFilters($args, false);
        if (null === $filters) {
            return 0;
        }

        $where = $this->buildWhere($filters, $wpdb);
        $sql = "SELECT COUNT(*) FROM {$tableName}{$where['sql']}";
        $previousSuppression = $this->suppressErrors($wpdb);

        try {
            $this->resetLastError($wpdb);
            $query = [] === $where['values']
                ? $sql
                : $wpdb->prepare($sql, ...$where['values']);

            if (! is_string($query) || '' === $query) {
                return 0;
            }

            $count = $wpdb->get_var($query);

            if ('' !== $this->lastError($wpdb) || ! is_numeric($count)) {
                return 0;
            }

            $this->lastOperationSucceeded = true;

            return max(0, (int) $count);
        } catch (Throwable) {
            return 0;
        } finally {
            $this->restoreErrors($wpdb, $previousSuppression);
        }
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function listByEmailHash(string $hash, int $offset = 0, int $limit = 100): array
    {
        $this->lastOperationSucceeded = false;
        $hash = strtolower(trim($hash));
        if (! self::isEmailHash($hash)) {
            return [];
        }

        return $this->list(
            [
                'email_hash' => $hash,
                'offset' => $offset,
                'limit' => $limit,
                'order' => 'ASC',
            ]
        );
    }

    /**
     * @return array<string, mixed>|null
     */
    public function get(int $id): ?array
    {
        $this->lastOperationSucceeded = false;

        if (! Installer::isReady() || $id < 1) {
            return null;
        }

        $tableName = Installer::tableName(Installer::TABLE_BLOCKED_SUBMISSIONS);
        $wpdb = $this->database(['prepare', 'get_row']);

        if ('' === $tableName || null === $wpdb) {
            return null;
        }

        $previousSuppression = $this->suppressErrors($wpdb);

        try {
            $this->resetLastError($wpdb);
            $query = $wpdb->prepare(
                "SELECT id, reason, post_id, widget_id, form_name, page_url, fields_json, email_hash, created_at, expires_at
                FROM {$tableName} WHERE id = %d LIMIT 1",
                $id
            );

            if (! is_string($query) || '' === $query) {
                return null;
            }

            $row = $wpdb->get_row($query, 'ARRAY_A');
            if ('' !== $this->lastError($wpdb)) {
                return null;
            }

            if (! is_array($row)) {
                $this->lastOperationSucceeded = true;

                return null;
            }

            $event = $this->hydrate($row);
            $this->lastOperationSucceeded = null !== $event;

            return $event;
        } catch (Throwable) {
            return null;
        } finally {
            $this->restoreErrors($wpdb, $previousSuppression);
        }
    }

    public function delete(int $id): bool
    {
        $this->lastOperationSucceeded = false;

        if (! Installer::isReady() || $id < 1) {
            return false;
        }

        $tableName = Installer::tableName(Installer::TABLE_BLOCKED_SUBMISSIONS);
        $wpdb = $this->database(['prepare', 'query']);

        if ('' === $tableName || null === $wpdb) {
            return false;
        }

        $previousSuppression = $this->suppressErrors($wpdb);

        try {
            $this->resetLastError($wpdb);
            $query = $wpdb->prepare("DELETE FROM {$tableName} WHERE id = %d LIMIT 1", $id);
            if (! is_string($query) || '' === $query) {
                return false;
            }

            $deleted = $wpdb->query($query);
            if (! is_int($deleted) || '' !== $this->lastError($wpdb)) {
                return false;
            }

            $this->lastOperationSucceeded = true;

            return 1 === $deleted;
        } catch (Throwable) {
            return false;
        } finally {
            $this->restoreErrors($wpdb, $previousSuppression);
        }
    }

    public function deleteByEmailHash(string $hash): int
    {
        $this->lastOperationSucceeded = false;

        if (! Installer::isReady()) {
            return 0;
        }

        $hash = strtolower(trim($hash));
        if (! self::isEmailHash($hash)) {
            return 0;
        }

        $tableName = Installer::tableName(Installer::TABLE_BLOCKED_SUBMISSIONS);
        $wpdb = $this->database(['prepare', 'query']);

        if ('' === $tableName || null === $wpdb) {
            return 0;
        }

        $previousSuppression = $this->suppressErrors($wpdb);

        try {
            $this->resetLastError($wpdb);
            $query = $wpdb->prepare("DELETE FROM {$tableName} WHERE email_hash = %s", $hash);
            if (! is_string($query) || '' === $query) {
                return 0;
            }

            $deleted = $wpdb->query($query);
            if (! is_int($deleted) || '' !== $this->lastError($wpdb)) {
                return 0;
            }

            $this->lastOperationSucceeded = true;

            return max(0, $deleted);
        } catch (Throwable) {
            return 0;
        } finally {
            $this->restoreErrors($wpdb, $previousSuppression);
        }
    }

    public function cleanupExpired(int $now, int $batch = 500): int
    {
        $this->lastOperationSucceeded = false;

        if (! Installer::isReady() || $now < 1 || $batch < 1) {
            return 0;
        }

        $tableName = Installer::tableName(Installer::TABLE_BLOCKED_SUBMISSIONS);
        $wpdb = $this->database(['prepare', 'query']);

        if ('' === $tableName || null === $wpdb) {
            return 0;
        }

        $limit = min($batch, self::MAXIMUM_CLEANUP_BATCH);
        $previousSuppression = $this->suppressErrors($wpdb);

        try {
            $this->resetLastError($wpdb);
            $query = $wpdb->prepare(
                "DELETE FROM {$tableName} WHERE expires_at <= %d ORDER BY expires_at ASC LIMIT %d",
                $now,
                $limit
            );

            if (! is_string($query) || '' === $query) {
                return 0;
            }

            $deleted = $wpdb->query($query);
            if (! is_int($deleted) || '' !== $this->lastError($wpdb)) {
                return 0;
            }

            $this->lastOperationSucceeded = true;

            return max(0, $deleted);
        } catch (Throwable) {
            return 0;
        } finally {
            $this->restoreErrors($wpdb, $previousSuppression);
        }
    }

    /**
     * @param array<string, mixed> $event
     *
     * @return array{
     *     reason: string,
     *     post_id: int,
     *     widget_id: string,
     *     form_name: string,
     *     page_url: string,
     *     fields_json: string,
     *     email_hash: string,
     *     created_at: int,
     *     expires_at: int
     * }|null
     */
    private function normalizeEvent(array $event): ?array
    {
        $reason = isset($event['reason']) && is_string($event['reason'])
            ? trim($event['reason'])
            : '';
        $formName = isset($event['form_name']) && is_string($event['form_name'])
            ? trim($event['form_name'])
            : '';
        $postId = $this->nonNegativeInteger($event['post_id'] ?? 0);
        $widgetId = isset($event['widget_id']) && is_string($event['widget_id'])
            ? trim($event['widget_id'])
            : '';
        $pageUrl = isset($event['page_url']) && is_string($event['page_url'])
            ? trim($event['page_url'])
            : '';
        $emailHash = isset($event['email_hash']) && is_string($event['email_hash'])
            ? strtolower(trim($event['email_hash']))
            : '';
        $createdAt = $this->positiveInteger($event['created_at'] ?? null);
        $expiresAt = $this->positiveInteger($event['expires_at'] ?? null);
        $fieldsJson = $this->normalizeFieldsJson($event);

        if (
            1 !== preg_match('/\A[a-z0-9_]{1,64}\z/D', $reason)
            || null === $postId
            || 1 !== preg_match('/\A[A-Za-z0-9_-]{0,128}\z/D', $widgetId)
            || ! $this->validUtf8WithinCharacters($formName, self::MAXIMUM_FORM_NAME_CHARACTERS)
            || ! $this->validUtf8WithinBytes($pageUrl, self::MAXIMUM_PAGE_URL_BYTES)
            || ('' !== $emailHash && ! self::isEmailHash($emailHash))
            || null === $createdAt
            || null === $expiresAt
            || $expiresAt <= $createdAt
            || null === $fieldsJson
        ) {
            return null;
        }

        return [
            'reason' => $reason,
            'post_id' => $postId,
            'widget_id' => $widgetId,
            'form_name' => $formName,
            'page_url' => $pageUrl,
            'fields_json' => $fieldsJson,
            'email_hash' => $emailHash,
            'created_at' => $createdAt,
            'expires_at' => $expiresAt,
        ];
    }

    /**
     * @param array<string, mixed> $event
     */
    private function normalizeFieldsJson(array $event): ?string
    {
        $fields = $event['fields'] ?? null;

        if (! is_array($fields) && isset($event['fields_json']) && is_string($event['fields_json'])) {
            try {
                $decoded = json_decode($event['fields_json'], true, 32, JSON_THROW_ON_ERROR);
            } catch (JsonException) {
                return null;
            }

            $fields = is_array($decoded) ? $decoded : null;
        }

        if (! is_array($fields) || ! $this->jsonValueIsSupported($fields, 0)) {
            return null;
        }

        try {
            $json = json_encode(
                $fields,
                JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE,
                32
            );
        } catch (JsonException | \ValueError) {
            return null;
        }

        return is_string($json) && strlen($json) <= self::MAXIMUM_FIELDS_JSON_BYTES
            ? $json
            : null;
    }

    /**
     * @param array<string, mixed> $args
     *
     * @return array{
     *     reason: string,
     *     search: string,
     *     email_hash: string,
     *     offset: int,
     *     limit: int,
     *     order: 'ASC'|'DESC'
     * }|null
     */
    private function normalizeFilters(array $args, bool $withPagination): ?array
    {
        $reason = isset($args['reason']) && is_string($args['reason'])
            ? trim($args['reason'])
            : '';
        $search = isset($args['search']) && is_string($args['search'])
            ? trim($args['search'])
            : '';
        $emailHash = isset($args['email_hash']) && is_string($args['email_hash'])
            ? strtolower(trim($args['email_hash']))
            : '';

        if (
            ('' !== $reason && 1 !== preg_match('/\A[a-z0-9_]{1,64}\z/D', $reason))
            || ! $this->validUtf8WithinBytes($search, self::MAXIMUM_SEARCH_BYTES)
            || ('' !== $emailHash && ! self::isEmailHash($emailHash))
        ) {
            return null;
        }

        $offset = $withPagination ? $this->nonNegativeInteger($args['offset'] ?? 0) : 0;
        $limit = $withPagination
            ? $this->positiveInteger($args['limit'] ?? self::DEFAULT_LIST_LIMIT)
            : self::DEFAULT_LIST_LIMIT;

        if (null === $offset || null === $limit) {
            return null;
        }

        $order = isset($args['order']) && is_string($args['order'])
            ? strtoupper(trim($args['order']))
            : 'DESC';

        if (! in_array($order, ['ASC', 'DESC'], true)) {
            return null;
        }

        return [
            'reason' => $reason,
            'search' => $search,
            'email_hash' => $emailHash,
            'offset' => $offset,
            'limit' => min($limit, self::MAXIMUM_LIST_LIMIT),
            'order' => $order,
        ];
    }

    /**
     * @param array{reason: string, search: string, email_hash: string} $filters
     *
     * @return array{sql: string, values: array<int, int|string>}
     */
    private function buildWhere(array $filters, object $wpdb): array
    {
        $clauses = [];
        $values = [];

        if ('' !== $filters['reason']) {
            $clauses[] = 'reason = %s';
            $values[] = $filters['reason'];
        }

        if ('' !== $filters['email_hash']) {
            $clauses[] = 'email_hash = %s';
            $values[] = $filters['email_hash'];
        }

        if ('' !== $filters['search']) {
            $escaped = method_exists($wpdb, 'esc_like')
                ? $wpdb->esc_like($filters['search'])
                : addcslashes($filters['search'], '_%\\');
            $like = '%' . $escaped . '%';
            $clauses[] = '(reason LIKE %s OR form_name LIKE %s OR page_url LIKE %s OR fields_json LIKE %s)';
            array_push($values, $like, $like, $like, $like);
        }

        return [
            'sql' => [] === $clauses ? '' : ' WHERE ' . implode(' AND ', $clauses),
            'values' => $values,
        ];
    }

    /**
     * @param array<string, mixed> $row
     *
     * @return array{
     *     id: int,
     *     reason: string,
     *     post_id: int,
     *     widget_id: string,
     *     form_name: string,
     *     page_url: string,
     *     fields: array<mixed>,
     *     fields_json: string,
     *     email_hash: string,
     *     created_at: int,
     *     expires_at: int
     * }|null
     */
    private function hydrate(array $row): ?array
    {
        $id = $this->positiveInteger($row['id'] ?? null);
        $createdAt = $this->positiveInteger($row['created_at'] ?? null);
        $expiresAt = $this->positiveInteger($row['expires_at'] ?? null);
        $reason = isset($row['reason']) && is_string($row['reason']) ? $row['reason'] : '';
        $postId = $this->nonNegativeInteger($row['post_id'] ?? null);
        $widgetId = isset($row['widget_id']) && is_string($row['widget_id']) ? $row['widget_id'] : '';
        $formName = isset($row['form_name']) && is_string($row['form_name']) ? $row['form_name'] : '';
        $pageUrl = isset($row['page_url']) && is_string($row['page_url']) ? $row['page_url'] : '';
        $fieldsJson = isset($row['fields_json']) && is_string($row['fields_json']) ? $row['fields_json'] : '';
        $emailHash = isset($row['email_hash']) && is_string($row['email_hash'])
            ? strtolower($row['email_hash'])
            : '';

        if (
            null === $id
            || null === $createdAt
            || null === $expiresAt
            || 1 !== preg_match('/\A[a-z0-9_]{1,64}\z/D', $reason)
            || null === $postId
            || 1 !== preg_match('/\A[A-Za-z0-9_-]{0,128}\z/D', $widgetId)
            || ! $this->validUtf8WithinCharacters($formName, self::MAXIMUM_FORM_NAME_CHARACTERS)
            || ! $this->validUtf8WithinBytes($pageUrl, self::MAXIMUM_PAGE_URL_BYTES)
            || ('' !== $emailHash && ! self::isEmailHash($emailHash))
            || strlen($fieldsJson) > self::MAXIMUM_FIELDS_JSON_BYTES
        ) {
            return null;
        }

        try {
            $fields = json_decode($fieldsJson, true, 32, JSON_THROW_ON_ERROR);
        } catch (JsonException) {
            return null;
        }

        if (! is_array($fields) || ! $this->jsonValueIsSupported($fields, 0)) {
            return null;
        }

        return [
            'id' => $id,
            'reason' => $reason,
            'post_id' => $postId,
            'widget_id' => $widgetId,
            'form_name' => $formName,
            'page_url' => $pageUrl,
            'fields' => $fields,
            'fields_json' => $fieldsJson,
            'email_hash' => $emailHash,
            'created_at' => $createdAt,
            'expires_at' => $expiresAt,
        ];
    }

    private function validUtf8WithinBytes(string $value, int $maximumBytes): bool
    {
        return strlen($value) <= $maximumBytes && 1 === preg_match('//u', $value);
    }

    private function validUtf8WithinCharacters(string $value, int $maximumCharacters): bool
    {
        if (1 !== preg_match('//u', $value)) {
            return false;
        }

        $length = function_exists('mb_strlen')
            ? mb_strlen($value, 'UTF-8')
            : strlen($value);

        return $length <= $maximumCharacters;
    }

    private function jsonValueIsSupported(mixed $value, int $depth): bool
    {
        if ($depth > 16) {
            return false;
        }

        if (is_string($value)) {
            return 1 === preg_match('//u', $value);
        }

        if (is_int($value) || is_bool($value) || null === $value) {
            return true;
        }

        if (is_float($value)) {
            return is_finite($value);
        }

        if (! is_array($value)) {
            return false;
        }

        foreach ($value as $key => $item) {
            if (
                (! is_int($key) && ! is_string($key))
                || (is_string($key) && 1 !== preg_match('//u', $key))
                || ! $this->jsonValueIsSupported($item, $depth + 1)
            ) {
                return false;
            }
        }

        return true;
    }

    private function positiveInteger(mixed $value): ?int
    {
        $integer = $this->nonNegativeInteger($value);

        return null !== $integer && $integer > 0 ? $integer : null;
    }

    private function nonNegativeInteger(mixed $value): ?int
    {
        if (is_int($value)) {
            return $value >= 0 ? $value : null;
        }

        if (! is_string($value) || 1 !== preg_match('/\A(?:0|[1-9][0-9]*)\z/D', $value)) {
            return null;
        }

        $integer = (int) $value;

        return (string) $integer === $value ? $integer : null;
    }

    private static function isEmailHash(string $value): bool
    {
        return 1 === preg_match('/\A[a-f0-9]{64}\z/D', $value);
    }

    /**
     * @param string[] $methods
     */
    private function database(array $methods): ?object
    {
        global $wpdb;

        if (! is_object($wpdb)) {
            return null;
        }

        foreach ($methods as $method) {
            if (! method_exists($wpdb, $method)) {
                return null;
            }
        }

        return $wpdb;
    }

    private function suppressErrors(object $wpdb): ?bool
    {
        if (! method_exists($wpdb, 'suppress_errors')) {
            return null;
        }

        return (bool) $wpdb->suppress_errors();
    }

    private function restoreErrors(object $wpdb, ?bool $previousSuppression): void
    {
        if (null !== $previousSuppression && method_exists($wpdb, 'suppress_errors')) {
            $wpdb->suppress_errors($previousSuppression);
        }
    }

    private function resetLastError(object $wpdb): void
    {
        if (property_exists($wpdb, 'last_error')) {
            $wpdb->last_error = '';
        }
    }

    private function lastError(object $wpdb): string
    {
        return isset($wpdb->last_error) ? (string) $wpdb->last_error : '';
    }
}
