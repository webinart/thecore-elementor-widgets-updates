<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity\Infrastructure;

use TheCore\ElementorWidgets\Contracts\Bootable;

final class Maintenance implements Bootable
{
    public const CLEANUP_HOOK = 'thecore_elementor_form_security_cleanup';

    private readonly BlockedSubmissionStore $blockedSubmissionStore;

    public function __construct(
        private readonly SecurityStore $store,
        ?BlockedSubmissionStore $blockedSubmissionStore = null
    ) {
        $this->blockedSubmissionStore = $blockedSubmissionStore ?? new BlockedSubmissionStore();
    }

    public function register(): void
    {
        add_action('admin_init', [Installer::class, 'maybeUpgrade'], 1);
        add_action('init', [$this, 'scheduleCleanup']);
        add_action(self::CLEANUP_HOOK, [$this, 'cleanup']);

        if (defined('WP_CLI') && true === WP_CLI) {
            add_action('cli_init', [$this, 'registerCliCommands']);
        }
    }

    public function scheduleCleanup(): void
    {
        if (! wp_next_scheduled(self::CLEANUP_HOOK)) {
            wp_schedule_event(time() + HOUR_IN_SECONDS, 'hourly', self::CLEANUP_HOOK);
        }
    }

    public function cleanup(): void
    {
        $now = time();

        $this->store->cleanupExpired($now, 500);
        $this->blockedSubmissionStore->cleanupExpired($now, 5000);
    }

    public function registerCliCommands(): void
    {
        if (! class_exists('\WP_CLI')) {
            return;
        }

        \WP_CLI::add_command(
            'thecore form-security status',
            [$this, 'cliStatus'],
            ['shortdesc' => 'Inspect the local Elementor Form Security schema.']
        );
        \WP_CLI::add_command(
            'thecore form-security schema',
            [$this, 'cliSchema'],
            ['shortdesc' => 'Verify or install the local Form Security schema.']
        );
    }

    /**
     * @param mixed $args
     * @param mixed $assocArgs
     */
    public function cliStatus($args, $assocArgs): void
    {
        unset($args, $assocArgs);

        \WP_CLI::log(
            wp_json_encode(
                [
                    'schema_version' => (string) get_option(Installer::OPTION_NAME, ''),
                    'schema_ready' => Installer::isReady(),
                    'schema_strictly_valid' => Installer::hasExpectedSchema(),
                    'tables' => Installer::tableNames(),
                    'cleanup_scheduled' => (bool) wp_next_scheduled(self::CLEANUP_HOOK),
                    'altcha_mode' => 'self-hosted',
                    'external_verification' => false,
                ],
                JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES
            )
        );
    }

    /**
     * @param string[]             $args
     * @param array<string, mixed> $assocArgs
     */
    public function cliSchema(array $args, array $assocArgs): void
    {
        unset($assocArgs);

        $operation = isset($args[0]) ? strtolower((string) $args[0]) : 'verify';
        if (! in_array($operation, ['verify', 'install'], true)) {
            \WP_CLI::error('Action invalide. Utiliser verify ou install.');
        }

        if ('install' === $operation && ! Installer::install()) {
            \WP_CLI::error('Installation du schéma Form Security impossible.');
        }

        if (! Installer::isReady() || ! Installer::hasExpectedSchema()) {
            \WP_CLI::error('Le schéma Form Security est absent ou non conforme.');
        }

        \WP_CLI::success('Schéma Form Security conforme (version ' . Installer::VERSION . ', InnoDB).');
    }
}
