<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity\Infrastructure;

use Throwable;

final class BlockedSubmissionDataPurger
{
    public function purgeCurrentSite(): bool
    {
        $tableName = Installer::tableName(Installer::TABLE_BLOCKED_SUBMISSIONS);

        if ('' === $tableName || ! Installer::isValidTableName($tableName)) {
            return false;
        }

        global $wpdb;

        if (! is_object($wpdb) || ! method_exists($wpdb, 'query')) {
            return false;
        }

        $previousSuppression = $this->suppressErrors($wpdb);

        try {
            $this->resetLastError($wpdb);
            $result = $wpdb->query("DROP TABLE IF EXISTS `{$tableName}`");

            return false !== $result && '' === $this->lastError($wpdb);
        } catch (Throwable) {
            return false;
        } finally {
            $this->restoreErrors($wpdb, $previousSuppression);
        }
    }

    public function purgeForDeactivation(bool $networkWide = false): bool
    {
        if (! $networkWide) {
            return $this->purgeCurrentSite();
        }

        $multisite = $this->multisiteStatus();

        if (null === $multisite) {
            return false;
        }

        return $multisite ? $this->purgeNetworkSites() : $this->purgeCurrentSite();
    }

    public function purgeForUninstall(): bool
    {
        $multisite = $this->multisiteStatus();

        if (null === $multisite) {
            return false;
        }

        return $multisite ? $this->purgeNetworkSites() : $this->purgeCurrentSite();
    }

    private function purgeNetworkSites(): bool
    {
        if (
            ! function_exists('get_sites')
            || ! function_exists('switch_to_blog')
            || ! function_exists('restore_current_blog')
        ) {
            return false;
        }

        try {
            $sites = get_sites(
                [
                    'fields' => 'ids',
                    'number' => 0,
                ]
            );
        } catch (Throwable) {
            return false;
        }

        $siteIds = $this->normalizeSiteIds($sites);
        if ([] === $siteIds) {
            return false;
        }

        $success = true;

        foreach ($siteIds as $siteId) {
            $switchAttempted = false;
            $contextRestored = true;

            try {
                $switchAttempted = true;
                $switched = true === switch_to_blog($siteId);

                if (! $switched) {
                    $success = false;
                } elseif (! $this->purgeCurrentSite()) {
                    $success = false;
                }
            } catch (Throwable) {
                $success = false;
            } finally {
                if ($switchAttempted) {
                    try {
                        $contextRestored = false !== restore_current_blog();
                    } catch (Throwable) {
                        $contextRestored = false;
                    }
                }
            }

            if (! $contextRestored) {
                // Continuing without a trustworthy blog context could target
                // the wrong table prefix, so stop immediately.
                return false;
            }
        }

        return $success;
    }

    /**
     * @param mixed $sites
     *
     * @return int[]
     */
    private function normalizeSiteIds(mixed $sites): array
    {
        if (! is_array($sites)) {
            return [];
        }

        $siteIds = [];

        foreach ($sites as $site) {
            if (is_object($site) && isset($site->blog_id)) {
                $site = $site->blog_id;
            }

            if (is_int($site)) {
                $siteId = $site;
            } elseif (
                is_string($site)
                && 1 === preg_match('/\A[1-9][0-9]*\z/D', $site)
            ) {
                $siteId = (int) $site;
            } else {
                return [];
            }

            if ($siteId < 1 || (is_string($site) && (string) $siteId !== $site)) {
                return [];
            }

            $siteIds[$siteId] = $siteId;
        }

        return array_values($siteIds);
    }

    private function multisiteStatus(): ?bool
    {
        if (! function_exists('is_multisite')) {
            return null;
        }

        try {
            return is_multisite();
        } catch (Throwable) {
            return null;
        }
    }

    private function suppressErrors(object $wpdb): ?bool
    {
        if (! method_exists($wpdb, 'suppress_errors')) {
            return null;
        }

        return (bool) $wpdb->suppress_errors();
    }

    private function restoreErrors(object $wpdb, ?bool $previousSuppression): void
    {
        if (null !== $previousSuppression && method_exists($wpdb, 'suppress_errors')) {
            $wpdb->suppress_errors($previousSuppression);
        }
    }

    private function resetLastError(object $wpdb): void
    {
        if (property_exists($wpdb, 'last_error')) {
            $wpdb->last_error = '';
        }
    }

    private function lastError(object $wpdb): string
    {
        return isset($wpdb->last_error) ? (string) $wpdb->last_error : '';
    }
}
