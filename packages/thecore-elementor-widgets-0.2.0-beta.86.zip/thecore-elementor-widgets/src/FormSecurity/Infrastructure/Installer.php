<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity\Infrastructure;

use Throwable;

final class Installer
{
    public const VERSION = '2';
    public const OPERATIONAL_VERSION = '1';
    public const OPTION_NAME = 'thecore_elementor_form_security_schema_version';

    public const TABLE_REPLAY = 'replay';
    public const TABLE_RATE = 'rate';
    public const TABLE_DEDUPLICATION = 'deduplication';
    public const TABLE_BLOCKED_SUBMISSIONS = 'blocked_submissions';

    /**
     * @var array<string, string>
     */
    private const TABLE_SUFFIXES = [
        self::TABLE_REPLAY => 'thecore_form_altcha_replay',
        self::TABLE_RATE => 'thecore_form_rate_buckets',
        self::TABLE_DEDUPLICATION => 'thecore_form_deduplication',
        self::TABLE_BLOCKED_SUBMISSIONS => 'thecore_form_blocked_submissions',
    ];

    public static function install(): bool
    {
        global $wpdb;

        $previousVersion = self::storedVersion();
        $tables = self::tableNames();

        if (
            ! is_object($wpdb)
            || count(self::TABLE_SUFFIXES) !== count($tables)
            || ! method_exists($wpdb, 'get_charset_collate')
        ) {
            return self::failInstallation($previousVersion);
        }

        if (! function_exists('dbDelta')) {
            if (! defined('ABSPATH')) {
                return self::failInstallation($previousVersion);
            }

            $upgradeFile = ABSPATH . 'wp-admin/includes/upgrade.php';

            if (! is_readable($upgradeFile)) {
                return self::failInstallation($previousVersion);
            }

            require_once $upgradeFile;
        }

        if (! function_exists('dbDelta')) {
            return self::failInstallation($previousVersion);
        }

        $charsetCollate = trim((string) $wpdb->get_charset_collate());
        $tableOptions = 'ENGINE=InnoDB';

        if ('' !== $charsetCollate) {
            $tableOptions .= ' ' . $charsetCollate;
        }

        $queries = [
            "CREATE TABLE {$tables[self::TABLE_REPLAY]} (
                proof_hash char(64) NOT NULL,
                expires_at bigint(20) unsigned NOT NULL,
                created_at bigint(20) unsigned NOT NULL,
                PRIMARY KEY  (proof_hash),
                KEY expires_at (expires_at)
            ) {$tableOptions};",
            "CREATE TABLE {$tables[self::TABLE_RATE]} (
                bucket_hash binary(32) NOT NULL,
                window_start bigint(20) unsigned NOT NULL,
                hits int(10) unsigned NOT NULL,
                expires_at bigint(20) unsigned NOT NULL,
                PRIMARY KEY  (bucket_hash, window_start),
                KEY expires_at (expires_at)
            ) {$tableOptions};",
            "CREATE TABLE {$tables[self::TABLE_DEDUPLICATION]} (
                fingerprint binary(32) NOT NULL,
                owner_token binary(16) NOT NULL,
                expires_at bigint(20) unsigned NOT NULL,
                created_at bigint(20) unsigned NOT NULL,
                PRIMARY KEY  (fingerprint),
                KEY expires_at (expires_at)
            ) {$tableOptions};",
            "CREATE TABLE {$tables[self::TABLE_BLOCKED_SUBMISSIONS]} (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                reason varchar(64) NOT NULL,
                post_id bigint(20) unsigned NOT NULL DEFAULT 0,
                widget_id varchar(128) NOT NULL DEFAULT '',
                form_name varchar(191) NOT NULL,
                page_url text NOT NULL,
                fields_json longtext NOT NULL,
                email_hash char(64) NOT NULL DEFAULT '',
                created_at bigint(20) unsigned NOT NULL,
                expires_at bigint(20) unsigned NOT NULL,
                PRIMARY KEY  (id),
                KEY expires_at (expires_at),
                KEY created_at (created_at),
                KEY reason_created_at (reason, created_at),
                KEY email_hash (email_hash)
            ) {$tableOptions};",
        ];

        try {
            dbDelta($queries);
        } catch (Throwable) {
            return self::failInstallation($previousVersion);
        }

        if (! self::hasExpectedSchema()) {
            return self::failInstallation($previousVersion);
        }

        update_option(self::OPTION_NAME, self::VERSION, false);

        if (! self::isReady()) {
            return self::failInstallation($previousVersion);
        }

        return true;
    }

    public static function maybeUpgrade(): bool
    {
        if (self::isReady()) {
            return true;
        }

        $isCli = defined('WP_CLI') && true === WP_CLI;
        $isAdmin = function_exists('is_admin') && is_admin();

        if (! $isCli && ! $isAdmin) {
            return false;
        }

        if (
            ! $isCli
            && (
                ! function_exists('current_user_can')
                || ! current_user_can('manage_options')
            )
        ) {
            return false;
        }

        return self::install();
    }

    /** Full v2 readiness, including the secondary detailed journal. */
    public static function isReady(): bool
    {
        if (! function_exists('get_option')) {
            return false;
        }

        return self::VERSION === (string) get_option(self::OPTION_NAME, '');
    }

    /**
     * Schema v1 contains the three fail-closed protection tables. Preserve
     * their availability while an administrator retries the secondary journal
     * migration to v2.
     */
    public static function isOperationallyReady(): bool
    {
        return in_array(
            self::storedVersion(),
            [self::OPERATIONAL_VERSION, self::VERSION],
            true
        );
    }

    /**
     * @return array<string, string>
     */
    public static function tableNames(): array
    {
        $tables = [];

        foreach (array_keys(self::TABLE_SUFFIXES) as $tableKey) {
            $tableName = self::tableName($tableKey);

            if ('' === $tableName) {
                return [];
            }

            $tables[$tableKey] = $tableName;
        }

        return $tables;
    }

    public static function tableName(string $tableKey): string
    {
        if (! isset(self::TABLE_SUFFIXES[$tableKey])) {
            return '';
        }

        global $wpdb;

        if (! is_object($wpdb) || ! isset($wpdb->prefix) || ! is_string($wpdb->prefix)) {
            return '';
        }

        $tableName = $wpdb->prefix . self::TABLE_SUFFIXES[$tableKey];

        return self::isValidTableName($tableName) ? $tableName : '';
    }

    public static function isValidTableName(string $tableName): bool
    {
        return '' !== $tableName
            && strlen($tableName) <= 64
            && 1 === preg_match('/\A[A-Za-z0-9_]+\z/D', $tableName);
    }

    /**
     * Full SQL introspection is intentionally reserved for installation,
     * upgrades and diagnostics. Public protection traffic calls
     * isOperationallyReady().
     */
    public static function hasExpectedSchema(): bool
    {
        global $wpdb;

        if (
            ! is_object($wpdb)
            || ! method_exists($wpdb, 'prepare')
            || ! method_exists($wpdb, 'get_row')
            || ! method_exists($wpdb, 'get_results')
        ) {
            return false;
        }

        $tables = self::tableNames();

        if (count(self::TABLE_SUFFIXES) !== count($tables)) {
            return false;
        }

        $schemas = [
            self::TABLE_REPLAY => [
                'columns' => [
                    'proof_hash' => '/\Achar\(64\)\z/',
                    'expires_at' => '/\Abigint(?:\(20\))? unsigned\z/',
                    'created_at' => '/\Abigint(?:\(20\))? unsigned\z/',
                ],
                'indexes' => [
                    'PRIMARY' => [
                        'unique' => true,
                        'columns' => ['proof_hash'],
                    ],
                    'expires_at' => [
                        'unique' => false,
                        'columns' => ['expires_at'],
                    ],
                ],
            ],
            self::TABLE_RATE => [
                'columns' => [
                    'bucket_hash' => '/\Abinary\(32\)\z/',
                    'window_start' => '/\Abigint(?:\(20\))? unsigned\z/',
                    'hits' => '/\Aint(?:\(10\))? unsigned\z/',
                    'expires_at' => '/\Abigint(?:\(20\))? unsigned\z/',
                ],
                'indexes' => [
                    'PRIMARY' => [
                        'unique' => true,
                        'columns' => ['bucket_hash', 'window_start'],
                    ],
                    'expires_at' => [
                        'unique' => false,
                        'columns' => ['expires_at'],
                    ],
                ],
            ],
            self::TABLE_DEDUPLICATION => [
                'columns' => [
                    'fingerprint' => '/\Abinary\(32\)\z/',
                    'owner_token' => '/\Abinary\(16\)\z/',
                    'expires_at' => '/\Abigint(?:\(20\))? unsigned\z/',
                    'created_at' => '/\Abigint(?:\(20\))? unsigned\z/',
                ],
                'indexes' => [
                    'PRIMARY' => [
                        'unique' => true,
                        'columns' => ['fingerprint'],
                    ],
                    'expires_at' => [
                        'unique' => false,
                        'columns' => ['expires_at'],
                    ],
                ],
            ],
            self::TABLE_BLOCKED_SUBMISSIONS => [
                'columns' => [
                    'id' => '/\Abigint(?:\(20\))? unsigned\z/',
                    'reason' => '/\Avarchar\(64\)\z/',
                    'post_id' => '/\Abigint(?:\(20\))? unsigned\z/',
                    'widget_id' => '/\Avarchar\(128\)\z/',
                    'form_name' => '/\Avarchar\(191\)\z/',
                    'page_url' => '/\Atext\z/',
                    'fields_json' => '/\Alongtext\z/',
                    'email_hash' => '/\Achar\(64\)\z/',
                    'created_at' => '/\Abigint(?:\(20\))? unsigned\z/',
                    'expires_at' => '/\Abigint(?:\(20\))? unsigned\z/',
                ],
                'indexes' => [
                    'PRIMARY' => [
                        'unique' => true,
                        'columns' => ['id'],
                    ],
                    'expires_at' => [
                        'unique' => false,
                        'columns' => ['expires_at'],
                    ],
                    'created_at' => [
                        'unique' => false,
                        'columns' => ['created_at'],
                    ],
                    'reason_created_at' => [
                        'unique' => false,
                        'columns' => ['reason', 'created_at'],
                    ],
                    'email_hash' => [
                        'unique' => false,
                        'columns' => ['email_hash'],
                    ],
                ],
            ],
        ];

        try {
            foreach ($schemas as $tableKey => $schema) {
                $tableName = $tables[$tableKey];

                if (
                    ! self::usesInnoDb($tableName)
                    || ! self::columnsMatch($tableName, $schema['columns'])
                    || ! self::indexesMatch($tableName, $schema['indexes'])
                ) {
                    return false;
                }
            }
        } catch (Throwable) {
            return false;
        }

        return true;
    }

    private static function usesInnoDb(string $tableName): bool
    {
        global $wpdb;

        self::resetLastError();
        $query = $wpdb->prepare('SHOW TABLE STATUS WHERE Name = %s', $tableName);

        if (! is_string($query) || '' === $query) {
            return false;
        }

        $status = $wpdb->get_row($query, 'ARRAY_A');

        return '' === self::lastError()
            && is_array($status)
            && isset($status['Engine'])
            && 'innodb' === strtolower((string) $status['Engine']);
    }

    /**
     * @param array<string, string> $expectedColumns
     */
    private static function columnsMatch(string $tableName, array $expectedColumns): bool
    {
        global $wpdb;

        self::resetLastError();
        $columns = $wpdb->get_results("SHOW FULL COLUMNS FROM `{$tableName}`", 'ARRAY_A');

        if ('' !== self::lastError() || ! is_array($columns)) {
            return false;
        }

        $actualColumns = [];

        foreach ($columns as $column) {
            if (! is_array($column)) {
                return false;
            }

            $field = isset($column['Field']) ? (string) $column['Field'] : '';
            $type = isset($column['Type'])
                ? strtolower((string) preg_replace('/\s+/', ' ', trim((string) $column['Type'])))
                : '';
            $nullable = isset($column['Null']) ? strtoupper((string) $column['Null']) : '';

            if ('' === $field || 'NO' !== $nullable) {
                return false;
            }

            $actualColumns[$field] = $type;
        }

        // dbDelta appends newly introduced columns to an existing table. The
        // physical order is irrelevant; require the exact same set instead so
        // a legitimate versioned upgrade can still pass strict validation.
        if (
            count($expectedColumns) !== count($actualColumns)
            || [] !== array_diff_key($expectedColumns, $actualColumns)
            || [] !== array_diff_key($actualColumns, $expectedColumns)
        ) {
            return false;
        }

        foreach ($expectedColumns as $field => $typePattern) {
            if (1 !== preg_match($typePattern, $actualColumns[$field])) {
                return false;
            }
        }

        return true;
    }

    /**
     * @param array<string, array{unique: bool, columns: string[]}> $expectedIndexes
     */
    private static function indexesMatch(string $tableName, array $expectedIndexes): bool
    {
        global $wpdb;

        self::resetLastError();
        $indexes = $wpdb->get_results("SHOW INDEX FROM `{$tableName}`", 'ARRAY_A');

        if ('' !== self::lastError() || ! is_array($indexes)) {
            return false;
        }

        $actualIndexes = [];

        foreach ($indexes as $index) {
            if (
                ! is_array($index)
                || ! isset($index['Key_name'], $index['Non_unique'], $index['Seq_in_index'], $index['Column_name'])
                || (isset($index['Sub_part']) && null !== $index['Sub_part'])
            ) {
                return false;
            }

            $keyName = (string) $index['Key_name'];
            $sequence = (int) $index['Seq_in_index'];
            $isUnique = 0 === (int) $index['Non_unique'];

            if ('' === $keyName || $sequence < 1) {
                return false;
            }

            if (! isset($actualIndexes[$keyName])) {
                $actualIndexes[$keyName] = [
                    'unique' => $isUnique,
                    'columns' => [],
                ];
            } elseif ($actualIndexes[$keyName]['unique'] !== $isUnique) {
                return false;
            }

            $actualIndexes[$keyName]['columns'][$sequence] = (string) $index['Column_name'];
        }

        if (count($expectedIndexes) !== count($actualIndexes)) {
            return false;
        }

        foreach ($actualIndexes as $keyName => $actualIndex) {
            if (! isset($expectedIndexes[$keyName])) {
                return false;
            }

            ksort($actualIndex['columns'], SORT_NUMERIC);
            $actualColumns = array_values($actualIndex['columns']);

            if (
                $actualIndex['unique'] !== $expectedIndexes[$keyName]['unique']
                || $actualColumns !== $expectedIndexes[$keyName]['columns']
            ) {
                return false;
            }
        }

        return true;
    }

    private static function resetLastError(): void
    {
        global $wpdb;

        if (is_object($wpdb) && property_exists($wpdb, 'last_error')) {
            $wpdb->last_error = '';
        }
    }

    private static function lastError(): string
    {
        global $wpdb;

        return is_object($wpdb) && isset($wpdb->last_error)
            ? (string) $wpdb->last_error
            : '';
    }

    private static function failInstallation(string $previousVersion): bool
    {
        if (
            self::OPERATIONAL_VERSION === $previousVersion
            && function_exists('update_option')
        ) {
            update_option(self::OPTION_NAME, self::OPERATIONAL_VERSION, false);

            return false;
        }

        self::deleteStoredVersion();

        return false;
    }

    private static function storedVersion(): string
    {
        return function_exists('get_option')
            ? (string) get_option(self::OPTION_NAME, '')
            : '';
    }

    private static function deleteStoredVersion(): void
    {
        if (function_exists('delete_option')) {
            delete_option(self::OPTION_NAME);
        }
    }
}
