<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity\Security;

use TheCore\ElementorWidgets\FormSecurity\Security\Altcha\Pbkdf2Protocol;

/**
 * Strict, site-local ALTCHA challenge adapter.
 *
 * Context data is authenticated with the challenge and compared exactly at
 * verification time. The reserved `iat` key is added by this service.
 */
final class AltchaService
{
    private const MAX_PAYLOAD_BYTES = 16384;
    private const MAX_DECODED_BYTES = 12288;
    private const MAX_CONTEXT_BYTES = 4096;
    private const MAX_CONTEXT_DEPTH = 5;
    private const MAX_CONTEXT_ITEMS = 64;
    private const MAX_CONTEXT_STRING_BYTES = 2048;
    private const MAX_SOLUTION_TIME_MS = 120000.0;
    private const MAX_COST = 1000000;
    private const MAX_DELAY_SECONDS = 86400;
    private const MAX_COUNTER = 4294967295;

    private readonly Pbkdf2Protocol $protocol;

    public function __construct(
        private readonly string $signatureSecret,
        private readonly string $keySignatureSecret,
        private readonly int $cost,
        private readonly int $counterMinimum,
        private readonly int $counterMaximum,
        private readonly int $minimumDelaySeconds,
        private readonly int $maximumDelaySeconds
    ) {
        $this->assertConfiguration();
        $this->protocol = new Pbkdf2Protocol();
    }

    /**
     * @param array<string, mixed> $contextData
     *
     * @return array{
     *     parameters: array<string, mixed>,
     *     signature: string
     * }
     */
    public function createChallenge(array $contextData, ?int $now = null): array
    {
        $this->assertContextData($contextData);
        $issuedAt = $this->resolveNow($now);

        if ($issuedAt > PHP_INT_MAX - $this->maximumDelaySeconds) {
            throw new \InvalidArgumentException('ALTCHA challenge timestamp is out of range.');
        }

        $signedData = $contextData;
        $signedData['iat'] = $issuedAt;

        return $this->protocol->createChallenge(
            $this->signatureSecret,
            $this->keySignatureSecret,
            $this->cost,
            random_int($this->counterMinimum, $this->counterMaximum),
            $issuedAt + $this->maximumDelaySeconds,
            $signedData
        );
    }

    /**
     * @param array<string, mixed> $expectedContextData
     *
     * @return array{
     *     status: 'valid'|'invalid'|'expired'|'too_early',
     *     replayKey: string|null,
     *     expiresAt: int|null
     * }
     */
    public function verifyPayload(
        string $base64,
        array $expectedContextData,
        ?int $now = null
    ): array {
        $this->assertContextData($expectedContextData);
        $currentTime = $this->resolveNow($now);

        if (! $this->isStrictBase64($base64)) {
            return $this->result('invalid');
        }

        $json = base64_decode($base64, true);

        if (false === $json || strlen($json) > self::MAX_DECODED_BYTES) {
            return $this->result('invalid');
        }

        try {
            $decoded = json_decode($json, true, 16, JSON_THROW_ON_ERROR);

            if (! is_array($decoded)) {
                return $this->result('invalid');
            }

            return $this->verifyDecodedPayload($decoded, $expectedContextData, $currentTime);
        } catch (\JsonException | \ValueError) {
            return $this->result('invalid');
        } catch (\Throwable) {
            return $this->result('invalid');
        }
    }

    private function assertConfiguration(): void
    {
        if (
            strlen($this->signatureSecret) < 32
            || strlen($this->keySignatureSecret) < 32
            || strlen($this->signatureSecret) > 4096
            || strlen($this->keySignatureSecret) > 4096
            || hash_equals($this->signatureSecret, $this->keySignatureSecret)
        ) {
            throw new \InvalidArgumentException('ALTCHA requires two distinct secrets of at least 32 bytes.');
        }

        if ($this->cost < 1 || $this->cost > self::MAX_COST) {
            throw new \InvalidArgumentException('ALTCHA PBKDF2 cost is out of range.');
        }

        if (
            $this->counterMinimum < 0
            || $this->counterMaximum < $this->counterMinimum
            || $this->counterMaximum > self::MAX_COUNTER
        ) {
            throw new \InvalidArgumentException('ALTCHA counter bounds are invalid.');
        }

        if (
            $this->minimumDelaySeconds < 0
            || $this->maximumDelaySeconds <= $this->minimumDelaySeconds
            || $this->maximumDelaySeconds > self::MAX_DELAY_SECONDS
        ) {
            throw new \InvalidArgumentException('ALTCHA timing bounds are invalid.');
        }
    }

    /**
     * @param array<string, mixed> $contextData
     */
    private function assertContextData(array $contextData): void
    {
        if ([] === $contextData || array_is_list($contextData) || array_key_exists('iat', $contextData)) {
            throw new \InvalidArgumentException('ALTCHA context must be a non-empty map without the reserved `iat` key.');
        }

        if (! $this->contextArrayIsValid($contextData, 0, false)) {
            throw new \InvalidArgumentException('ALTCHA context contains unsupported keys or values.');
        }

        try {
            if (strlen($this->protocol->canonicalJson($contextData)) > self::MAX_CONTEXT_BYTES) {
                throw new \InvalidArgumentException('ALTCHA context is too large.');
            }
        } catch (\JsonException) {
            throw new \InvalidArgumentException('ALTCHA context is not valid JSON data.');
        }
    }

    private function resolveNow(?int $now): int
    {
        $timestamp = $now ?? time();

        if ($timestamp < 0) {
            throw new \InvalidArgumentException('ALTCHA timestamp must be non-negative.');
        }

        return $timestamp;
    }

    /**
     * @param array<mixed>         $decoded
     * @param array<string, mixed> $expectedContextData
     *
     * @return array{
     *     status: 'valid'|'invalid'|'expired'|'too_early',
     *     replayKey: string|null,
     *     expiresAt: int|null
     * }
     */
    private function verifyDecodedPayload(
        array $decoded,
        array $expectedContextData,
        int $currentTime
    ): array {
        if (! $this->hasExactKeys($decoded, ['challenge', 'solution'])) {
            return $this->result('invalid');
        }

        $challenge = $decoded['challenge'];
        $solution = $decoded['solution'];

        if (
            ! is_array($challenge)
            || ! is_array($solution)
            || ! $this->hasExactKeys($challenge, ['parameters', 'signature'])
            || ! is_array($challenge['parameters'])
            || ! $this->hasExactKeys(
                $challenge['parameters'],
                [
                    'algorithm',
                    'cost',
                    'data',
                    'expiresAt',
                    'keyLength',
                    'keyPrefix',
                    'keySignature',
                    'nonce',
                    'salt',
                ]
            )
            || ! $this->hasExactKeys($solution, ['counter', 'derivedKey'], ['time'])
        ) {
            return $this->result('invalid');
        }

        $parameters = $challenge['parameters'];
        $data = $parameters['data'];

        if (
            ! is_string($challenge['signature'])
            || ! $this->isLowerHex($challenge['signature'], 64)
            || Pbkdf2Protocol::ALGORITHM !== $parameters['algorithm']
            || ! is_int($parameters['cost'])
            || $this->cost !== $parameters['cost']
            || ! is_int($parameters['keyLength'])
            || Pbkdf2Protocol::KEY_LENGTH !== $parameters['keyLength']
            || ! is_string($parameters['keyPrefix'])
            || ! $this->isLowerHex($parameters['keyPrefix'], Pbkdf2Protocol::KEY_PREFIX_BYTES * 2)
            || ! is_string($parameters['keySignature'])
            || ! $this->isLowerHex($parameters['keySignature'], 64)
            || ! is_string($parameters['nonce'])
            || ! $this->isLowerHex($parameters['nonce'], 32)
            || ! is_string($parameters['salt'])
            || ! $this->isLowerHex($parameters['salt'], 32)
            || ! is_int($parameters['expiresAt'])
            || ! is_array($data)
            || ! is_int($solution['counter'])
            || $solution['counter'] < $this->counterMinimum
            || $solution['counter'] > $this->counterMaximum
            || ! is_string($solution['derivedKey'])
            || ! $this->isLowerHex($solution['derivedKey'], Pbkdf2Protocol::KEY_LENGTH * 2)
            || ! $this->solutionTimeIsValid($solution['time'] ?? null)
        ) {
            return $this->result('invalid');
        }

        $expectedSignature = $this->protocol->challengeSignature(
            $parameters,
            $this->signatureSecret
        );

        if (! hash_equals($expectedSignature, $challenge['signature'])) {
            return $this->result('invalid');
        }

        $issuedAt = $this->verifiedIssuedAt($data, $expectedContextData);

        if (
            null === $issuedAt
            || $issuedAt > PHP_INT_MAX - $this->maximumDelaySeconds
            || $parameters['expiresAt'] !== $issuedAt + $this->maximumDelaySeconds
        ) {
            return $this->result('invalid');
        }

        $replayKey = $challenge['signature'];
        $expiresAt = $parameters['expiresAt'];

        if ($currentTime > $expiresAt) {
            return $this->result('expired', $replayKey, $expiresAt);
        }

        if ($currentTime - $issuedAt < $this->minimumDelaySeconds) {
            return $this->result('too_early', $replayKey, $expiresAt);
        }

        $expectedKeySignature = $this->protocol->keySignature(
            $solution['derivedKey'],
            $this->keySignatureSecret
        );

        if (! hash_equals($expectedKeySignature, $parameters['keySignature'])) {
            return $this->result('invalid');
        }

        $derivedKey = $this->protocol->deriveKeyHex(
            $parameters['nonce'],
            $parameters['salt'],
            $parameters['cost'],
            $parameters['keyLength'],
            $solution['counter']
        );

        if (
            ! hash_equals($derivedKey, $solution['derivedKey'])
            || ! hash_equals(
                $parameters['keyPrefix'],
                substr($derivedKey, 0, Pbkdf2Protocol::KEY_PREFIX_BYTES * 2)
            )
        ) {
            return $this->result('invalid');
        }

        return $this->result('valid', $replayKey, $expiresAt);
    }

    /**
     * @param array<mixed>         $data
     * @param array<string, mixed> $expectedContextData
     */
    private function verifiedIssuedAt(array $data, array $expectedContextData): ?int
    {
        $expectedKeys = array_keys($expectedContextData);
        $expectedKeys[] = 'iat';

        if (
            ! $this->hasExactKeys($data, $expectedKeys)
            || ! isset($data['iat'])
            || ! is_int($data['iat'])
            || $data['iat'] < 0
            || ! $this->contextArrayIsValid($data, 0, true)
        ) {
            return null;
        }

        $submittedContext = $data;
        $issuedAt = $submittedContext['iat'];
        unset($submittedContext['iat']);

        try {
            $submittedJson = $this->protocol->canonicalJson($submittedContext);
            $expectedJson = $this->protocol->canonicalJson($expectedContextData);
        } catch (\JsonException) {
            return null;
        }

        if (
            strlen($submittedJson) > self::MAX_CONTEXT_BYTES
            || ! hash_equals($expectedJson, $submittedJson)
        ) {
            return null;
        }

        return $issuedAt;
    }

    /**
     * @param array<mixed> $value
     */
    private function contextArrayIsValid(array $value, int $depth, bool $allowIssuedAt): bool
    {
        if ($depth > self::MAX_CONTEXT_DEPTH || count($value) > self::MAX_CONTEXT_ITEMS) {
            return false;
        }

        $isList = array_is_list($value);

        foreach ($value as $key => $item) {
            if (! $isList) {
                if (
                    ! is_string($key)
                    || 1 !== preg_match('/\A[A-Za-z0-9_.:-]{1,64}\z/', $key)
                    || ('iat' === $key && ! $allowIssuedAt)
                ) {
                    return false;
                }
            }

            if (is_string($item)) {
                if (strlen($item) > self::MAX_CONTEXT_STRING_BYTES) {
                    return false;
                }

                continue;
            }

            if (is_int($item) || is_bool($item) || null === $item) {
                continue;
            }

            if (is_array($item) && $this->contextArrayIsValid($item, $depth + 1, $allowIssuedAt)) {
                continue;
            }

            return false;
        }

        return true;
    }

    /**
     * @param array<mixed> $value
     * @param string[]     $required
     * @param string[]     $optional
     */
    private function hasExactKeys(array $value, array $required, array $optional = []): bool
    {
        foreach ($required as $key) {
            if (! array_key_exists($key, $value)) {
                return false;
            }
        }

        $allowed = array_merge($required, $optional);

        foreach (array_keys($value) as $key) {
            if (! is_string($key) || ! in_array($key, $allowed, true)) {
                return false;
            }
        }

        return true;
    }

    private function isStrictBase64(string $value): bool
    {
        return '' !== $value
            && strlen($value) <= self::MAX_PAYLOAD_BYTES
            && 0 === strlen($value) % 4
            && 1 === preg_match(
                '/\A(?:[A-Za-z0-9+\/]{4})*(?:[A-Za-z0-9+\/]{2}==|[A-Za-z0-9+\/]{3}=)?\z/',
                $value
            );
    }

    private function isLowerHex(string $value, int $length): bool
    {
        return strlen($value) === $length
            && 1 === preg_match('/\A[a-f0-9]+\z/', $value);
    }

    private function solutionTimeIsValid(mixed $value): bool
    {
        if (null === $value) {
            return true;
        }

        if (! is_int($value) && ! is_float($value)) {
            return false;
        }

        $time = (float) $value;

        return is_finite($time) && $time >= 0.0 && $time <= self::MAX_SOLUTION_TIME_MS;
    }

    /**
     * @return array{
     *     status: 'valid'|'invalid'|'expired'|'too_early',
     *     replayKey: string|null,
     *     expiresAt: int|null
     * }
     */
    private function result(
        string $status,
        ?string $replayKey = null,
        ?int $expiresAt = null
    ): array {
        return [
            'status' => $status,
            'replayKey' => $replayKey,
            'expiresAt' => $expiresAt,
        ];
    }
}
