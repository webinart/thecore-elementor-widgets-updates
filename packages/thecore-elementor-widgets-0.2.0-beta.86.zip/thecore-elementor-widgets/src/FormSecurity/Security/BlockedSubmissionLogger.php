<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity\Security;

use TheCore\ElementorWidgets\FormSecurity\Infrastructure\BlockedSubmissionStore;
use TheCore\ElementorWidgets\FormSecurity\Infrastructure\Installer;
use TheCore\ElementorWidgets\FormSecurity\Infrastructure\SecurityStore;
use TheCore\ElementorWidgets\FormSecurity\Support\BlockedSubmissionPayloadBuilder;
use TheCore\ElementorWidgets\FormSecurity\Support\DataMinimizer;
use TheCore\ElementorWidgets\FormSecurity\Support\EmailIdentity;
use TheCore\ElementorWidgets\FormSecurity\Support\FormContext;
use TheCore\ElementorWidgets\FormSecurity\Support\Metrics;
use TheCore\ElementorWidgets\FormSecurity\Support\SecuritySettings;
use Throwable;

final class BlockedSubmissionLogger
{
    private const GLOBAL_QUOTA_IDENTITY = 'b6108e4fc529759d5cb08dbce05c9916e52810bf384f2302bd5f12a0d4cbd17c';

    public function __construct(
        private readonly BlockedSubmissionStore $store,
        private readonly SecurityStore $quotaStore,
        private readonly BlockedSubmissionPayloadBuilder $payloadBuilder,
        private readonly EmailIdentity $emailIdentity,
        private readonly DataMinimizer $minimizer,
        private readonly SecuritySettings $settings,
        private readonly Metrics $metrics,
        private readonly bool $personalDataLookupAvailable = true
    ) {
    }

    public function log(object $record, string $reason, ?FormContext $context): bool
    {
        if (! $this->shouldPersistDetails($reason)) {
            return false;
        }

        if (
            function_exists('apply_filters')
            && ! (bool) apply_filters(
                'thecore/elementor_forms/security/blocked_submission_logging_enabled',
                true,
                $reason,
                $context,
                $record
            )
        ) {
            return false;
        }

        // Schema v1 can keep protecting forms while the secondary v2 journal
        // migration is retried. Do not consume its daily quota until v2 exists.
        if (! $this->personalDataLookupAvailable || ! Installer::isReady()) {
            return false;
        }

        try {
            $now = time();
            $quotaStatus = $this->quotaStore->consumeRateLimit(
                'journal',
                self::GLOBAL_QUOTA_IDENTITY,
                DAY_IN_SECONDS,
                $this->settings->blockedSubmissionDailyLimit(),
                $now
            );

            if ('allowed' !== $quotaStatus) {
                $this->metrics->increment(
                    'limited' === $quotaStatus
                        ? 'blocked_log_daily_limit'
                        : 'blocked_log_write_error'
                );

                return false;
            }

            $recordFields = method_exists($record, 'get') ? $record->get('fields') : [];
            $recordFields = is_array($recordFields) ? $recordFields : [];
            $email = $this->payloadBuilder->emailFromRecord($recordFields, $context);
            $fields = $this->payloadBuilder->build($recordFields, $context);
            $fieldsJson = wp_json_encode(
                $fields,
                JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
            );

            if (! is_string($fieldsJson)) {
                $this->metrics->increment('blocked_log_write_error');

                return false;
            }

            $retention = $this->settings->blockedSubmissionRetentionDays() * DAY_IN_SECONDS;
            $formName = method_exists($record, 'get_form_settings')
                ? sanitize_text_field((string) $record->get_form_settings('form_name'))
                : '';
            $pageUrl = $this->pageUrl($record);

            $inserted = $this->store->insert([
                'created_at' => $now,
                'expires_at' => $now + $retention,
                'reason' => $reason,
                'post_id' => null !== $context ? $context->postId() : $this->postId($record),
                'widget_id' => null !== $context ? $context->widgetId() : '',
                'form_name' => $formName,
                'page_url' => $pageUrl,
                'email_hash' => $this->emailIdentity->hash($email),
                'fields_json' => $fieldsJson,
            ]);

            if (false === $inserted) {
                $this->metrics->increment('blocked_log_write_error');

                return false;
            }

            return true;
        } catch (Throwable) {
            // Logging is secondary: a storage problem must never undo a block.
            $this->metrics->increment('blocked_log_write_error');

            return false;
        }
    }

    private function shouldPersistDetails(string $reason): bool
    {
        return in_array(
            $reason,
            [
                'blocked_duplicate',
                'blocked_honeypot',
                'blocked_payload_size',
                'blocked_replay',
            ],
            true
        ) || 1 === preg_match('/\Ablocked_altcha_[a-z0-9_]{1,47}\z/D', $reason);
    }

    private function postId(object $record): int
    {
        if (! method_exists($record, 'get_form_settings')) {
            return 0;
        }

        return max(0, (int) $record->get_form_settings('form_post_id'));
    }

    private function pageUrl(object $record): string
    {
        $value = '';

        if (method_exists($record, 'get')) {
            $meta = $record->get('meta');

            if (
                is_array($meta)
                && isset($meta['page_url'])
                && is_array($meta['page_url'])
                && isset($meta['page_url']['value'])
                && is_scalar($meta['page_url']['value'])
            ) {
                $value = (string) $meta['page_url']['value'];
            }
        }

        if (
            '' === $value
            && isset($_POST['referrer'])
            && is_scalar($_POST['referrer'])
        ) {
            $value = (string) wp_unslash($_POST['referrer']);
        }

        return $this->minimizer->canonicalReferrer($value, home_url('/'));
    }
}
