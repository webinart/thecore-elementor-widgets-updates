<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity\Security\Altcha;

/**
 * Minimal ALTCHA v2 protocol primitives for PBKDF2/SHA-256 challenges.
 *
 * The implementation is intentionally private to the plugin. It mirrors the
 * canonical challenge encoding and key derivation used by altcha-php 2.1.0,
 * without requiring Composer at runtime.
 */
final class Pbkdf2Protocol
{
    public const ALGORITHM = 'PBKDF2/SHA-256';
    public const KEY_LENGTH = 32;
    public const KEY_PREFIX_BYTES = 16;

    /**
     * @param array<string, mixed> $data
     *
     * @return array{
     *     parameters: array<string, mixed>,
     *     signature: string
     * }
     */
    public function createChallenge(
        string $signatureSecret,
        string $keySignatureSecret,
        int $cost,
        int $counter,
        int $expiresAt,
        array $data
    ): array {
        $nonce = bin2hex(random_bytes(16));
        $salt = bin2hex(random_bytes(16));
        $derivedKey = $this->deriveKey($nonce, $salt, $cost, self::KEY_LENGTH, $counter);
        $derivedKeyHex = bin2hex($derivedKey);

        $parameters = [
            'algorithm' => self::ALGORITHM,
            'cost' => $cost,
            'data' => $data,
            'expiresAt' => $expiresAt,
            'keyLength' => self::KEY_LENGTH,
            'keyPrefix' => bin2hex(substr($derivedKey, 0, self::KEY_PREFIX_BYTES)),
            'keySignature' => $this->hmacHex($derivedKeyHex, $keySignatureSecret),
            'nonce' => $nonce,
            'salt' => $salt,
        ];

        ksort($parameters);

        return [
            'parameters' => $parameters,
            'signature' => $this->hmacHex($this->canonicalJson($parameters), $signatureSecret),
        ];
    }

    /**
     * @param array<string, mixed> $parameters
     */
    public function challengeSignature(array $parameters, string $secret): string
    {
        return $this->hmacHex($this->canonicalJson($parameters), $secret);
    }

    public function keySignature(string $derivedKeyHex, string $secret): string
    {
        return $this->hmacHex($derivedKeyHex, $secret);
    }

    public function deriveKeyHex(
        string $nonceHex,
        string $saltHex,
        int $cost,
        int $keyLength,
        int $counter
    ): string {
        return bin2hex($this->deriveKey($nonceHex, $saltHex, $cost, $keyLength, $counter));
    }

    /**
     * @param array<string, mixed> $data
     */
    public function canonicalJson(array $data): string
    {
        ksort($data);
        $this->sortRecursively($data);

        return json_encode(
            $data,
            JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
        );
    }

    private function deriveKey(
        string $nonceHex,
        string $saltHex,
        int $cost,
        int $keyLength,
        int $counter
    ): string {
        $nonce = hex2bin($nonceHex);
        $salt = hex2bin($saltHex);

        if (false === $nonce || false === $salt) {
            throw new \InvalidArgumentException('ALTCHA nonce and salt must be hexadecimal strings.');
        }

        return hash_pbkdf2(
            'sha256',
            $nonce . pack('N', $counter),
            $salt,
            $cost,
            $keyLength,
            true
        );
    }

    private function hmacHex(string $data, string $secret): string
    {
        return hash_hmac('sha256', $data, $secret);
    }

    /**
     * Match altcha-php's canonical JSON behavior: associative maps are sorted,
     * while JSON lists keep their original order.
     *
     * @param array<mixed> $data
     */
    private function sortRecursively(array &$data): void
    {
        foreach ($data as &$value) {
            if (is_array($value) && ! array_is_list($value)) {
                ksort($value);
                $this->sortRecursively($value);
            }
        }

        unset($value);
    }
}
