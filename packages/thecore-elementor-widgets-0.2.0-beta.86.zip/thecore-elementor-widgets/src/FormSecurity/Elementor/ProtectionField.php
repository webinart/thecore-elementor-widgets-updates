<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity\Elementor;

use ElementorPro\Core\Utils;
use ElementorPro\Modules\Forms\Fields\Field_Base;
use ElementorPro\Plugin as ElementorProPlugin;
use InvalidArgumentException;
use TheCore\ElementorWidgets\FormSecurity\Assets;
use TheCore\ElementorWidgets\FormSecurity\Support\ContextToken;
use TheCore\ElementorWidgets\FormSecurity\Support\FormContext;
use TheCore\ElementorWidgets\FormSecurity\Support\FormContextResolver;
use TheCore\ElementorWidgets\FormSecurity\Support\SecuritySettings;

final class ProtectionField extends Field_Base
{
    public function __construct(
        private readonly ContextToken $contextToken,
        private readonly SecuritySettings $settings
    ) {
        parent::__construct();
    }

    public function get_type(): string
    {
        return FormContextResolver::FIELD_TYPE;
    }

    public function get_name(): string
    {
        return __('The Core — Protection anti-spam', 'thecore-elementor-widgets');
    }

    /**
     * @return string[]
     */
    public function get_script_depends(): array
    {
        return [Assets::SCRIPT];
    }

    /**
     * @return string[]
     */
    public function get_style_depends(): array
    {
        return [Assets::STYLE];
    }

    /**
     * @param array<string, mixed> $item
     * @param mixed                $itemIndex
     * @param object               $form
     */
    public function render($item, $itemIndex, $form): void
    {
        unset($itemIndex);

        $fieldId = is_array($item) && isset($item['custom_id'])
            ? (string) $item['custom_id']
            : '';
        $widgetId = is_object($form) && method_exists($form, 'get_id')
            ? (string) $form->get_id()
            : '';
        $postId = class_exists(Utils::class) ? (int) Utils::get_current_post_id() : 0;

        try {
            $context = new FormContext($postId, $widgetId, $fieldId);
        } catch (InvalidArgumentException) {
            $this->renderUnavailableMessage();

            return;
        }

        $challengeUrl = add_query_arg(
            'context',
            $this->contextToken->encode($context),
            rest_url('thecore-elementor-widgets/v1/form-security/challenge')
        );
        $configuration = wp_json_encode(
            [
                'auto' => 'off',
                'display' => 'invisible',
                'hideFooter' => true,
                'hideLogo' => true,
                'humanInteractionSignature' => false,
                'minDuration' => $this->settings->challengeMinimumSeconds() * 1000,
                'timeout' => 45000,
                'workers' => 2,
            ]
        );
        ?>
        <div
            class="thecore-form-security"
            data-thecore-form-security
            data-challenge-url="<?php echo esc_url($challengeUrl); ?>"
            data-altcha-input="<?php echo esc_attr(SecuritySettings::ALTCHA_INPUT); ?>"
            data-honeypot-input="<?php echo esc_attr(SecuritySettings::HONEYPOT_INPUT); ?>"
            data-min-duration="<?php echo esc_attr((string) $this->settings->challengeMinimumSeconds()); ?>"
            data-message-loading="<?php echo esc_attr__('Préparation du contrôle anti-spam…', 'thecore-elementor-widgets'); ?>"
            data-message-error="<?php echo esc_attr__('Le contrôle anti-spam n’a pas pu se charger. Actualisez la page puis réessayez.', 'thecore-elementor-widgets'); ?>"
            data-message-verification="<?php echo esc_attr__('Le contrôle anti-spam doit être terminé avant l’envoi.', 'thecore-elementor-widgets'); ?>"
        >
            <label class="thecore-form-security__trap" aria-hidden="true">
                <span><?php esc_html_e('Site internet', 'thecore-elementor-widgets'); ?></span>
                <input
                    type="text"
                    name="<?php echo esc_attr(SecuritySettings::HONEYPOT_INPUT); ?>"
                    value=""
                    tabindex="-1"
                    autocomplete="off"
                    inputmode="none"
                >
            </label>
            <altcha-widget
                name="<?php echo esc_attr(SecuritySettings::ALTCHA_INPUT); ?>"
                challenge="<?php echo esc_url($challengeUrl); ?>"
                auto="off"
                display="invisible"
                workers="2"
                configuration="<?php echo esc_attr(is_string($configuration) ? $configuration : '{}'); ?>"
                data-thecore-altcha
            ></altcha-widget>
            <p
                class="thecore-form-security__status"
                role="status"
                aria-live="polite"
                data-thecore-form-security-status
            ></p>
            <noscript>
                <p class="thecore-form-security__noscript">
                    <?php esc_html_e('JavaScript doit être activé pour envoyer ce formulaire.', 'thecore-elementor-widgets'); ?>
                </p>
            </noscript>
        </div>
        <?php
    }

    /**
     * @param mixed                $value
     * @param array<string, mixed> $field
     */
    public function sanitize_field($value, $field): string
    {
        unset($value, $field);

        return '';
    }

    /**
     * Keep Elementor's `Required` switch unavailable for this technical field.
     * The field itself is stripped before the per-field validation loop and
     * the protection is validated once, at form level.
     *
     * @param object $widget Elementor Form widget.
     */
    public function update_controls($widget): void
    {
        if (
            ! is_object($widget)
            || ! method_exists($widget, 'get_unique_name')
            || ! method_exists($widget, 'update_control')
            || ! method_exists(ElementorProPlugin::class, 'elementor')
        ) {
            return;
        }

        $elementor = ElementorProPlugin::elementor();
        if (
            ! is_object($elementor)
            || ! isset($elementor->controls_manager)
            || ! is_object($elementor->controls_manager)
            || ! method_exists($elementor->controls_manager, 'get_control_from_stack')
        ) {
            return;
        }

        $controlData = $elementor->controls_manager->get_control_from_stack(
            $widget->get_unique_name(),
            'form_fields'
        );

        if (
            is_wp_error($controlData)
            || ! is_array($controlData)
            || ! isset($controlData['fields']['required'])
            || ! is_array($controlData['fields']['required'])
        ) {
            return;
        }

        $requiredControl = $controlData['fields']['required'];
        $terms = $requiredControl['conditions']['terms'] ?? [];

        if (! is_array($terms)) {
            return;
        }

        foreach ($terms as &$term) {
            if (
                ! is_array($term)
                || 'field_type' !== (string) ($term['name'] ?? '')
                || '!in' !== (string) ($term['operator'] ?? '')
                || ! isset($term['value'])
                || ! is_array($term['value'])
            ) {
                continue;
            }

            if (! in_array($this->get_type(), $term['value'], true)) {
                $term['value'][] = $this->get_type();
            }
        }
        unset($term);

        $requiredControl['conditions']['terms'] = $terms;
        $controlData['fields']['required'] = $requiredControl;
        $widget->update_control('form_fields', $controlData);
    }

    private function renderUnavailableMessage(): void
    {
        ?>
        <div class="thecore-form-security" data-thecore-form-security>
            <p class="thecore-form-security__status is-error" role="alert">
                <?php esc_html_e('Le contrôle anti-spam est momentanément indisponible.', 'thecore-elementor-widgets'); ?>
            </p>
        </div>
        <?php
    }
}
