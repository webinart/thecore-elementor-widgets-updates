<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity\Support;

use InvalidArgumentException;

final class FormContext
{
    private const IDENTIFIER_PATTERN = '/\A[A-Za-z0-9_-]{1,128}\z/';

    public function __construct(
        private readonly int $postId,
        private readonly string $widgetId,
        private readonly string $fieldId
    ) {
        if (
            $this->postId < 1
            || preg_match(self::IDENTIFIER_PATTERN, $this->widgetId) !== 1
            || preg_match(self::IDENTIFIER_PATTERN, $this->fieldId) !== 1
        ) {
            throw new InvalidArgumentException('Invalid Elementor form context.');
        }
    }

    public function postId(): int
    {
        return $this->postId;
    }

    public function widgetId(): string
    {
        return $this->widgetId;
    }

    public function fieldId(): string
    {
        return $this->fieldId;
    }

    /**
     * @return array{field: string, post: int, v: int, widget: string}
     */
    public function toArray(): array
    {
        return [
            'field' => $this->fieldId,
            'post' => $this->postId,
            'v' => 1,
            'widget' => $this->widgetId,
        ];
    }

    public function canonicalJson(): string
    {
        return (string) json_encode(
            $this->toArray(),
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
        );
    }

    public function fingerprint(): string
    {
        return hash('sha256', $this->canonicalJson());
    }

    /**
     * @param array<string, mixed> $data
     */
    public static function fromArray(array $data): ?self
    {
        $keys = array_keys($data);
        sort($keys);

        if (
            $keys !== ['field', 'post', 'v', 'widget']
            || ! isset($data['v'], $data['post'], $data['widget'], $data['field'])
            || $data['v'] !== 1
            || ! is_int($data['post'])
            || ! is_string($data['widget'])
            || ! is_string($data['field'])
        ) {
            return null;
        }

        try {
            return new self($data['post'], $data['widget'], $data['field']);
        } catch (InvalidArgumentException) {
            return null;
        }
    }
}
