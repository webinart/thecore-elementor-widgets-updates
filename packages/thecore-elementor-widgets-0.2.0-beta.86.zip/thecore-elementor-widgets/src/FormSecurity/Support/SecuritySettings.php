<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity\Support;

final class SecuritySettings
{
    public const ALTCHA_INPUT = 'thecore_form_security_altcha';
    public const HONEYPOT_INPUT = 'thecore_form_security_website';
    public const ALTCHA_WIDGET_VERSION = '3.2.1';

    public function challengeMinimumSeconds(): int
    {
        return $this->boundedInt('challenge_minimum_seconds', 3, 1, 30);
    }

    public function challengeMaximumSeconds(): int
    {
        return max(
            $this->challengeMinimumSeconds() + 30,
            $this->boundedInt('challenge_maximum_seconds', 300, 31, DAY_IN_SECONDS)
        );
    }

    public function altchaCost(): int
    {
        return $this->boundedInt('altcha_cost', 5000, 1000, 20000);
    }

    public function counterMinimum(): int
    {
        return $this->boundedInt('counter_minimum', 1000, 1000, 50000);
    }

    public function counterMaximum(): int
    {
        return max(
            $this->counterMinimum(),
            $this->boundedInt('counter_maximum', 2000, 1000, 100000)
        );
    }

    public function challengeRateWindow(): int
    {
        return $this->boundedInt('challenge_rate_window', 300, 60, HOUR_IN_SECONDS);
    }

    public function challengeRateLimit(): int
    {
        return $this->boundedInt('challenge_rate_limit', 30, 5, 300);
    }

    public function attemptRateWindow(): int
    {
        return $this->boundedInt('attempt_rate_window', 600, 60, HOUR_IN_SECONDS);
    }

    public function attemptRateLimit(): int
    {
        return $this->boundedInt('attempt_rate_limit', 30, 5, 300);
    }

    public function submissionRateWindow(): int
    {
        return $this->boundedInt('submission_rate_window', 600, 60, HOUR_IN_SECONDS);
    }

    public function submissionRateLimit(): int
    {
        return $this->boundedInt('submission_rate_limit', 8, 2, 100);
    }

    public function deduplicationTtl(): int
    {
        return $this->boundedInt('deduplication_ttl', 600, 60, HOUR_IN_SECONDS);
    }

    /**
     * Disabled by default because a reusable Elementor form may contain file
     * uploads. Sites that do not accept uploads can opt into a stricter cap.
     */
    public function maximumRequestBytes(): int
    {
        return $this->boundedInt('maximum_request_bytes', 0, 0, 104857600);
    }

    /**
     * Detailed rejected submissions have a short operational lifetime. Sites
     * may shorten this further according to their own documented purpose.
     */
    public function blockedSubmissionRetentionDays(): int
    {
        return $this->boundedInt('blocked_submission_retention_days', 30, 1, 365);
    }

    /**
     * Global safety ceiling for detailed entries. Aggregated counters continue
     * to record every rejection after this daily ceiling is reached.
     */
    public function blockedSubmissionDailyLimit(): int
    {
        return $this->boundedInt('blocked_submission_daily_limit', 200, 10, 10000);
    }

    private function boundedInt(string $name, int $default, int $minimum, int $maximum): int
    {
        $value = (int) apply_filters(
            'thecore/elementor_forms/security/' . $name,
            $default
        );

        return max($minimum, min($maximum, $value));
    }
}
