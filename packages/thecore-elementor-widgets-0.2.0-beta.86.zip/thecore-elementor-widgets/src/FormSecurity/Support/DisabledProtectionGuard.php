<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity\Support;

use TheCore\ElementorWidgets\Contracts\Bootable;

final class DisabledProtectionGuard implements Bootable
{
    public function __construct(
        private readonly FormContextResolver $resolver,
        private readonly bool $featureEnabled
    ) {
    }

    public function register(): void
    {
        add_filter(
            'elementor_pro/forms/validation/skip_all',
            [$this, 'preventValidationBypass'],
            PHP_INT_MAX,
            3
        );
        add_filter(
            'elementor_pro/forms/validation/skip_types',
            [$this, 'preventTypeBypass'],
            PHP_INT_MAX
        );

        if (! $this->featureEnabled) {
            add_action(
                'elementor_pro/forms/validation',
                [$this, 'blockWhenDisabled'],
                1,
                2
            );
        }
    }

    public function preventValidationBypass(
        bool $skip,
        object $record,
        object $ajaxHandler
    ): bool {
        if ($this->resolver->resolve($record, $ajaxHandler)->isProtected()) {
            return false;
        }

        return $skip;
    }

    /**
     * @param mixed $types
     *
     * @return string[]
     */
    public function preventTypeBypass($types): array
    {
        if (! is_array($types)) {
            $types = [];
        }

        $types = array_values(
            array_filter(
                $types,
                static fn ($type): bool => FormContextResolver::FIELD_TYPE !== (string) $type
            )
        );

        if ($this->featureEnabled) {
            $types[] = FormContextResolver::FIELD_TYPE;
        }

        return array_values(array_unique($types));
    }

    public function blockWhenDisabled(object $record, object $ajaxHandler): void
    {
        if (
            $this->resolver->resolve($record, $ajaxHandler)->isProtected()
            && method_exists($ajaxHandler, 'add_error')
        ) {
            $ajaxHandler->add_error(
                'invalid_form',
                __(
                    'Le formulaire est temporairement indisponible. Merci de réessayer ultérieurement.',
                    'thecore-elementor-widgets'
                )
            );
        }
    }
}
