<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity\Support;

use JsonException;

final class ContextToken
{
    private const MAX_TOKEN_BYTES = 2048;

    public function __construct(private readonly string $secret)
    {
    }

    public function encode(FormContext $context): string
    {
        $payload = self::base64UrlEncode($context->canonicalJson());
        $signature = hash_hmac('sha256', $payload, $this->secret);

        return $payload . '.' . $signature;
    }

    public function decode(string $token): ?FormContext
    {
        if (
            '' === $token
            || strlen($token) > self::MAX_TOKEN_BYTES
            || 1 !== substr_count($token, '.')
        ) {
            return null;
        }

        [$payload, $signature] = explode('.', $token, 2);

        if (
            preg_match('/\A[A-Za-z0-9_-]+\z/', $payload) !== 1
            || preg_match('/\A[a-f0-9]{64}\z/', $signature) !== 1
            || ! hash_equals(hash_hmac('sha256', $payload, $this->secret), $signature)
        ) {
            return null;
        }

        $json = self::base64UrlDecode($payload);
        if (null === $json || strlen($json) > 1024) {
            return null;
        }

        try {
            $data = json_decode($json, true, 8, JSON_THROW_ON_ERROR);
        } catch (JsonException) {
            return null;
        }

        return is_array($data) ? FormContext::fromArray($data) : null;
    }

    private static function base64UrlEncode(string $value): string
    {
        return rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
    }

    private static function base64UrlDecode(string $value): ?string
    {
        $padding = strlen($value) % 4;
        if (1 === $padding) {
            return null;
        }

        if ($padding > 0) {
            $value .= str_repeat('=', 4 - $padding);
        }

        $decoded = base64_decode(strtr($value, '-_', '+/'), true);

        return false === $decoded ? null : $decoded;
    }
}
