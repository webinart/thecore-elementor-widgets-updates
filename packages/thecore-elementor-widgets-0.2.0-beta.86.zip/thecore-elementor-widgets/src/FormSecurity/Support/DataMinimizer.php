<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity\Support;

final class DataMinimizer
{
    /**
     * Remove IP and User-Agent metadata and discard tracking query parameters
     * before Elementor storage, e-mail, webhook or CRM actions can read them.
     */
    public function minimize(object $record): void
    {
        if (! method_exists($record, 'get') || ! method_exists($record, 'set')) {
            return;
        }

        $settings = $record->get('form_settings');
        if (is_array($settings)) {
            foreach (['submissions_metadata', 'form_metadata', 'form_metadata_2'] as $key) {
                if (isset($settings[$key]) && is_array($settings[$key])) {
                    $settings[$key] = array_values(
                        array_diff($settings[$key], ['remote_ip', 'user_agent'])
                    );
                }
            }

            $record->set('form_settings', $settings);
        }

        $canonicalReferrer = $this->canonicalReferrer(
            isset($_POST['referrer']) && is_scalar($_POST['referrer'])
                ? (string) wp_unslash($_POST['referrer'])
                : '',
            home_url('/')
        );

        $meta = $record->get('meta');
        if (is_array($meta)) {
            unset($meta['remote_ip'], $meta['user_agent']);

            if (isset($meta['page_url']) && is_array($meta['page_url'])) {
                $meta['page_url']['value'] = $canonicalReferrer;
            }

            $record->set('meta', $meta);
        }

        // Public Elementor form request; Elementor performs its own request validation.
        $_POST['referrer'] = $canonicalReferrer; // phpcs:ignore WordPress.Security.NonceVerification.Missing
    }

    public function canonicalReferrer(string $referrer, string $homeUrl): string
    {
        $home = parse_url($homeUrl);
        $candidate = parse_url($referrer);

        if (! is_array($home) || ! is_array($candidate)) {
            return $this->homeWithoutQuery($homeUrl);
        }

        $homeScheme = strtolower((string) ($home['scheme'] ?? ''));
        $homeHost = strtolower((string) ($home['host'] ?? ''));
        $candidateScheme = strtolower((string) ($candidate['scheme'] ?? ''));
        $candidateHost = strtolower((string) ($candidate['host'] ?? ''));

        if (
            '' === $homeScheme
            || '' === $homeHost
            || $homeScheme !== $candidateScheme
            || $homeHost !== $candidateHost
        ) {
            return $this->homeWithoutQuery($homeUrl);
        }

        $homePort = isset($home['port']) ? (int) $home['port'] : null;
        $candidatePort = isset($candidate['port']) ? (int) $candidate['port'] : null;

        if ($homePort !== $candidatePort) {
            return $this->homeWithoutQuery($homeUrl);
        }

        $authority = $candidateScheme . '://' . $candidateHost;
        if (null !== $candidatePort) {
            $authority .= ':' . $candidatePort;
        }

        $path = isset($candidate['path']) && is_string($candidate['path'])
            ? '/' . ltrim($candidate['path'], '/')
            : '/';

        return $authority . $path;
    }

    private function homeWithoutQuery(string $homeUrl): string
    {
        $home = parse_url($homeUrl);
        if (! is_array($home)) {
            return '';
        }

        $scheme = strtolower((string) ($home['scheme'] ?? ''));
        $host = strtolower((string) ($home['host'] ?? ''));

        if ('' === $scheme || '' === $host) {
            return '';
        }

        $value = $scheme . '://' . $host;
        if (isset($home['port'])) {
            $value .= ':' . (int) $home['port'];
        }

        $path = isset($home['path']) && is_string($home['path'])
            ? '/' . ltrim($home['path'], '/')
            : '/';

        return $value . $path;
    }
}
