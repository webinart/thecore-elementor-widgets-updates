<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity\Support;

use InvalidArgumentException;

final class FormContextResolver
{
    public const FIELD_TYPE = 'thecore_form_security';

    /**
     * Resolve the protected target exclusively from Elementor's server-side
     * widget settings. No submitted page, widget or form identifier is trusted.
     */
    public function resolve(object $record, object $ajaxHandler): FormContextResolution
    {
        if (! method_exists($record, 'get_form_settings')) {
            return FormContextResolution::none();
        }

        $configuredFields = $record->get_form_settings('form_fields');
        if (! is_array($configuredFields)) {
            return FormContextResolution::none();
        }

        $protectionFields = [];

        foreach ($configuredFields as $configuredField) {
            if (
                is_array($configuredField)
                && isset($configuredField['field_type'])
                && self::FIELD_TYPE === (string) $configuredField['field_type']
            ) {
                $protectionFields[] = $configuredField;
            }
        }

        if ([] === $protectionFields) {
            return FormContextResolution::none();
        }

        if (1 !== count($protectionFields)) {
            return FormContextResolution::invalid();
        }

        $fieldId = isset($protectionFields[0]['custom_id'])
            ? (string) $protectionFields[0]['custom_id']
            : '';
        $postId = (int) $record->get_form_settings('form_post_id');

        if (! method_exists($ajaxHandler, 'get_current_form')) {
            return FormContextResolution::invalid();
        }

        $currentForm = $ajaxHandler->get_current_form();
        if (
            ! is_array($currentForm)
            || ! isset($currentForm['id'], $currentForm['widgetType'])
            || 'form' !== (string) $currentForm['widgetType']
        ) {
            return FormContextResolution::invalid();
        }

        try {
            return FormContextResolution::valid(
                new FormContext($postId, (string) $currentForm['id'], $fieldId)
            );
        } catch (InvalidArgumentException) {
            return FormContextResolution::invalid();
        }
    }
}
