<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity\Support;

final class DeduplicationFingerprint
{
    private const EXCLUDED_TYPES = [
        FormContextResolver::FIELD_TYPE,
        'html',
        'step',
        'honeypot',
        'recaptcha',
        'recaptcha_v3',
        'hcaptcha',
        'turnstile',
    ];

    public function __construct(private readonly string $secret)
    {
    }

    /**
     * @param array<string, mixed> $fields
     */
    public function create(FormContext $context, array $fields): string
    {
        $values = [];

        foreach ($fields as $fallbackId => $field) {
            if (! is_array($field)) {
                continue;
            }

            $type = isset($field['type']) ? (string) $field['type'] : '';
            if (in_array($type, self::EXCLUDED_TYPES, true)) {
                continue;
            }

            $id = isset($field['id']) ? (string) $field['id'] : (string) $fallbackId;
            if ('' === $id) {
                continue;
            }

            $value = $field['value'] ?? '';
            if (! is_scalar($value) && null !== $value) {
                continue;
            }

            $normalized = $this->normalize((string) $value);
            if ('email' === $type) {
                $normalized = strtolower($normalized);
            }

            $values[$id] = [
                'type' => $type,
                'value' => $normalized,
            ];
        }

        ksort($values);

        $canonical = (string) json_encode(
            [
                'context' => $context->fingerprint(),
                'fields' => $values,
                'v' => 1,
            ],
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
        );

        return hash_hmac('sha256', $canonical, $this->secret);
    }

    private function normalize(string $value): string
    {
        $value = str_replace(["\r\n", "\r"], "\n", trim($value));

        return (string) preg_replace('/[ \t]+/u', ' ', $value);
    }
}
