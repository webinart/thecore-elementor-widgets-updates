<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity\Support;

final class ChallengeContext
{
    /**
     * @return array{aud: string, context: string, purpose: string, v: int}
     */
    public static function forForm(FormContext $context): array
    {
        return [
            'aud' => Secrets::audience(),
            'context' => $context->fingerprint(),
            'purpose' => 'elementor_form',
            'v' => 1,
        ];
    }
}
