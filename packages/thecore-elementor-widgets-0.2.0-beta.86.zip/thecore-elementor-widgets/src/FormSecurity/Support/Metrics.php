<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity\Support;

final class Metrics
{
    public function increment(string $metric, int $amount = 1): void
    {
        if (preg_match('/\A[a-z0-9_]{1,64}\z/', $metric) !== 1) {
            return;
        }

        $month = gmdate('Ym');
        $day = gmdate('Y-m-d');
        $optionName = 'thecore_elementor_form_security_metrics_' . $month;
        $metrics = get_option($optionName, []);

        if (! is_array($metrics)) {
            $metrics = [];
        }

        if (! isset($metrics[$day]) || ! is_array($metrics[$day])) {
            $metrics[$day] = [];
        }

        $metrics[$day][$metric] = (int) ($metrics[$day][$metric] ?? 0) + max(1, $amount);

        if (false === get_option($optionName, false)) {
            add_option($optionName, $metrics, '', false);
            return;
        }

        update_option($optionName, $metrics, false);
    }
}
