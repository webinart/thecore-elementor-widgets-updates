<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity\Support;

final class ClientIdentity
{
    public function __construct(private readonly string $secret)
    {
    }

    /**
     * @param array<string, mixed> $server
     */
    public function hash(array $server): string
    {
        $remoteAddress = isset($server['REMOTE_ADDR']) && is_scalar($server['REMOTE_ADDR'])
            ? trim((string) $server['REMOTE_ADDR'])
            : '';

        if (false === filter_var($remoteAddress, FILTER_VALIDATE_IP)) {
            $remoteAddress = 'unavailable';
        } elseif (false !== filter_var($remoteAddress, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
            $packed = inet_pton($remoteAddress);

            if (false !== $packed) {
                $network = inet_ntop(substr($packed, 0, 8) . str_repeat("\0", 8));

                if (false !== $network) {
                    $remoteAddress = $network . '/64';
                }
            }
        }

        return hash_hmac('sha256', $remoteAddress, $this->secret);
    }
}
