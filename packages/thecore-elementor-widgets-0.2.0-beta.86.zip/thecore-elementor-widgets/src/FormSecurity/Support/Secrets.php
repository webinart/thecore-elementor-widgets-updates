<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity\Support;

final class Secrets
{
    private const PERSONAL_DATA_LOOKUP_OPTION =
        'thecore_elementor_form_security_personal_data_lookup_secret';

    public static function audience(): string
    {
        return untrailingslashit(strtolower(home_url('/')));
    }

    public static function contextSigning(): string
    {
        return hash_hmac(
            'sha256',
            'thecore-form-security-context-v1|' . self::audience(),
            wp_salt('auth')
        );
    }

    public static function challengeSigning(): string
    {
        return hash_hmac(
            'sha256',
            'thecore-form-security-challenge-v1|' . self::audience(),
            wp_salt('secure_auth')
        );
    }

    public static function challengeKeySigning(): string
    {
        return hash_hmac(
            'sha256',
            'thecore-form-security-key-v1|' . self::audience(),
            wp_salt('logged_in')
        );
    }

    public static function privacy(): string
    {
        return hash_hmac('sha256', 'thecore-form-security-privacy-v1', wp_salt('nonce'), true);
    }

    /**
     * Return a site-local key that remains stable when WordPress salts rotate.
     * The option stores only the hexadecimal representation of 32 random bytes.
     */
    public static function personalDataLookup(): string
    {
        if (! function_exists('get_option')) {
            return self::privacy();
        }

        try {
            $stored = self::decodePersonalDataLookupSecret(
                get_option(self::PERSONAL_DATA_LOOKUP_OPTION, '')
            );

            if (null !== $stored) {
                return $stored;
            }

            if (! function_exists('add_option') || ! function_exists('random_bytes')) {
                return self::privacy();
            }

            $candidateHex = bin2hex(random_bytes(32));
            $candidate = self::decodePersonalDataLookupSecret($candidateHex);

            if (null === $candidate) {
                return self::privacy();
            }

            if (add_option(self::PERSONAL_DATA_LOOKUP_OPTION, $candidateHex, '', false)) {
                return $candidate;
            }

            // add_option() is atomic. A false return can mean another request
            // created the option first. Clear this request's potentially stale
            // negative option cache before re-reading the winning value.
            self::clearPersonalDataLookupOptionCache();
            $winner = self::decodePersonalDataLookupSecret(
                get_option(self::PERSONAL_DATA_LOOKUP_OPTION, '')
            );

            return $winner ?? self::privacy();
        } catch (\Throwable) {
            return self::privacy();
        }
    }

    public static function personalDataLookupIsPersistent(): bool
    {
        if (! function_exists('get_option')) {
            return false;
        }

        try {
            return null !== self::decodePersonalDataLookupSecret(
                get_option(self::PERSONAL_DATA_LOOKUP_OPTION, '')
            );
        } catch (\Throwable) {
            return false;
        }
    }

    private static function decodePersonalDataLookupSecret(mixed $value): ?string
    {
        if (
            ! is_string($value)
            || 1 !== preg_match('/\A[a-fA-F0-9]{64}\z/D', $value)
        ) {
            return null;
        }

        $decoded = hex2bin($value);

        return is_string($decoded) && 32 === strlen($decoded) ? $decoded : null;
    }

    private static function clearPersonalDataLookupOptionCache(): void
    {
        if (! function_exists('wp_cache_delete')) {
            return;
        }

        wp_cache_delete(self::PERSONAL_DATA_LOOKUP_OPTION, 'options');
        wp_cache_delete('notoptions', 'options');
    }
}
