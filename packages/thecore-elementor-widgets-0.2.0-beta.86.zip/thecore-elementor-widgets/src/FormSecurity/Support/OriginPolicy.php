<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity\Support;

final class OriginPolicy
{
    /**
     * Missing Origin is accepted for older browsers and command-line clients.
     * An explicit cross-site signal or a different origin is rejected.
     *
     * @param array<string, mixed> $server
     */
    public function isAllowed(array $server, string $homeUrl): bool
    {
        $fetchSite = isset($server['HTTP_SEC_FETCH_SITE']) && is_scalar($server['HTTP_SEC_FETCH_SITE'])
            ? strtolower(trim((string) $server['HTTP_SEC_FETCH_SITE']))
            : '';

        if ('cross-site' === $fetchSite) {
            return false;
        }

        $origin = isset($server['HTTP_ORIGIN']) && is_scalar($server['HTTP_ORIGIN'])
            ? trim((string) $server['HTTP_ORIGIN'])
            : '';

        if ('' === $origin) {
            return true;
        }

        if ('null' === strtolower($origin)) {
            return false;
        }

        $expected = parse_url($homeUrl);
        $received = parse_url($origin);

        if (! is_array($expected) || ! is_array($received)) {
            return false;
        }

        $expectedScheme = strtolower((string) ($expected['scheme'] ?? ''));
        $receivedScheme = strtolower((string) ($received['scheme'] ?? ''));
        $expectedHost = strtolower((string) ($expected['host'] ?? ''));
        $receivedHost = strtolower((string) ($received['host'] ?? ''));
        $expectedPort = isset($expected['port']) ? (int) $expected['port'] : $this->defaultPort($expectedScheme);
        $receivedPort = isset($received['port']) ? (int) $received['port'] : $this->defaultPort($receivedScheme);

        return '' !== $expectedScheme
            && $expectedScheme === $receivedScheme
            && '' !== $expectedHost
            && $expectedHost === $receivedHost
            && $expectedPort === $receivedPort;
    }

    private function defaultPort(string $scheme): int
    {
        return match ($scheme) {
            'https' => 443,
            'http' => 80,
            default => 0,
        };
    }
}
