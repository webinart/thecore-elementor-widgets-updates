<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity\Support;

final class BlockedSubmissionPayloadBuilder
{
    private const MAXIMUM_FIELD_BYTES = 2048;
    private const MAXIMUM_TEXTAREA_BYTES = 8192;
    private const MAXIMUM_TOTAL_BYTES = 16384;
    private const MAXIMUM_LIST_ITEMS = 20;

    /**
     * Files, passwords, hidden/technical fields and layout-only controls are
     * deliberately excluded from the anti-spam journal.
     *
     * @var string[]
     */
    private const ALLOWED_TYPES = [
        'acceptance',
        'checkbox',
        'date',
        'email',
        'number',
        'radio',
        'select',
        'tel',
        'text',
        'textarea',
        'time',
        'url',
    ];

    /**
     * Values remain excluded even if an integration exposes them as a generic
     * text field instead of their usual technical Elementor field type.
     *
     * @var string[]
     */
    private const TECHNICAL_FIELD_IDENTIFIERS = [
        '_wpnonce',
        'altcha',
        'g-recaptcha-response',
        'h-captcha-response',
        'honeypot',
        'recaptcha',
        'thecore_form_security',
        'turnstile',
    ];

    /**
     * @param array<string|int, mixed> $fields
     *
     * @return array<int, array{id: string, label: string, type: string, value: string}>
     */
    public function build(array $fields, ?FormContext $context = null): array
    {
        $selected = [];
        $totalBytes = 2;
        $excludedIds = $this->excludedIds($context);
        $candidates = [];
        $position = 0;

        foreach ($fields as $key => $field) {
            if (! is_array($field)) {
                continue;
            }

            $item = $this->normalizeField($key, $field, $excludedIds);
            if (null === $item) {
                continue;
            }

            $candidates[] = [
                'item' => $item,
                'position' => $position,
                'priority' => $this->priority($item),
            ];
            ++$position;
        }

        usort(
            $candidates,
            static fn (array $left, array $right): int => [$left['priority'], $left['position']]
                <=> [$right['priority'], $right['position']]
        );

        foreach ($candidates as $candidate) {
            $item = $candidate['item'];
            $encoded = wp_json_encode($item, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

            if (! is_string($encoded) || $totalBytes + strlen($encoded) > self::MAXIMUM_TOTAL_BYTES) {
                continue;
            }

            $selected[] = $candidate;
            $totalBytes += strlen($encoded) + 1;
        }

        usort(
            $selected,
            static fn (array $left, array $right): int => $left['position'] <=> $right['position']
        );

        return array_values(
            array_map(static fn (array $candidate): array => $candidate['item'], $selected)
        );
    }

    /**
     * Find the first valid, allowed Elementor e-mail before applying the total
     * journal payload ceiling. This keeps WordPress privacy lookup available
     * even when less important fields must be omitted from fields_json.
     *
     * @param array<string|int, mixed> $fields
     */
    public function emailFromRecord(array $fields, ?FormContext $context = null): string
    {
        $excludedIds = $this->excludedIds($context);

        foreach ($fields as $key => $field) {
            if (! is_array($field)) {
                continue;
            }

            $item = $this->normalizeField($key, $field, $excludedIds);
            if (null === $item || 'email' !== $item['type']) {
                continue;
            }

            $email = sanitize_email(trim($item['value']));
            if ('' !== $email && false !== is_email($email)) {
                return $email;
            }
        }

        return '';
    }

    /**
     * @return string[]
     */
    private function excludedIds(?FormContext $context): array
    {
        if (! function_exists('apply_filters')) {
            return [];
        }

        $values = apply_filters(
            'thecore/elementor_forms/security/blocked_submission_excluded_field_ids',
            [],
            $context
        );

        if (! is_array($values)) {
            return [];
        }

        $ids = [];

        foreach ($values as $value) {
            if (is_scalar($value)) {
                $id = sanitize_key((string) $value);

                if ('' !== $id) {
                    $ids[] = $id;
                }
            }
        }

        return array_values(array_unique($ids));
    }

    private function isTechnicalIdentifier(string $identifier): bool
    {
        foreach (self::TECHNICAL_FIELD_IDENTIFIERS as $technicalIdentifier) {
            if (str_contains($identifier, $technicalIdentifier)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param string|int           $key
     * @param array<string, mixed> $field
     * @param string[]             $excludedIds
     *
     * @return array{id: string, label: string, type: string, value: string}|null
     */
    private function normalizeField(string|int $key, array $field, array $excludedIds): ?array
    {
        $type = sanitize_key((string) ($field['type'] ?? ''));
        if (! in_array($type, self::ALLOWED_TYPES, true)) {
            return null;
        }

        $id = sanitize_key((string) ($field['id'] ?? $key));
        if (
            '' === $id
            || in_array($id, $excludedIds, true)
            || $this->isTechnicalIdentifier($id)
        ) {
            return null;
        }

        $value = $this->value(
            $field['value'] ?? '',
            'textarea' === $type ? self::MAXIMUM_TEXTAREA_BYTES : self::MAXIMUM_FIELD_BYTES,
            'textarea' === $type
        );
        $label = sanitize_text_field((string) ($field['title'] ?? $field['label'] ?? $id));

        return [
            'id' => $this->limitBytes($id, 128),
            'label' => $this->limitBytes('' !== $label ? $label : $id, 191),
            'type' => $type,
            'value' => $value,
        ];
    }

    /**
     * @param array{id: string, label: string, type: string, value: string} $field
     */
    private function priority(array $field): int
    {
        if ('email' === $field['type']) {
            return 0;
        }

        $searchKey = $this->searchKey($field['id'] . ' ' . $field['label']);
        if ($this->containsAny($searchKey, ['nom', 'name', 'prenom', 'firstname', 'lastname', 'fullname'])) {
            return 1;
        }

        if (
            'textarea' === $field['type']
            || $this->containsAny(
                $searchKey,
                ['message', 'demande', 'commentaire', 'comment', 'description']
            )
        ) {
            return 2;
        }

        return 3;
    }

    /**
     * @param string[] $needles
     */
    private function containsAny(string $haystack, array $needles): bool
    {
        foreach ($needles as $needle) {
            if (str_contains($haystack, $needle)) {
                return true;
            }
        }

        return false;
    }

    private function searchKey(string $value): string
    {
        $value = strtr(
            strtolower($value),
            [
                'à' => 'a',
                'â' => 'a',
                'ä' => 'a',
                'ç' => 'c',
                'é' => 'e',
                'è' => 'e',
                'ê' => 'e',
                'ë' => 'e',
                'î' => 'i',
                'ï' => 'i',
                'ô' => 'o',
                'ö' => 'o',
                'ù' => 'u',
                'û' => 'u',
                'ü' => 'u',
            ]
        );

        return (string) preg_replace('/[^a-z0-9]+/', '', $value);
    }

    private function value(mixed $value, int $maximumBytes, bool $multiline): string
    {
        if (is_array($value)) {
            $items = [];

            foreach (array_slice($value, 0, self::MAXIMUM_LIST_ITEMS) as $item) {
                if (is_scalar($item)) {
                    $items[] = (string) $item;
                }
            }

            $value = implode(', ', $items);
        }

        if (! is_scalar($value)) {
            return '';
        }

        $sanitized = $multiline
            ? sanitize_textarea_field((string) $value)
            : sanitize_text_field((string) $value);

        return $this->limitBytes($sanitized, $maximumBytes);
    }

    private function limitBytes(string $value, int $maximumBytes): string
    {
        if (strlen($value) <= $maximumBytes) {
            return $value;
        }

        if (function_exists('mb_strcut')) {
            return mb_strcut($value, 0, $maximumBytes, 'UTF-8');
        }

        return substr($value, 0, $maximumBytes);
    }
}
