<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity\Support;

final class FormContextResolution
{
    public const NONE = 'none';
    public const VALID = 'valid';
    public const INVALID = 'invalid';

    private function __construct(
        private readonly string $status,
        private readonly ?FormContext $context
    ) {
    }

    public static function none(): self
    {
        return new self(self::NONE, null);
    }

    public static function valid(FormContext $context): self
    {
        return new self(self::VALID, $context);
    }

    public static function invalid(): self
    {
        return new self(self::INVALID, null);
    }

    public function status(): string
    {
        return $this->status;
    }

    public function context(): ?FormContext
    {
        return $this->context;
    }

    public function isProtected(): bool
    {
        return self::NONE !== $this->status;
    }

    public function isValid(): bool
    {
        return self::VALID === $this->status && null !== $this->context;
    }
}
