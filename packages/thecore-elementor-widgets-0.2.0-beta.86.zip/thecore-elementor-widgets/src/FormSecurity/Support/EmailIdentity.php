<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity\Support;

final class EmailIdentity
{
    public function __construct(private readonly string $secret)
    {
    }

    public function hash(string $email): string
    {
        $normalized = $this->normalize($email);

        return '' === $normalized
            ? ''
            : hash_hmac('sha256', $normalized, $this->secret);
    }

    public function normalize(string $email): string
    {
        $email = sanitize_email(trim($email));

        if ('' === $email || false === is_email($email)) {
            return '';
        }

        return strtolower($email);
    }
}
