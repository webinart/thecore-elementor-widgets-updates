<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity\Privacy;

use Closure;
use JsonException;
use TheCore\ElementorWidgets\Contracts\Bootable;
use TheCore\ElementorWidgets\FormSecurity\Infrastructure\BlockedSubmissionStore;
use TheCore\ElementorWidgets\FormSecurity\Support\EmailIdentity;
use TheCore\ElementorWidgets\FormSecurity\Support\Secrets;
use Throwable;

final class BlockedSubmissionsPrivacy implements Bootable
{
    private const EXPORTER_ID = 'thecore-elementor-form-security-blocked-submissions';
    private const GROUP_ID = 'thecore-elementor-form-security-blocked-submissions';
    private const PAGE_SIZE = 100;

    private Closure $listByEmailHash;
    private Closure $deleteByEmailHash;
    private Closure $operationSucceeded;

    private function __construct(
        callable $listByEmailHash,
        callable $deleteByEmailHash,
        callable $operationSucceeded,
        private readonly EmailIdentity $emailIdentity,
        private readonly bool $personalDataLookupAvailable
    ) {
        $this->listByEmailHash = Closure::fromCallable($listByEmailHash);
        $this->deleteByEmailHash = Closure::fromCallable($deleteByEmailHash);
        $this->operationSucceeded = Closure::fromCallable($operationSucceeded);
    }

    public static function fromStore(BlockedSubmissionStore $store): self
    {
        $personalDataLookup = Secrets::personalDataLookup();

        return new self(
            static fn (string $hash, int $offset, int $limit): array => $store->listByEmailHash(
                $hash,
                $offset,
                $limit
            ),
            static fn (string $hash): int => $store->deleteByEmailHash($hash),
            static fn (): bool => $store->lastOperationSucceeded(),
            new EmailIdentity($personalDataLookup),
            Secrets::personalDataLookupIsPersistent()
        );
    }

    /**
     * Alternative constructor for adapters and isolated tests.
     */
    public static function fromCallbacks(
        callable $listByEmailHash,
        callable $deleteByEmailHash,
        EmailIdentity $emailIdentity,
        ?callable $operationSucceeded = null,
        bool $personalDataLookupAvailable = true
    ): self {
        return new self(
            $listByEmailHash,
            $deleteByEmailHash,
            $operationSucceeded ?? static fn (): bool => true,
            $emailIdentity,
            $personalDataLookupAvailable
        );
    }

    public function register(): void
    {
        add_filter(
            'wp_privacy_personal_data_exporters',
            [$this, 'registerExporter'],
            10,
            1
        );
        add_filter(
            'wp_privacy_personal_data_erasers',
            [$this, 'registerEraser'],
            10,
            1
        );
    }

    /**
     * @param array<string, array<string, mixed>> $exporters
     *
     * @return array<string, array<string, mixed>>
     */
    public function registerExporter(array $exporters): array
    {
        $exporters[self::EXPORTER_ID] = [
            'exporter_friendly_name' => __(
                'The Core — Soumissions de formulaire bloquées',
                'thecore-elementor-widgets'
            ),
            'callback' => [$this, 'exportPersonalData'],
        ];

        return $exporters;
    }

    /**
     * @param array<string, array<string, mixed>> $erasers
     *
     * @return array<string, array<string, mixed>>
     */
    public function registerEraser(array $erasers): array
    {
        $erasers[self::EXPORTER_ID] = [
            'eraser_friendly_name' => __(
                'The Core — Soumissions de formulaire bloquées',
                'thecore-elementor-widgets'
            ),
            'callback' => [$this, 'erasePersonalData'],
        ];

        return $erasers;
    }

    /**
     * @return array{data: array<int, array<string, mixed>>, done: bool}|\WP_Error
     */
    public function exportPersonalData(string $emailAddress, int $page = 1): array|\WP_Error
    {
        if (! $this->personalDataLookupAvailable) {
            return $this->storageError();
        }

        $emailHash = $this->emailIdentity->hash($emailAddress);
        if ('' === $emailHash) {
            return ['data' => [], 'done' => true];
        }

        $offset = (max(1, $page) - 1) * self::PAGE_SIZE;

        try {
            $rows = ($this->listByEmailHash)($emailHash, $offset, self::PAGE_SIZE);
        } catch (Throwable) {
            return $this->storageError();
        }

        if (! is_array($rows) || ! ($this->operationSucceeded)()) {
            return $this->storageError();
        }

        $data = [];

        foreach ($rows as $row) {
            if (! is_array($row)) {
                continue;
            }

            $item = $this->exportItem($row);
            if (null !== $item) {
                $data[] = $item;
            }
        }

        return [
            'data' => $data,
            'done' => count($rows) < self::PAGE_SIZE,
        ];
    }

    /**
     * @return array{
     *     items_removed: bool,
     *     items_retained: bool,
     *     messages: string[],
     *     done: bool
     * }|\WP_Error
     */
    public function erasePersonalData(string $emailAddress, int $page = 1): array|\WP_Error
    {
        unset($page);

        if (! $this->personalDataLookupAvailable) {
            return $this->storageError();
        }

        $emailHash = $this->emailIdentity->hash($emailAddress);
        if ('' === $emailHash) {
            return $this->erasureResult(false, false);
        }

        try {
            $deleted = (int) ($this->deleteByEmailHash)($emailHash);
            if (! ($this->operationSucceeded)()) {
                return $this->storageError();
            }

            $remaining = ($this->listByEmailHash)($emailHash, 0, 1);
            if (! is_array($remaining) || ! ($this->operationSucceeded)()) {
                return $this->storageError();
            }

            $itemsRetained = is_array($remaining) && [] !== $remaining;

            return $this->erasureResult($deleted > 0, $itemsRetained);
        } catch (Throwable) {
            return $this->storageError();
        }
    }

    /**
     * @param array<string, mixed> $row
     *
     * @return array<string, mixed>|null
     */
    private function exportItem(array $row): ?array
    {
        $id = (int) ($row['id'] ?? 0);
        if ($id < 1) {
            return null;
        }

        $data = [];

        $this->append($data, __('Raison du blocage', 'thecore-elementor-widgets'), $row['reason'] ?? '');
        $this->append($data, __('Nom du formulaire', 'thecore-elementor-widgets'), $row['form_name'] ?? '');
        $this->append($data, __('Page concernée', 'thecore-elementor-widgets'), $row['page_url'] ?? '');
        $this->append($data, __('Identifiant de page', 'thecore-elementor-widgets'), $row['post_id'] ?? '');
        $this->append($data, __('Identifiant du widget', 'thecore-elementor-widgets'), $row['widget_id'] ?? '');
        $this->append(
            $data,
            __('Date du blocage (UTC)', 'thecore-elementor-widgets'),
            $this->timestamp($row['created_at'] ?? 0)
        );
        $this->append(
            $data,
            __('Date d’effacement prévue (UTC)', 'thecore-elementor-widgets'),
            $this->timestamp($row['expires_at'] ?? 0)
        );

        foreach ($this->fields($row) as $field) {
            $label = trim((string) ($field['label'] ?? $field['id'] ?? ''));
            if ('' === $label) {
                continue;
            }

            $this->append(
                $data,
                sprintf(__('Champ : %s', 'thecore-elementor-widgets'), $label),
                $field['value'] ?? ''
            );
        }

        return [
            'group_id' => self::GROUP_ID,
            'group_label' => __(
                'Soumissions de formulaire bloquées',
                'thecore-elementor-widgets'
            ),
            'item_id' => 'thecore-form-security-blocked-submission-' . $id,
            'data' => $data,
        ];
    }

    /**
     * @param array<string, mixed> $row
     *
     * @return array<int, array<string, mixed>>
     */
    private function fields(array $row): array
    {
        if (isset($row['fields']) && is_array($row['fields'])) {
            return array_values(
                array_filter($row['fields'], static fn (mixed $field): bool => is_array($field))
            );
        }

        $json = $row['fields_json'] ?? '';
        if (! is_string($json) || '' === $json) {
            return [];
        }

        try {
            $fields = json_decode($json, true, 16, JSON_THROW_ON_ERROR);
        } catch (JsonException) {
            return [];
        }

        if (! is_array($fields)) {
            return [];
        }

        return array_values(
            array_filter($fields, static fn (mixed $field): bool => is_array($field))
        );
    }

    /**
     * @param array<int, array{name: string, value: string}> $data
     */
    private function append(array &$data, string $name, mixed $value): void
    {
        $formatted = $this->value($value);
        if ('' === $formatted) {
            return;
        }

        $data[] = [
            'name' => $name,
            'value' => $formatted,
        ];
    }

    private function value(mixed $value): string
    {
        if (is_bool($value)) {
            return $value ? '1' : '0';
        }

        if (is_scalar($value)) {
            return trim((string) $value);
        }

        if (! is_array($value)) {
            return '';
        }

        $encoded = json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        return is_string($encoded) ? $encoded : '';
    }

    private function timestamp(mixed $value): string
    {
        $timestamp = is_numeric($value) ? (int) $value : 0;

        return $timestamp > 0 ? gmdate('Y-m-d\TH:i:s\Z', $timestamp) : '';
    }

    /**
     * @return array{
     *     items_removed: bool,
     *     items_retained: bool,
     *     messages: string[],
     *     done: bool
     * }
     */
    private function erasureResult(bool $itemsRemoved, bool $itemsRetained): array
    {
        return [
            'items_removed' => $itemsRemoved,
            'items_retained' => $itemsRetained,
            'messages' => $itemsRetained
                ? [
                    __(
                        'Certaines soumissions bloquées n’ont pas pu être effacées.',
                        'thecore-elementor-widgets'
                    ),
                ]
                : [],
            'done' => true,
        ];
    }

    private function storageError(): \WP_Error
    {
        return new \WP_Error(
            'thecore_form_security_privacy_store_unavailable',
            __(
                'Le journal des soumissions bloquées est momentanément inaccessible. La demande RGPD n’a pas été marquée comme terminée.',
                'thecore-elementor-widgets'
            )
        );
    }
}
