<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity\Admin;

use InvalidArgumentException;
use TheCore\ElementorWidgets\Contracts\Bootable;
use TheCore\ElementorWidgets\FormSecurity\Infrastructure\Installer;
use TheCore\ElementorWidgets\FormSecurity\Support\SecuritySettings;
use Throwable;

final class BlockedSubmissionsPage implements Bootable
{
    public const PAGE_SLUG = 'thecore-elementor-blocked-submissions';
    public const DELETE_ACTION = 'thecore_elementor_delete_blocked_submission';
    public const DELETE_NONCE_NAME = '_thecore_blocked_submission_nonce';

    private const PARENT_SLUG = 'thecore-elementor-widgets';
    private const CAPABILITY_FILTER = 'thecore/elementor_forms/security/admin_capability';
    private const PER_PAGE_FILTER = 'thecore/elementor_forms/security/admin_per_page';
    private const DEFAULT_CAPABILITY = 'manage_options';
    private const DEFAULT_PER_PAGE = 20;
    private const MAXIMUM_PER_PAGE = 100;

    /**
     * Elementor field types whose submitted values may be presented to an
     * administrator. Security, hidden and integration fields deliberately do
     * not appear here.
     *
     * @var string[]
     */
    private const ALLOWED_FIELD_TYPES = [
        'acceptance',
        'checkbox',
        'date',
        'email',
        'number',
        'radio',
        'select',
        'tel',
        'text',
        'textarea',
        'time',
        'url',
    ];

    /**
     * @var string[]
     */
    private const TECHNICAL_FIELD_IDENTIFIERS = [
        '_wpnonce',
        'altcha',
        'g-recaptcha-response',
        'h-captcha-response',
        'honeypot',
        'recaptcha',
        'thecore_form_security',
        'turnstile',
    ];

    private object $store;

    /**
     * Expected store API:
     *
     * - count(array $args = []): int
     * - list(array $args = []): array
     * - get(int $id): ?array
     * - delete(int $id): bool
     * - lastOperationSucceeded(): bool (optional compatibility signal)
     */
    public function __construct(object $store)
    {
        foreach (['count', 'list', 'get', 'delete'] as $method) {
            if (! method_exists($store, $method)) {
                throw new InvalidArgumentException(
                    sprintf('Blocked submission store must expose %s().', $method)
                );
            }
        }

        $this->store = $store;
    }

    public function register(): void
    {
        add_action('admin_menu', [$this, 'registerMenu']);
        add_action('admin_post_' . self::DELETE_ACTION, [$this, 'handleDelete']);
    }

    public function registerMenu(): void
    {
        add_submenu_page(
            self::PARENT_SLUG,
            __('Soumissions bloquées', 'thecore-elementor-widgets'),
            __('Soumissions bloquées', 'thecore-elementor-widgets'),
            $this->capability(),
            self::PAGE_SLUG,
            [$this, 'renderPage']
        );
    }

    public function renderPage(): void
    {
        if (! $this->currentUserCanAccess()) {
            wp_die(
                esc_html__(
                    'Vous n’êtes pas autorisé à consulter ce journal.',
                    'thecore-elementor-widgets'
                )
            );

            return;
        }

        $recordId = $this->positiveIntegerFromRequest($_GET, 'submission_id');

        echo '<div class="wrap">';

        if (! $this->schemaIsReady()) {
            echo '<h1>';
            echo esc_html__('Journal des soumissions bloquées', 'thecore-elementor-widgets');
            echo '</h1>';
            $this->renderErrorNotice(
                __(
                    'Le stockage du journal n’est pas installé ou doit être mis à niveau. Aucun état du journal ne peut être déduit tant que le schéma n’est pas disponible.',
                    'thecore-elementor-widgets'
                )
            );
            echo '</div>';

            return;
        }

        if ($recordId > 0) {
            $this->renderDetail($recordId);
        } else {
            $this->renderList();
        }

        echo '</div>';
    }

    public function handleDelete(): void
    {
        if (! $this->currentUserCanAccess()) {
            wp_die(
                esc_html__(
                    'Vous n’êtes pas autorisé à supprimer cette entrée.',
                    'thecore-elementor-widgets'
                )
            );

            return;
        }

        $requestMethod = isset($_SERVER['REQUEST_METHOD']) && is_scalar($_SERVER['REQUEST_METHOD'])
            ? strtoupper((string) $_SERVER['REQUEST_METHOD'])
            : '';

        if ('POST' !== $requestMethod) {
            wp_die(
                esc_html__(
                    'Cette action doit être envoyée avec une requête POST.',
                    'thecore-elementor-widgets'
                )
            );

            return;
        }

        $recordId = $this->positiveIntegerFromRequest($_POST, 'submission_id');

        if ($recordId < 1) {
            $this->redirectAfterDelete('invalid');
        }

        check_admin_referer(
            $this->deleteNonceAction($recordId),
            self::DELETE_NONCE_NAME
        );

        if (! $this->schemaIsReady()) {
            $this->redirectAfterDelete('store_error');
        }

        $operationSucceeded = false;

        try {
            $deleted = (bool) $this->store->delete($recordId);
            $operationSucceeded = $this->lastStoreOperationSucceeded();
        } catch (Throwable) {
            $deleted = false;
        }

        if (! $operationSucceeded) {
            $this->redirectAfterDelete('store_error');
        }

        $this->redirectAfterDelete($deleted ? 'deleted' : 'not_found');
    }

    public function capability(): string
    {
        $capability = apply_filters(
            self::CAPABILITY_FILTER,
            self::DEFAULT_CAPABILITY
        );

        if (! is_string($capability)) {
            return self::DEFAULT_CAPABILITY;
        }

        $capability = sanitize_key($capability);

        return '' !== $capability ? $capability : self::DEFAULT_CAPABILITY;
    }

    private function renderList(): void
    {
        $settings = new SecuritySettings();

        echo '<h1>';
        echo esc_html__('Journal des soumissions bloquées', 'thecore-elementor-widgets');
        echo '</h1>';

        echo '<p>';
        echo esc_html__(
            'Ce journal est réservé aux administrateurs et ne présente pas les valeurs techniques de protection.',
            'thecore-elementor-widgets'
        );
        echo ' ';
        echo esc_html(
            sprintf(
                __(
                    'Seuls certains motifs sont détaillés, dans la limite de %1$d entrées par fenêtre de 24 heures ; chaque entrée devient éligible à l’effacement après %2$d jours.',
                    'thecore-elementor-widgets'
                ),
                $settings->blockedSubmissionDailyLimit(),
                $settings->blockedSubmissionRetentionDays()
            )
        );
        echo '</p>';

        $this->renderDeleteNotice();

        $perPage = $this->perPage();
        $requestedPage = $this->positiveIntegerFromRequest($_GET, 'paged');
        $currentPage = max(1, $requestedPage);

        try {
            $total = max(0, (int) $this->store->count([]));

            if (! $this->lastStoreOperationSucceeded()) {
                $this->renderErrorNotice(
                    __(
                        'Le nombre d’entrées du journal n’a pas pu être lu en base de données. Le journal n’est donc pas présenté comme vide.',
                        'thecore-elementor-widgets'
                    )
                );

                return;
            }

            $totalPages = max(1, (int) ceil($total / $perPage));
            $currentPage = min($currentPage, $totalPages);
            $rows = $this->store->list(
                [
                    'limit' => $perPage,
                    'offset' => ($currentPage - 1) * $perPage,
                ]
            );

            if (! $this->lastStoreOperationSucceeded()) {
                $this->renderErrorNotice(
                    __(
                        'Les entrées du journal n’ont pas pu être lues en base de données. Vérifiez la connexion et la conformité du schéma avant de réessayer.',
                        'thecore-elementor-widgets'
                    )
                );

                return;
            }
        } catch (Throwable) {
            $this->renderErrorNotice(
                __('Le journal ne peut pas être chargé pour le moment.', 'thecore-elementor-widgets')
            );

            return;
        }

        if (! is_array($rows)) {
            $this->renderErrorNotice(
                __('Le stockage du journal a renvoyé une réponse invalide.', 'thecore-elementor-widgets')
            );

            return;
        }

        echo '<table class="widefat fixed striped">';
        echo '<thead><tr>';
        $this->renderTableHeading(__('Date', 'thecore-elementor-widgets'));
        $this->renderTableHeading(__('Motif', 'thecore-elementor-widgets'));
        $this->renderTableHeading(__('Formulaire', 'thecore-elementor-widgets'));
        $this->renderTableHeading(__('Nom', 'thecore-elementor-widgets'));
        $this->renderTableHeading(__('E-mail', 'thecore-elementor-widgets'));
        $this->renderTableHeading(__('Message', 'thecore-elementor-widgets'));
        $this->renderTableHeading(__('Action', 'thecore-elementor-widgets'));
        echo '</tr></thead>';
        echo '<tbody>';

        $rendered = 0;

        foreach ($rows as $row) {
            if (! is_array($row) || $this->rowId($row) < 1) {
                continue;
            }

            $this->renderListRow($row);
            ++$rendered;
        }

        if (0 === $rendered) {
            echo '<tr><td colspan="7">';
            echo esc_html__(
                'Aucune soumission bloquée enregistrée.',
                'thecore-elementor-widgets'
            );
            echo '</td></tr>';
        }

        echo '</tbody>';
        echo '</table>';

        $this->renderPagination($currentPage, $totalPages, $total);
    }

    /**
     * @param array<string, mixed> $row
     */
    private function renderListRow(array $row): void
    {
        $recordId = $this->rowId($row);
        $fields = $this->allowedFields($row);
        $summary = $this->summary($fields);

        echo '<tr>';
        $this->renderTableCell($this->formatDate($row['created_at'] ?? null));
        $this->renderTableCell($this->reasonLabel($row['reason'] ?? ''));
        $this->renderTableCell($this->scalarString($row['form_name'] ?? ''));
        $this->renderTableCell($this->truncate($summary['name'], 80));
        $this->renderTableCell($this->truncate($summary['email'], 100));
        $this->renderTableCell($this->truncate($summary['message'], 140));

        echo '<td><a class="button button-small" href="';
        echo esc_url($this->detailUrl($recordId));
        echo '">';
        echo esc_html__('Voir le détail', 'thecore-elementor-widgets');
        echo '</a></td>';
        echo '</tr>';
    }

    private function renderDetail(int $recordId): void
    {
        $operationSucceeded = false;

        try {
            $row = $this->store->get($recordId);
            $operationSucceeded = $this->lastStoreOperationSucceeded();
        } catch (Throwable) {
            $row = null;
        }

        echo '<p><a href="';
        echo esc_url($this->listUrl());
        echo '">&larr; ';
        echo esc_html__('Retour au journal', 'thecore-elementor-widgets');
        echo '</a></p>';

        if (! $operationSucceeded) {
            echo '<h1>';
            echo esc_html__('Journal momentanément indisponible', 'thecore-elementor-widgets');
            echo '</h1>';
            $this->renderErrorNotice(
                __(
                    'La lecture de cette entrée a échoué au niveau du stockage. Il est impossible de déterminer si elle existe.',
                    'thecore-elementor-widgets'
                )
            );

            return;
        }

        if (! is_array($row) || $this->rowId($row) !== $recordId) {
            echo '<h1>';
            echo esc_html__('Soumission bloquée introuvable', 'thecore-elementor-widgets');
            echo '</h1>';
            $this->renderErrorNotice(
                __('Cette entrée n’existe plus ou n’est pas accessible.', 'thecore-elementor-widgets')
            );

            return;
        }

        echo '<h1>';
        echo esc_html__(
            'Détail d’une soumission bloquée',
            'thecore-elementor-widgets'
        );
        echo '</h1>';

        echo '<table class="widefat striped"><tbody>';
        $this->renderDetailRow(
            __('Date du blocage', 'thecore-elementor-widgets'),
            $this->formatDate($row['created_at'] ?? null)
        );
        $this->renderDetailRow(
            __('Expiration prévue', 'thecore-elementor-widgets'),
            $this->formatDate($row['expires_at'] ?? null)
        );
        $this->renderDetailRow(
            __('Motif', 'thecore-elementor-widgets'),
            $this->reasonLabel($row['reason'] ?? '')
        );
        $this->renderDetailRow(
            __('Formulaire', 'thecore-elementor-widgets'),
            $this->scalarString($row['form_name'] ?? '')
        );
        $this->renderDetailRow(
            __('ID de la page WordPress', 'thecore-elementor-widgets'),
            $this->positiveIntegerString($row['post_id'] ?? null)
        );
        $this->renderDetailRow(
            __('ID du widget Elementor', 'thecore-elementor-widgets'),
            $this->scalarString($row['widget_id'] ?? '')
        );
        $this->renderPageUrlRow($row['page_url'] ?? '');
        echo '</tbody></table>';

        echo '<h2>';
        echo esc_html__('Champs transmis', 'thecore-elementor-widgets');
        echo '</h2>';

        $fields = $this->allowedFields($row);
        echo '<table class="widefat striped"><tbody>';

        if ([] === $fields) {
            echo '<tr><td>';
            echo esc_html__(
                'Aucun champ métier n’a été conservé pour cette entrée.',
                'thecore-elementor-widgets'
            );
            echo '</td></tr>';
        } else {
            foreach ($fields as $field) {
                $label = '' !== $field['label']
                    ? $field['label']
                    : __('Champ sans libellé', 'thecore-elementor-widgets');

                $this->renderDetailRow($label, $field['value'], true);
            }
        }

        echo '</tbody></table>';

        echo '<hr>';
        echo '<h2>';
        echo esc_html__('Suppression', 'thecore-elementor-widgets');
        echo '</h2>';
        echo '<p>';
        echo esc_html__(
            'Cette suppression est définitive et retire immédiatement l’entrée du journal.',
            'thecore-elementor-widgets'
        );
        echo '</p>';
        $this->renderDeleteForm($recordId);
    }

    private function renderDeleteForm(int $recordId): void
    {
        $nonce = wp_create_nonce($this->deleteNonceAction($recordId));

        echo '<form method="post" action="';
        echo esc_url(admin_url('admin-post.php'));
        echo '">';
        echo '<input type="hidden" name="action" value="';
        echo esc_attr(self::DELETE_ACTION);
        echo '">';
        echo '<input type="hidden" name="submission_id" value="';
        echo esc_attr((string) $recordId);
        echo '">';
        echo '<input type="hidden" name="';
        echo esc_attr(self::DELETE_NONCE_NAME);
        echo '" value="';
        echo esc_attr((string) $nonce);
        echo '">';
        echo '<button type="submit" class="button button-link-delete">';
        echo esc_html__('Supprimer définitivement', 'thecore-elementor-widgets');
        echo '</button>';
        echo '</form>';
    }

    private function renderDeleteNotice(): void
    {
        $result = isset($_GET['delete_result']) && is_scalar($_GET['delete_result'])
            ? sanitize_key((string) wp_unslash($_GET['delete_result']))
            : '';

        if ('deleted' === $result) {
            echo '<div class="notice notice-success is-dismissible"><p>';
            echo esc_html__(
                'La soumission bloquée a été supprimée.',
                'thecore-elementor-widgets'
            );
            echo '</p></div>';

            return;
        }

        if ('store_error' === $result) {
            $this->renderErrorNotice(
                __(
                    'Le stockage du journal n’a pas confirmé l’opération de suppression. Vérifiez la base de données avant de réessayer.',
                    'thecore-elementor-widgets'
                )
            );

            return;
        }

        if ('not_found' === $result) {
            $this->renderErrorNotice(
                __(
                    'Aucune entrée correspondante n’existait au moment de la suppression.',
                    'thecore-elementor-widgets'
                )
            );

            return;
        }

        if ('invalid' === $result) {
            $this->renderErrorNotice(
                __('La demande de suppression est invalide.', 'thecore-elementor-widgets')
            );
        }
    }

    private function renderErrorNotice(string $message): void
    {
        echo '<div class="notice notice-error"><p>';
        echo esc_html($message);
        echo '</p></div>';
    }

    private function renderPagination(int $currentPage, int $totalPages, int $total): void
    {
        echo '<div class="tablenav"><div class="tablenav-pages">';
        echo '<span class="displaying-num">';
        echo esc_html(
            sprintf(
                _n(
                    '%d entrée',
                    '%d entrées',
                    $total,
                    'thecore-elementor-widgets'
                ),
                $total
            )
        );
        echo '</span> ';

        if ($currentPage > 1) {
            echo '<a class="button" href="';
            echo esc_url($this->pageUrl($currentPage - 1));
            echo '">';
            echo esc_html__('Page précédente', 'thecore-elementor-widgets');
            echo '</a> ';
        }

        echo '<span class="paging-input">';
        echo esc_html(
            sprintf(
                __('Page %1$d sur %2$d', 'thecore-elementor-widgets'),
                $currentPage,
                $totalPages
            )
        );
        echo '</span>';

        if ($currentPage < $totalPages) {
            echo ' <a class="button" href="';
            echo esc_url($this->pageUrl($currentPage + 1));
            echo '">';
            echo esc_html__('Page suivante', 'thecore-elementor-widgets');
            echo '</a>';
        }

        echo '</div></div>';
    }

    private function renderTableHeading(string $label): void
    {
        echo '<th scope="col">';
        echo esc_html($label);
        echo '</th>';
    }

    private function renderTableCell(string $value): void
    {
        echo '<td>';
        echo esc_html('' !== $value ? $value : '—');
        echo '</td>';
    }

    private function renderDetailRow(string $label, string $value, bool $multiline = false): void
    {
        echo '<tr><th scope="row">';
        echo esc_html($label);
        echo '</th><td>';

        $value = '' !== $value ? $value : '—';
        $escapedValue = esc_html($value);
        echo $multiline ? nl2br($escapedValue) : $escapedValue;

        echo '</td></tr>';
    }

    private function renderPageUrlRow(mixed $pageUrl): void
    {
        $pageUrl = $this->scalarString($pageUrl);

        echo '<tr><th scope="row">';
        echo esc_html__('Page', 'thecore-elementor-widgets');
        echo '</th><td>';

        if ('' === $pageUrl || '' === esc_url($pageUrl)) {
            echo '—';
        } else {
            echo '<a href="';
            echo esc_url($pageUrl);
            echo '" target="_blank" rel="noopener noreferrer">';
            echo esc_html($pageUrl);
            echo '</a>';
        }

        echo '</td></tr>';
    }

    /**
     * @param array<string, mixed> $row
     *
     * @return array<int, array{id: string, label: string, type: string, value: string}>
     */
    private function allowedFields(array $row): array
    {
        $fields = $row['fields'] ?? null;

        if (! is_array($fields)) {
            $encoded = $row['fields_json'] ?? '';
            if (! is_string($encoded) || '' === trim($encoded)) {
                return [];
            }

            $decoded = json_decode($encoded, true, 32);
            if (! is_array($decoded)) {
                return [];
            }

            $fields = $decoded;
        }

        $allowed = [];

        foreach ($fields as $field) {
            if (! is_array($field)) {
                continue;
            }

            $type = sanitize_key($this->scalarString($field['type'] ?? ''));
            $id = sanitize_key($this->scalarString($field['id'] ?? ''));

            if (
                ! in_array($type, self::ALLOWED_FIELD_TYPES, true)
                || $this->isTechnicalFieldIdentifier($id)
            ) {
                continue;
            }

            $allowed[] = [
                'id' => $id,
                'label' => $this->scalarString($field['label'] ?? ''),
                'type' => $type,
                'value' => $this->fieldValue($field['value'] ?? ''),
            ];
        }

        return $allowed;
    }

    private function isTechnicalFieldIdentifier(string $identifier): bool
    {
        foreach (self::TECHNICAL_FIELD_IDENTIFIERS as $technicalIdentifier) {
            if (str_contains($identifier, $technicalIdentifier)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param array<int, array{id: string, label: string, type: string, value: string}> $fields
     *
     * @return array{name: string, email: string, message: string}
     */
    private function summary(array $fields): array
    {
        $nameValues = [];
        $email = '';
        $message = '';
        $firstTextarea = '';

        foreach ($fields as $field) {
            $searchKey = $this->searchKey($field['id'] . ' ' . $field['label']);

            if (
                '' === $email
                && (
                    'email' === $field['type']
                    || $this->containsAny($searchKey, ['email', 'courriel', 'mail'])
                )
            ) {
                $email = $field['value'];
            }

            if ('textarea' === $field['type'] && '' === $firstTextarea) {
                $firstTextarea = $field['value'];
            }

            if (
                '' === $message
                && $this->containsAny(
                    $searchKey,
                    ['message', 'demande', 'commentaire', 'comment', 'description']
                )
            ) {
                $message = $field['value'];
            }

            if (
                in_array($field['type'], ['text', 'textarea'], true)
                && $this->containsAny(
                    $searchKey,
                    ['nom', 'name', 'prenom', 'firstname', 'lastname', 'fullname']
                )
                && '' !== $field['value']
            ) {
                $nameValues[] = $field['value'];
            }
        }

        if ('' === $message) {
            $message = $firstTextarea;
        }

        return [
            'name' => implode(' ', array_slice(array_unique($nameValues), 0, 2)),
            'email' => $email,
            'message' => $message,
        ];
    }

    /**
     * @param string[] $needles
     */
    private function containsAny(string $haystack, array $needles): bool
    {
        foreach ($needles as $needle) {
            if (str_contains($haystack, $needle)) {
                return true;
            }
        }

        return false;
    }

    private function searchKey(string $value): string
    {
        $value = strtr(
            strtolower($value),
            [
                'à' => 'a',
                'â' => 'a',
                'ä' => 'a',
                'ç' => 'c',
                'é' => 'e',
                'è' => 'e',
                'ê' => 'e',
                'ë' => 'e',
                'î' => 'i',
                'ï' => 'i',
                'ô' => 'o',
                'ö' => 'o',
                'ù' => 'u',
                'û' => 'u',
                'ü' => 'u',
            ]
        );

        return (string) preg_replace('/[^a-z0-9]+/', '', $value);
    }

    private function fieldValue(mixed $value): string
    {
        if (is_scalar($value) || null === $value) {
            return trim((string) $value);
        }

        if (! is_array($value)) {
            return '';
        }

        $scalars = [];

        array_walk_recursive(
            $value,
            static function (mixed $item) use (&$scalars): void {
                if (is_scalar($item) || null === $item) {
                    $scalars[] = trim((string) $item);
                }
            }
        );

        return implode(', ', array_filter($scalars, static fn (string $item): bool => '' !== $item));
    }

    private function reasonLabel(mixed $reason): string
    {
        $reason = sanitize_key($this->scalarString($reason));

        $labels = [
            'blocked_attempt_rate' => __('Trop de tentatives rapprochées', 'thecore-elementor-widgets'),
            'blocked_configuration' => __('Configuration de protection invalide', 'thecore-elementor-widgets'),
            'blocked_duplicate' => __('Soumission dupliquée', 'thecore-elementor-widgets'),
            'blocked_elementor' => __('Validation du formulaire refusée', 'thecore-elementor-widgets'),
            'blocked_honeypot' => __('Champ leurre rempli', 'thecore-elementor-widgets'),
            'blocked_origin' => __('Origine de la requête refusée', 'thecore-elementor-widgets'),
            'blocked_payload_size' => __('Requête trop volumineuse', 'thecore-elementor-widgets'),
            'blocked_replay' => __('Preuve de contrôle déjà utilisée', 'thecore-elementor-widgets'),
            'blocked_schema_unavailable' => __('Stockage de sécurité indisponible', 'thecore-elementor-widgets'),
            'blocked_store_unavailable' => __('Stockage de sécurité indisponible', 'thecore-elementor-widgets'),
            'blocked_submission_rate' => __('Trop de soumissions rapprochées', 'thecore-elementor-widgets'),
        ];

        if (isset($labels[$reason])) {
            return $labels[$reason];
        }

        if (str_starts_with($reason, 'blocked_altcha_')) {
            return __('Contrôle anti-robot refusé', 'thecore-elementor-widgets');
        }

        return __('Blocage de sécurité', 'thecore-elementor-widgets');
    }

    private function formatDate(mixed $value): string
    {
        if (is_int($value) || (is_string($value) && ctype_digit($value))) {
            $timestamp = (int) $value;

            return $timestamp > 0 ? gmdate('Y-m-d H:i:s', $timestamp) . ' UTC' : '';
        }

        return $this->scalarString($value);
    }

    private function scalarString(mixed $value): string
    {
        return is_scalar($value) ? trim((string) $value) : '';
    }

    private function positiveIntegerString(mixed $value): string
    {
        if (is_int($value) && $value > 0) {
            return (string) $value;
        }

        if (is_string($value) && ctype_digit($value) && (int) $value > 0) {
            return (string) (int) $value;
        }

        return '';
    }

    private function truncate(string $value, int $maximumCharacters): string
    {
        if ($maximumCharacters < 2) {
            return '';
        }

        if (function_exists('mb_strlen') && function_exists('mb_substr')) {
            return mb_strlen($value) > $maximumCharacters
                ? rtrim(mb_substr($value, 0, $maximumCharacters - 1)) . '…'
                : $value;
        }

        return strlen($value) > $maximumCharacters
            ? rtrim(substr($value, 0, $maximumCharacters - 1)) . '…'
            : $value;
    }

    private function perPage(): int
    {
        $perPage = (int) apply_filters(
            self::PER_PAGE_FILTER,
            self::DEFAULT_PER_PAGE
        );

        return max(1, min(self::MAXIMUM_PER_PAGE, $perPage));
    }

    private function currentUserCanAccess(): bool
    {
        return current_user_can($this->capability());
    }

    private function schemaIsReady(): bool
    {
        return Installer::isReady() && Installer::hasExpectedSchema();
    }

    private function lastStoreOperationSucceeded(): bool
    {
        if (! method_exists($this->store, 'lastOperationSucceeded')) {
            return true;
        }

        try {
            return true === $this->store->lastOperationSucceeded();
        } catch (Throwable) {
            return false;
        }
    }

    /**
     * @param array<string, mixed> $source
     */
    private function positiveIntegerFromRequest(array $source, string $key): int
    {
        if (! isset($source[$key]) || ! is_scalar($source[$key])) {
            return 0;
        }

        $value = (string) wp_unslash($source[$key]);

        if (1 !== preg_match('/\A[1-9][0-9]*\z/D', $value)) {
            return 0;
        }

        return (int) $value;
    }

    /**
     * @param array<string, mixed> $row
     */
    private function rowId(array $row): int
    {
        $id = $row['id'] ?? 0;

        return (is_int($id) || (is_string($id) && ctype_digit($id)))
            ? max(0, (int) $id)
            : 0;
    }

    private function deleteNonceAction(int $recordId): string
    {
        return self::DELETE_ACTION . ':' . $recordId;
    }

    private function detailUrl(int $recordId): string
    {
        return add_query_arg(
            [
                'page' => self::PAGE_SLUG,
                'submission_id' => $recordId,
            ],
            admin_url('admin.php')
        );
    }

    private function listUrl(): string
    {
        return add_query_arg(
            ['page' => self::PAGE_SLUG],
            admin_url('admin.php')
        );
    }

    private function pageUrl(int $page): string
    {
        return add_query_arg(
            [
                'page' => self::PAGE_SLUG,
                'paged' => max(1, $page),
            ],
            admin_url('admin.php')
        );
    }

    private function redirectAfterDelete(string $result): never
    {
        $url = add_query_arg(
            [
                'page' => self::PAGE_SLUG,
                'delete_result' => sanitize_key($result),
            ],
            admin_url('admin.php')
        );

        wp_safe_redirect($url);
        exit;
    }
}
