<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\FormSecurity;

use TheCore\ElementorWidgets\Contracts\Bootable;
use TheCore\ElementorWidgets\FormSecurity\Support\SecuritySettings;

final class Assets implements Bootable
{
    public const ALTCHA_SCRIPT = 'thecore-form-security-altcha';
    public const PBKDF2_SCRIPT = 'thecore-form-security-pbkdf2';
    public const SCRIPT = 'thecore-form-security';
    public const ALTCHA_STYLE = 'thecore-form-security-altcha';
    public const STYLE = 'thecore-form-security';

    public function register(): void
    {
        add_action('wp_enqueue_scripts', [$this, 'registerAssets'], 5);
        add_action('elementor/editor/before_enqueue_scripts', [$this, 'registerAssets'], 5);
    }

    public function registerAssets(): void
    {
        wp_register_style(
            self::ALTCHA_STYLE,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/vendor/altcha/altcha.css',
            [],
            SecuritySettings::ALTCHA_WIDGET_VERSION
        );

        wp_register_style(
            self::STYLE,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/form-security.css',
            [self::ALTCHA_STYLE],
            THECORE_ELEMENTOR_WIDGETS_VERSION
        );

        wp_register_script(
            self::ALTCHA_SCRIPT,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/vendor/altcha/altcha.external.classic.min.js',
            [],
            SecuritySettings::ALTCHA_WIDGET_VERSION,
            true
        );

        wp_register_script(
            self::PBKDF2_SCRIPT,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/vendor/altcha/register-pbkdf2.js',
            [self::ALTCHA_SCRIPT],
            SecuritySettings::ALTCHA_WIDGET_VERSION,
            true
        );

        $workerConfiguration = wp_json_encode(
            [
                'workerUrl' => add_query_arg(
                    'ver',
                    SecuritySettings::ALTCHA_WIDGET_VERSION,
                    THECORE_ELEMENTOR_WIDGETS_URL . 'assets/vendor/altcha/pbkdf2.js'
                ),
            ]
        );

        if (is_string($workerConfiguration)) {
            wp_add_inline_script(
                self::PBKDF2_SCRIPT,
                'window.theCoreElementorFormSecurity = ' . $workerConfiguration . ';',
                'before'
            );
        }

        wp_register_script(
            self::SCRIPT,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/form-security.js',
            [self::PBKDF2_SCRIPT],
            THECORE_ELEMENTOR_WIDGETS_VERSION,
            true
        );
    }
}
