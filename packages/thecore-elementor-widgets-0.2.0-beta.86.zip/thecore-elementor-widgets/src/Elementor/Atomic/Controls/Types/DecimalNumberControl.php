<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Controls\Types;

use Elementor\Modules\AtomicWidgets\Controls\Base\Atomic_Control_Base;

/**
 * Native Atomic number control with decimal-compatible server-side bounds.
 *
 * Elementor's editor control supports decimal values, but its PHP setters are
 * currently restricted to integers. Keeping the native `number` type avoids a
 * custom editor component while allowing legitimate decimal configuration.
 */
final class DecimalNumberControl extends Atomic_Control_Base
{
    private ?string $placeholder = null;

    private int|float|null $max = null;

    private int|float|null $min = null;

    private int|float|null $step = null;

    public function get_type(): string
    {
        return 'number';
    }

    public function set_placeholder(string $placeholder): self
    {
        $this->placeholder = $placeholder;

        return $this;
    }

    public function set_max(int|float|null $max): self
    {
        $this->max = $max;

        return $this;
    }

    public function set_min(int|float|null $min): self
    {
        $this->min = $min;

        return $this;
    }

    public function set_step(int|float|null $step): self
    {
        $this->step = $step;

        return $this;
    }

    public function get_props(): array
    {
        return [
            'placeholder' => $this->placeholder,
            'max' => $this->max,
            'min' => $this->min,
            'step' => $this->step,
            'shouldForceInt' => false,
        ];
    }
}
