<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\IconText;

final class DisplaySettings
{
    public const DEFAULT_TEXT = 'Texte avec icône';
    public const DEFAULT_HTML_TAG = 'div';
    public const DEFAULT_ICON_TYPE = 'glyph';
    public const DEFAULT_ICON_GLYPH = '✓';
    public const DEFAULT_ICON_SVG = '';
    public const DEFAULT_ICON_POSITION = 'before';
    public const DEFAULT_ALIGNMENT = 'flex-start';
    public const DEFAULT_VERTICAL_ALIGNMENT = 'center';
    public const DEFAULT_GAP = 10;
    public const DEFAULT_ICON_COLOR = 'currentColor';
    public const DEFAULT_ICON_BACKGROUND_COLOR = 'transparent';
    public const DEFAULT_ICON_BOX_WIDTH = [
        'size' => 18.0,
        'unit' => 'px',
    ];
    public const DEFAULT_ICON_BOX_RATIO = 1.0;
    public const DEFAULT_ICON_SIZE = [
        'size' => 18.0,
        'unit' => 'px',
    ];
    public const DEFAULT_ICON_PADDING = 0;
    public const DEFAULT_ICON_RADIUS = 0;
    public const DEFAULT_TEXT_COLOR = '#222222';
    public const DEFAULT_FONT_FAMILY = 'inherit';
    public const DEFAULT_FONT_SIZE = [
        'size' => 16.0,
        'unit' => 'px',
    ];
    public const DEFAULT_FONT_WEIGHT = '400';
    public const DEFAULT_LINE_HEIGHT = [
        'size' => 1.4,
        'unit' => 'em',
    ];
    public const DEFAULT_LETTER_SPACING = [
        'size' => 0.0,
        'unit' => 'px',
    ];
    public const DEFAULT_TEXT_TRANSFORM = 'none';

    /**
     * @param array<string, mixed> $settings
     *
     * @return array{
     *     text: string,
     *     html_tag: string,
     *     icon_type: string,
     *     icon_glyph: string,
     *     icon_svg: string,
     *     icon_position: string,
     *     flex_direction: string,
     *     alignment: string,
     *     vertical_alignment: string,
     *     gap: int,
     *     icon_color: string,
     *     icon_background_color: string,
     *     icon_box_width: array{size: float, unit: string},
     *     icon_box_ratio: float,
     *     icon_size: array{size: float, unit: string},
     *     icon_padding: int,
     *     icon_radius: int,
     *     text_color: string,
     *     font_family: string,
     *     font_size: array{size: float, unit: string},
     *     font_weight: string,
     *     line_height: array{size: float, unit: string},
     *     letter_spacing: array{size: float, unit: string},
     *     text_transform: string
     * }
     */
    public function normalize(array $settings): array
    {
        $iconPosition = $this->sanitizeEnum(
            $settings['icon_position'] ?? self::DEFAULT_ICON_POSITION,
            ['before', 'after'],
            self::DEFAULT_ICON_POSITION
        );

        return [
            'text' => $this->sanitizeTextarea($settings['text'] ?? self::DEFAULT_TEXT),
            'html_tag' => $this->sanitizeEnum(
                $settings['html_tag'] ?? self::DEFAULT_HTML_TAG,
                ['div', 'p', 'span'],
                self::DEFAULT_HTML_TAG
            ),
            'icon_type' => $this->sanitizeEnum(
                $settings['icon_type'] ?? self::DEFAULT_ICON_TYPE,
                ['glyph', 'svg'],
                self::DEFAULT_ICON_TYPE
            ),
            'icon_glyph' => $this->sanitizeGlyph($settings['icon_glyph'] ?? self::DEFAULT_ICON_GLYPH),
            'icon_svg' => $this->sanitizeSvgInput($settings['icon_svg'] ?? self::DEFAULT_ICON_SVG),
            'icon_position' => $iconPosition,
            'flex_direction' => 'after' === $iconPosition ? 'row-reverse' : 'row',
            'alignment' => $this->sanitizeEnum(
                $settings['alignment'] ?? self::DEFAULT_ALIGNMENT,
                ['flex-start', 'center', 'flex-end'],
                self::DEFAULT_ALIGNMENT
            ),
            'vertical_alignment' => $this->sanitizeEnum(
                $settings['vertical_alignment'] ?? self::DEFAULT_VERTICAL_ALIGNMENT,
                ['flex-start', 'center', 'flex-end', 'baseline'],
                self::DEFAULT_VERTICAL_ALIGNMENT
            ),
            'gap' => $this->clampInt($settings['gap'] ?? self::DEFAULT_GAP, 0, 100, self::DEFAULT_GAP),
            'icon_color' => $this->sanitizeColor(
                $settings['icon_color'] ?? self::DEFAULT_ICON_COLOR,
                self::DEFAULT_ICON_COLOR
            ),
            'icon_background_color' => $this->sanitizeColor(
                $settings['icon_background_color'] ?? self::DEFAULT_ICON_BACKGROUND_COLOR,
                self::DEFAULT_ICON_BACKGROUND_COLOR
            ),
            'icon_box_width' => $this->sanitizeSize(
                $settings['icon_box_width'] ?? self::DEFAULT_ICON_BOX_WIDTH,
                self::DEFAULT_ICON_BOX_WIDTH,
                ['px', 'em', 'rem'],
                4.0,
                320.0
            ),
            'icon_box_ratio' => $this->clampFloat(
                $settings['icon_box_ratio'] ?? self::DEFAULT_ICON_BOX_RATIO,
                0.25,
                4.0,
                self::DEFAULT_ICON_BOX_RATIO
            ),
            'icon_size' => $this->sanitizeSize(
                $settings['icon_size'] ?? self::DEFAULT_ICON_SIZE,
                self::DEFAULT_ICON_SIZE,
                ['px', 'em', 'rem'],
                4.0,
                160.0
            ),
            'icon_padding' => $this->clampInt(
                $settings['icon_padding'] ?? self::DEFAULT_ICON_PADDING,
                0,
                80,
                self::DEFAULT_ICON_PADDING
            ),
            'icon_radius' => $this->clampInt(
                $settings['icon_radius'] ?? self::DEFAULT_ICON_RADIUS,
                0,
                120,
                self::DEFAULT_ICON_RADIUS
            ),
            'text_color' => $this->sanitizeColor(
                $settings['text_color'] ?? self::DEFAULT_TEXT_COLOR,
                self::DEFAULT_TEXT_COLOR
            ),
            'font_family' => $this->sanitizeFontFamily(
                $settings['font_family'] ?? self::DEFAULT_FONT_FAMILY,
                self::DEFAULT_FONT_FAMILY
            ),
            'font_size' => $this->sanitizeSize(
                $settings['font_size'] ?? self::DEFAULT_FONT_SIZE,
                self::DEFAULT_FONT_SIZE,
                ['px', 'em', 'rem'],
                8.0,
                120.0
            ),
            'font_weight' => $this->sanitizeEnum(
                $settings['font_weight'] ?? self::DEFAULT_FONT_WEIGHT,
                ['100', '200', '300', '400', '500', '600', '700', '800', '900'],
                self::DEFAULT_FONT_WEIGHT
            ),
            'line_height' => $this->sanitizeSize(
                $settings['line_height'] ?? self::DEFAULT_LINE_HEIGHT,
                self::DEFAULT_LINE_HEIGHT,
                ['px', 'em', 'rem'],
                0.5,
                4.0
            ),
            'letter_spacing' => $this->sanitizeSize(
                $settings['letter_spacing'] ?? self::DEFAULT_LETTER_SPACING,
                self::DEFAULT_LETTER_SPACING,
                ['px', 'em', 'rem'],
                -20.0,
                20.0
            ),
            'text_transform' => $this->sanitizeEnum(
                $settings['text_transform'] ?? self::DEFAULT_TEXT_TRANSFORM,
                ['none', 'uppercase', 'lowercase', 'capitalize'],
                self::DEFAULT_TEXT_TRANSFORM
            ),
        ];
    }

    private function sanitizeTextarea(mixed $value): string
    {
        if (! is_string($value)) {
            return '';
        }

        return sanitize_textarea_field($value);
    }

    private function sanitizeGlyph(mixed $value): string
    {
        if (! is_string($value)) {
            return '';
        }

        $normalized = sanitize_text_field($value);

        if (function_exists('mb_substr')) {
            return mb_substr($normalized, 0, 12);
        }

        return substr($normalized, 0, 48);
    }

    private function sanitizeSvgInput(mixed $value): string
    {
        if (! is_string($value)) {
            return '';
        }

        $normalized = trim($value);

        if ('' === $normalized || 1 !== preg_match('/^<svg[\s>]/i', $normalized)) {
            return '';
        }

        return substr($normalized, 0, 20000);
    }

    private function clampInt(mixed $value, int $min, int $max, int $default): int
    {
        if (! is_numeric($value)) {
            return $default;
        }

        return max($min, min($max, (int) $value));
    }

    private function clampFloat(mixed $value, float $min, float $max, float $default): float
    {
        if (! is_numeric($value)) {
            return $default;
        }

        return max($min, min($max, (float) $value));
    }

    private function sanitizeColor(mixed $value, string $default): string
    {
        if (! is_string($value)) {
            return $default;
        }

        $normalized = trim($value);

        if ('' === $normalized) {
            return $default;
        }

        if (1 === preg_match('/^#(?:[0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/', $normalized)) {
            return $normalized;
        }

        if (1 === preg_match('/^(?:rgb|rgba|hsl|hsla)\([0-9.,%\s\/-]+\)$/i', $normalized)) {
            return $normalized;
        }

        if (1 === preg_match('/^var\(--[a-zA-Z0-9_-]+\)$/', $normalized)) {
            return $normalized;
        }

        if (in_array(strtolower($normalized), ['transparent', 'currentcolor', 'inherit'], true)) {
            return $normalized;
        }

        return $default;
    }

    private function sanitizeFontFamily(mixed $value, string $default): string
    {
        if (! is_string($value)) {
            return $default;
        }

        $normalized = trim(str_replace([';', '{', '}', '<', '>'], '', $value));

        return '' !== $normalized ? $normalized : $default;
    }

    /**
     * @param array<int, string> $allowed
     */
    private function sanitizeEnum(mixed $value, array $allowed, string $default): string
    {
        if (! is_string($value)) {
            return $default;
        }

        $normalized = trim($value);

        return in_array($normalized, $allowed, true) ? $normalized : $default;
    }

    /**
     * @param array{size: float|int, unit: string} $default
     * @param array<int, string>                   $allowedUnits
     *
     * @return array{size: float, unit: string}
     */
    private function sanitizeSize(mixed $value, array $default, array $allowedUnits, float $min, float $max): array
    {
        if (! is_array($value)) {
            return [
                'size' => (float) $default['size'],
                'unit' => $default['unit'],
            ];
        }

        $size = $value['size'] ?? $default['size'];
        $unit = $value['unit'] ?? $default['unit'];

        if (! is_numeric($size) || ! is_string($unit) || ! in_array($unit, $allowedUnits, true)) {
            return [
                'size' => (float) $default['size'],
                'unit' => $default['unit'],
            ];
        }

        $normalizedSize = (float) $size;

        if ($normalizedSize < $min || $normalizedSize > $max) {
            return [
                'size' => (float) $default['size'],
                'unit' => $default['unit'],
            ];
        }

        return [
            'size' => $normalizedSize,
            'unit' => $unit,
        ];
    }
}
