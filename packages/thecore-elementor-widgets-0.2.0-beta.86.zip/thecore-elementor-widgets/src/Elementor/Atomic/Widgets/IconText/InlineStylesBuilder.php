<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\IconText;

final class InlineStylesBuilder
{
    /**
     * @param array{
     *     flex_direction: string,
     *     alignment: string,
     *     vertical_alignment: string,
     *     gap: int,
     *     icon_color: string,
     *     icon_background_color: string,
     *     icon_box_width: array{size: float, unit: string},
     *     icon_box_ratio: float,
     *     icon_size: array{size: float, unit: string},
     *     icon_padding: int,
     *     icon_radius: int,
     *     text_color: string,
     *     font_family: string,
     *     font_size: array{size: float, unit: string},
     *     font_weight: string,
     *     line_height: array{size: float, unit: string},
     *     letter_spacing: array{size: float, unit: string},
     *     text_transform: string
     * } $settings
     */
    public function build(string $scopeSelector, array $settings): string
    {
        $rules = [];
        $rules[] = $scopeSelector . '{' . implode(';', [
            '--thecore-icon-text-direction:' . $settings['flex_direction'],
            '--thecore-icon-text-justify:' . $settings['alignment'],
            '--thecore-icon-text-align:' . $settings['vertical_alignment'],
            '--thecore-icon-text-gap:' . (int) $settings['gap'] . 'px',
            '--thecore-icon-text-icon-color:' . $settings['icon_color'],
            '--thecore-icon-text-icon-bg:' . $settings['icon_background_color'],
            '--thecore-icon-text-icon-box-width:' . $this->formatSize($settings['icon_box_width']),
            '--thecore-icon-text-icon-box-ratio:' . $this->formatNumber($settings['icon_box_ratio']),
            '--thecore-icon-text-icon-size:' . $this->formatSize($settings['icon_size']),
            '--thecore-icon-text-icon-padding:' . (int) $settings['icon_padding'] . 'px',
            '--thecore-icon-text-icon-radius:' . (int) $settings['icon_radius'] . 'px',
            '--thecore-icon-text-color:' . $settings['text_color'],
            '--thecore-icon-text-font-family:' . $settings['font_family'],
            '--thecore-icon-text-font-size:' . $this->formatSize($settings['font_size']),
            '--thecore-icon-text-font-weight:' . $settings['font_weight'],
            '--thecore-icon-text-line-height:' . $this->formatSize($settings['line_height']),
            '--thecore-icon-text-letter-spacing:' . $this->formatSize($settings['letter_spacing']),
            '--thecore-icon-text-text-transform:' . $settings['text_transform'],
        ]) . ';}';
        $rules[] = $scopeSelector . ' .thecore-icon-text__inner{display:inline-flex;flex-direction:var(--thecore-icon-text-direction);align-items:var(--thecore-icon-text-align);justify-content:var(--thecore-icon-text-justify);gap:var(--thecore-icon-text-gap);max-width:100%;margin:0;}';
        $rules[] = $scopeSelector . ' .thecore-icon-text__icon{display:inline-flex;flex:0 0 auto;align-items:center;justify-content:center;width:var(--thecore-icon-text-icon-box-width);aspect-ratio:var(--thecore-icon-text-icon-box-ratio)/1;box-sizing:border-box;padding:var(--thecore-icon-text-icon-padding);border-radius:var(--thecore-icon-text-icon-radius);background:var(--thecore-icon-text-icon-bg);color:var(--thecore-icon-text-icon-color);font-size:var(--thecore-icon-text-icon-size);line-height:1;}';
        $rules[] = $scopeSelector . ' .thecore-icon-text__icon svg{display:block;width:var(--thecore-icon-text-icon-size);height:var(--thecore-icon-text-icon-size);fill:currentColor;overflow:visible;}';
        $rules[] = $scopeSelector . ' .thecore-icon-text__text{min-width:0;color:var(--thecore-icon-text-color);font-family:var(--thecore-icon-text-font-family);font-size:var(--thecore-icon-text-font-size);font-weight:var(--thecore-icon-text-font-weight);line-height:var(--thecore-icon-text-line-height);letter-spacing:var(--thecore-icon-text-letter-spacing);text-transform:var(--thecore-icon-text-text-transform);word-break:break-word;}';
        $rules[] = $scopeSelector . ' .thecore-icon-text__empty{padding:16px;border:1px dashed #C7C7C7;color:#666;font-size:14px;line-height:1.4;}';

        return implode('', $rules);
    }

    /**
     * @param array{size: float, unit: string} $value
     */
    private function formatSize(array $value): string
    {
        $size = (float) $value['size'];

        if ((float) (int) $size === $size) {
            return (string) (int) $size . $value['unit'];
        }

        return rtrim(rtrim(sprintf('%.4F', $size), '0'), '.') . $value['unit'];
    }

    private function formatNumber(float $value): string
    {
        if ((float) (int) $value === $value) {
            return (string) (int) $value;
        }

        return rtrim(rtrim(sprintf('%.4F', $value), '0'), '.');
    }
}
