<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\IconText;

final class MarkupBuilder
{
    /**
     * @param array{
     *     text: string,
     *     html_tag: string,
     *     icon_type: string,
     *     icon_glyph: string,
     *     icon_svg: string,
     *     icon_position: string
     * } $settings
     */
    public function build(array $settings): string
    {
        if ('' === $settings['text']) {
            return $this->renderEmptyState(
                __('Add text to render the Icon Text widget.', 'thecore-elementor-widgets')
            );
        }

        $iconMarkup = $this->buildIcon($settings);
        $tag = esc_html($settings['html_tag']);
        $textMarkup = sprintf(
            '<span class="thecore-icon-text__text">%s</span>',
            nl2br(esc_html($settings['text']))
        );
        $content = 'after' === $settings['icon_position']
            ? $textMarkup . $iconMarkup
            : $iconMarkup . $textMarkup;

        return sprintf(
            '<%1$s class="thecore-icon-text__inner">%2$s</%1$s>',
            $tag,
            $content
        );
    }

    /**
     * @param array{icon_type: string, icon_glyph: string, icon_svg: string} $settings
     */
    private function buildIcon(array $settings): string
    {
        $icon = 'svg' === $settings['icon_type']
            ? $this->sanitizeSvgMarkup($settings['icon_svg'])
            : esc_html($settings['icon_glyph']);

        if ('' === $icon) {
            return '';
        }

        return sprintf(
            '<span class="thecore-icon-text__icon" aria-hidden="true">%s</span>',
            $icon
        );
    }

    private function sanitizeSvgMarkup(string $svg): string
    {
        if ('' === $svg || ! function_exists('wp_kses')) {
            return '';
        }

        $allowed = [
            'svg' => [
                'aria-hidden' => true,
                'class' => true,
                'fill' => true,
                'focusable' => true,
                'height' => true,
                'role' => true,
                'stroke' => true,
                'stroke-linecap' => true,
                'stroke-linejoin' => true,
                'stroke-width' => true,
                'viewbox' => true,
                'viewBox' => true,
                'width' => true,
                'xmlns' => true,
            ],
            'circle' => [
                'cx' => true,
                'cy' => true,
                'fill' => true,
                'r' => true,
                'stroke' => true,
                'stroke-linecap' => true,
                'stroke-linejoin' => true,
                'stroke-width' => true,
            ],
            'g' => [
                'clip-path' => true,
                'fill' => true,
                'stroke' => true,
                'stroke-linecap' => true,
                'stroke-linejoin' => true,
                'stroke-width' => true,
                'transform' => true,
            ],
            'line' => [
                'fill' => true,
                'stroke' => true,
                'stroke-linecap' => true,
                'stroke-linejoin' => true,
                'stroke-width' => true,
                'x1' => true,
                'x2' => true,
                'y1' => true,
                'y2' => true,
            ],
            'path' => [
                'd' => true,
                'fill' => true,
                'fill-rule' => true,
                'stroke' => true,
                'stroke-linecap' => true,
                'stroke-linejoin' => true,
                'stroke-width' => true,
            ],
            'polyline' => [
                'fill' => true,
                'points' => true,
                'stroke' => true,
                'stroke-linecap' => true,
                'stroke-linejoin' => true,
                'stroke-width' => true,
            ],
            'rect' => [
                'fill' => true,
                'height' => true,
                'rx' => true,
                'stroke' => true,
                'stroke-linecap' => true,
                'stroke-linejoin' => true,
                'stroke-width' => true,
                'width' => true,
                'x' => true,
                'y' => true,
            ],
        ];
        $sanitized = wp_kses($svg, $allowed);

        return 1 === preg_match('/<svg[\s>]/i', $sanitized) ? $sanitized : '';
    }

    private function renderEmptyState(string $message): string
    {
        if (! $this->isElementorEditingContext()) {
            return '';
        }

        return sprintf(
            '<div class="thecore-icon-text__empty">%s</div>',
            esc_html($message)
        );
    }

    private function isElementorEditingContext(): bool
    {
        if (! class_exists('\Elementor\Plugin')) {
            return false;
        }

        return \Elementor\Plugin::$instance->editor->is_edit_mode()
            || \Elementor\Plugin::$instance->preview->is_preview_mode();
    }
}
