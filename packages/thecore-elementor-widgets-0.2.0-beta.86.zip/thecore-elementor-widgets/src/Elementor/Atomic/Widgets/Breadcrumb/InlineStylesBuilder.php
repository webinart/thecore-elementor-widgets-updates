<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\Breadcrumb;

final class InlineStylesBuilder
{
    /**
     * @param array{
     *     alignment: string,
     *     text_color: string,
     *     current_color: string,
     *     separator_color: string,
     *     font_family: string,
     *     font_size: array{size: float, unit: string},
     *     font_weight: string,
     *     current_font_weight: string,
     *     line_height: array{size: float, unit: string},
     *     letter_spacing: array{size: float, unit: string},
     *     text_transform: string,
     *     gap: int
     * } $settings
     */
    public function build(string $scopeSelector, array $settings): string
    {
        $rules = [];
        $rules[] = $scopeSelector . '{' . implode(';', [
            '--thecore-breadcrumb-gap:' . (int) $settings['gap'] . 'px',
            '--thecore-breadcrumb-justify:' . $settings['alignment'],
            '--thecore-breadcrumb-text-color:' . $settings['text_color'],
            '--thecore-breadcrumb-current-color:' . $settings['current_color'],
            '--thecore-breadcrumb-separator-color:' . $settings['separator_color'],
            '--thecore-breadcrumb-font-family:' . $settings['font_family'],
            '--thecore-breadcrumb-font-size:' . $this->formatSize($settings['font_size']),
            '--thecore-breadcrumb-font-weight:' . $settings['font_weight'],
            '--thecore-breadcrumb-current-font-weight:' . $settings['current_font_weight'],
            '--thecore-breadcrumb-line-height:' . $this->formatSize($settings['line_height']),
            '--thecore-breadcrumb-letter-spacing:' . $this->formatSize($settings['letter_spacing']),
            '--thecore-breadcrumb-text-transform:' . $settings['text_transform'],
        ]) . ';}';
        $rules[] = $scopeSelector . ' .thecore-breadcrumb__nav{display:block;width:100%;}';
        $rules[] = $scopeSelector . ' .thecore-breadcrumb__list{display:flex;flex-wrap:wrap;align-items:center;justify-content:var(--thecore-breadcrumb-justify);gap:var(--thecore-breadcrumb-gap);margin:0;padding:0;list-style:none;}';
        $rules[] = $scopeSelector . ' .thecore-breadcrumb__item{display:inline-flex;align-items:center;gap:var(--thecore-breadcrumb-gap);min-width:0;}';
        $rules[] = $scopeSelector . ' .thecore-breadcrumb__link,' . $scopeSelector . ' .thecore-breadcrumb__current,' . $scopeSelector . ' .thecore-breadcrumb__separator{font-family:var(--thecore-breadcrumb-font-family);font-size:var(--thecore-breadcrumb-font-size);line-height:var(--thecore-breadcrumb-line-height);letter-spacing:var(--thecore-breadcrumb-letter-spacing);text-transform:var(--thecore-breadcrumb-text-transform);}';
        $rules[] = $scopeSelector . ' .thecore-breadcrumb__link{color:var(--thecore-breadcrumb-text-color);font-weight:var(--thecore-breadcrumb-font-weight);text-decoration:none;word-break:break-word;}';
        $rules[] = $scopeSelector . ' .thecore-breadcrumb__link:hover,' . $scopeSelector . ' .thecore-breadcrumb__link:focus-visible{text-decoration:underline;}';
        $rules[] = $scopeSelector . ' .thecore-breadcrumb__current{color:var(--thecore-breadcrumb-current-color);font-weight:var(--thecore-breadcrumb-current-font-weight);word-break:break-word;}';
        $rules[] = $scopeSelector . ' .thecore-breadcrumb__separator{color:var(--thecore-breadcrumb-separator-color);font-weight:var(--thecore-breadcrumb-font-weight);flex:0 0 auto;}';
        $rules[] = $scopeSelector . ' .thecore-breadcrumb__empty{padding:16px;border:1px dashed #C7C7C7;color:#666;font-size:14px;line-height:1.4;}';

        return implode('', $rules);
    }

    /**
     * @param array{size: float, unit: string} $value
     */
    private function formatSize(array $value): string
    {
        $size = (float) $value['size'];

        if ((float) (int) $size === $size) {
            return (string) (int) $size . $value['unit'];
        }

        return rtrim(rtrim(sprintf('%.4F', $size), '0'), '.') . $value['unit'];
    }
}
