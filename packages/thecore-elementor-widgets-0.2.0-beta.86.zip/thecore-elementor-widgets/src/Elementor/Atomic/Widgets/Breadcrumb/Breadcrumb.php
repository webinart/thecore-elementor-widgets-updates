<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\Breadcrumb;

use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Number_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Select_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Size_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Switch_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Text_Control;
use Elementor\Modules\AtomicWidgets\DynamicTags\Dynamic_Prop_Type;
use Elementor\Modules\AtomicWidgets\Elements\Base\Atomic_Widget_Base;
use Elementor\Modules\AtomicWidgets\Elements\Base\Has_Template;
use Elementor\Modules\AtomicWidgets\PropTypes\Attributes_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Classes_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Color_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Dimensions_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Boolean_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Number_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Size_Prop_Type;
use Elementor\Modules\AtomicWidgets\Styles\Style_Definition;
use Elementor\Modules\AtomicWidgets\Styles\Style_Variant;
use Elementor\Modules\Components\PropTypes\Overridable_Prop_Type;
use TheCore\ElementorWidgets\Elementor\Atomic\Controls\Types\ColorControl;
use TheCore\ElementorWidgets\Elementor\Atomic\Controls\Types\FontFamilyControl;
use TheCore\ElementorWidgets\Elementor\Atomic\Controls\Types\ZeroDefaultSizeControl;
use TheCore\ElementorWidgets\Elementor\Atomic\PropTypes\ZeroableSizePropType;

final class Breadcrumb extends Atomic_Widget_Base
{
    use Has_Template;

    public static $widget_description = 'Accessible breadcrumb navigation with semantic nav/list markup and dynamic WordPress trail generation.';

    public static function get_element_type(): string
    {
        return 'thecore-breadcrumb';
    }

    public function get_title(): string
    {
        return esc_html__('Breadcrumb', 'thecore-elementor-widgets');
    }

    public function get_icon(): string
    {
        return 'eicon-product-breadcrumbs';
    }

    public function get_keywords(): array
    {
        return ['breadcrumb', 'breadcrumbs', 'navigation', 'accessible', 'atomic'];
    }

    protected static function define_props_schema(): array
    {
        return [
            'classes' => Classes_Prop_Type::make()->default([]),
            'aria_label' => String_Prop_Type::make()
                ->default(DisplaySettings::DEFAULT_ARIA_LABEL)
                ->meta(Dynamic_Prop_Type::ignore())
                ->meta(Overridable_Prop_Type::ignore()),
            'home_label' => String_Prop_Type::make()
                ->default(DisplaySettings::DEFAULT_HOME_LABEL)
                ->meta(Dynamic_Prop_Type::ignore())
                ->meta(Overridable_Prop_Type::ignore()),
            'separator' => String_Prop_Type::make()
                ->default(DisplaySettings::DEFAULT_SEPARATOR)
                ->meta(Dynamic_Prop_Type::ignore())
                ->meta(Overridable_Prop_Type::ignore()),
            'show_home' => Boolean_Prop_Type::make()
                ->default(DisplaySettings::DEFAULT_SHOW_HOME)
                ->meta(Dynamic_Prop_Type::ignore())
                ->meta(Overridable_Prop_Type::ignore()),
            'show_current' => Boolean_Prop_Type::make()
                ->default(DisplaySettings::DEFAULT_SHOW_CURRENT)
                ->meta(Dynamic_Prop_Type::ignore())
                ->meta(Overridable_Prop_Type::ignore()),
            'alignment' => String_Prop_Type::make()
                ->enum(['flex-start', 'center', 'flex-end'])
                ->default(DisplaySettings::DEFAULT_ALIGNMENT)
                ->meta(Dynamic_Prop_Type::ignore())
                ->meta(Overridable_Prop_Type::ignore()),
            'text_color' => Color_Prop_Type::make()->default(DisplaySettings::DEFAULT_TEXT_COLOR),
            'current_color' => Color_Prop_Type::make()->default(DisplaySettings::DEFAULT_CURRENT_COLOR),
            'separator_color' => Color_Prop_Type::make()->default(DisplaySettings::DEFAULT_SEPARATOR_COLOR),
            'font_family' => String_Prop_Type::make()->default(DisplaySettings::DEFAULT_FONT_FAMILY),
            'font_size' => Size_Prop_Type::make()
                ->units(['px', 'em', 'rem'])
                ->default_unit('px')
                ->default(DisplaySettings::DEFAULT_FONT_SIZE),
            'font_weight' => String_Prop_Type::make()->enum(self::fontWeightValues())->default(DisplaySettings::DEFAULT_FONT_WEIGHT),
            'current_font_weight' => String_Prop_Type::make()->enum(self::fontWeightValues())->default(DisplaySettings::DEFAULT_CURRENT_FONT_WEIGHT),
            'line_height' => Size_Prop_Type::make()
                ->units(['em', 'px', 'rem'])
                ->default_unit('em')
                ->default(DisplaySettings::DEFAULT_LINE_HEIGHT),
            'letter_spacing' => ZeroableSizePropType::make()
                ->units(['px', 'em', 'rem'])
                ->default_unit('px')
                ->meta(Dynamic_Prop_Type::ignore())
                ->meta(Overridable_Prop_Type::ignore())
                ->initial_value(DisplaySettings::DEFAULT_LETTER_SPACING)
                ->default(DisplaySettings::DEFAULT_LETTER_SPACING),
            'text_transform' => String_Prop_Type::make()
                ->enum(self::textTransformValues())
                ->default(DisplaySettings::DEFAULT_TEXT_TRANSFORM),
            'gap' => Number_Prop_Type::make()->default(DisplaySettings::DEFAULT_GAP),
            'attributes' => Attributes_Prop_Type::make()->meta(Overridable_Prop_Type::ignore()),
        ];
    }

    protected function define_base_styles(): array
    {
        $zeroSize = Size_Prop_Type::generate([
            'size' => 0,
            'unit' => 'px',
        ]);

        $spacingValue = Dimensions_Prop_Type::generate([
            'block-start' => $zeroSize,
            'inline-end' => $zeroSize,
            'block-end' => $zeroSize,
            'inline-start' => $zeroSize,
        ]);

        return [
            'base' => Style_Definition::make()
                ->add_variant(
                    Style_Variant::make()
                        ->add_prop('padding', $spacingValue)
                        ->add_prop('margin', $spacingValue)
                ),
        ];
    }

    protected function define_atomic_controls(): array
    {
        return [
            Section::make()
                ->set_label(__('Content', 'thecore-elementor-widgets'))
                ->set_items([
                    Text_Control::bind_to('aria_label')
                        ->set_label(__('ARIA label', 'thecore-elementor-widgets'))
                        ->set_description(__('Used by screen readers on the breadcrumb navigation landmark.', 'thecore-elementor-widgets')),
                    Text_Control::bind_to('home_label')
                        ->set_label(__('Home label', 'thecore-elementor-widgets')),
                    Text_Control::bind_to('separator')
                        ->set_label(__('Separator', 'thecore-elementor-widgets')),
                    Switch_Control::bind_to('show_home')
                        ->set_label(__('Show home item', 'thecore-elementor-widgets')),
                    Switch_Control::bind_to('show_current')
                        ->set_label(__('Show current item', 'thecore-elementor-widgets')),
                ]),
            Section::make()
                ->set_label(__('Style', 'thecore-elementor-widgets'))
                ->set_items([
                    Select_Control::bind_to('alignment')
                        ->set_label(__('Alignment', 'thecore-elementor-widgets'))
                        ->set_options([
                            [
                                'label' => __('Start', 'thecore-elementor-widgets'),
                                'value' => 'flex-start',
                            ],
                            [
                                'label' => __('Center', 'thecore-elementor-widgets'),
                                'value' => 'center',
                            ],
                            [
                                'label' => __('End', 'thecore-elementor-widgets'),
                                'value' => 'flex-end',
                            ],
                        ]),
                    ColorControl::bind_to('text_color')
                        ->set_label(__('Link color', 'thecore-elementor-widgets')),
                    ColorControl::bind_to('current_color')
                        ->set_label(__('Current item color', 'thecore-elementor-widgets')),
                    ColorControl::bind_to('separator_color')
                        ->set_label(__('Separator color', 'thecore-elementor-widgets')),
                    FontFamilyControl::bind_to('font_family')
                        ->set_label(__('Font family', 'thecore-elementor-widgets')),
                    Size_Control::bind_to('font_size')
                        ->set_label(__('Font size', 'thecore-elementor-widgets'))
                        ->set_units(['px', 'em', 'rem'])
                        ->set_default_unit('px')
                        ->set_disable_custom(true),
                    Select_Control::bind_to('font_weight')
                        ->set_label(__('Link weight', 'thecore-elementor-widgets'))
                        ->set_options(self::fontWeightOptions()),
                    Select_Control::bind_to('current_font_weight')
                        ->set_label(__('Current item weight', 'thecore-elementor-widgets'))
                        ->set_options(self::fontWeightOptions()),
                    Size_Control::bind_to('line_height')
                        ->set_label(__('Line height', 'thecore-elementor-widgets'))
                        ->set_units(['em', 'px', 'rem'])
                        ->set_default_unit('em')
                        ->set_disable_custom(true),
                    ZeroDefaultSizeControl::bind_to('letter_spacing')
                        ->set_label(__('Letter spacing', 'thecore-elementor-widgets'))
                        ->set_units(['px', 'em', 'rem'])
                        ->set_default_unit('px')
                        ->set_disable_custom(true),
                    Select_Control::bind_to('text_transform')
                        ->set_label(__('Text transform', 'thecore-elementor-widgets'))
                        ->set_options(self::textTransformOptions()),
                    Number_Control::bind_to('gap')
                        ->set_label(__('Gap (px)', 'thecore-elementor-widgets'))
                        ->set_min(0)
                        ->set_max(48)
                        ->set_step(1)
                        ->set_should_force_int(true),
                ]),
            Section::make()
                ->set_label(__('Settings', 'thecore-elementor-widgets'))
                ->set_id('settings')
                ->set_items([
                    Text_Control::bind_to('_cssid')
                        ->set_label(__('ID', 'thecore-elementor-widgets'))
                        ->set_meta($this->get_css_id_control_meta()),
                ]),
        ];
    }

    protected function get_templates(): array
    {
        return [
            'thecore/elements/breadcrumb' => __DIR__ . '/breadcrumb.html.twig',
        ];
    }

    protected function render()
    {
        $atomicSettings = $this->get_atomic_settings();
        $settings = (new DisplaySettings())->normalize($atomicSettings);
        $items = (new TrailBuilder())->build(
            $settings['show_home'],
            $settings['show_current'],
            $settings['home_label']
        );
        $markup = (new MarkupBuilder())->build(
            $items,
            $settings['aria_label'],
            $settings['separator']
        );

        if ('' === $markup) {
            return;
        }

        $cssId = trim((string) $this->get_atomic_setting('_cssid'));
        $scope = $this->buildScopeValue();
        $scopeSelector = '[data-thecore-breadcrumb-scope="' . $scope . '"]';
        $styleMarkup = (new InlineStylesBuilder())->build($scopeSelector, $settings);
        $classes = array_filter(array_merge(
            ['thecore-breadcrumb', $this->get_base_styles_dictionary()['base'] ?? ''],
            is_array($atomicSettings['classes'] ?? null) ? $atomicSettings['classes'] : []
        ));
        $attributes = [
            'class' => implode(' ', array_unique($classes)),
            'data-thecore-breadcrumb' => 'true',
            'data-thecore-breadcrumb-scope' => $scope,
        ];

        if ('' !== $cssId) {
            $attributes['id'] = $cssId;
        }

        echo '<style>' . $styleMarkup . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo '<div' . $this->buildAttributes($attributes) . '>';
        echo $markup; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo '</div>';
    }

    /**
     * @return array<int, array{label: string, value: string}>
     */
    private static function fontWeightOptions(): array
    {
        return array_map(
            static fn(string $value): array => [
                'label' => $value,
                'value' => $value,
            ],
            self::fontWeightValues()
        );
    }

    /**
     * @return array<int, string>
     */
    private static function fontWeightValues(): array
    {
        return ['100', '200', '300', '400', '500', '600', '700', '800', '900'];
    }

    /**
     * @return array<int, array{label: string, value: string}>
     */
    private static function textTransformOptions(): array
    {
        return [
            [
                'label' => __('None', 'thecore-elementor-widgets'),
                'value' => 'none',
            ],
            [
                'label' => __('Uppercase', 'thecore-elementor-widgets'),
                'value' => 'uppercase',
            ],
            [
                'label' => __('Lowercase', 'thecore-elementor-widgets'),
                'value' => 'lowercase',
            ],
            [
                'label' => __('Capitalize', 'thecore-elementor-widgets'),
                'value' => 'capitalize',
            ],
        ];
    }

    /**
     * @return array<int, string>
     */
    private static function textTransformValues(): array
    {
        return ['none', 'uppercase', 'lowercase', 'capitalize'];
    }

    private function buildScopeValue(): string
    {
        return 'thecore-breadcrumb-' . sanitize_html_class($this->get_id());
    }

    /**
     * @param array<string, string> $attributes
     */
    private function buildAttributes(array $attributes): string
    {
        $markup = '';

        foreach ($attributes as $name => $value) {
            $markup .= sprintf(
                ' %s="%s"',
                esc_attr($name),
                esc_attr($value)
            );
        }

        return $markup;
    }
}
