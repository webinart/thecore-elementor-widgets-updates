<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\Breadcrumb;

final class MarkupBuilder
{
    /**
     * @param array<int, array{label: string, url: string, is_current: bool}> $items
     */
    public function build(array $items, string $ariaLabel, string $separator): string
    {
        if ([] === $items) {
            return $this->renderEmptyState(
                __('Le fil d’ariane s’affichera quand un contexte de page sera disponible.', 'thecore-elementor-widgets')
            );
        }

        $markup = sprintf(
            '<nav class="thecore-breadcrumb__nav" aria-label="%s"><ol class="thecore-breadcrumb__list">',
            esc_attr($ariaLabel)
        );

        foreach ($items as $index => $item) {
            $markup .= '<li class="thecore-breadcrumb__item">';

            if ($index > 0) {
                $markup .= sprintf(
                    '<span class="thecore-breadcrumb__separator" aria-hidden="true">%s</span>',
                    esc_html($separator)
                );
            }

            if ($item['is_current'] || '' === $item['url']) {
                $markup .= sprintf(
                    '<span class="thecore-breadcrumb__current" aria-current="page">%s</span>',
                    esc_html($item['label'])
                );
            } else {
                $markup .= sprintf(
                    '<a class="thecore-breadcrumb__link" href="%s">%s</a>',
                    esc_url($item['url']),
                    esc_html($item['label'])
                );
            }

            $markup .= '</li>';
        }

        $markup .= '</ol></nav>';

        return $markup;
    }

    private function renderEmptyState(string $message): string
    {
        if (! $this->isElementorEditingContext()) {
            return '';
        }

        return sprintf(
            '<div class="thecore-breadcrumb__empty">%s</div>',
            esc_html($message)
        );
    }

    private function isElementorEditingContext(): bool
    {
        if (! class_exists('\Elementor\Plugin')) {
            return false;
        }

        return \Elementor\Plugin::$instance->editor->is_edit_mode()
            || \Elementor\Plugin::$instance->preview->is_preview_mode();
    }
}
