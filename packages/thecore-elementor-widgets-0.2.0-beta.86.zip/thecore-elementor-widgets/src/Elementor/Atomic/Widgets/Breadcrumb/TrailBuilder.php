<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\Breadcrumb;

use WP_Post;
use WP_Post_Type;
use WP_Term;
use WP_Taxonomy;

final class TrailBuilder
{
    /**
     * @return array<int, array{label: string, url: string, is_current: bool}>
     */
    public function build(bool $showHome, bool $showCurrent, string $homeLabel): array
    {
        $items = [];

        if ($showHome) {
            $items[] = [
                'label' => $this->cleanLabel($homeLabel),
                'url' => home_url('/'),
                'is_current' => false,
            ];
        }

        if (is_front_page()) {
            if ([] === $items) {
                return [];
            }

            $items[count($items) - 1]['is_current'] = true;

            return $this->deduplicate($items);
        }

        if (is_home()) {
            if ($showCurrent) {
                $items[] = [
                    'label' => $this->getPostsPageLabel(),
                    'url' => $this->getPostsPageUrl(),
                    'is_current' => true,
                ];
            }

            return $this->deduplicate($items);
        }

        if (is_page()) {
            return $this->deduplicate($this->buildPageTrail($items, $showCurrent));
        }

        if (is_singular()) {
            return $this->deduplicate($this->buildSingularTrail($items, $showCurrent));
        }

        if (is_category() || is_tag() || is_tax()) {
            return $this->deduplicate($this->buildTaxonomyTrail($items, $showCurrent));
        }

        if (is_post_type_archive()) {
            return $this->deduplicate($this->buildPostTypeArchiveTrail($items, $showCurrent));
        }

        if (is_author()) {
            if ($showCurrent) {
                $author = get_queried_object();

                if ($author && isset($author->display_name)) {
                    $items[] = [
                        'label' => $this->cleanLabel((string) $author->display_name),
                        'url' => '',
                        'is_current' => true,
                    ];
                }
            }

            return $this->deduplicate($items);
        }

        if (is_search()) {
            if ($showCurrent) {
                $items[] = [
                    'label' => sprintf(
                        __('Résultats pour "%s"', 'thecore-elementor-widgets'),
                        $this->cleanLabel(get_search_query())
                    ),
                    'url' => '',
                    'is_current' => true,
                ];
            }

            return $this->deduplicate($items);
        }

        if (is_year()) {
            if ($showCurrent) {
                $items[] = [
                    'label' => (string) get_query_var('year'),
                    'url' => '',
                    'is_current' => true,
                ];
            }

            return $this->deduplicate($items);
        }

        if (is_month()) {
            $year = (int) get_query_var('year');

            if ($year > 0) {
                $items[] = [
                    'label' => (string) $year,
                    'url' => get_year_link($year),
                    'is_current' => false,
                ];
            }

            if ($showCurrent) {
                $items[] = [
                    'label' => single_month_title(' ', false),
                    'url' => '',
                    'is_current' => true,
                ];
            }

            return $this->deduplicate($items);
        }

        if (is_day()) {
            $year = (int) get_query_var('year');
            $month = (int) get_query_var('monthnum');
            $day = (int) get_query_var('day');

            if ($year > 0) {
                $items[] = [
                    'label' => (string) $year,
                    'url' => get_year_link($year),
                    'is_current' => false,
                ];
            }

            if ($year > 0 && $month > 0) {
                $items[] = [
                    'label' => wp_date('F', mktime(0, 0, 0, $month, 1, $year)),
                    'url' => get_month_link($year, $month),
                    'is_current' => false,
                ];
            }

            if ($showCurrent && $day > 0) {
                $items[] = [
                    'label' => (string) $day,
                    'url' => '',
                    'is_current' => true,
                ];
            }

            return $this->deduplicate($items);
        }

        if (is_404() && $showCurrent) {
            $items[] = [
                'label' => __('Page introuvable', 'thecore-elementor-widgets'),
                'url' => '',
                'is_current' => true,
            ];
        }

        return $this->deduplicate($items);
    }

    /**
     * @param array<int, array{label: string, url: string, is_current: bool}> $items
     * @return array<int, array{label: string, url: string, is_current: bool}>
     */
    private function buildPageTrail(array $items, bool $showCurrent): array
    {
        $post = get_queried_object();

        if (! $post instanceof WP_Post) {
            return $items;
        }

        $ancestors = array_reverse(array_map('intval', get_post_ancestors($post)));

        foreach ($ancestors as $ancestorId) {
            $label = $this->cleanLabel((string) get_the_title($ancestorId));
            $url = get_permalink($ancestorId);

            if ('' === $label || ! is_string($url) || '' === $url) {
                continue;
            }

            $items[] = [
                'label' => $label,
                'url' => $url,
                'is_current' => false,
            ];
        }

        if ($showCurrent) {
            $items[] = [
                'label' => $this->cleanLabel((string) get_the_title($post)),
                'url' => '',
                'is_current' => true,
            ];
        }

        return $items;
    }

    /**
     * @param array<int, array{label: string, url: string, is_current: bool}> $items
     * @return array<int, array{label: string, url: string, is_current: bool}>
     */
    private function buildSingularTrail(array $items, bool $showCurrent): array
    {
        $post = get_queried_object();

        if (! $post instanceof WP_Post) {
            return $items;
        }

        $postType = get_post_type($post);
        if (! is_string($postType) || '' === $postType) {
            return $items;
        }

        if ('post' === $postType) {
            $this->appendPostsPage($items);
        } else {
            $this->appendPostTypeArchive($items, $postType);
        }

        $term = $this->resolvePreferredTerm($post);
        if ($term instanceof WP_Term) {
            $this->appendTermAncestors($items, $term);
            $link = get_term_link($term);

            if (is_string($link) && '' !== $link) {
                $items[] = [
                    'label' => $this->cleanLabel($term->name),
                    'url' => $link,
                    'is_current' => false,
                ];
            }
        }

        if ($showCurrent) {
            $items[] = [
                'label' => $this->cleanLabel((string) get_the_title($post)),
                'url' => '',
                'is_current' => true,
            ];
        }

        return $items;
    }

    /**
     * @param array<int, array{label: string, url: string, is_current: bool}> $items
     * @return array<int, array{label: string, url: string, is_current: bool}>
     */
    private function buildTaxonomyTrail(array $items, bool $showCurrent): array
    {
        $term = get_queried_object();

        if (! $term instanceof WP_Term) {
            return $items;
        }

        $taxonomy = get_taxonomy($term->taxonomy);
        if (! $taxonomy instanceof WP_Taxonomy) {
            return $items;
        }

        if (in_array($term->taxonomy, ['category', 'post_tag'], true)) {
            $this->appendPostsPage($items);
        } else {
            $this->appendPrimaryArchiveForTaxonomy($items, $taxonomy);
        }

        $this->appendTermAncestors($items, $term);

        if ($showCurrent) {
            $items[] = [
                'label' => $this->cleanLabel($term->name),
                'url' => '',
                'is_current' => true,
            ];
        }

        return $items;
    }

    /**
     * @param array<int, array{label: string, url: string, is_current: bool}> $items
     * @return array<int, array{label: string, url: string, is_current: bool}>
     */
    private function buildPostTypeArchiveTrail(array $items, bool $showCurrent): array
    {
        $postType = get_query_var('post_type');
        $postType = is_array($postType) ? reset($postType) : $postType;

        if (! is_string($postType) || '' === $postType) {
            return $items;
        }

        if ($showCurrent) {
            $object = get_post_type_object($postType);

            if ($object instanceof WP_Post_Type) {
                $items[] = [
                    'label' => $this->cleanLabel((string) $object->labels->name),
                    'url' => '',
                    'is_current' => true,
                ];
            }
        }

        return $items;
    }

    /**
     * @param array<int, array{label: string, url: string, is_current: bool}> $items
     */
    private function appendPostsPage(array &$items): void
    {
        $pageForPosts = (int) get_option('page_for_posts');
        if ($pageForPosts <= 0) {
            return;
        }

        $url = get_permalink($pageForPosts);
        if (! is_string($url) || '' === $url) {
            return;
        }

        $items[] = [
            'label' => $this->cleanLabel((string) get_the_title($pageForPosts)),
            'url' => $url,
            'is_current' => false,
        ];
    }

    /**
     * @param array<int, array{label: string, url: string, is_current: bool}> $items
     */
    private function appendPostTypeArchive(array &$items, string $postType): void
    {
        $object = get_post_type_object($postType);
        if (! $object instanceof WP_Post_Type || ! $object->has_archive) {
            return;
        }

        $url = get_post_type_archive_link($postType);
        if (! is_string($url) || '' === $url) {
            return;
        }

        $items[] = [
            'label' => $this->cleanLabel((string) $object->labels->name),
            'url' => $url,
            'is_current' => false,
        ];
    }

    /**
     * @param array<int, array{label: string, url: string, is_current: bool}> $items
     */
    private function appendPrimaryArchiveForTaxonomy(array &$items, WP_Taxonomy $taxonomy): void
    {
        foreach ($taxonomy->object_type as $postType) {
            if (! is_string($postType) || '' === $postType || 'attachment' === $postType) {
                continue;
            }

            $object = get_post_type_object($postType);
            if (! $object instanceof WP_Post_Type || ! $object->public || ! $object->has_archive) {
                continue;
            }

            $url = get_post_type_archive_link($postType);
            if (! is_string($url) || '' === $url) {
                continue;
            }

            $items[] = [
                'label' => $this->cleanLabel((string) $object->labels->name),
                'url' => $url,
                'is_current' => false,
            ];

            return;
        }
    }

    /**
     * @param array<int, array{label: string, url: string, is_current: bool}> $items
     */
    private function appendTermAncestors(array &$items, WP_Term $term): void
    {
        if ($term->parent <= 0) {
            return;
        }

        $ancestors = array_reverse(get_ancestors($term->term_id, $term->taxonomy, 'taxonomy'));

        foreach ($ancestors as $ancestorId) {
            $ancestor = get_term((int) $ancestorId, $term->taxonomy);
            if (! $ancestor instanceof WP_Term) {
                continue;
            }

            $url = get_term_link($ancestor);
            if (! is_string($url) || '' === $url) {
                continue;
            }

            $items[] = [
                'label' => $this->cleanLabel($ancestor->name),
                'url' => $url,
                'is_current' => false,
            ];
        }
    }

    private function resolvePreferredTerm(WP_Post $post): ?WP_Term
    {
        $postType = get_post_type($post);
        if (! is_string($postType) || '' === $postType) {
            return null;
        }

        if ('post' === $postType) {
            $terms = get_the_category($post->ID);

            if (is_array($terms) && [] !== $terms) {
                return $this->selectPreferredTerm($terms);
            }
        }

        $taxonomies = get_object_taxonomies($postType, 'objects');
        if (! is_array($taxonomies)) {
            return null;
        }

        foreach ($taxonomies as $taxonomy) {
            if (! $taxonomy instanceof WP_Taxonomy || ! $taxonomy->public || ! $taxonomy->hierarchical || 'post_format' === $taxonomy->name) {
                continue;
            }

            $terms = wp_get_post_terms($post->ID, $taxonomy->name);
            if (is_wp_error($terms) || ! is_array($terms) || [] === $terms) {
                continue;
            }

            $selected = $this->selectPreferredTerm($terms);
            if ($selected instanceof WP_Term) {
                return $selected;
            }
        }

        return null;
    }

    /**
     * @param array<int, WP_Term> $terms
     */
    private function selectPreferredTerm(array $terms): ?WP_Term
    {
        usort(
            $terms,
            fn (WP_Term $left, WP_Term $right): int => $this->termDepth($right) <=> $this->termDepth($left)
        );

        return $terms[0] ?? null;
    }

    private function termDepth(WP_Term $term): int
    {
        return count(get_ancestors($term->term_id, $term->taxonomy, 'taxonomy'));
    }

    private function getPostsPageLabel(): string
    {
        $pageForPosts = (int) get_option('page_for_posts');

        if ($pageForPosts > 0) {
            return $this->cleanLabel((string) get_the_title($pageForPosts));
        }

        return __('Blog', 'thecore-elementor-widgets');
    }

    private function getPostsPageUrl(): string
    {
        $pageForPosts = (int) get_option('page_for_posts');

        if ($pageForPosts > 0) {
            $url = get_permalink($pageForPosts);

            return is_string($url) ? $url : '';
        }

        return '';
    }

    /**
     * @param array<int, array{label: string, url: string, is_current: bool}> $items
     * @return array<int, array{label: string, url: string, is_current: bool}>
     */
    private function deduplicate(array $items): array
    {
        $normalized = [];
        $seen = [];

        foreach ($items as $item) {
            $label = $this->cleanLabel($item['label']);
            $url = is_string($item['url']) ? $item['url'] : '';

            if ('' === $label) {
                continue;
            }

            $key = $label . '|' . $url . '|' . ($item['is_current'] ? '1' : '0');
            if (isset($seen[$key])) {
                continue;
            }

            $seen[$key] = true;
            $normalized[] = [
                'label' => $label,
                'url' => $url,
                'is_current' => (bool) $item['is_current'],
            ];
        }

        return $normalized;
    }

    private function cleanLabel(string $value): string
    {
        return trim(wp_strip_all_tags($value, true));
    }
}
