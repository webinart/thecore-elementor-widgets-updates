<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\Breadcrumb;

final class DisplaySettings
{
    public const DEFAULT_ARIA_LABEL = 'Fil d’ariane';
    public const DEFAULT_HOME_LABEL = 'Accueil';
    public const DEFAULT_SEPARATOR = '/';
    public const DEFAULT_SHOW_HOME = true;
    public const DEFAULT_SHOW_CURRENT = true;
    public const DEFAULT_ALIGNMENT = 'flex-start';
    public const DEFAULT_TEXT_COLOR = '#5F6368';
    public const DEFAULT_CURRENT_COLOR = '#111111';
    public const DEFAULT_SEPARATOR_COLOR = '#8A8F98';
    public const DEFAULT_FONT_FAMILY = 'inherit';
    public const DEFAULT_FONT_SIZE = [
        'size' => 14.0,
        'unit' => 'px',
    ];
    public const DEFAULT_FONT_WEIGHT = '500';
    public const DEFAULT_CURRENT_FONT_WEIGHT = '700';
    public const DEFAULT_LINE_HEIGHT = [
        'size' => 1.4,
        'unit' => 'em',
    ];
    public const DEFAULT_LETTER_SPACING = [
        'size' => 0.0,
        'unit' => 'px',
    ];
    public const DEFAULT_TEXT_TRANSFORM = 'none';
    public const DEFAULT_GAP = 10;

    /**
     * @param array<string, mixed> $settings
     *
     * @return array{
     *     aria_label: string,
     *     home_label: string,
     *     separator: string,
     *     show_home: bool,
     *     show_current: bool,
     *     alignment: string,
     *     text_color: string,
     *     current_color: string,
     *     separator_color: string,
     *     font_family: string,
     *     font_size: array{size: float, unit: string},
     *     font_weight: string,
     *     current_font_weight: string,
     *     line_height: array{size: float, unit: string},
     *     letter_spacing: array{size: float, unit: string},
     *     text_transform: string,
     *     gap: int
     * }
     */
    public function normalize(array $settings): array
    {
        return [
            'aria_label' => $this->sanitizeText($settings['aria_label'] ?? self::DEFAULT_ARIA_LABEL, self::DEFAULT_ARIA_LABEL),
            'home_label' => $this->sanitizeText($settings['home_label'] ?? self::DEFAULT_HOME_LABEL, self::DEFAULT_HOME_LABEL),
            'separator' => $this->sanitizeText($settings['separator'] ?? self::DEFAULT_SEPARATOR, self::DEFAULT_SEPARATOR),
            'show_home' => $this->sanitizeBoolean($settings['show_home'] ?? self::DEFAULT_SHOW_HOME),
            'show_current' => $this->sanitizeBoolean($settings['show_current'] ?? self::DEFAULT_SHOW_CURRENT),
            'alignment' => $this->sanitizeEnum(
                $settings['alignment'] ?? self::DEFAULT_ALIGNMENT,
                ['flex-start', 'center', 'flex-end'],
                self::DEFAULT_ALIGNMENT
            ),
            'text_color' => $this->sanitizeColor(
                $settings['text_color'] ?? self::DEFAULT_TEXT_COLOR,
                self::DEFAULT_TEXT_COLOR
            ),
            'current_color' => $this->sanitizeColor(
                $settings['current_color'] ?? self::DEFAULT_CURRENT_COLOR,
                self::DEFAULT_CURRENT_COLOR
            ),
            'separator_color' => $this->sanitizeColor(
                $settings['separator_color'] ?? self::DEFAULT_SEPARATOR_COLOR,
                self::DEFAULT_SEPARATOR_COLOR
            ),
            'font_family' => $this->sanitizeFontFamily(
                $settings['font_family'] ?? self::DEFAULT_FONT_FAMILY,
                self::DEFAULT_FONT_FAMILY
            ),
            'font_size' => $this->sanitizeSize(
                $settings['font_size'] ?? self::DEFAULT_FONT_SIZE,
                self::DEFAULT_FONT_SIZE,
                ['px', 'em', 'rem'],
                8.0,
                120.0
            ),
            'font_weight' => $this->sanitizeEnum(
                $settings['font_weight'] ?? self::DEFAULT_FONT_WEIGHT,
                ['100', '200', '300', '400', '500', '600', '700', '800', '900'],
                self::DEFAULT_FONT_WEIGHT
            ),
            'current_font_weight' => $this->sanitizeEnum(
                $settings['current_font_weight'] ?? self::DEFAULT_CURRENT_FONT_WEIGHT,
                ['100', '200', '300', '400', '500', '600', '700', '800', '900'],
                self::DEFAULT_CURRENT_FONT_WEIGHT
            ),
            'line_height' => $this->sanitizeSize(
                $settings['line_height'] ?? self::DEFAULT_LINE_HEIGHT,
                self::DEFAULT_LINE_HEIGHT,
                ['px', 'em', 'rem'],
                0.5,
                4.0
            ),
            'letter_spacing' => $this->sanitizeSize(
                $settings['letter_spacing'] ?? self::DEFAULT_LETTER_SPACING,
                self::DEFAULT_LETTER_SPACING,
                ['px', 'em', 'rem'],
                -20.0,
                20.0
            ),
            'text_transform' => $this->sanitizeEnum(
                $settings['text_transform'] ?? self::DEFAULT_TEXT_TRANSFORM,
                ['none', 'uppercase', 'lowercase', 'capitalize'],
                self::DEFAULT_TEXT_TRANSFORM
            ),
            'gap' => $this->clampInt(
                $settings['gap'] ?? self::DEFAULT_GAP,
                0,
                48,
                self::DEFAULT_GAP
            ),
        ];
    }

    private function sanitizeText(mixed $value, string $default): string
    {
        if (! is_string($value)) {
            return $default;
        }

        $normalized = sanitize_text_field($value);

        return '' !== $normalized ? $normalized : $default;
    }

    private function sanitizeBoolean(mixed $value): bool
    {
        if (is_bool($value)) {
            return $value;
        }

        if (is_numeric($value)) {
            return (bool) ((int) $value);
        }

        if (is_string($value)) {
            return in_array(strtolower($value), ['1', 'true', 'yes', 'on'], true);
        }

        return false;
    }

    private function clampInt(mixed $value, int $min, int $max, int $default): int
    {
        if (! is_numeric($value)) {
            return $default;
        }

        return max($min, min($max, (int) $value));
    }

    private function sanitizeColor(mixed $value, string $default): string
    {
        if (! is_string($value)) {
            return $default;
        }

        $normalized = trim($value);

        if ('' === $normalized) {
            return $default;
        }

        if (1 === preg_match('/^#(?:[0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/', $normalized)) {
            return $normalized;
        }

        if (1 === preg_match('/^(?:rgb|rgba|hsl|hsla)\([0-9.,%\s\/-]+\)$/i', $normalized)) {
            return $normalized;
        }

        if (1 === preg_match('/^var\(--[a-zA-Z0-9_-]+\)$/', $normalized)) {
            return $normalized;
        }

        if (in_array(strtolower($normalized), ['transparent', 'currentcolor', 'inherit'], true)) {
            return $normalized;
        }

        return $default;
    }

    private function sanitizeFontFamily(mixed $value, string $default): string
    {
        if (! is_string($value)) {
            return $default;
        }

        $normalized = trim(str_replace([';', '{', '}', '<', '>'], '', $value));

        return '' !== $normalized ? $normalized : $default;
    }

    /**
     * @param array<int, string> $allowed
     */
    private function sanitizeEnum(mixed $value, array $allowed, string $default): string
    {
        if (! is_string($value)) {
            return $default;
        }

        $normalized = trim($value);

        return in_array($normalized, $allowed, true) ? $normalized : $default;
    }

    /**
     * @param array{size: float|int, unit: string} $default
     * @param array<int, string>                   $allowedUnits
     *
     * @return array{size: float, unit: string}
     */
    private function sanitizeSize(mixed $value, array $default, array $allowedUnits, float $min, float $max): array
    {
        if (! is_array($value)) {
            return [
                'size' => (float) $default['size'],
                'unit' => $default['unit'],
            ];
        }

        $size = $value['size'] ?? $default['size'];
        $unit = $value['unit'] ?? $default['unit'];

        if (! is_numeric($size) || ! is_string($unit) || ! in_array($unit, $allowedUnits, true)) {
            return [
                'size' => (float) $default['size'],
                'unit' => $default['unit'],
            ];
        }

        $normalizedSize = (float) $size;

        if ($normalizedSize < $min || $normalizedSize > $max) {
            return [
                'size' => (float) $default['size'],
                'unit' => $default['unit'],
            ];
        }

        return [
            'size' => $normalizedSize,
            'unit' => $unit,
        ];
    }
}
