<?php

declare(strict_types=1);

if (! defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

require_once __DIR__ . '/src/Infrastructure/Autoloader.php';

(new \TheCore\ElementorWidgets\Infrastructure\Autoloader())->register();

$purged = (new \TheCore\ElementorWidgets\FormSecurity\Infrastructure\BlockedSubmissionDataPurger())
    ->purgeForUninstall();

if (! $purged) {
    wp_die(
        esc_html__(
            'La table temporaire des soumissions bloquées n’a pas pu être supprimée. La désinstallation est interrompue afin de ne pas laisser de données personnelles orphelines.',
            'thecore-elementor-widgets'
        )
    );
}
