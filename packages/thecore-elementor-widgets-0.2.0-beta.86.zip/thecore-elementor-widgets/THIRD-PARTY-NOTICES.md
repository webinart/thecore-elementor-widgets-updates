# Third-party notices

## ALTCHA widget

The browser widget and PBKDF2 worker files in `assets/vendor/altcha/` are based
on `altcha-org/altcha` version 3.2.1.

`altcha.external.classic.min.js` contains the upstream external ESM artifact
wrapped in a strict IIFE so that WordPress can load it through its classic
script dependency API without exposing the artifact's lexical bindings to
Underscore, Backbone or other page scripts. The upstream artifact itself is
otherwise unchanged.

Copyright (c) 2023-2026 Daniel Regeci, BAU Software s.r.o.

Distributed under the MIT License reproduced in
`assets/vendor/altcha/LICENSE.txt`.

## ALTCHA PHP

The private PBKDF2/SHA-256 protocol subset in
`src/FormSecurity/Security/Altcha/` is derived from `altcha-org/altcha`
version 2.1.0.

Copyright (c) 2023 Daniel Regeci

MIT License

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
