/* ------------------------------------------------------------
   TChat – widget visiteur
------------------------------------------------------------ */
(() => {
    if (!window.TCHAT_SETTINGS) {
        return;
    }

    if (
        window.thecoreElementorWidgetsTChat
        && typeof window.thecoreElementorWidgetsTChat.refresh === 'function'
    ) {
        window.thecoreElementorWidgetsTChat.refresh();
        return;
    }

    const createFallbackUUID = () => `tchat-${Date.now()}-${Math.random().toString(16).slice(2)}`;
    const OPEN_HASH = '#thecore-tchat-open';
    const TOGGLE_HASH = '#thecore-tchat-toggle';

    const safeStorageGet = (key) => {
        try {
            return window.localStorage.getItem(key);
        } catch (error) {
            return null;
        }
    };

    const safeStorageSet = (key, value) => {
        try {
            window.localStorage.setItem(key, value);
        } catch (error) {
            // ignore storage write failures
        }
    };

    const getVisitorUUID = () => {
        const key = 'tchat_uuid';
        const cookieMatch = document.cookie.match(/(?:^|;\s*)tchat_uuid=([^;]+)/);
        let uuid = cookieMatch ? cookieMatch[1] : safeStorageGet(key);

        if (!uuid) {
            uuid = typeof crypto !== 'undefined' && crypto.randomUUID
                ? crypto.randomUUID()
                : createFallbackUUID();
            document.cookie = `tchat_uuid=${uuid}; path=/; max-age=${3600 * 24 * 365}`;
            safeStorageSet(key, uuid);
        }

        return uuid;
    };

    const visitorUUID = getVisitorUUID();
    const settings = window.TCHAT_SETTINGS;
    const transport = settings.transport || {};
    const pollingCfg = transport.polling || {};
    const getTriggers = () => Array.from(document.querySelectorAll('[data-thecore-tchat-trigger]'));
    const apiUrl = (path) => {
        const base = String(settings.restUrl || '').replace(/\/+$/, '');
        const normalizedPath = String(path || '').replace(/^\/+/, '');

        return `${base}/${normalizedPath}`;
    };

    let module = null;
    let dialog = null;
    let backdrop = null;
    let log = null;
    let input = null;
    let convId = null;
    let lastTS = '1970-01-01 00:00:00';
    let pollTimer = null;
    let eventSource = null;
    let bootstrapping = false;
    let transportInitialized = false;
    let refreshScheduled = false;

    const currentMode = () => (transport.mode || 'polling');
    const openInterval = Number(pollingCfg.visitorOpenMs || 3000);
    const idleInterval = Number(pollingCfg.visitorIdleMs || 10000);

    const cacheElements = () => {
        const nextModule = document.querySelector('[data-thecore-tchat-module]');
        const changed = nextModule !== module;

        module = nextModule;
        dialog = module ? module.querySelector('.thecore-tchat-module__dialog') : null;
        backdrop = module ? module.querySelector('.thecore-tchat-module__backdrop') : null;
        log = module ? module.querySelector('.thecore-tchat-module__log') : null;
        input = module ? module.querySelector('.thecore-tchat-module__input') : null;

        return changed;
    };

    const hasUsableModule = () => !!(module && dialog && backdrop && log && input);

    const isOpen = () => !!(module && module.classList.contains('is-open'));

    const syncTriggers = (open) => {
        getTriggers().forEach((trigger) => {
            trigger.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
    };

    const appendMsg = (message) => {
        if (!message || typeof message.content !== 'string' || message.content === '') {
            return;
        }

        lastTS = message.created_at || lastTS;

        const row = document.createElement('p');
        row.className = `thecore-tchat-module__message ${message.sender_type === 'agent' ? 'is-in' : 'is-out'}`;
        row.textContent = message.content;
        if (!log) {
            return;
        }
        log.appendChild(row);
        row.scrollIntoView({ behavior: 'smooth', block: 'end' });
    };

    const clearPolling = () => {
        if (!pollTimer) {
            return;
        }

        window.clearTimeout(pollTimer);
        pollTimer = null;
    };

    const schedulePoll = (delay) => {
        clearPolling();
        pollTimer = window.setTimeout(runPoll, delay);
    };

    const buildAjaxPayload = (since) => new URLSearchParams({
        action: 'tchat_poll',
        nonce: settings.nonce,
        conversation_id: String(convId),
        visitor_uuid: visitorUUID,
        since,
    });

    const setOpen = (open) => {
        if (!hasUsableModule()) {
            return false;
        }

        module.classList.toggle('is-open', open);
        dialog.setAttribute('aria-hidden', open ? 'false' : 'true');
        backdrop.setAttribute('aria-hidden', open ? 'false' : 'true');
        syncTriggers(open);

        if (open && input) {
            input.focus();
        }

        if (currentMode() === 'polling') {
            schedulePoll(0);
        }

        return true;
    };

    const clearHash = () => {
        if (!window.location.hash || !window.history || typeof window.history.replaceState !== 'function') {
            return;
        }

        window.history.replaceState(null, document.title, window.location.pathname + window.location.search);
    };

    const handleHashAction = () => {
        if (window.location.hash === OPEN_HASH) {
            if (setOpen(true)) {
                clearHash();
            }
            return;
        }

        if (window.location.hash === TOGGLE_HASH) {
            if (setOpen(!isOpen())) {
                clearHash();
            }
        }
    };

    const loadHistory = async() => {
        if (!convId || !log) {
            return;
        }

        const response = await fetch(settings.ajaxUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: buildAjaxPayload('1970-01-01 00:00:00'),
        });
        const payload = await response.json();
        if (!payload || !payload.success || !Array.isArray(payload.data)) {
            return;
        }

        log.innerHTML = '';
        payload.data.forEach(appendMsg);
    };

    const handleRealtimeMessage = (message) => {
        if (!message || Number(message.conversation_id) !== Number(convId)) {
            return;
        }

        if (message.sender_type === 'visitor' && message.visitor_uuid === visitorUUID) {
            return;
        }

        appendMsg(message);
    };

    const runPoll = async() => {
        if (!convId) {
            return;
        }

        try {
            const response = await fetch(settings.ajaxUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: buildAjaxPayload(lastTS),
            });
            const payload = await response.json();
            if (payload && payload.success && Array.isArray(payload.data)) {
                payload.data.forEach((message) => {
                    if (message.sender_type === 'visitor' && message.visitor_uuid === visitorUUID) {
                        return;
                    }

                    appendMsg(message);
                });
            }
        } finally {
            schedulePoll(isOpen() ? openInterval : idleInterval);
        }
    };

    const stopRealtime = () => {
        if (!eventSource) {
            return;
        }

        eventSource.close();
        eventSource = null;
    };

    const startSse = () => {
        if (typeof window.EventSource !== 'function' || !transport.sseEventsUrl) {
            return false;
        }

        const url = new URL(transport.sseEventsUrl, window.location.href);
        url.searchParams.set('conversation_id', String(convId));
        url.searchParams.set('visitor_uuid', visitorUUID);

        stopRealtime();

        const source = new window.EventSource(url.toString());
        source.addEventListener('message', (event) => {
            try {
                handleRealtimeMessage(JSON.parse(event.data));
            } catch (error) {
                console.warn('TChat SSE parse error', error);
            }
        });
        source.onerror = () => {
            stopRealtime();
            if (currentMode() === 'auto') {
                schedulePoll(0);
            }
        };

        eventSource = source;
        return true;
    };

    const initTransport = () => {
        if (transportInitialized) {
            return;
        }

        transportInitialized = true;
        const mode = currentMode();
        if ((mode === 'sse' || mode === 'auto') && startSse()) {
            return;
        }

        schedulePoll(0);
    };

    const bootstrapConversation = async() => {
        if (bootstrapping || convId || !hasUsableModule()) {
            if (convId) {
                handleHashAction();
            }
            return;
        }

        bootstrapping = true;

        try {
            const response = await fetch(apiUrl('conversations'), {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    ...(settings.restNonce ? { 'X-WP-Nonce': settings.restNonce } : {}),
                },
                body: JSON.stringify({ uuid: visitorUUID }),
            });
            const payload = await response.json();
            convId = Number(payload.id || 0);

            if (!convId) {
                return;
            }

            await loadHistory();
            initTransport();
            handleHashAction();
        } catch (error) {
            console.error('TChat conversation bootstrap error', error);
        } finally {
            bootstrapping = false;
        }
    };

    const handleSendKeydown = async(event) => {
        if (event.key !== 'Enter') {
            return;
        }

        if (!input || event.target !== input) {
            return;
        }

        const content = input.value.trim();
        if (!content || !convId) {
            return;
        }

        input.disabled = true;

        try {
            const response = await fetch(apiUrl('persist'), {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    conversation_id: convId,
                    visitor_uuid: visitorUUID,
                    sender_type: 'visitor',
                    content,
                }),
            });
            const payload = await response.json();
            if (payload && payload.message) {
                appendMsg(payload.message);
            }
            input.value = '';
        } catch (error) {
            console.error('TChat visitor send error', error);
        } finally {
            input.disabled = false;
            input.focus();
        }
    };

    const handleDocumentClick = (event) => {
        const trigger = event.target.closest('[data-thecore-tchat-trigger]');
        if (trigger) {
            event.preventDefault();
            cacheElements();
            setOpen(!isOpen());
            return;
        }

        const closeTarget = event.target.closest('[data-thecore-tchat-close]');
        if (closeTarget && module && module.contains(closeTarget)) {
            event.preventDefault();
            setOpen(false);
        }
    };

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && isOpen()) {
            setOpen(false);
        }

        handleSendKeydown(event);
    });

    document.addEventListener('click', handleDocumentClick);
    window.addEventListener('hashchange', handleHashAction);

    const refresh = () => {
        const changed = cacheElements();
        syncTriggers(isOpen());
        handleHashAction();

        if (!hasUsableModule()) {
            return;
        }

        if (convId === null) {
            bootstrapConversation();
            return;
        }

        if (changed) {
            loadHistory();
        }
    };

    const scheduleRefresh = () => {
        if (refreshScheduled) {
            return;
        }

        refreshScheduled = true;
        window.requestAnimationFrame(() => {
            refreshScheduled = false;
            refresh();
        });
    };

    if (typeof window.MutationObserver === 'function' && document.body) {
        const observer = new window.MutationObserver(() => {
            scheduleRefresh();
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true,
        });
    }

    refresh();

    window.thecoreElementorWidgetsTChat = {
        refresh,
        open() {
            refresh();
            setOpen(true);
        },
        close() {
            refresh();
            setOpen(false);
        },
    };
})();
