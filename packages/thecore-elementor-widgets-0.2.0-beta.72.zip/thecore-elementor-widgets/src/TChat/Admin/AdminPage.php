<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\TChat\Admin;

use TheCore\ElementorWidgets\TChat\Support\ModuleSettings;

final class AdminPage
{
    private const MENU_SLUG = 'tchat';
    private const SETTINGS_SLUG = 'tchat-settings';
    private const TOOLS_SLUG = 'tchat-tools';
    private const DELETE_ACTION = 'tchat_delete_all_conversations';

    public static function register(): void
    {
        add_action('admin_menu', [self::class, 'menu']);
        add_action('admin_enqueue_scripts', [self::class, 'assets']);
        add_action('admin_init', [ModuleSettings::class, 'register']);
        add_action('admin_post_' . self::DELETE_ACTION, [self::class, 'handleDeleteAllConversations']);
    }

    public static function menu(): void
    {
        add_menu_page(
            'TChat Conversations',
            'TChat',
            'edit_posts',
            self::MENU_SLUG,
            [self::class, 'renderChat'],
            'dashicons-format-chat',
            55
        );

        add_submenu_page(
            self::MENU_SLUG,
            'Conversations',
            'Conversations',
            'edit_posts',
            self::MENU_SLUG,
            [self::class, 'renderChat']
        );

        add_submenu_page(
            self::MENU_SLUG,
            'TChat Settings',
            'Settings',
            'manage_options',
            self::SETTINGS_SLUG,
            [self::class, 'renderSettings']
        );

        add_submenu_page(
            self::MENU_SLUG,
            'TChat Tools',
            'Tools',
            'manage_options',
            self::TOOLS_SLUG,
            [self::class, 'renderTools']
        );
    }

    public static function renderChat(): void
    {
        echo '<div id="tchat-admin-root"></div>';
    }

    public static function renderSettings(): void
    {
        $settings = ModuleSettings::get();
        ?>
        <div class="wrap">
            <h1>TChat Settings</h1>
            <form action="options.php" method="post">
                <?php settings_fields('tchat_module_settings_group'); ?>
                <table class="form-table" role="presentation">
                    <tbody>
                    <tr>
                        <th scope="row"><label for="tchat-transport-mode">Transport mode</label></th>
                        <td>
                            <select id="tchat-transport-mode" name="<?php echo esc_attr(ModuleSettings::OPTION_KEY); ?>[transport_mode]">
                                <option value="polling" <?php selected($settings['transport_mode'], 'polling'); ?>>Polling only</option>
                                <option value="sse" <?php selected($settings['transport_mode'], 'sse'); ?>>SSE only</option>
                                <option value="auto" <?php selected($settings['transport_mode'], 'auto'); ?>>Auto (prefer SSE, fallback polling)</option>
                            </select>
                            <p class="description">Polling fonctionne partout. SSE et Auto nécessitent un endpoint d’événements et un endpoint de diffusion.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="tchat-sse-events-url">SSE events URL</label></th>
                        <td>
                            <input id="tchat-sse-events-url" class="regular-text code" type="url" name="<?php echo esc_attr(ModuleSettings::OPTION_KEY); ?>[sse_events_url]" value="<?php echo esc_attr((string) $settings['sse_events_url']); ?>" placeholder="https://tchat.example.com/sse">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="tchat-sse-send-url">SSE send URL</label></th>
                        <td>
                            <input id="tchat-sse-send-url" class="regular-text code" type="url" name="<?php echo esc_attr(ModuleSettings::OPTION_KEY); ?>[sse_send_url]" value="<?php echo esc_attr((string) $settings['sse_send_url']); ?>" placeholder="https://tchat.example.com/send">
                            <p class="description">Le plugin persiste toujours les messages dans WordPress, puis relaie l’événement vers cet endpoint si le transport temps réel est actif.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="tchat-visitor-poll-open-ms">Visitor poll interval (open)</label></th>
                        <td>
                            <input id="tchat-visitor-poll-open-ms" class="small-text" type="number" min="250" step="250" name="<?php echo esc_attr(ModuleSettings::OPTION_KEY); ?>[visitor_poll_open_ms]" value="<?php echo esc_attr((string) $settings['visitor_poll_open_ms']); ?>"> ms
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="tchat-visitor-poll-idle-ms">Visitor poll interval (closed)</label></th>
                        <td>
                            <input id="tchat-visitor-poll-idle-ms" class="small-text" type="number" min="250" step="250" name="<?php echo esc_attr(ModuleSettings::OPTION_KEY); ?>[visitor_poll_idle_ms]" value="<?php echo esc_attr((string) $settings['visitor_poll_idle_ms']); ?>"> ms
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="tchat-admin-poll-list-ms">Admin poll interval (list)</label></th>
                        <td>
                            <input id="tchat-admin-poll-list-ms" class="small-text" type="number" min="250" step="250" name="<?php echo esc_attr(ModuleSettings::OPTION_KEY); ?>[admin_poll_list_ms]" value="<?php echo esc_attr((string) $settings['admin_poll_list_ms']); ?>"> ms
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="tchat-admin-poll-conversation-ms">Admin poll interval (conversation)</label></th>
                        <td>
                            <input id="tchat-admin-poll-conversation-ms" class="small-text" type="number" min="250" step="250" name="<?php echo esc_attr(ModuleSettings::OPTION_KEY); ?>[admin_poll_conversation_ms]" value="<?php echo esc_attr((string) $settings['admin_poll_conversation_ms']); ?>"> ms
                        </td>
                    </tr>
                    </tbody>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    public static function renderTools(): void
    {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('You are not allowed to access this page.', 'thecore-elementor-widgets'));
        }

        global $wpdb;

        $conversationCount = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}tchat_conversations");
        $messageCount = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}tchat_messages");
        $status = isset($_GET['tchat_tools_status']) ? sanitize_key((string) $_GET['tchat_tools_status']) : '';
        $deletedConversations = isset($_GET['deleted_conversations']) ? max(0, (int) $_GET['deleted_conversations']) : 0;
        $deletedMessages = isset($_GET['deleted_messages']) ? max(0, (int) $_GET['deleted_messages']) : 0;
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('TChat Tools', 'thecore-elementor-widgets'); ?></h1>
            <?php self::renderToolsNotice($status, $deletedConversations, $deletedMessages); ?>

            <div class="card" style="max-width: 880px;">
                <h2><?php esc_html_e('Delete all conversations', 'thecore-elementor-widgets'); ?></h2>
                <p>
                    <?php esc_html_e('This tool permanently deletes every TChat conversation and message stored in WordPress.', 'thecore-elementor-widgets'); ?>
                </p>
                <ul style="list-style: disc; padding-left: 18px;">
                    <li>
                        <?php
                        echo esc_html(
                            sprintf(
                                /* translators: %d: number of conversations. */
                                __('Current conversations: %d', 'thecore-elementor-widgets'),
                                $conversationCount
                            )
                        );
                        ?>
                    </li>
                    <li>
                        <?php
                        echo esc_html(
                            sprintf(
                                /* translators: %d: number of messages. */
                                __('Current messages: %d', 'thecore-elementor-widgets'),
                                $messageCount
                            )
                        );
                        ?>
                    </li>
                </ul>

                <form
                    method="post"
                    action="<?php echo esc_url(admin_url('admin-post.php')); ?>"
                    id="tchat-delete-all-form"
                >
                    <input type="hidden" name="action" value="<?php echo esc_attr(self::DELETE_ACTION); ?>">
                    <?php wp_nonce_field(self::DELETE_ACTION); ?>

                    <table class="form-table" role="presentation">
                        <tbody>
                        <tr>
                            <th scope="row">
                                <label for="tchat-delete-confirm-text"><?php esc_html_e('Confirmation text', 'thecore-elementor-widgets'); ?></label>
                            </th>
                            <td>
                                <input
                                    id="tchat-delete-confirm-text"
                                    name="confirm_text"
                                    type="text"
                                    class="regular-text"
                                    autocomplete="off"
                                    spellcheck="false"
                                    placeholder="SUPPRIMER"
                                    required
                                >
                                <p class="description">
                                    <?php esc_html_e('Type SUPPRIMER to unlock the deletion.', 'thecore-elementor-widgets'); ?>
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Acknowledgement', 'thecore-elementor-widgets'); ?></th>
                            <td>
                                <label for="tchat-delete-confirm-checkbox">
                                    <input
                                        id="tchat-delete-confirm-checkbox"
                                        name="confirm_checkbox"
                                        type="checkbox"
                                        value="1"
                                        required
                                    >
                                    <?php esc_html_e('I understand this action permanently deletes every TChat conversation and message.', 'thecore-elementor-widgets'); ?>
                                </label>
                            </td>
                        </tr>
                        </tbody>
                    </table>

                    <?php submit_button(__('Delete all conversations', 'thecore-elementor-widgets'), 'delete', 'submit', false); ?>
                </form>
            </div>
        </div>
        <script>
            (function () {
                const form = document.getElementById('tchat-delete-all-form');
                if (!form) {
                    return;
                }

                form.addEventListener('submit', function (event) {
                    const textInput = document.getElementById('tchat-delete-confirm-text');
                    const checkbox = document.getElementById('tchat-delete-confirm-checkbox');
                    const confirmText = textInput ? textInput.value.trim() : '';
                    const isChecked = checkbox ? checkbox.checked : false;

                    if (confirmText !== 'SUPPRIMER' || !isChecked) {
                        event.preventDefault();
                        window.alert('<?php echo esc_js(__('Type SUPPRIMER and check the acknowledgement box before continuing.', 'thecore-elementor-widgets')); ?>');
                        return;
                    }

                    if (!window.confirm('<?php echo esc_js(__('This will permanently delete all TChat conversations and messages. Continue?', 'thecore-elementor-widgets')); ?>')) {
                        event.preventDefault();
                    }
                });
            })();
        </script>
        <?php
    }

    public static function assets(string $hook): void
    {
        if ($hook !== 'toplevel_page_tchat') {
            return;
        }

        $js_file = THECORE_ELEMENTOR_WIDGETS_PATH . 'assets/admin/tchat-admin.js';
        $css_file = THECORE_ELEMENTOR_WIDGETS_PATH . 'assets/admin/tchat-admin.css';
        $version = (string) max(
            @filemtime($js_file) ?: 0,
            @filemtime($css_file) ?: 0,
            @filemtime(THECORE_ELEMENTOR_WIDGETS_FILE) ?: 0
        );

        wp_enqueue_script(
            'tchat-admin',
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/admin/tchat-admin.js',
            ['wp-element', 'wp-api-fetch'],
            $version,
            true
        );

        wp_localize_script(
            'tchat-admin',
            'TCHAT_ADMIN',
            [
                'restUrl' => rest_url('tchat/v1'),
                'nonce' => wp_create_nonce('wp_rest'),
                'userId' => get_current_user_id(),
                'transport' => ModuleSettings::getFrontendSettings(),
            ]
        );

        wp_enqueue_style(
            'tchat-admin',
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/admin/tchat-admin.css',
            [],
            $version
        );
    }

    public static function handleDeleteAllConversations(): void
    {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('You are not allowed to perform this action.', 'thecore-elementor-widgets'));
        }

        check_admin_referer(self::DELETE_ACTION);

        $confirmText = isset($_POST['confirm_text']) ? trim((string) wp_unslash($_POST['confirm_text'])) : '';
        $confirmCheckbox = isset($_POST['confirm_checkbox']) ? (string) wp_unslash($_POST['confirm_checkbox']) : '0';

        if ($confirmText !== 'SUPPRIMER' || $confirmCheckbox !== '1') {
            self::redirectToTools('invalid_confirmation');
        }

        global $wpdb;

        $deletedMessages = (int) $wpdb->query("DELETE FROM {$wpdb->prefix}tchat_messages");
        if ($deletedMessages < 0) {
            $deletedMessages = 0;
        }

        $deletedConversations = (int) $wpdb->query("DELETE FROM {$wpdb->prefix}tchat_conversations");
        if ($deletedConversations < 0) {
            $deletedConversations = 0;
        }

        self::redirectToTools(
            'deleted',
            [
                'deleted_conversations' => $deletedConversations,
                'deleted_messages' => $deletedMessages,
            ]
        );
    }

    private static function renderToolsNotice(string $status, int $deletedConversations, int $deletedMessages): void
    {
        if ($status === 'deleted') {
            ?>
            <div class="notice notice-success is-dismissible">
                <p>
                    <?php
                    echo esc_html(
                        sprintf(
                            /* translators: 1: deleted conversations count, 2: deleted messages count. */
                            __('Deleted %1$d conversations and %2$d messages.', 'thecore-elementor-widgets'),
                            $deletedConversations,
                            $deletedMessages
                        )
                    );
                    ?>
                </p>
            </div>
            <?php

            return;
        }

        if ($status === 'invalid_confirmation') {
            ?>
            <div class="notice notice-error is-dismissible">
                <p><?php esc_html_e('Deletion aborted. Type SUPPRIMER and tick the acknowledgement box to confirm.', 'thecore-elementor-widgets'); ?></p>
            </div>
            <?php
        }
    }

    /**
     * @param array<string, int> $extraArgs
     */
    private static function redirectToTools(string $status, array $extraArgs = []): never
    {
        $args = array_merge(
            [
                'page' => self::TOOLS_SLUG,
                'tchat_tools_status' => $status,
            ],
            $extraArgs
        );

        wp_safe_redirect(add_query_arg($args, admin_url('admin.php')));
        exit;
    }
}
