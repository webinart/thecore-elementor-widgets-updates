(() => {
    'use strict';

    const selector = '[data-thecore-animated-text]';
    const accessibilityModuleSelector = '[data-thecore-accessibility-module]';
    const accessibilityTriggerSelector = '[data-thecore-accessibility-trigger], .thecore-accessibility-trigger-legacy, .thecore-accessibility-trigger, a[href="#thecore-accessibility-open"], a[href="#thecore-accessibility-toggle"]';
    const accessibilityActionSelector = '[data-action="pause-animations"]';
    const globalPauseClass = 'thecore-accessibility-pause-animations';
    const instances = new Map();
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
    const editorPreview = /(?:^|[?&])elementor-preview=/.test(window.location.search);
    const fontsReady = document.fonts ? document.fonts.ready : Promise.resolve();
    const segmenter = typeof Intl.Segmenter === 'function'
        ? new Intl.Segmenter(undefined, { granularity: 'grapheme' })
        : null;
    let globalPaused = false;
    let globalControllerReady = false;
    let accessibilityModule = null;
    let accessibilityTriggers = [];

    if (window.thecoreAnimatedTextInitialized) {
        return;
    }

    window.thecoreAnimatedTextInitialized = true;

    const number = (value, fallback, minimum, maximum) => {
        const parsed = Number(value);
        return Number.isFinite(parsed)
            ? Math.min(Math.max(parsed, minimum), maximum)
            : fallback;
    };

    const characters = (text) => segmenter
        ? Array.from(segmenter.segment(text), (part) => part.segment)
        : Array.from(text);

    const usableTrigger = (trigger) => {
        if (trigger.getAttribute('data-thecore-accessibility-trigger-bound') !== '1'
            || trigger.disabled || trigger.getAttribute('aria-disabled') === 'true'
            || trigger.tabIndex < 0 || trigger.closest('[hidden], [inert], [aria-hidden="true"]')
            || !trigger.matches('button, a[href], [role="button"]')
            || !trigger.getClientRects().length) {
            return false;
        }

        const style = window.getComputedStyle(trigger);
        return style.display !== 'none' && style.visibility !== 'hidden';
    };

    const refreshGlobalState = () => {
        const paused = document.body.classList.contains(globalPauseClass);
        const modules = document.querySelectorAll(accessibilityModuleSelector);
        accessibilityModule = modules.length ? modules[modules.length - 1] : null;
        accessibilityTriggers = Array.from(document.querySelectorAll(accessibilityTriggerSelector));
        const action = accessibilityModule?.querySelector(accessibilityActionSelector);
        const ready = !!(accessibilityModule
            && accessibilityModule.getAttribute('data-thecore-accessibility-bound') === '1'
            && action && action.matches('button') && !action.disabled && !action.hidden
            && action.getAttribute('aria-disabled') !== 'true'
            && accessibilityTriggers.some((trigger) => !accessibilityModule.contains(trigger) && usableTrigger(trigger)));
        const pauseChanged = paused !== globalPaused;
        const controllerChanged = ready !== globalControllerReady;
        globalPaused = paused;
        globalControllerReady = ready;

        if (pauseChanged || controllerChanged) {
            instances.forEach((instance) => {
                if (pauseChanged || !instance.toggle) {
                    instance.configureMotion();
                }
            });
        }
    };

    const containsAccessibility = (node) => node instanceof Element && (
        node.matches(`${accessibilityModuleSelector}, ${accessibilityTriggerSelector}, ${accessibilityActionSelector}`)
        || node.querySelector(`${accessibilityModuleSelector}, ${accessibilityTriggerSelector}, ${accessibilityActionSelector}`)
    );

    const affectsAccessibility = (node) => containsAccessibility(node)
        || accessibilityModule?.contains(node)
        || accessibilityTriggers.some((trigger) => node === trigger || node.contains(trigger));

    class AnimatedText {
        constructor(root, config) {
            this.root = root;
            this.output = root.querySelector('[data-thecore-animated-text-output]');
            this.visual = root.querySelector('[data-thecore-animated-text-visual]');
            this.toggle = root.querySelector('[data-thecore-animated-text-toggle]');
            this.phrases = config.phrases.filter((phrase) => typeof phrase === 'string' && phrase.trim());
            this.sequences = this.phrases.map(characters);
            this.staticText = typeof config.staticText === 'string' && config.staticText.trim()
                ? config.staticText
                : this.phrases[0];
            this.typeSpeed = number(config.typeSpeed, 60, 10, 1000);
            this.eraseSpeed = number(config.eraseSpeed, 35, 10, 1000);
            this.pauseDuration = number(config.pauseDuration, 2000, 0, 60000);
            this.startDelay = number(config.startDelay, 1300, 0, 60000);
            this.loop = config.loop !== false;
            this.mobileStatic = config.mobileMode !== 'animate';
            this.mobile = window.matchMedia(`(max-width: ${number(config.mobileBreakpoint, 767, 320, 2560)}px)`);
            this.pauseLabel = config.pauseLabel || 'Mettre l\u2019animation en pause';
            this.resumeLabel = config.resumeLabel || 'Reprendre l\u2019animation';
            this.fontsLoaded = false;
            this.inViewport = !('IntersectionObserver' in window);
            this.userPaused = false;
            this.destroyed = false;
            this.completed = false;
            this.timer = null;
            this.pending = null;
            this.started = false;
            this.index = 0;
            this.position = 0;
            this.phase = 'idle';
            this.onToggle = () => {
                this.userPaused = !this.userPaused;
                this.sync();
            };
            this.onMotionChange = () => this.configureMotion();
            this.root.setAttribute('data-thecore-animated-text-cursor', config.cursor === false ? 'false' : 'true');

            if (this.toggle) {
                this.toggle.addEventListener('click', this.onToggle);
            }

            this.mobile.addEventListener('change', this.onMotionChange);
            reducedMotion.addEventListener('change', this.onMotionChange);

            if ('IntersectionObserver' in window) {
                this.observer = new IntersectionObserver((entries) => {
                    this.inViewport = entries[0].isIntersecting;
                    this.sync();
                }, { threshold: 0.01 });
                this.observer.observe(root);
            }

            const text = root.querySelector('.thecore-animated-text__text');

            if ('ResizeObserver' in window && text) {
                this.resizeObserver = new ResizeObserver(() => this.updateToggleColor());
                this.resizeObserver.observe(text);
            }

            this.configureMotion();
            fontsReady.then(() => {
                if (!this.destroyed) {
                    this.fontsLoaded = true;
                    this.updateToggleColor();
                    this.sync();
                }
            });
        }

        active() {
            return !this.destroyed && !this.staticMode && !this.completed
                && this.fontsLoaded && this.inViewport && !document.hidden && !this.userPaused;
        }

        schedule(delay, callback) {
            this.stopTimer();
            this.pending = { remaining: delay, callback };
            this.resumeTimer();
        }

        stopTimer() {
            if (this.timer !== null) {
                window.clearTimeout(this.timer);
                this.timer = null;

                if (this.pending) {
                    this.pending.remaining = Math.max(0, this.pending.due - performance.now());
                }
            }
        }

        resumeTimer() {
            if (!this.active() || !this.pending || this.timer !== null) {
                return;
            }

            this.pending.due = performance.now() + this.pending.remaining;
            this.timer = window.setTimeout(() => {
                this.timer = null;
                const callback = this.pending.callback;
                this.pending = null;

                if (this.active()) {
                    callback();
                } else {
                    this.pending = { remaining: 0, callback };
                    this.sync();
                }
            }, this.pending.remaining);
        }

        configureMotion() {
            this.stopTimer();
            this.pending = null;
            this.staticMode = editorPreview || reducedMotion.matches || (this.mobileStatic && this.mobile.matches)
                || globalPaused || (!this.toggle && !globalControllerReady);
            this.completed = false;
            this.started = false;
            this.index = 0;
            this.position = 0;
            this.phase = 'idle';
            this.output.textContent = this.staticText;
            this.root.classList.toggle('is-static', this.staticMode);
            this.root.classList.add('is-ready');
            this.updateToggleColor();
            this.sync();
        }

        updateToggleColor() {
            const text = this.root.querySelector('.thecore-animated-text__text');

            if (this.toggle && text) {
                const style = window.getComputedStyle(text);
                const lineHeight = Number.parseFloat(style.lineHeight) || Number.parseFloat(style.fontSize) * 1.2;
                this.root.style.setProperty('--thecore-animated-text-toggle-color', style.color);
                this.root.style.setProperty('--thecore-animated-text-line-height', `${lineHeight}px`);
            }
        }

        sync() {
            if (this.destroyed) {
                return;
            }

            const active = this.active();
            const canAnimate = !this.staticMode && !this.completed;
            this.root.classList.toggle('is-started', this.started);
            this.root.classList.toggle('is-running', active && this.started);
            this.root.classList.toggle('is-paused', canAnimate && !active);
            this.root.setAttribute('data-thecore-animated-text-state',
                this.staticMode ? 'static' : this.completed ? 'complete' : !active ? 'paused' : this.phase);

            if (this.toggle) {
                const label = this.userPaused ? this.resumeLabel : this.pauseLabel;
                this.toggle.hidden = this.staticMode;
                this.toggle.disabled = this.completed;
                this.toggle.classList.toggle('is-complete', this.completed);
                this.toggle.setAttribute('aria-pressed', this.userPaused ? 'true' : 'false');
                this.toggle.setAttribute('aria-label', label);
                this.toggle.setAttribute('title', label);
                this.toggle.classList.toggle('is-paused', this.userPaused);
            }

            if (!active) {
                this.stopTimer();
                return;
            }

            if (!this.started && !this.pending) {
                this.schedule(this.startDelay, () => {
                    this.started = true;
                    this.phase = 'typing';
                    this.type();
                });
            } else {
                this.resumeTimer();
            }
        }

        type() {
            this.position += 1;
            this.output.textContent = this.sequences[this.index].slice(0, this.position).join('');

            if (this.position < this.sequences[this.index].length) {
                this.schedule(this.typeSpeed, () => this.type());
            } else if (!this.loop && this.index === this.phrases.length - 1) {
                this.completed = true;
            } else {
                this.phase = 'waiting';
                this.schedule(this.pauseDuration, () => {
                    this.phase = 'erasing';
                    this.erase();
                });
            }

            this.sync();
        }

        erase() {
            this.position -= 1;
            this.output.textContent = this.sequences[this.index].slice(0, this.position).join('');

            if (this.position > 0) {
                this.schedule(this.eraseSpeed, () => this.erase());
            } else {
                this.index = (this.index + 1) % this.phrases.length;
                this.phase = 'typing';
                this.schedule(this.typeSpeed, () => this.type());
            }

            this.sync();
        }

        referencesValid() {
            return this.output === this.root.querySelector('[data-thecore-animated-text-output]')
                && this.toggle === this.root.querySelector('[data-thecore-animated-text-toggle]');
        }

        destroy() {
            this.destroyed = true;
            this.stopTimer();
            this.pending = null;
            this.observer?.disconnect();
            this.resizeObserver?.disconnect();
            this.toggle?.removeEventListener('click', this.onToggle);
            this.mobile.removeEventListener('change', this.onMotionChange);
            reducedMotion.removeEventListener('change', this.onMotionChange);
            instances.delete(this.root);
        }
    }

    const initialize = (root, force = false) => {
        if (!root.isConnected) {
            return;
        }

        const existing = instances.get(root);

        if (existing && !force && existing.referencesValid()) {
            return;
        }

        existing?.destroy();
        let config;

        try {
            config = JSON.parse(root.getAttribute('data-thecore-animated-text'));
        } catch {
            return;
        }

        if (!config || !Array.isArray(config.phrases)
            || !config.phrases.some((phrase) => typeof phrase === 'string' && phrase.trim())
            || !root.querySelector('[data-thecore-animated-text-output]')) {
            return;
        }

        instances.set(root, new AnimatedText(root, config));
    };

    const scan = (node) => {
        if (!(node instanceof Element)) {
            return;
        }

        if (node.matches(selector)) {
            initialize(node);
        } else {
            const root = node.closest(selector);

            if (root) {
                initialize(root);
            }
        }

        node.querySelectorAll(selector).forEach((root) => initialize(root));
    };

    const start = () => {
        refreshGlobalState();
        document.querySelectorAll(selector).forEach((root) => initialize(root));
        document.addEventListener('visibilitychange', () => instances.forEach((instance) => instance.sync()));
        window.addEventListener('resize', refreshGlobalState, { passive: true });

        const bodyObserver = new MutationObserver(() => refreshGlobalState());
        bodyObserver.observe(document.body, { attributes: true, attributeFilter: ['class'] });

        // Elementor replaces widget fragments without reloading the document.
        const observer = new MutationObserver((records) => {
            let accessibilityChanged = false;

            records.forEach((record) => {
                if (record.type === 'attributes') {
                    if (record.attributeName === 'data-thecore-animated-text') {
                        initialize(record.target, true);
                    } else if (record.target !== document.body && affectsAccessibility(record.target)) {
                        accessibilityChanged = true;
                    }

                    return;
                }

                record.addedNodes.forEach((node) => {
                    scan(node);
                    accessibilityChanged = accessibilityChanged || containsAccessibility(node);
                });
                record.removedNodes.forEach((node) => {
                    if (node instanceof Element) {
                        accessibilityChanged = accessibilityChanged || containsAccessibility(node);
                        instances.forEach((instance, root) => {
                            if (!root.isConnected && (root === node || node.contains(root))) {
                                instance.destroy();
                            }
                        });
                    }
                });
            });

            if (accessibilityChanged) {
                refreshGlobalState();
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: [
                'data-thecore-animated-text', 'data-thecore-accessibility-module',
                'data-thecore-accessibility-trigger', 'data-thecore-accessibility-bound',
                'data-thecore-accessibility-trigger-bound', 'data-action', 'disabled',
                'aria-disabled', 'hidden', 'inert', 'aria-hidden', 'tabindex', 'class', 'style',
            ],
        });
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', start, { once: true });
    } else {
        start();
    }
})();
