<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\AnimatedText;

use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Number_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Select_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Switch_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Text_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Textarea_Control;
use Elementor\Modules\AtomicWidgets\DynamicTags\Dynamic_Prop_Type;
use Elementor\Modules\AtomicWidgets\Elements\Base\Atomic_Widget_Base;
use Elementor\Modules\AtomicWidgets\Elements\Base\Has_Template;
use Elementor\Modules\AtomicWidgets\Elements\TemplateRenderer\Template_Renderer;
use Elementor\Modules\AtomicWidgets\PropTypes\Attributes_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Classes_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Boolean_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Number_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Size_Prop_Type;
use Elementor\Modules\AtomicWidgets\Styles\Style_Definition;
use Elementor\Modules\AtomicWidgets\Styles\Style_Variant;
use Elementor\Modules\Components\PropTypes\Overridable_Prop_Type;

final class AnimatedText extends Atomic_Widget_Base
{
    use Has_Template;

    public static $widget_description = 'Editable typewriter text with native atomic styles, stable layout and accessible motion controls.';

    public static function get_element_type(): string
    {
        return 'thecore-animated-text';
    }

    public function get_title(): string
    {
        return esc_html__('Texte animé', 'thecore-elementor-widgets');
    }

    public function get_icon(): string
    {
        return 'eicon-animated-headline';
    }

    public function get_keywords(): array
    {
        return ['texte', 'animated', 'typewriter', 'heading', 'atomic'];
    }

    public function get_script_depends(): array
    {
        return ['thecore-animated-text'];
    }

    public function get_style_depends(): array
    {
        return ['thecore-animated-text'];
    }

    protected static function define_props_schema(): array
    {
        return [
            'classes' => Classes_Prop_Type::make()->default([]),
            'phrases_text' => self::textProp(DisplaySettings::DEFAULT_PHRASES_TEXT),
            'prefix' => self::textProp(''),
            'suffix' => self::textProp(''),
            'static_text' => self::textProp(''),
            'html_tag' => String_Prop_Type::make()
                ->enum(['div', 'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'span'])
                ->default(DisplaySettings::DEFAULT_HTML_TAG),
            'type_speed' => Number_Prop_Type::make()->default(DisplaySettings::DEFAULT_TYPE_SPEED),
            'erase_speed' => Number_Prop_Type::make()->default(DisplaySettings::DEFAULT_ERASE_SPEED),
            'pause_duration' => Number_Prop_Type::make()->default(DisplaySettings::DEFAULT_PAUSE_DURATION),
            'start_delay' => Number_Prop_Type::make()->default(DisplaySettings::DEFAULT_START_DELAY),
            'loop' => Boolean_Prop_Type::make()->default(true),
            'cursor' => Boolean_Prop_Type::make()->default(true),
            'pause_toggle' => Boolean_Prop_Type::make()->default(false),
            'mobile_mode' => String_Prop_Type::make()->enum(['static', 'animate'])->default('static'),
            'mobile_breakpoint' => Number_Prop_Type::make()->default(DisplaySettings::DEFAULT_MOBILE_BREAKPOINT),
            'attributes' => Attributes_Prop_Type::make()->meta(Overridable_Prop_Type::ignore()),
        ];
    }

    protected function define_base_styles(): array
    {
        return [
            'base' => Style_Definition::make()->add_variant(
                Style_Variant::make()->add_prop('margin', Size_Prop_Type::generate([
                    'size' => 0,
                    'unit' => 'px',
                ]))
            ),
        ];
    }

    protected function define_atomic_controls(): array
    {
        return [
            Section::make()
                ->set_label(__('Contenu', 'thecore-elementor-widgets'))
                ->set_id('content')
                ->set_items([
                    Textarea_Control::bind_to('phrases_text')
                        ->set_label(__('Phrases', 'thecore-elementor-widgets'))
                        ->set_description(__('Une phrase par ligne, jusqu’à 20 phrases de 200 caractères.', 'thecore-elementor-widgets')),
                    Text_Control::bind_to('prefix')->set_label(__('Préfixe', 'thecore-elementor-widgets')),
                    Text_Control::bind_to('suffix')->set_label(__('Suffixe', 'thecore-elementor-widgets')),
                    Select_Control::bind_to('html_tag')
                        ->set_label(__('Balise HTML', 'thecore-elementor-widgets'))
                        ->set_options(array_map(
                            static fn (string $tag): array => ['label' => $tag, 'value' => $tag],
                            ['div', 'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'span']
                        )),
                ]),
            Section::make()
                ->set_label(__('Animation', 'thecore-elementor-widgets'))
                ->set_id('animation')
                ->set_items([
                    self::numberControl('type_speed', __('Écriture : délai par lettre (ms)', 'thecore-elementor-widgets'), 15, 500),
                    self::numberControl('erase_speed', __('Effacement : délai par lettre (ms)', 'thecore-elementor-widgets'), 15, 500),
                    self::numberControl('pause_duration', __('Pause entre les phrases (ms)', 'thecore-elementor-widgets'), 500, 30000),
                    self::numberControl('start_delay', __('Délai initial (ms)', 'thecore-elementor-widgets'), 0, 10000),
                    Switch_Control::bind_to('loop')->set_label(__('Lecture en boucle', 'thecore-elementor-widgets')),
                    Switch_Control::bind_to('cursor')->set_label(__('Afficher le curseur', 'thecore-elementor-widgets')),
                    Switch_Control::bind_to('pause_toggle')
                        ->set_label(__('Commande de pause', 'thecore-elementor-widgets'))
                        ->set_description(__('Sans commande locale, utilisez le module Accessibilité. Sinon, le texte reste fixe.', 'thecore-elementor-widgets')),
                ]),
            Section::make()
                ->set_label(__('Mobile et accessibilité', 'thecore-elementor-widgets'))
                ->set_id('accessibility')
                ->set_items([
                    Select_Control::bind_to('mobile_mode')
                        ->set_label(__('Comportement mobile', 'thecore-elementor-widgets'))
                        ->set_options([
                            ['label' => __('Texte fixe', 'thecore-elementor-widgets'), 'value' => 'static'],
                            ['label' => __('Texte animé', 'thecore-elementor-widgets'), 'value' => 'animate'],
                        ]),
                    self::numberControl('mobile_breakpoint', __('Largeur maximale du mode mobile (px)', 'thecore-elementor-widgets'), 320, 1024),
                    Textarea_Control::bind_to('static_text')
                        ->set_label(__('Texte fixe alternatif', 'thecore-elementor-widgets'))
                        ->set_description(__('Utilisé sur mobile et avec une préférence de mouvement réduit. Vide : première phrase.', 'thecore-elementor-widgets')),
                ]),
            Section::make()
                ->set_label(__('Réglages', 'thecore-elementor-widgets'))
                ->set_id('settings')
                ->set_items([
                    Text_Control::bind_to('_cssid')
                        ->set_label(__('ID', 'thecore-elementor-widgets'))
                        ->set_meta($this->get_css_id_control_meta()),
                ]),
        ];
    }

    protected function get_templates(): array
    {
        return [
            'thecore/elements/animated-text' => __DIR__ . '/animated-text.html.twig',
        ];
    }

    protected function render()
    {
        $settings = (new DisplaySettings())->normalize($this->get_atomic_settings());

        if ('' === $settings['phrases_text']) {
            return;
        }

        // The theme may remove Elementor's frontend loader; enqueue our standalone assets too.
        wp_enqueue_style('thecore-animated-text');
        wp_enqueue_script('thecore-animated-text');

        $renderer = Template_Renderer::instance();

        foreach (array_merge($this->get_shared_templates(), $this->get_templates()) as $name => $path) {
            if (! $renderer->is_registered($name)) {
                $renderer->register($name, $path);
            }
        }

        echo $renderer->render($this->get_main_template(), [ // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            'id' => $this->get_id(),
            'interaction_id' => $this->get_interaction_id(),
            'type' => $this->get_name(),
            'settings' => $settings,
            'base_styles' => $this->get_base_styles_dictionary(),
        ]);
    }

    private static function textProp(string $default): String_Prop_Type
    {
        return String_Prop_Type::make()
            ->default($default)
            ->meta(Dynamic_Prop_Type::ignore())
            ->meta(Overridable_Prop_Type::ignore());
    }

    private static function numberControl(string $name, string $label, int $minimum, int $maximum): Number_Control
    {
        return Number_Control::bind_to($name)
            ->set_label($label)
            ->set_min($minimum)
            ->set_max($maximum)
            ->set_step(1)
            ->set_should_force_int(true);
    }
}
