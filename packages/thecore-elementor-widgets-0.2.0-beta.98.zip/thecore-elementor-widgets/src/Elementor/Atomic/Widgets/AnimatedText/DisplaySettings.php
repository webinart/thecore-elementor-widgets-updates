<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\AnimatedText;

final class DisplaySettings
{
    public const DEFAULT_PHRASES_TEXT = 'Votre texte prend vie.';
    public const DEFAULT_HTML_TAG = 'div';
    public const DEFAULT_TYPE_SPEED = 60;
    public const DEFAULT_ERASE_SPEED = 35;
    public const DEFAULT_PAUSE_DURATION = 2000;
    public const DEFAULT_START_DELAY = 1300;
    public const DEFAULT_MOBILE_BREAKPOINT = 767;
    public const MAX_PHRASES = 20;
    public const MAX_PHRASE_LENGTH = 200;

    /**
     * @param array<string, mixed> $settings
     * @return array<string, mixed>
     */
    public function normalize(array $settings): array
    {
        $settings['phrases_text'] = implode("\n", $this->normalizePhrases(
            $settings['phrases_text'] ?? self::DEFAULT_PHRASES_TEXT
        ));
        $settings['prefix'] = $this->normalizeText($settings['prefix'] ?? '');
        $settings['suffix'] = $this->normalizeText($settings['suffix'] ?? '');
        $settings['static_text'] = $this->normalizeStaticText($settings['static_text'] ?? '');
        $settings['html_tag'] = $this->normalizeEnum(
            $settings['html_tag'] ?? self::DEFAULT_HTML_TAG,
            ['div', 'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'span'],
            self::DEFAULT_HTML_TAG
        );
        $settings['type_speed'] = $this->normalizeNumber(
            $settings['type_speed'] ?? null,
            15,
            500,
            self::DEFAULT_TYPE_SPEED
        );
        $settings['erase_speed'] = $this->normalizeNumber(
            $settings['erase_speed'] ?? null,
            15,
            500,
            self::DEFAULT_ERASE_SPEED
        );
        $settings['pause_duration'] = $this->normalizeNumber(
            $settings['pause_duration'] ?? null,
            500,
            30000,
            self::DEFAULT_PAUSE_DURATION
        );
        $settings['start_delay'] = $this->normalizeNumber(
            $settings['start_delay'] ?? null,
            0,
            10000,
            self::DEFAULT_START_DELAY
        );
        $settings['mobile_breakpoint'] = $this->normalizeNumber(
            $settings['mobile_breakpoint'] ?? null,
            320,
            1024,
            self::DEFAULT_MOBILE_BREAKPOINT
        );
        $settings['mobile_mode'] = $this->normalizeEnum(
            $settings['mobile_mode'] ?? 'static',
            ['static', 'animate'],
            'static'
        );

        foreach (['loop' => true, 'cursor' => true, 'pause_toggle' => false] as $name => $default) {
            $settings[$name] = $this->normalizeBoolean($settings[$name] ?? $default, $default);
        }

        $settings['_pause_label'] = __('Mettre l’animation en pause', 'thecore-elementor-widgets');
        $settings['_resume_label'] = __('Reprendre l’animation', 'thecore-elementor-widgets');

        return $settings;
    }

    /** @return list<string> */
    private function normalizePhrases(mixed $value): array
    {
        if (! is_string($value)) {
            return [];
        }

        $lines = preg_split('/\r\n|\r|\n/', $value) ?: [];
        $phrases = [];

        foreach ($lines as $line) {
            $phrase = $this->normalizeText($line);

            if ('' === $phrase) {
                continue;
            }

            $phrases[] = $phrase;

            if (count($phrases) >= self::MAX_PHRASES) {
                break;
            }
        }

        return $phrases;
    }

    private function normalizeText(mixed $value): string
    {
        if (! is_string($value)) {
            return '';
        }

        $value = sanitize_text_field($value);
        $value = trim(preg_replace('/[\p{Z}\s]+/u', ' ', $value) ?? '');

        return $this->truncate($value);
    }

    private function normalizeStaticText(mixed $value): string
    {
        if (! is_string($value)) {
            return '';
        }

        $value = sanitize_textarea_field($value);
        $lines = preg_split('/\r\n|\r|\n/', $value) ?: [];
        $lines = array_map(
            static fn (string $line): string => trim(preg_replace('/[\p{Z}\t ]+/u', ' ', $line) ?? ''),
            $lines
        );

        return $this->truncate(trim(implode("\n", $lines)));
    }

    private function truncate(string $value): string
    {
        if (function_exists('mb_substr')) {
            return mb_substr($value, 0, self::MAX_PHRASE_LENGTH, 'UTF-8');
        }

        $characters = preg_split('//u', $value, -1, PREG_SPLIT_NO_EMPTY) ?: [];

        return implode('', array_slice($characters, 0, self::MAX_PHRASE_LENGTH));
    }

    /** @param list<string> $allowed */
    private function normalizeEnum(mixed $value, array $allowed, string $default): string
    {
        return is_string($value) && in_array($value, $allowed, true) ? $value : $default;
    }

    private function normalizeNumber(mixed $value, int $minimum, int $maximum, int $default): int
    {
        if (! is_numeric($value) || ! is_finite((float) $value)) {
            return $default;
        }

        return max($minimum, min($maximum, (int) round((float) $value)));
    }

    private function normalizeBoolean(mixed $value, bool $default): bool
    {
        if (is_bool($value)) {
            return $value;
        }

        if (in_array($value, [1, '1', 'true', 'yes'], true)) {
            return true;
        }

        if (in_array($value, [0, '0', 'false', 'no', ''], true)) {
            return false;
        }

        return $default;
    }
}
