<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Email;

use TheCore\ElementorWidgets\Forms\FormDefinition;

/** Small, shared HTML-email kit with inline styles and no visitor-supplied HTML. */
final class TemplateRenderer
{
    public static function notification(FormDefinition $form, array $values): string
    {
        $brand = BrandProfile::load();
        $content = self::paragraph('Une nouvelle demande a été envoyée depuis votre site.');
        $content .= '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="width:100%;border-collapse:collapse;margin:24px 0;">';
        foreach (SummaryBuilder::rows($form, $values, $brand) as $row) {
            $value = nl2br(self::escape($row['value']), false);
            if ($row['type'] === 'media') {
                $links = [];
                foreach ($row['files'] as $file) {
                    $links[] = self::link($file['url'], $file['name'], $brand['primary_color']);
                }
                $value = implode('<br>', $links);
            }
            $content .= '<tr><td valign="top" style="padding:13px 0;border-bottom:1px solid #E7EDF2;">'
                . '<div style="font-size:12px;line-height:18px;font-weight:700;color:#667687;margin-bottom:4px;">'
                . self::escape($row['label']) . '</div><div style="font-size:16px;line-height:24px;color:#243443;overflow-wrap:anywhere;word-break:break-word;">'
                . $value . '</div></td></tr>';
        }
        $content .= '</table>';
        return self::frame(
            $brand,
            'Nouvelle demande',
            (string) ($form->settings['form-name'] ?? 'Contact'),
            $content,
            'Les coordonnées et pièces jointes de ce message sont réservées au traitement de cette demande.'
        );
    }

    /** The only input is the administrator's saved static acknowledgement text. */
    public static function acknowledgement(string $staticBody): string
    {
        $brand = BrandProfile::load();
        $content = '';
        foreach (preg_split('/\R[\t ]*\R/u', trim($staticBody)) ?: [] as $paragraph) {
            if (trim($paragraph) !== '') {
                $content .= self::paragraph($paragraph);
            }
        }
        return self::frame(
            $brand,
            'Votre demande a bien été reçue',
            'Merci pour votre message',
            $content,
            'Vos informations sont utilisées pour traiter votre demande et vous répondre.'
        );
    }

    private static function frame(array $brand, string $title, string $eyebrow, string $content, string $privacy): string
    {
        $name = self::escape($brand['name']);
        $logo = $brand['logo_url'] !== ''
            ? '<img src="' . self::escape($brand['logo_url']) . '" width="230" alt="' . $name
                . '" style="display:block;width:230px;max-width:100%;height:auto;border:0;">'
            : '<span style="font-size:22px;line-height:30px;font-weight:700;color:' . $brand['primary_color'] . ';">' . $name . '</span>';
        if ($brand['url'] !== '') {
            $logo = '<a href="' . self::escape($brand['url']) . '" style="text-decoration:none;">' . $logo . '</a>';
        }
        $contacts = [];
        if ($brand['phone'] !== '') {
            $contacts[] = self::link('tel:' . preg_replace('/[^+0-9]/', '', $brand['phone']), $brand['phone'], $brand['primary_color']);
        }
        if ($brand['email'] !== '') {
            $contacts[] = self::link('mailto:' . $brand['email'], $brand['email'], $brand['primary_color']);
        }
        if ($brand['url'] !== '') {
            $host = (string) parse_url($brand['url'], PHP_URL_HOST);
            $contacts[] = self::link($brand['url'], $host, $brand['primary_color']);
        }
        $signature = '<p style="margin:24px 0 0;font-size:15px;line-height:24px;font-weight:700;color:#243443;">L’équipe '
            . $name . '</p>';
        if ($contacts !== []) {
            $signature .= '<p style="margin:6px 0 0;font-size:14px;line-height:24px;">' . implode('<br>', $contacts) . '</p>';
        }
        return '<!doctype html><html lang="fr"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            . '<title>' . self::escape($title) . '</title></head><body style="margin:0;padding:0;background-color:#F2F5F8;font-family:Arial,Helvetica,sans-serif;color:#243443;">'
            . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="width:100%;border-collapse:collapse;background-color:#F2F5F8;">'
            . '<tr><td align="center" style="padding:28px 12px;"><!--[if mso]><table role="presentation" width="640" cellpadding="0" cellspacing="0"><tr><td><![endif]-->'
            . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="width:100%;max-width:640px;border-collapse:collapse;background-color:#FFFFFF;">'
            . '<tr><td style="padding:28px 28px 24px;">' . $logo . '</td></tr>'
            . '<tr><td height="5" style="height:5px;background-color:' . $brand['primary_color'] . ';font-size:0;line-height:0;"><div style="width:64px;height:5px;background-color:'
            . $brand['accent_color'] . ';font-size:0;line-height:0;">&nbsp;</div></td></tr>'
            . '<tr><td style="padding:28px;"><p style="margin:0 0 9px;font-size:12px;line-height:18px;font-weight:700;color:#667687;">'
            . self::escape($eyebrow) . '</p><h1 style="margin:0 0 22px;font-size:26px;line-height:34px;font-weight:700;color:'
            . $brand['primary_color'] . ';">' . self::escape($title) . '</h1>' . $content . $signature . '</td></tr>'
            . '<tr><td style="padding:19px 28px;background-color:#F7F9FB;border-top:1px solid #E7EDF2;font-size:12px;line-height:19px;color:#667687;">'
            . self::escape($privacy) . '</td></tr></table><!--[if mso]></td></tr></table><![endif]--></td></tr></table></body></html>';
    }

    private static function paragraph(string $text): string
    {
        return '<p style="margin:0 0 17px;font-size:16px;line-height:26px;color:#425567;">' . nl2br(self::escape($text), false) . '</p>';
    }

    private static function link(string $url, string $text, string $color): string
    {
        return '<a href="' . self::escape($url) . '" style="color:' . $color . ';text-decoration:underline;overflow-wrap:anywhere;word-break:break-word;">'
            . self::escape($text) . '</a>';
    }

    private static function escape(string $text): string
    {
        return htmlspecialchars($text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}
