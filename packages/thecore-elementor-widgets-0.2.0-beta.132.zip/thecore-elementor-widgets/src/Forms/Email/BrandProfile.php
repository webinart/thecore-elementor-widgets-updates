<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Email;

/** Server-owned email identity. It never supplies delivery recipients. */
final class BrandProfile
{
    public static function load(): array
    {
        $logoId = (int) get_theme_mod('custom_logo', 0);
        $defaults = [
            'name' => self::text((string) get_bloginfo('name')) ?: 'Contact',
            'url' => self::safeUrl((string) home_url('/')),
            'logo_url' => $logoId > 0 ? self::safeUrl((string) wp_get_attachment_image_url($logoId, 'full')) : '',
            'primary_color' => '#174E78',
            'accent_color' => '#EE9739',
            'phone' => '',
            'email' => '',
            'field_labels' => [],
            'value_labels' => [],
        ];
        $saved = get_option('thecore_forms_email_brand', []);
        $candidate = apply_filters('thecore/forms/email/brand', array_replace($defaults, is_array($saved) ? $saved : []));
        $candidate = is_array($candidate) ? $candidate : [];
        $profile = $defaults;
        if (is_string($candidate['name'] ?? null) && self::text($candidate['name']) !== '') {
            $profile['name'] = self::text($candidate['name']);
        }
        foreach (['url', 'logo_url'] as $key) {
            if (is_string($candidate[$key] ?? null)) {
                $profile[$key] = self::safeUrl($candidate[$key]) ?: $defaults[$key];
            }
        }
        foreach (['primary_color', 'accent_color'] as $key) {
            if (is_string($candidate[$key] ?? null) && preg_match('/\A#[a-fA-F0-9]{6}\z/', $candidate[$key])) {
                $profile[$key] = strtoupper($candidate[$key]);
            }
        }
        $phone = $candidate['phone'] ?? '';
        if (is_string($phone) && strlen($phone) <= 60 && preg_match('/\A\+?[0-9 ()\.\-]+\z/', $phone)) {
            $digits = preg_replace('/\D/', '', $phone);
            if (strlen($digits) >= 7 && strlen($digits) <= 15) {
                $profile['phone'] = trim($phone);
            }
        }
        $email = $candidate['email'] ?? '';
        if (is_string($email) && strlen($email) <= 254 && ! preg_match('/[\x00-\x20\x7F]/', $email) && is_email($email)) {
            $profile['email'] = $email;
        }
        $profile['field_labels'] = self::labels($candidate['field_labels'] ?? []);
        $valueLabels = $candidate['value_labels'] ?? [];
        if (is_array($valueLabels)) {
            foreach (array_slice($valueLabels, 0, 100, true) as $key => $labels) {
                if (self::validKey($key)) {
                    $profile['value_labels'][$key] = self::labels($labels, false);
                }
            }
        }
        return $profile;
    }

    /** Validate links without fetching them or permitting executable URL schemes. */
    public static function safeUrl(string $url): string
    {
        if ($url === '' || strlen($url) > 2048 || preg_match('/[\x00-\x20\x7F]/', $url)) {
            return '';
        }
        $parts = parse_url($url);
        if (
            ! is_array($parts) || ! in_array(strtolower($parts['scheme'] ?? ''), ['https', 'http'], true)
            || empty($parts['host']) || isset($parts['user']) || isset($parts['pass'])
            || filter_var($url, FILTER_VALIDATE_URL) === false
        ) {
            return '';
        }
        return $url;
    }

    private static function labels(mixed $labels, bool $fieldKeys = true): array
    {
        $result = [];
        if (! is_array($labels)) {
            return $result;
        }
        foreach (array_slice($labels, 0, 100, true) as $key => $label) {
            if (
                ($fieldKeys ? self::validKey($key) : (is_string($key) || is_int($key)) && strlen((string) $key) <= 1000)
                && is_string($label) && self::text($label) !== ''
            ) {
                $result[$key] = self::text($label);
            }
        }
        return $result;
    }

    private static function validKey(mixed $key): bool
    {
        return is_string($key) && preg_match('/\A[A-Za-z0-9_.:\[\]-]{1,128}\z/', $key) === 1;
    }

    private static function text(string $text): string
    {
        return trim(preg_replace('/[\x00-\x1F\x7F]/', ' ', strip_tags(substr($text, 0, 300))) ?? '');
    }
}
