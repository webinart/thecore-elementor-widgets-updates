<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Email;

use TheCore\ElementorWidgets\Forms\FormDefinition;

/** A presentation-only summary; it never alters validated values or their archive. */
final class SummaryBuilder
{
    public static function rows(FormDefinition $form, array $values, array $brand = []): array
    {
        $rows = [];
        $groups = [];
        foreach ($form->activeFor($values)->fields as $id => $field) {
            $type = $field['type'];
            $value = $values[$id] ?? '';
            if ($type === 'media') {
                $files = [];
                foreach ($form->settings['_media-files'][$id]['files'] ?? [] as $file) {
                    if (! is_array($file) || ! is_string($file['url'] ?? null) || BrandProfile::safeUrl($file['url']) === '') {
                        continue;
                    }
                    $files[] = ['name' => (string) ($file['name'] ?? 'Fichier'), 'url' => $file['url']];
                }
                if ($files !== []) {
                    $rows[] = ['label' => self::label($field, $brand), 'value' => implode(', ', array_column($files, 'name')),
                        'type' => $type, 'files' => $files];
                }
                continue;
            }
            $items = is_array($value) ? $value : [$value];
            $items = array_values(array_filter($items, static fn ($item): bool => is_string($item) && trim($item) !== ''));
            if ($items === []) {
                continue;
            }
            if ($type === 'radio') {
                $group = (string) ($field['name'] ?? $field['domId']);
                if (isset($groups[$group])) {
                    continue;
                }
                $groups[$group] = true;
                $label = self::mapped($brand['field_labels'] ?? [], $field);
                $valueLabel = self::valueLabel($field, $items[0], $brand);
                $rows[] = ['label' => $label !== '' ? $label : 'Choix',
                    'value' => $valueLabel !== '' ? $valueLabel : (string) $field['label'], 'type' => $type];
                continue;
            }
            $display = [];
            foreach ($items as $item) {
                $mapped = self::valueLabel($field, $item, $brand);
                $display[] = $mapped !== '' ? $mapped : ($type === 'checkbox' ? 'Oui' : $item);
            }
            $rows[] = ['label' => self::label($field, $brand), 'value' => implode(', ', $display), 'type' => $type];
        }
        return $rows;
    }

    private static function label(array $field, array $brand): string
    {
        $label = self::mapped($brand['field_labels'] ?? [], $field);
        return $label !== '' ? $label : (string) $field['label'];
    }

    private static function valueLabel(array $field, string $value, array $brand): string
    {
        foreach ([$field['domId'] ?? '', $field['name'] ?? ''] as $key) {
            $label = $brand['value_labels'][$key][$value] ?? null;
            if (is_string($label) && trim($label) !== '') {
                return $label;
            }
        }
        $label = $field['optionLabels'][$value] ?? null;
        return is_string($label) && trim($label) !== '' ? $label : '';
    }

    private static function mapped(array $labels, array $field): string
    {
        foreach ([$field['domId'] ?? '', $field['name'] ?? ''] as $key) {
            if (is_string($labels[$key] ?? null) && trim($labels[$key]) !== '') {
                return $labels[$key];
            }
        }
        return '';
    }
}
