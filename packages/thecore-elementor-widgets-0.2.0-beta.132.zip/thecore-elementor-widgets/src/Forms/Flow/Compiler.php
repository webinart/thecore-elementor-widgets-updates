<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Flow;

use TheCore\ElementorWidgets\Forms\ConfigurationException;
use TheCore\ElementorWidgets\Forms\FormDefinition;

/** Only saved, static rules can select a form branch or require another field. */
final class Compiler
{
    public const GROUP_TYPE = 'thecore-form-group';

    public static function compile(array $element, array &$fields): array
    {
        $positions = [];
        $cursor = 0;
        self::positions($element['elements'] ?? [], $positions, $cursor);
        $groups = [];
        $rules = [];
        $cursor = 0;
        self::walk($element['elements'] ?? [], $fields, $positions, $cursor, [], false, $groups, $rules);
        if ($groups === []) {
            return [];
        }
        if (count(array_filter($groups, static fn (array $group): bool => $group['step'])) > 12) {
            throw new ConfigurationException('A form supports at most 12 steps.');
        }
        return ['groups' => array_values($groups), 'requiredRules' => $rules];
    }

    public static function matches(array $conditions, array $fields, array $submitted): bool
    {
        $active = [];
        return self::evaluate($conditions, $fields, $submitted, $active);
    }

    private static function evaluate(array $conditions, array $fields, array $submitted, array &$active): bool
    {
        foreach ($conditions as $condition) {
            $field = $fields[$condition['field']];
            $active[$condition['field']] ??= self::evaluate($field['conditions'] ?? [], $fields, $submitted, $active);
            if (! $active[$condition['field']]) {
                return false;
            }
            $value = $field['readonly'] ? $field['value'] : ($submitted[$condition['field']] ?? '');
            if (! is_string($value) || ! hash_equals($condition['value'], $value)) {
                return false;
            }
        }
        return true;
    }

    private static function positions(array $children, array &$positions, int &$cursor): void
    {
        foreach ($children as $child) {
            $positions[(string) ($child['id'] ?? '')] = ++$cursor;
            self::positions($child['elements'] ?? [], $positions, $cursor);
        }
    }

    private static function walk(
        array $children,
        array &$fields,
        array $positions,
        int &$cursor,
        array $inherited,
        bool $insideStep,
        array &$groups,
        array &$rules
    ): array {
        $descendants = [];
        foreach ($children as $child) {
            ++$cursor;
            $id = (string) ($child['id'] ?? '');
            $conditions = $inherited;
            $group = ($child['elType'] ?? '') === self::GROUP_TYPE;
            $step = false;
            if ($group) {
                if (! preg_match('/\A[A-Za-z0-9_-]{1,128}\z/', $id) || isset($groups[$id]) || isset($fields[$id]) || count($groups) >= 50) {
                    throw new ConfigurationException('Invalid or duplicate form group.');
                }
                $props = FormDefinition::settings($child['settings'] ?? []);
                $label = $props['label'] ?? '';
                $step = $props['is-step'] ?? false;
                if (! is_string($label) || strlen($label) > 1000 || ! is_bool($step) || ($step && $insideStep)) {
                    throw new ConfigurationException('Invalid form step. Steps cannot be nested.');
                }
                $source = $props['condition-field'] ?? '';
                $value = $props['condition-value'] ?? '';
                $required = $props['require-field'] ?? '';
                foreach ([$source, $value, $required] as $setting) {
                    if (! is_string($setting) || strlen($setting) > 1000) {
                        throw new ConfigurationException('Invalid static form condition.');
                    }
                }
                if ($source === '' && $value !== '') {
                    throw new ConfigurationException('A condition value requires a controlling field.');
                }
                if ($source !== '') {
                    $sourceId = self::earlierField($source, $fields, $positions, $cursor);
                    $controller = $fields[$sourceId];
                    $allowed = match ($controller['type']) {
                        'select' => $controller['multiple'] ? [] : $controller['options'],
                        'radio', 'checkbox' => [$controller['value'] !== '' ? $controller['value'] : 'on'],
                        default => [],
                    };
                    if ($value === '' || ! in_array($value, $allowed, true)) {
                        throw new ConfigurationException('A condition needs a declared select, radio or checkbox value.');
                    }
                    $conditions[] = ['field' => $sourceId, 'value' => $value];
                }
                if ($required !== '') {
                    $target = self::earlierField($required, $fields, $positions, $cursor);
                    if (in_array($fields[$target]['type'], ['media', 'radio'], true)) {
                        throw new ConfigurationException('Unsupported conditional required field.');
                    }
                    $rules[] = ['field' => $target, 'conditions' => $conditions];
                }
                $groups[$id] = ['id' => $id, 'label' => trim(strip_tags($label)), 'step' => $step,
                    'conditions' => $conditions, 'fields' => []];
            }
            if (isset($fields[$id])) {
                $descendants[] = $id;
                if ($conditions !== []) {
                    $fields[$id]['conditions'] = $conditions;
                }
            }
            $nested = self::walk($child['elements'] ?? [], $fields, $positions, $cursor, $conditions, $insideStep || $step, $groups, $rules);
            $descendants = array_merge($descendants, $nested);
            if ($group) {
                $groups[$id]['fields'] = $nested;
            }
        }
        return $descendants;
    }

    private static function earlierField(string $cssId, array $fields, array $positions, int $position): string
    {
        foreach ($fields as $id => $field) {
            if ($field['domId'] === $cssId) {
                if (($positions[$id] ?? PHP_INT_MAX) >= $position) {
                    throw new ConfigurationException('Conditional controllers and required targets must be earlier fields.');
                }
                return $id;
            }
        }
        throw new ConfigurationException('Condition references an unknown saved CSS ID.');
    }
}
