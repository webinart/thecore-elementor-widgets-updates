<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Media;

use TheCore\ElementorWidgets\FormSecurity\Support\OriginPolicy;
use TheCore\ElementorWidgets\Forms\Controller as FormController;
use TheCore\ElementorWidgets\Forms\SubmissionException;
use Throwable;
use WP_REST_Request;
use WP_REST_Response;

final class Controller
{
    private const INPUTS = [
        'session' => ['context', 'field', 'proof', 'website'], 'status' => ['session', 'owner'],
        'upload' => ['session', 'owner', 'mobile'], 'delete' => ['session', 'owner', 'id'],
        'bridge' => ['session', 'owner'], 'exchange' => ['bridge', 'secret'],
        'approve' => ['session', 'owner', 'pair_code'], 'mobile-status' => ['session', 'mobile'],
        'finish' => ['session', 'owner', 'mobile'], 'revoke' => ['session', 'owner'],
    ];

    public function __construct(private readonly Service $service)
    {
    }

    public function register(): void
    {
        foreach (array_keys(self::INPUTS) as $operation) {
            register_rest_route(FormController::NAMESPACE, '/forms/media/' . $operation, [
                'methods' => 'POST', 'permission_callback' => '__return_true',
                'callback' => fn (WP_REST_Request $request): WP_REST_Response => $this->serve($operation, $request),
            ]);
        }
    }

    public function serve(string $operation, WP_REST_Request $request): WP_REST_Response
    {
        $status = 200;
        try {
            if (! (new OriginPolicy())->isAllowed($_SERVER, home_url('/'))) {
                throw new SubmissionException('origin_forbidden', 'Requête non autorisée.', 403);
            }
            $upload = $operation === 'upload';
            if (! $upload && strlen($request->get_body()) > 20000) {
                throw new SubmissionException('payload_too_large', 'Requête trop volumineuse.', 413);
            }
            $params = $upload ? $request->get_body_params() : $request->get_json_params();
            $files = $request->get_file_params();
            if (
                ! isset(self::INPUTS[$operation]) || ! is_array($params) || array_diff(array_keys($params), self::INPUTS[$operation])
                || (! $upload && $files !== []) || ($upload && array_keys($files) !== ['file'])
            ) {
                throw new SubmissionException('invalid_request', 'Paramètres de dépôt invalides.');
            }
            $optional = in_array($operation, ['upload', 'finish'], true) ? ['owner', 'mobile'] : [];
            foreach (self::INPUTS[$operation] as $key) {
                if (in_array($key, $optional, true) && ! array_key_exists($key, $params)) {
                    continue;
                }
                $maximum = $key === 'proof' ? 16384 : ($key === 'context' ? 2048 : 128);
                if (! is_string($params[$key] ?? null) || strlen($params[$key]) > $maximum || str_contains($params[$key], "\0")) {
                    throw new SubmissionException('invalid_request', 'Paramètres de dépôt invalides.');
                }
            }
            if ($optional !== [] && (isset($params['owner']) === isset($params['mobile']))) {
                throw new SubmissionException('invalid_request', 'Identité du dépôt invalide.');
            }
            $data = $this->service->operation($operation, $params, $files);
        } catch (SubmissionException $error) {
            $status = $error->status;
            $data = ['code' => $error->errorCode, 'message' => $error->getMessage(), 'data' => ['status' => $status]];
        } catch (Throwable) {
            $status = 503;
            $data = ['code' => 'media_unavailable', 'message' => 'Le dépôt de fichiers est momentanément indisponible.', 'data' => ['status' => 503]];
        }
        $response = new WP_REST_Response($data, $status);
        $response->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $response->header('X-Robots-Tag', 'noindex, nofollow');
        $response->header('Referrer-Policy', 'no-referrer');
        return $response;
    }
}
