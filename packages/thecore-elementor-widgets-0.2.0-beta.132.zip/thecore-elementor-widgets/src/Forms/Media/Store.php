<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Media;

use Closure;
use TheCore\ElementorWidgets\FormSecurity\Support\EmailIdentity;
use TheCore\ElementorWidgets\FormSecurity\Support\FormContext;
use TheCore\ElementorWidgets\FormSecurity\Support\Secrets;
use TheCore\ElementorWidgets\Forms\FormDefinition;
use TheCore\ElementorWidgets\Forms\SubmissionException;
use Throwable;

/** Private durable storage, independent of the optional form-submission archive. */
final class Store
{
    private const MAX_SESSIONS = 1000;
    private const MAX_PENDING = 200;
    private const MAX_BYTES = 2147483648;
    private const MAX_SESSION_BYTES = 314572800;
    private Closure $clock;
    private Closure $uploader;
    private readonly bool $testUploader;

    public function __construct(
        private readonly ?string $directory = null,
        ?callable $clock = null,
        ?callable $uploader = null
    ) {
        $this->clock = Closure::fromCallable($clock ?? static fn (): int => time());
        $this->uploader = Closure::fromCallable($uploader ?? 'move_uploaded_file');
        $this->testUploader = $uploader !== null;
    }

    public function create(FormContext $context, array $field): array
    {
        return $this->locked(function (string $root) use ($context, $field): array {
            $this->purge($root);
            $records = $this->records($root);
            $pending = count(array_filter($records, static fn (array $record): bool => ! $record['committed']));
            if (count($records) >= self::MAX_SESSIONS || $pending >= self::MAX_PENDING) {
                throw $this->failure('media_capacity', 'Le dépôt de fichiers est temporairement saturé.', 503);
            }
            $id = bin2hex(random_bytes(16));
            $owner = bin2hex(random_bytes(32));
            $record = ['id' => $id, 'owner_hash' => hash('sha256', $owner), 'scope' => $this->scope($context, $field['id']),
                'policy' => $field['media'], 'created_at' => $this->now(), 'expires_at' => $this->now() + 86400,
                'committed' => false, 'files' => [], 'bridge' => null, 'email_hashes' => []];
            if (function_exists('update_option')) {
                update_option(Module::HISTORY_OPTION, true, false);
                if (! get_option(Module::HISTORY_OPTION, false)) {
                    throw $this->failure();
                }
            }
            $this->write($root, $record);
            return ['session' => $id, 'owner' => $owner, 'files' => [], 'expires_at' => $record['expires_at'], 'policy' => $record['policy']];
        });
    }

    public function status(string $session, string $owner): array
    {
        return $this->locked(function (string $root) use ($session, $owner): array {
            $record = $this->owned($root, $session, $owner);
            $bridge = $this->bridgeState($record);
            return ['files' => $this->publicFiles($record), 'expires_at' => $record['expires_at'], 'bridge' => $bridge];
        });
    }

    public function upload(string $session, string $credential, bool $mobile, array $file): array
    {
        return $this->locked(function (string $root) use ($session, $credential, $mobile, $file): array {
            $record = $mobile ? $this->mobile($root, $session, $credential, true) : $this->owned($root, $session, $credential);
            if (count($record['files']) >= $record['policy']['max_files']) {
                throw $this->failure('media_limit', 'Le nombre maximal de fichiers est atteint.', 422);
            }
            if (! $this->testUploader && (! is_string($file['tmp_name'] ?? null) || ! is_uploaded_file($file['tmp_name']))) {
                throw $this->failure('media_invalid_file', 'Fichier invalide.', 422);
            }
            $metadata = (new FileValidator())->inspect($file, $record['policy']);
            $sessionBytes = array_sum(array_column($record['files'], 'size'));
            $totalBytes = 0;
            foreach ($this->records($root) as $other) {
                $totalBytes += array_sum(array_column($other['files'], 'size'));
            }
            if ($sessionBytes + $metadata['size'] > self::MAX_SESSION_BYTES || $totalBytes + $metadata['size'] > self::MAX_BYTES) {
                throw $this->failure('media_capacity', 'La capacité de dépôt est atteinte.', 413);
            }
            $id = $session . bin2hex(random_bytes(16));
            $destination = $root . '/' . $id . '.bin';
            if (! ($this->uploader)($file['tmp_name'], $destination) || ! is_file($destination) || is_link($destination)) {
                throw $this->failure();
            }
            try {
                if (! chmod($destination, 0600) || ! touch($destination, $this->now())) {
                    throw $this->failure();
                }
                $record['files'][$id] = ['id' => $id] + $metadata;
                $this->write($root, $record);
            } catch (Throwable $error) {
                @unlink($destination);
                throw $error;
            }
            return $mobile ? ['state' => 'approved', 'count' => count($record['files']),
                'remaining' => max(0, $record['policy']['max_files'] - count($record['files']))]
                : ['files' => $this->publicFiles($record)];
        });
    }

    public function delete(string $session, string $owner, string $id): array
    {
        return $this->locked(function (string $root) use ($session, $owner, $id): array {
            $record = $this->owned($root, $session, $owner);
            if (! isset($record['files'][$id])) {
                throw $this->failure('media_not_found', 'Fichier introuvable.', 404);
            }
            $this->removeBinary($root, $id);
            unset($record['files'][$id]);
            $this->write($root, $record);
            return ['files' => $this->publicFiles($record)];
        });
    }

    public function bridge(string $session, string $owner): array
    {
        return $this->locked(function (string $root) use ($session, $owner): array {
            $record = $this->owned($root, $session, $owner);
            if (! $record['policy']['mobile_transfer']) {
                throw $this->failure('media_mobile_disabled', 'Le transfert depuis un téléphone est désactivé.', 403);
            }
            $secret = bin2hex(random_bytes(32));
            $record['bridge'] = ['secret_hash' => hash('sha256', $secret), 'state' => 'waiting',
                'expires_at' => $this->now() + 900, 'attempts' => 0];
            $this->write($root, $record);
            return ['mobile_url' => admin_url('admin-post.php?action=thecore_form_media_mobile&thecore-form-media=mobile') . '#' . $session . '.' . $secret,
                'expires_at' => $record['bridge']['expires_at']];
        });
    }

    public function exchange(string $bridge, string $secret): array
    {
        return $this->locked(function (string $root) use ($bridge, $secret): array {
            $record = $this->read($root, $bridge);
            $state = $this->bridgeState($record);
            if (
                ! $this->currentSite($record) || $record['committed'] || $state['state'] !== 'waiting' || ! $this->secret($secret)
                || ! hash_equals($record['bridge']['secret_hash'], hash('sha256', $secret))
            ) {
                throw $this->failure('media_bridge_invalid', 'Ce lien de transfert est expiré ou déjà utilisé.', 403);
            }
            $mobile = bin2hex(random_bytes(32));
            $code = (string) random_int(100000, 999999);
            unset($record['bridge']['secret_hash']);
            $record['bridge'] += ['mobile_hash' => hash('sha256', $mobile), 'pair_code' => $code];
            $record['bridge']['state'] = 'pending';
            $this->write($root, $record);
            return ['session' => $bridge, 'mobile' => $mobile, 'pair_code' => $code, 'state' => 'pending',
                'policy' => $record['policy'], 'expires_at' => $record['bridge']['expires_at']];
        });
    }

    public function approve(string $session, string $owner, string $code): array
    {
        return $this->locked(function (string $root) use ($session, $owner, $code): array {
            $record = $this->owned($root, $session, $owner);
            if ($this->bridgeState($record)['state'] !== 'pending') {
                throw $this->failure('media_bridge_invalid', 'Connexion au téléphone indisponible.', 409);
            }
            if (! preg_match('/\A[0-9]{6}\z/', $code) || ! hash_equals($record['bridge']['pair_code'], $code)) {
                $record['bridge']['attempts']++;
                if ($record['bridge']['attempts'] >= 5) {
                    $record['bridge'] = null;
                }
                $this->write($root, $record);
                throw $this->failure('media_pair_invalid', 'Le code de confirmation ne correspond pas.', 403);
            }
            $record['bridge']['state'] = 'approved';
            unset($record['bridge']['pair_code']);
            $this->write($root, $record);
            return ['state' => 'approved'];
        });
    }

    public function mobileStatus(string $session, string $mobile): array
    {
        return $this->locked(function (string $root) use ($session, $mobile): array {
            $record = $this->mobile($root, $session, $mobile, false);
            return ['state' => $this->bridgeState($record)['state'], 'count' => count($record['files']),
                'remaining' => max(0, $record['policy']['max_files'] - count($record['files'])),
                'policy' => $record['policy'], 'expires_at' => $record['bridge']['expires_at']];
        });
    }

    /** Finishing a phone channel never deletes files; desktop can continue or submit. */
    public function finish(string $session, string $credential, bool $mobile = false): array
    {
        return $this->locked(function (string $root) use ($session, $credential, $mobile): array {
            $record = $mobile ? $this->mobile($root, $session, $credential, false) : $this->owned($root, $session, $credential);
            $record['bridge'] = null;
            $this->write($root, $record);
            return ['state' => 'finished'];
        });
    }

    public function revoke(string $session, string $owner): array
    {
        return $this->locked(function (string $root) use ($session, $owner): array {
            $record = $this->owned($root, $session, $owner);
            $this->removeRecord($root, $record);
            return ['state' => 'revoked'];
        });
    }

    /** Prepare is read-only so fleet dry-runs can validate without consuming an upload. */
    public function validateSubmission(FormContext $context, FormDefinition $form, array $values, array $sessions): array
    {
        $mediaFields = array_filter($form->fields, static fn (array $field): bool => $field['type'] === 'media');
        if (array_diff_key($sessions, $mediaFields) || count($sessions) > FormDefinition::MAX_FIELDS) {
            throw $this->failure('media_invalid_session', 'Dépôt de fichiers invalide.', 422);
        }
        if ($sessions === [] && ! array_filter($mediaFields, static fn (array $field): bool => ($values[$field['id']] ?? []) !== [])) {
            return [];
        }
        return $this->locked(function (string $root) use ($context, $form, $values, $sessions, $mediaFields): array {
            $prepared = [];
            $seen = [];
            foreach ($mediaFields as $fieldId => $field) {
                $ids = $values[$fieldId] ?? [];
                if (! isset($sessions[$fieldId]) && $ids === []) {
                    continue;
                }
                $credentials = $sessions[$fieldId] ?? null;
                if (
                    ! is_array($credentials) || array_keys($credentials) !== ['session', 'owner']
                    && array_keys($credentials) !== ['owner', 'session']
                    || ! is_string($credentials['session'] ?? null) || ! is_string($credentials['owner'] ?? null)
                ) {
                    throw $this->fieldFailure($fieldId);
                }
                $record = $this->owned($root, $credentials['session'], $credentials['owner']);
                if (
                    $record['scope'] !== $this->scope($context, $fieldId) || isset($seen[$record['id']])
                    || ! is_array($ids) || count($ids) > $field['media']['max_files']
                ) {
                    throw $this->fieldFailure($fieldId);
                }
                $seen[$record['id']] = true;
                $files = [];
                foreach ($ids as $id) {
                    $file = $record['files'][$id] ?? null;
                    if (! is_array($file) || ! $this->matchesPolicy($file, $field['media']) || ! is_file($root . '/' . $id . '.bin')) {
                        throw $this->fieldFailure($fieldId);
                    }
                    $files[] = $file + ['url' => self::downloadUrl($id)];
                }
                $prepared[$fieldId] = ['session' => $record['id'], 'scope' => $record['scope'], 'files' => $files,
                    'retention_days' => $field['media']['retention_days']];
            }
            return $prepared;
        });
    }

    /** All selected sessions are sealed under the same lock before the first delivery. */
    public function commitSubmission(array $prepared, array $emailHashes = []): void
    {
        if ($prepared === []) {
            return;
        }
        $this->locked(function (string $root) use ($prepared, $emailHashes): void {
            $records = [];
            foreach ($prepared as $fieldId => $item) {
                $record = $this->read($root, $item['session']);
                if ($record['committed'] || $record['scope'] !== $item['scope']) {
                    throw $this->fieldFailure((string) $fieldId);
                }
                foreach ($item['files'] as $file) {
                    if (! isset($record['files'][$file['id']]) || ! is_file($root . '/' . $file['id'] . '.bin')) {
                        throw $this->fieldFailure((string) $fieldId);
                    }
                }
                $records[] = [$record, $item];
            }
            foreach ($records as [$record, $item]) {
                $keep = array_column($item['files'], null, 'id');
                foreach ($record['files'] as $id => $file) {
                    if (! isset($keep[$id])) {
                        $this->removeBinary($root, $id);
                    }
                }
                $record['files'] = array_intersect_key($record['files'], $keep);
                $record['committed'] = true;
                $record['bridge'] = null;
                unset($record['owner_hash']);
                $record['email_hashes'] = array_values(array_filter($emailHashes, static fn ($hash): bool => is_string($hash) && preg_match('/\A[a-f0-9]{64}\z/', $hash) === 1));
                $record['expires_at'] = $this->now() + $item['retention_days'] * 86400;
                $this->write($root, $record);
            }
        });
    }

    public function download(string $id): array
    {
        return $this->locked(function (string $root) use ($id): array {
            if (! $this->fileId($id)) {
                throw $this->failure('media_not_found', 'Fichier introuvable.', 404);
            }
            $record = $this->read($root, substr($id, 0, 32));
            if (! $this->currentSite($record) || ! $record['committed'] || ! isset($record['files'][$id]) || ! is_file($root . '/' . $id . '.bin') || is_link($root . '/' . $id . '.bin')) {
                throw $this->failure('media_not_found', 'Fichier introuvable.', 404);
            }
            return $record['files'][$id] + ['path' => $root . '/' . $id . '.bin'];
        });
    }

    /** Called after archive erasure, including its privacy and retention cleanup paths. */
    public function forgetIds(array $ids): void
    {
        $ids = array_values(array_filter($ids, fn ($id): bool => is_string($id) && $this->fileId($id)));
        if ($ids === []) {
            return;
        }
        $this->locked(function (string $root) use ($ids): void {
            foreach (array_unique(array_map(static fn (string $id): string => substr($id, 0, 32), $ids)) as $session) {
                if (! is_file($root . '/' . $session . '.json')) {
                    continue;
                }
                $record = $this->read($root, $session, true);
                if (! $this->currentSite($record)) {
                    throw $this->failure('media_forbidden', 'Dépôt de fichiers non autorisé.', 403);
                }
                foreach ($ids as $id) {
                    if (isset($record['files'][$id])) {
                        $this->removeBinary($root, $id);
                        unset($record['files'][$id]);
                    }
                }
                if ($record['files'] === []) {
                    $this->removeRecord($root, $record);
                } else {
                    $this->write($root, $record);
                }
            }
        });
    }

    public function cleanup(): void
    {
        $this->locked(fn (string $root) => $this->purge($root));
    }

    /** Uninstall removes only this site's validated metadata and its referenced binaries. */
    public function purgeForSite(): void
    {
        $this->locked(function (string $root): void {
            foreach ($this->records($root) as $record) {
                if ($this->currentSite($record)) {
                    $this->removeRecord($root, $record);
                }
            }
        });
    }

    public function byEmailHash(string $hash, bool $erase, int $offset = 0, int $limit = 100): array
    {
        return $this->locked(function (string $root) use ($hash, $erase, $offset, $limit): array {
            $found = array_values(array_filter($this->records($root), fn (array $record): bool => $this->currentSite($record) && in_array($hash, $record['email_hashes'] ?? [], true)));
            usort($found, static fn (array $first, array $second): int => strcmp($first['id'], $second['id']));
            $batch = array_slice($found, max(0, $offset), min(100, max(1, $limit)));
            if ($erase) {
                foreach ($batch as $record) {
                    $this->removeRecord($root, $record);
                }
            }
            return ['records' => $batch, 'done' => count($found) <= max(0, $offset) + count($batch)];
        });
    }

    public static function downloadUrl(string $id): string
    {
        return admin_url('admin-post.php?action=thecore_form_media_download&media=' . rawurlencode($id));
    }

    public static function emailHashes(FormDefinition $form, array $values): array
    {
        if (! Secrets::personalDataLookupIsPersistent()) {
            throw new SubmissionException('media_storage_unavailable', 'Le stockage sécurisé des fichiers est indisponible.', 503);
        }
        $identity = new EmailIdentity(Secrets::personalDataLookup());
        $hashes = [];
        foreach ($form->fields as $id => $field) {
            if ($field['type'] === 'email' && is_string($values[$id] ?? null) && $values[$id] !== '') {
                $hash = $identity->hash($values[$id]);
                if ($hash !== '') {
                    $hashes[] = $hash;
                }
            }
        }
        return array_values(array_unique($hashes));
    }

    private function owned(string $root, string $session, string $owner): array
    {
        $record = $this->read($root, $session);
        if (! $this->currentSite($record) || $record['committed'] || ! $this->secret($owner) || ! hash_equals($record['owner_hash'] ?? '', hash('sha256', $owner))) {
            throw $this->failure('media_forbidden', 'Dépôt de fichiers non autorisé.', 403);
        }
        return $record;
    }

    private function mobile(string $root, string $session, string $mobile, bool $requireApproval): array
    {
        $record = $this->read($root, $session);
        $state = $this->bridgeState($record)['state'];
        if (
            ! $this->currentSite($record) || $record['committed'] || ! $this->secret($mobile) || ! in_array($state, $requireApproval ? ['approved'] : ['pending', 'approved'], true)
            || ! hash_equals($record['bridge']['mobile_hash'] ?? '', hash('sha256', $mobile))
        ) {
            throw $this->failure('media_mobile_forbidden', 'Connexion au téléphone expirée ou non confirmée.', 403);
        }
        return $record;
    }

    private function bridgeState(array $record): array
    {
        $bridge = $record['bridge'];
        if (! is_array($bridge)) {
            return ['state' => 'none'];
        }
        if ($bridge['expires_at'] <= $this->now()) {
            return ['state' => 'expired', 'expires_at' => $bridge['expires_at']];
        }
        $state = ['state' => $bridge['state'], 'expires_at' => $bridge['expires_at']];
        if ($bridge['state'] === 'pending') {
            $state['pair_code'] = $bridge['pair_code'];
        }
        return $state;
    }

    private function publicFiles(array $record): array
    {
        return array_values($record['files']);
    }

    private function scope(FormContext $context, string $field): array
    {
        return ['site' => hash('sha256', home_url('/')), 'blog' => get_current_blog_id(),
            'post' => $context->postId(), 'form' => $context->widgetId(), 'field' => $field];
    }

    private function currentSite(array $record): bool
    {
        return ($record['scope']['site'] ?? null) === hash('sha256', home_url('/'))
            && ($record['scope']['blog'] ?? null) === get_current_blog_id();
    }

    private function matchesPolicy(array $file, array $policy): bool
    {
        $mode = str_starts_with($file['mime'], 'image/') ? 'photos' : 'videos';
        return ($policy['mode'] === 'both' || $policy['mode'] === $mode) && $file['size'] <= $policy['max_file_size_mb'] * 1048576;
    }

    private function locked(callable $callback): mixed
    {
        $root = $this->root();
        if (is_link($root . '/.lock')) {
            throw $this->failure();
        }
        $lock = @fopen($root . '/.lock', 'c+b');
        if ($lock === false || ! chmod($root . '/.lock', 0600) || ! flock($lock, LOCK_EX)) {
            if (is_resource($lock)) {
                fclose($lock);
            }
            throw $this->failure();
        }
        try {
            return $callback($root);
        } finally {
            flock($lock, LOCK_UN);
            fclose($lock);
        }
    }

    private function root(): string
    {
        $base = defined('ABSPATH') ? rtrim(ABSPATH, '/\\') : '';
        $configured = $this->directory ?? (defined('THECORE_FORM_MEDIA_DIR') ? THECORE_FORM_MEDIA_DIR : null);
        $path = $configured ?? ($base !== '' ? dirname($base) . '/.thecore-form-media-' . substr(hash('sha256', $base), 0, 16) : '');
        if (! is_string($path) || ! str_starts_with($path, '/') || str_contains($path, "\0") || is_link($path)) {
            throw $this->failure();
        }
        $parent = realpath(dirname($path));
        if ($parent === false || $parent === '/' || $parent . '/' . basename($path) !== rtrim($path, '/')) {
            throw $this->failure();
        }
        foreach ([$base, is_string($_SERVER['DOCUMENT_ROOT'] ?? null) ? $_SERVER['DOCUMENT_ROOT'] : ''] as $webroot) {
            $webroot = $webroot !== '' ? realpath($webroot) : false;
            if ($webroot !== false && ($path === $webroot || str_starts_with($path, rtrim($webroot, '/') . '/'))) {
                throw $this->failure();
            }
        }
        if ((! is_dir($path) && ! @mkdir($path, 0700)) || realpath($path) !== $path || ! is_writable($path)) {
            throw $this->failure();
        }
        $marker = $path . '/.thecore-media-store';
        if (is_link($marker)) {
            throw $this->failure();
        }
        if (! is_file($marker)) {
            // Never chmod or adopt an existing general-purpose directory containing unrelated data.
            $entries = scandir($path);
            if ($entries !== ['.', '..']) {
                throw $this->failure();
            }
            $handle = @fopen($marker, 'xb');
            if ($handle === false) {
                throw $this->failure();
            }
            try {
                if (! chmod($marker, 0600) || fwrite($handle, "thecore-form-media-v1\n") !== 22) {
                    throw $this->failure();
                }
            } finally {
                fclose($handle);
            }
        }
        if (filesize($marker) !== 22 || file_get_contents($marker) !== "thecore-form-media-v1\n" || ! @chmod($path, 0700)) {
            throw $this->failure();
        }
        return $path;
    }

    private function read(string $root, string $id, bool $allowExpired = false): array
    {
        if (! preg_match('/\A[a-f0-9]{32}\z/', $id)) {
            throw $this->failure('media_invalid_session', 'Dépôt de fichiers invalide.', 403);
        }
        $path = $root . '/' . $id . '.json';
        if (! is_file($path) || is_link($path) || filesize($path) > 65536) {
            throw $this->failure('media_expired', 'Le dépôt a expiré. Ajoutez à nouveau vos fichiers.', 410);
        }
        $json = file_get_contents($path);
        $record = is_string($json) ? json_decode($json, true, 16) : null;
        if (
            ! is_array($record) || ($record['id'] ?? '') !== $id || ! is_array($record['files'] ?? null)
            || ! is_int($record['expires_at'] ?? null) || ! is_bool($record['committed'] ?? null)
        ) {
            throw $this->failure();
        }
        if (! $allowExpired && $record['expires_at'] <= $this->now()) {
            throw $this->failure('media_expired', 'Le dépôt a expiré. Ajoutez à nouveau vos fichiers.', 410);
        }
        return $record;
    }

    private function write(string $root, array $record): void
    {
        $json = json_encode($record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        $temporary = $root . '/.tmp-' . bin2hex(random_bytes(16));
        $handle = @fopen($temporary, 'xb');
        if ($handle === false) {
            throw $this->failure();
        }
        $written = false;
        try {
            if (! chmod($temporary, 0600) || fwrite($handle, $json) !== strlen($json) || ! fflush($handle)) {
                throw $this->failure();
            }
            $written = true;
        } finally {
            fclose($handle);
            if (! $written) {
                @unlink($temporary);
            }
        }
        if (! rename($temporary, $root . '/' . $record['id'] . '.json')) {
            @unlink($temporary);
            throw $this->failure();
        }
    }

    private function records(string $root): array
    {
        $files = glob($root . '/*.json');
        if (! is_array($files) || count($files) > self::MAX_SESSIONS) {
            throw $this->failure();
        }
        return array_map(fn (string $path): array => $this->read($root, basename($path, '.json'), true), $files);
    }

    private function purge(string $root): void
    {
        foreach ($this->records($root) as $record) {
            if ($record['expires_at'] <= $this->now()) {
                $this->removeRecord($root, $record);
            }
        }
        $referenced = [];
        foreach ($this->records($root) as $record) {
            $referenced += $record['files'];
        }
        foreach (glob($root . '/*.bin') ?: [] as $path) {
            $id = basename($path, '.bin');
            if ($this->fileId($id) && ! isset($referenced[$id]) && filemtime($path) < $this->now() - 86400) {
                $this->removeBinary($root, $id);
            }
        }
        foreach (glob($root . '/.tmp-*') ?: [] as $path) {
            if (
                preg_match('/\A\.tmp-[a-f0-9]{32}\z/', basename($path)) && filemtime($path) < $this->now() - 86400
                && ! unlink($path)
            ) {
                throw $this->failure();
            }
        }
    }

    private function removeRecord(string $root, array $record): void
    {
        foreach ($record['files'] as $id => $file) {
            $this->removeBinary($root, (string) $id);
        }
        if (! unlink($root . '/' . $record['id'] . '.json')) {
            throw $this->failure();
        }
    }

    private function removeBinary(string $root, string $id): void
    {
        if (! $this->fileId($id)) {
            throw $this->failure();
        }
        $path = $root . '/' . $id . '.bin';
        if ((is_file($path) || is_link($path)) && ! unlink($path)) {
            throw $this->failure();
        }
    }

    private function secret(string $secret): bool
    {
        return preg_match('/\A[a-f0-9]{64}\z/', $secret) === 1;
    }

    private function fileId(string $id): bool
    {
        return preg_match('/\A[a-f0-9]{64}\z/', $id) === 1;
    }

    private function now(): int
    {
        return ($this->clock)();
    }

    private function fieldFailure(string $field): SubmissionException
    {
        return new SubmissionException(
            'media_invalid_reference',
            'Veuillez ajouter à nouveau les fichiers de ce champ.',
            422,
            [$field => 'Fichiers expirés, invalides ou provenant d’un autre formulaire.']
        );
    }

    private function failure(string $code = 'media_storage_unavailable', string $message = 'Le stockage sécurisé des fichiers est indisponible.', int $status = 503): SubmissionException
    {
        return new SubmissionException($code, $message, $status);
    }
}
