<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Media;

use TheCore\ElementorWidgets\Forms\ConfigurationException;

/** Only saved Elementor properties are allowed to define upload rules. */
final class Policy
{
    public static function fromProps(array $props): array
    {
        $mode = $props['media-mode'] ?? 'both';
        $mobile = $props['mobile-transfer'] ?? true;
        if (! in_array($mode, ['photos', 'videos', 'both'], true) || ! is_bool($mobile)) {
            throw new ConfigurationException('Invalid media field policy.');
        }
        return ['mode' => $mode,
            'max_files' => self::integer($props['max-files'] ?? 5, 1, 10),
            'max_file_size_mb' => self::integer($props['max-file-size-mb'] ?? 25, 1, 150),
            'mobile_transfer' => $mobile,
            'retention_days' => self::integer($props['retention-days'] ?? 30, 1, 365)];
    }

    private static function integer(mixed $value, int $minimum, int $maximum): int
    {
        // Atomic Number props can arrive as a JSON float, but never accept strings or fractions.
        if (
            (! is_int($value) && ! is_float($value)) || ! is_finite((float) $value)
            || (float) (int) $value !== (float) $value || $value < $minimum || $value > $maximum
        ) {
            throw new ConfigurationException('Invalid media field limit.');
        }
        return (int) $value;
    }
}
