<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Media;

use TheCore\ElementorWidgets\FormSecurity\Support\ContextToken;
use TheCore\ElementorWidgets\FormSecurity\Support\Secrets;
use TheCore\ElementorWidgets\Forms\FormDefinition;
use TheCore\ElementorWidgets\Forms\FormProvider;
use TheCore\ElementorWidgets\Forms\SubmissionException;
use TheCore\ElementorWidgets\Forms\SubmissionProtection;

final class Service
{
    public function __construct(
        private readonly FormProvider $forms,
        private readonly SubmissionProtection $security,
        private readonly ContextToken $tokens,
        private readonly Store $store
    ) {
    }

    public function create(array $request): array
    {
        $context = $this->tokens->decode($request['context']);
        if ($context === null || $context->fieldId() !== FormDefinition::SECURITY_FIELD) {
            throw new SubmissionException('invalid_context', 'Formulaire invalide.', 403);
        }
        $form = $this->forms->find($context->postId(), $context->widgetId());
        $field = $form->fields[$request['field']] ?? null;
        if (! is_array($field) || $field['type'] !== 'media') {
            throw new SubmissionException('media_invalid_field', 'Champ de fichiers invalide.', 422);
        }
        // Each upload session needs a fresh one-use anti-spam proof. Final submit needs another.
        $this->security->check($context, $request);
        // Establish durable privacy lookup on the write path, never during a submission dry-run.
        Secrets::personalDataLookup();
        if (! Secrets::personalDataLookupIsPersistent()) {
            throw new SubmissionException('media_storage_unavailable', 'Le stockage sécurisé des fichiers est indisponible.', 503);
        }
        return $this->store->create($context, $field);
    }

    public function operation(string $operation, array $request, array $files = []): array
    {
        return match ($operation) {
            'session' => $this->create($request),
            'status' => $this->store->status($request['session'], $request['owner']),
            'upload' => $this->store->upload($request['session'], $request['owner'] ?? $request['mobile'], isset($request['mobile']), $files['file']),
            'delete' => $this->store->delete($request['session'], $request['owner'], $request['id']),
            'bridge' => $this->store->bridge($request['session'], $request['owner']),
            'exchange' => $this->store->exchange($request['bridge'], $request['secret']),
            'approve' => $this->store->approve($request['session'], $request['owner'], $request['pair_code']),
            'mobile-status' => $this->store->mobileStatus($request['session'], $request['mobile']),
            'finish' => $this->store->finish($request['session'], $request['owner'] ?? $request['mobile'], isset($request['mobile'])),
            'revoke' => $this->store->revoke($request['session'], $request['owner']),
        };
    }
}
