<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Media;

use TheCore\ElementorWidgets\Forms\SubmissionException;

/** Reject browser MIME assertions: inspect the actual temporary upload content. */
final class FileValidator
{
    private const TYPES = [
        'image/jpeg' => ['jpg', 'jpeg'], 'image/png' => ['png'], 'image/webp' => ['webp'],
        'video/mp4' => ['mp4', 'm4v'], 'video/quicktime' => ['mov'], 'video/webm' => ['webm'],
    ];

    public function inspect(array $file, array $policy): array
    {
        if (
            ($file['error'] ?? null) !== UPLOAD_ERR_OK || ! is_string($file['tmp_name'] ?? null)
            || ! is_string($file['name'] ?? null) || strlen($file['name']) > 250
            || preg_match('/[\x00-\x1f\x7f]/', $file['name']) || ! is_file($file['tmp_name'])
            || is_link($file['tmp_name']) || ! class_exists(\finfo::class)
        ) {
            throw $this->failure();
        }
        $size = filesize($file['tmp_name']);
        if (! is_int($size) || $size < 1 || $size > ($policy['max_file_size_mb'] ?? 0) * 1048576) {
            throw new SubmissionException('media_too_large', 'Le fichier dépasse la taille autorisée.', 413);
        }
        $mime = (new \finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (! is_string($mime) || ! isset(self::TYPES[$mime]) || ! in_array($extension, self::TYPES[$mime], true)) {
            throw $this->failure();
        }
        $photo = str_starts_with($mime, 'image/');
        if (($policy['mode'] ?? '') !== 'both' && ($policy['mode'] ?? '') !== ($photo ? 'photos' : 'videos')) {
            throw $this->failure();
        }
        if ($photo) {
            $image = @getimagesize($file['tmp_name']);
            if (
                ! is_array($image) || ($image['mime'] ?? '') !== $mime || $image[0] < 1 || $image[1] < 1
                || $image[0] > 30000 || $image[1] > 30000 || $image[0] * $image[1] > 120000000
            ) {
                throw $this->failure();
            }
        } else {
            // WordPress' bundled getID3 reads container metadata; a fabricated MIME signature alone is insufficient.
            if (
                ! function_exists('wp_read_video_metadata') && defined('ABSPATH')
                && is_file(ABSPATH . 'wp-admin/includes/media.php')
            ) {
                require_once ABSPATH . 'wp-admin/includes/media.php';
            }
            $metadata = function_exists('wp_read_video_metadata') ? wp_read_video_metadata($file['tmp_name']) : false;
            if (
                ! is_array($metadata) || ($metadata['width'] ?? 0) < 1 || ($metadata['height'] ?? 0) < 1
                || ($metadata['length'] ?? 0) <= 0
            ) {
                throw $this->failure();
            }
        }
        // The stored filename is an opaque ID. This cleaned name is display-only, never a path or mail header.
        $name = basename(str_replace('\\', '/', $file['name']));
        $name = preg_replace('/[^\pL\pN ._()-]/u', '_', $name);
        if (! is_string($name) || $name === '' || strlen($name) > 250) {
            throw $this->failure();
        }
        return ['name' => $name, 'mime' => $mime, 'size' => $size];
    }

    private function failure(): SubmissionException
    {
        return new SubmissionException('media_invalid_file', 'Format non autorisé ou fichier invalide. Utilisez JPG, PNG, WebP, MP4, MOV ou WebM selon le champ.', 422);
    }
}
