<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Media;

use TheCore\ElementorWidgets\Contracts\Bootable;
use TheCore\ElementorWidgets\FormSecurity\Support\EmailIdentity;
use TheCore\ElementorWidgets\FormSecurity\Support\Secrets;
use Throwable;

/** Lifecycle stays registered even if new form widgets are disabled later. */
final class Module implements Bootable
{
    public const HISTORY_OPTION = 'thecore_form_media_history';
    private const CLEANUP_HOOK = 'thecore_form_media_cleanup';
    private const PRIVACY_ID = 'thecore-form-media';

    public function register(): void
    {
        if (($_GET['thecore-form-media'] ?? null) === 'mobile' && ! defined('DONOTCACHEPAGE')) {
            define('DONOTCACHEPAGE', true);
        }
        add_action('admin_post_thecore_form_media_download', [$this, 'download']);
        add_action('admin_post_nopriv_thecore_form_media_download', [$this, 'denyDownload']);
        add_action('admin_post_thecore_form_media_mobile', [$this, 'mobilePage']);
        add_action('admin_post_nopriv_thecore_form_media_mobile', [$this, 'mobilePage']);
        add_action('init', [$this, 'schedule']);
        add_action(self::CLEANUP_HOOK, [$this, 'cleanup']);
        add_filter('wp_privacy_personal_data_exporters', [$this, 'exporter']);
        add_filter('wp_privacy_personal_data_erasers', [$this, 'eraser']);
    }

    public function schedule(): void
    {
        if (get_option(self::HISTORY_OPTION, false) && ! wp_next_scheduled(self::CLEANUP_HOOK)) {
            wp_schedule_event(time() + 300, 'hourly', self::CLEANUP_HOOK);
        }
    }

    public function cleanup(): void
    {
        try {
            (new Store())->cleanup();
        } catch (Throwable) {
            // The next cron run retries. No private filenames or contents are logged.
        }
    }

    public static function deactivate(): void
    {
        wp_clear_scheduled_hook(self::CLEANUP_HOOK);
    }

    /** Caller switches blog for network uninstall. Throw rather than silently orphan private files. */
    public static function uninstall(): void
    {
        self::deactivate();
        if (get_option(self::HISTORY_OPTION, false)) {
            (new Store())->purgeForSite();
            delete_option(self::HISTORY_OPTION);
        }
    }

    public function denyDownload(): void
    {
        nocache_headers();
        wp_die('Connexion administrateur requise.', '', ['response' => 403]);
    }

    public function download(): void
    {
        if (! current_user_can('manage_options')) {
            $this->denyDownload();
            return;
        }
        try {
            $id = $_GET['media'] ?? null;
            if (! is_string($id)) {
                throw new \RuntimeException('Invalid media ID.');
            }
            $file = (new Store())->download($id);
            nocache_headers();
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . preg_replace('/[^A-Za-z0-9._-]/', '_', $file['name']) . '"; filename*=UTF-8\'\'' . rawurlencode($file['name']));
            header('Content-Length: ' . $file['size']);
            header('X-Content-Type-Options: nosniff');
            header('X-Robots-Tag: noindex, nofollow');
            header('Referrer-Policy: no-referrer');
            header("Content-Security-Policy: sandbox; default-src 'none'");
            readfile($file['path']);
            exit;
        } catch (Throwable) {
            nocache_headers();
            wp_die('Fichier introuvable ou expiré.', '', ['response' => 404]);
        }
    }

    /** Isolated, cache-free page: the fragment secret is read/erased only by first-party JavaScript. */
    public function mobilePage(): void
    {
        if (($_GET['thecore-form-media'] ?? null) !== 'mobile') {
            return;
        }
        if (! defined('DONOTCACHEPAGE')) {
            define('DONOTCACHEPAGE', true);
        }
        nocache_headers();
        header('Content-Type: text/html; charset=UTF-8');
        header('Referrer-Policy: no-referrer');
        header('X-Robots-Tag: noindex, nofollow');
        header('X-Content-Type-Options: nosniff');
        $nonce = base64_encode(random_bytes(18));
        header("Content-Security-Policy: default-src 'none'; script-src 'self' 'nonce-{$nonce}'; style-src 'nonce-{$nonce}'; connect-src 'self'; img-src 'self' data:; base-uri 'none'; form-action 'none'; frame-ancestors 'none'");
        $configuration = wp_json_encode(['endpoint' => rest_url('thecore-elementor-widgets/v1/forms/media/')]);
        $source = esc_url(THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/form-media-mobile.js?ver=' . rawurlencode(THECORE_ELEMENTOR_WIDGETS_VERSION));
        echo '<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">';
        echo '<meta name="robots" content="noindex,nofollow"><title>Ajouter des photos ou vidéos</title>';
        echo '<style nonce="' . esc_attr($nonce) . '">*{box-sizing:border-box}body{font:17px/1.55 system-ui,sans-serif;margin:0;background:#f5f5f5;color:#17242c}main{max-width:40rem;margin:4vh auto;padding:1.5rem;background:white;border-radius:1rem}button,label,input{font:inherit}button{padding:.8rem 1rem;margin:.4rem .4rem .4rem 0;border:1px solid #526975;border-radius:.5rem;cursor:pointer}button:focus-visible,input:focus-visible{outline:3px solid #1b77b7;outline-offset:3px}input[type=file]{max-width:100%}code{font-size:2rem;letter-spacing:.2em}h1{line-height:1.15;font-size:1.8rem}noscript{display:block;padding:1rem}</style>';
        $stylesheet = dirname(__DIR__, 3) . '/assets/frontend/form-media-mobile.css';
        if (is_file($stylesheet)) {
            echo '<style nonce="' . esc_attr($nonce) . '">';
            readfile($stylesheet);
            echo '</style>';
        }
        echo '</head><body>';
        echo '<main data-thecore-media-mobile><h1>Ajouter des photos ou vidéos</h1><p data-thecore-mobile-status role="status" aria-live="polite" tabindex="-1"></p><div data-thecore-mobile-ui></div><noscript>JavaScript est nécessaire pour ce transfert sécurisé.</noscript></main>';
        echo '<script nonce="' . esc_attr($nonce) . '">window.TheCoreFormMediaMobile=' . $configuration . ';</script><script nonce="' . esc_attr($nonce) . '" src="' . $source . '" defer></script></body></html>';
        exit;
    }

    public function exporter(array $exporters): array
    {
        if (get_option(self::HISTORY_OPTION, false)) {
            $exporters[self::PRIVACY_ID] = ['exporter_friendly_name' => 'The Core — Photos et vidéos des formulaires',
                'callback' => [$this, 'exportPersonalData']];
        }
        return $exporters;
    }

    public function eraser(array $erasers): array
    {
        if (get_option(self::HISTORY_OPTION, false)) {
            $erasers[self::PRIVACY_ID] = ['eraser_friendly_name' => 'The Core — Photos et vidéos des formulaires',
                'callback' => [$this, 'erasePersonalData']];
        }
        return $erasers;
    }

    public function exportPersonalData(string $email, int $page = 1): array|\WP_Error
    {
        try {
            $hash = $this->emailHash($email);
            $batch = $hash === '' ? ['records' => [], 'done' => true] : (new Store())->byEmailHash($hash, false, (max(1, $page) - 1) * 100);
            $items = [];
            foreach ($batch['records'] as $record) {
                $data = [['name' => 'Effacement prévu (UTC)', 'value' => gmdate('Y-m-d H:i:s', $record['expires_at'])]];
                foreach ($record['files'] as $file) {
                    $data[] = ['name' => 'Fichier', 'value' => $file['name'] . ' (' . $file['mime'] . ', ' . $file['size'] . ' octets)'];
                }
                $items[] = ['group_id' => self::PRIVACY_ID, 'group_label' => 'Photos et vidéos des formulaires',
                    'item_id' => self::PRIVACY_ID . '-' . $record['id'], 'data' => $data];
            }
            return ['data' => $items, 'done' => $batch['done']];
        } catch (Throwable) {
            return $this->privacyError();
        }
    }

    public function erasePersonalData(string $email, int $page = 1): array|\WP_Error
    {
        unset($page);
        try {
            $hash = $this->emailHash($email);
            $batch = $hash === '' ? ['records' => [], 'done' => true] : (new Store())->byEmailHash($hash, true);
            return ['items_removed' => $batch['records'] !== [], 'items_retained' => false, 'messages' => [], 'done' => $batch['done']];
        } catch (Throwable) {
            return $this->privacyError();
        }
    }

    private function emailHash(string $email): string
    {
        if (! Secrets::personalDataLookupIsPersistent()) {
            throw new \RuntimeException('Privacy lookup unavailable.');
        }
        return (new EmailIdentity(Secrets::personalDataLookup()))->hash($email);
    }

    private function privacyError(): \WP_Error
    {
        return new \WP_Error('thecore_media_unavailable', 'Les fichiers n’ont pas pu être consultés ou effacés. Vérifiez le stockage sécurisé puis réessayez.');
    }
}
