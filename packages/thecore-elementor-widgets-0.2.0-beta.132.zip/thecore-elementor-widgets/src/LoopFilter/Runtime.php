<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\LoopFilter;

use Elementor\Plugin;
use TheCore\ElementorWidgets\Contracts\Bootable;
use TheCore\ElementorWidgets\Elementor\Atomic\Widgets\LoopFilter\Config;

final class Runtime implements Bootable
{
    public const HANDLE = 'thecore-loop-filter';
    private array $bound = [];
    private static string $template = '';
    private static array $fragment = [];
    private ?int $uncached = null;

    public function register(): void
    {
        add_action('wp_enqueue_scripts', [$this, 'registerAssets'], 6);
        add_action('elementor/editor/before_enqueue_scripts', [$this, 'registerAssets'], 6);
        add_action('elementor/atomic-widgets/frontend/loader/scripts/register', [$this, 'registerAssets']);
        add_filter('elementor/frontend/builder_content_data', [$this, 'prepare'], 20, 2);
        add_action('elementor/frontend/get_builder_content', [$this, 'finishDocument'], 99);
        add_filter('template_include', [$this, 'chooseTemplate'], PHP_INT_MAX);
    }

    public function registerAssets(): void
    {
        $base = THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/loop-filter';
        wp_register_style(self::HANDLE, $base . '.css', [], THECORE_ELEMENTOR_WIDGETS_VERSION);
        wp_register_script(self::HANDLE, $base . '.js', [], THECORE_ELEMENTOR_WIDGETS_VERSION, ['in_footer' => true, 'strategy' => 'defer']);
    }

    private static function publicPost(): ?\WP_Post
    {
        $post = get_queried_object();
        return is_singular() && !is_preview() && !isset($_GET['elementor-preview']) && !is_feed() && !is_embed()
            && $post instanceof \WP_Post && $post->post_status === 'publish' && $post->post_password === ''
            && is_post_publicly_viewable($post) ? $post : null;
    }

    public function prepare(array $nodes, int $postId): array
    {
        if ((int) get_queried_object_id() !== $postId || !self::publicPost()) {
            return $nodes;
        }
        // Elementor already loaded this meta value. Ordinary pages need no recursive element walk, term lookup or assets.
        $raw = get_post_meta($postId, '_elementor_data', true);
        if (is_string($raw) && !str_contains($raw, '"thecore-loop-filter"')) {
            return $nodes;
        }
        $bindings = Bindings::discover($nodes);
        if (!$bindings) {
            return $nodes;
        }
        $request = wp_unslash($_GET);
        foreach ($bindings as $binding) {
            $state = Bindings::state($binding, $request);
            $id = $binding['id'];
            if (!isset($this->bound[$id])) {
                $this->bound[$id] = true;
                add_action('elementor/query/' . $binding['hook'], static function ($query, $element) use ($id, $postId, $binding, $state) {
                    $doc = Plugin::$instance->documents->get_current();
                    if (
                        $query instanceof \WP_Query && $element && $element->get_id() === $id
                        && $doc && (int) $doc->get_main_id() === $postId
                    ) {
                        Bindings::restrict($query, $binding, $state);
                    }
                }, PHP_INT_MAX, 2);
            }
            if (
                array_key_exists($binding['key'], $request) || array_key_exists('e-page-' . $id, $request)
                || self::$fragment !== []
            ) {
                // A filtered or pruned render may neither read nor populate the full Elementor document cache.
                $this->uncached = $postId;
                add_filter('pre_option_elementor_element_cache_ttl', [$this, 'disableDocumentCache']);
                if (!defined('DONOTCACHEPAGE')) {
                    define('DONOTCACHEPAGE', true);
                }
            }
        }
        $nodes = Bindings::wire($nodes, $bindings);
        if (self::$fragment && isset($bindings[self::$fragment['loop']])) {
            $b = $bindings[self::$fragment['loop']];
            $nodes = Bindings::branch($nodes, [$b['id'], $b['filter']]);
        }
        return $nodes;
    }

    public function disableDocumentCache(): string
    {
        return 'disable';
    }

    public function finishDocument($document): void
    {
        if ($this->uncached !== null && (int) $document->get_main_id() === $this->uncached) {
            remove_filter('pre_option_elementor_element_cache_ttl', [$this, 'disableDocumentCache']);
            $this->uncached = null;
        }
    }

    public function chooseTemplate($template)
    {
        if (!array_key_exists(Fragment::PARAM, $_GET)) {
            return $template;
        }
        if (!defined('DONOTCACHEPAGE')) {
            define('DONOTCACHEPAGE', true);
        }
        nocache_headers();
        header('X-Robots-Tag: noindex, nofollow, noarchive', true);
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
            header('Allow: GET');
            self::error('method_not_allowed', 405);
        }
        $post = self::publicPost();
        $raw = wp_unslash($_GET[Fragment::PARAM]);
        $target = is_string($raw) ? Config::target($raw) : '';
        if (
            !$post || !$target || $target !== $raw || !class_exists(Plugin::class)
            || !is_string($template) || !is_readable($template)
            || !in_array(pathinfo($template, PATHINFO_EXTENSION), ['php', 'html'], true)
        ) {
            self::error('not_available', 404);
        }
        $doc = Plugin::$instance->documents->get($post->ID);
        $nodes = $doc && $doc->is_built_with_elementor() ? $doc->get_elements_data() : [];
        $binding = Bindings::discover($nodes)[$target] ?? null;
        if (!$binding) {
            self::error('not_available', 404);
        }
        $state = Bindings::state($binding, wp_unslash($_GET));
        if (!$state) {
            self::error('invalid_filter_or_page', 400);
        }
        $node = \Elementor\Utils::find_element_recursive($nodes, $target);
        if (!$node || !Fragment::compatible($node)) {
            self::error('full_navigation_required', 409);
        }
        self::$fragment = ['loop' => $target, 'term' => $state['term'], 'page' => $state['page']];
        self::$template = $template;
        return __DIR__ . '/fragment-template.php';
    }

    public static function originalTemplate(): string
    {
        return self::$template;
    }

    public static function respond(string $html): void
    {
        $status = http_response_code();
        if ($status && $status !== 200) {
            self::error('not_available', 404);
        }
        $fragment = Fragment::extract($html, self::$fragment['loop']);
        if ($fragment === null) {
            self::error('full_navigation_required', 409);
        }
        // The optional The Core output-buffer lazy loader normally transforms the complete HTML after the template.
        $lazy = 'TheCore\\Modules\\LazyLoadManagement\\Frontend\\LLFrontend';
        $processor = 'TheCore\\Modules\\LazyLoadManagement\\Frontend\\LLProcessing';
        if (
            is_callable([$lazy, 'is_module_enabled']) && $lazy::is_module_enabled()
            && is_callable([$lazy, 'get_config']) && is_callable([$processor, 'transform_html'])
        ) {
            $fragment = $processor::transform_html($fragment, $lazy::get_config());
        }
        self::json(self::$fragment + ['html' => $fragment], 200);
    }

    private static function error(string $code, int $status): void
    {
        self::json(['error' => $code], $status);
    }

    private static function json(array $body, int $status): void
    {
        // Cache keys for a public document must never interchange its HTML with JSON.
        nocache_headers();
        header('Cache-Control: private, no-store, max-age=0', true);
        header('X-Robots-Tag: noindex, nofollow, noarchive', true);
        wp_send_json($body, $status, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_INVALID_UTF8_SUBSTITUTE);
    }
}
