<?php

declare(strict_types=1);

use TheCore\ElementorWidgets\LoopFilter\Runtime;

// WordPress includes this file in the real template scope, including its normal globals and access restrictions.
defined('ABSPATH') || exit;
if (Runtime::originalTemplate() === '') {
    return;
}
$thecoreLoopDepth = ob_get_level();
ob_start();
try {
    include Runtime::originalTemplate();
} finally {
    // Finish any buffers owned by late theme hooks into our capture, leaving pre-existing server buffers untouched.
    while (ob_get_level() > $thecoreLoopDepth + 1 && ob_end_flush()) {
    }
    $thecoreLoopPublicHtml = (string) ob_get_clean();
}
Runtime::respond($thecoreLoopPublicHtml);
