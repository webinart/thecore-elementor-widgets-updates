<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\LoopFilter;

use TheCore\ElementorWidgets\Elementor\Atomic\Widgets\LoopFilter\Config;

/** Derive the only permissible targets from the published document, never from the request. */
final class Bindings
{
    public static function discover(array $nodes): array
    {
        $filters = [];
        $loops = [];
        self::index($nodes, $filters, $loops);
        $result = [];
        $keys = [];
        foreach ($filters as $filter) {
            $settings = $filter['settings'] ?? [];
            $id = Config::target(self::value($settings['target_loop'] ?? null));
            $taxonomy = Config::taxonomy(self::value($settings['taxonomy'] ?? null) ?? 'category');
            $key = Config::key((string) self::value($settings['url_key'] ?? null), $id);
            if (!$id || !$taxonomy || !$key || count($loops[$id] ?? []) !== 1) {
                continue;
            }
            $query = $loops[$id][0]['settings']['query']['value'] ?? [];
            $type = self::value($query['template_type'] ?? null) ?: 'post';
            $source = self::value($query['source'] ?? null) ?: 'post';
            $postType = is_string($source) ? get_post_type_object($source) : null;
            $tax = get_taxonomy($taxonomy);
            if (
                $type !== 'post' || !$postType || !$postType->public || !is_post_type_viewable($postType)
                || !$tax || !$tax->public || !is_object_in_taxonomy($source, $taxonomy)
            ) {
                continue;
            }
            $existing = self::value($query['query_id'] ?? null);
            $binding = [
                'id' => $id, 'filter' => $filter['id'], 'taxonomy' => $taxonomy, 'key' => $key,
                'source' => $source, 'hook' => $existing ?: 'thecore_loop_' . $id,
            ];
            // Ambiguous definitions must never silently filter the wrong collection.
            $keys[$key][] = $id;
            $result[$id][] = $binding;
        }
        $valid = [];
        foreach ($result as $id => $bindings) {
            if (count($bindings) === 1 && count($keys[$bindings[0]['key']]) === 1) {
                $valid[$id] = $bindings[0];
            }
        }
        return $valid;
    }

    private static function value(mixed $prop): ?string
    {
        return is_array($prop) && ($prop['$$type'] ?? '') === 'string' && is_string($prop['value'] ?? null)
            ? $prop['value'] : null;
    }

    private static function index(array $nodes, array &$filters, array &$loops): void
    {
        foreach ($nodes as $node) {
            if (!is_array($node) || empty($node['id'])) {
                continue;
            }
            if (($node['elType'] ?? '') === 'e-collection-loop') {
                $loops[$node['id']][] = $node;
                // Filters nested inside a repeating item cannot target a unique public DOM element.
                continue;
            }
            if (($node['widgetType'] ?? '') === 'thecore-loop-filter') {
                $filters[] = $node;
            }
            self::index($node['elements'] ?? [], $filters, $loops);
        }
    }

    public static function state(array $binding, array $query): ?array
    {
        $slug = $query[$binding['key']] ?? '';
        $page = $query['e-page-' . $binding['id']] ?? '1';
        if (
            !is_string($slug) || strlen($slug) > 200 || !is_string($page)
            || !preg_match('/^[1-9][0-9]{0,3}$/D', $page)
        ) {
            return null;
        }
        $term = $slug !== '' ? get_term_by('slug', $slug, $binding['taxonomy']) : null;
        if ($slug !== '' && (!$term instanceof \WP_Term || $term->slug !== $slug)) {
            return null;
        }
        return ['term' => $slug, 'termId' => $term ? (int) $term->term_id : 0, 'page' => (int) $page];
    }

    /** Patch only the in-memory render data; keep authored Query IDs and all other Elementor settings. */
    public static function wire(array $nodes, array $bindings): array
    {
        foreach ($nodes as &$node) {
            $id = $node['id'] ?? '';
            if (isset($bindings[$id]) && ($node['elType'] ?? '') === 'e-collection-loop') {
                $node['settings']['query'] ??= ['$$type' => 'loop-query', 'value' => []];
                $node['settings']['query']['value']['query_id'] = ['$$type' => 'string', 'value' => $bindings[$id]['hook']];
                // One owner for pager clicks: our controller also manages taxonomy changes and browser history.
                $node['settings']['pagination_load_type'] = ['$$type' => 'string', 'value' => 'page_reload'];
            } elseif (!empty($node['elements'])) {
                $node['elements'] = self::wire($node['elements'], $bindings);
            }
        }
        return $nodes;
    }

    /** Retain original ancestor wrappers and their display conditions on a fragment request. */
    public static function branch(array $nodes, array $keep): array
    {
        $result = [];
        foreach ($nodes as $node) {
            if (in_array($node['id'] ?? '', $keep, true)) {
                $result[] = $node;
            } elseif (!empty($node['elements'])) {
                $node['elements'] = self::branch($node['elements'], $keep);
                if ($node['elements']) {
                    $result[] = $node;
                }
            }
        }
        return $result;
    }

    /** Intersect, never replace, existing taxonomy constraints (including OR groups). */
    public static function restrict(\WP_Query $query, array $binding, ?array $state): void
    {
        $type = $query->get('post_type');
        $status = array_filter((array) $query->get('post_status'));
        $hadPassword = $query->get('has_password') === true || (string) $query->get('post_password') !== '';
        $query->set('post_type', $binding['source']);
        $query->set('post_status', 'publish');
        $query->set('has_password', false);
        if (
            !$state || ($type && !in_array($binding['source'], (array) $type, true))
            || ($status && !in_array('publish', $status, true) && !in_array('any', $status, true))
            || $hadPassword
        ) {
            foreach (['p', 'page_id', 'attachment_id'] as $selector) {
                $query->set($selector, 0);
            }
            $query->set('ignore_sticky_posts', true);
            $query->set('post__in', [0]);
            return;
        }
        if ($state['termId']) {
            // WP can otherwise append sticky posts from outside a category to the first page.
            $query->set('ignore_sticky_posts', true);
            $old = $query->get('tax_query');
            $constraint = ['taxonomy' => $binding['taxonomy'], 'field' => 'term_id', 'terms' => [$state['termId']], 'include_children' => false];
            $query->set('tax_query', $old ? ['relation' => 'AND', $old, $constraint] : [$constraint]);
        }
    }
}
