<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\LoopFilter;

/** Extract only ordinary presentation HTML, after the normal theme and access checks have rendered it. */
final class Fragment
{
    public const PARAM = 'tc_loop_fragment';

    public static function compatible(array $node): bool
    {
        $type = $node['widgetType'] ?? $node['elType'] ?? '';
        if (
            !in_array($type, [
            'e-collection-loop', 'e-collection-loop-layout', 'e-collection-loop-item', 'e-collection-loop-empty-state',
            'e-pagination', 'e-pagination-prev', 'e-pagination-next', 'e-flexbox', 'e-div-block', 'e-grid',
            'e-heading', 'e-paragraph', 'e-image', 'e-button', 'e-divider',
            ], true)
        ) {
            return false;
        }
        foreach ($node['elements'] ?? [] as $child) {
            if (!self::compatible($child)) {
                return false;
            }
        }
        return true;
    }

    public static function extract(string $html, string $id): ?string
    {
        if (strlen($html) > 4194304 || !class_exists(\DOMDocument::class) || !preg_match('/^[a-zA-Z0-9_-]+$/D', $id)) {
            return null;
        }
        $doc = new \DOMDocument();
        // No DTD loading, entity substitution, resource loads, or script execution.
        if (!@$doc->loadHTML('<?xml encoding="UTF-8">' . $html, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING)) {
            return null;
        }
        $xpath = new \DOMXPath($doc);
        $nav = $xpath->query('//*[@data-tc-loop-filter="' . $id . '"]');
        $loops = $xpath->query('//*[@data-e-type="e-collection-loop" and @data-id="' . $id . '"]');
        if ($nav->length !== 1 || $loops->length !== 1) {
            return null;
        }
        $loop = $loops->item(0);
        if (!$loop instanceof \DOMElement || $xpath->query('.//*[@role="list"]', $loop)->length !== 1) {
            return null;
        }
        $allowed = array_flip(explode(' ', 'div section article header footer h1 h2 h3 h4 h5 h6 p span a img picture source strong em b i small time mark del ins sub sup br hr blockquote cite ul ol li dl dt dd nav figure figcaption'));
        foreach ($xpath->query('descendant-or-self::*', $loop) as $element) {
            if (!isset($allowed[$element->nodeName])) {
                return null;
            }
            foreach ($element->attributes as $attr) {
                if (str_starts_with(strtolower($attr->name), 'on') || $attr->name === 'srcdoc') {
                    return null;
                }
            }
            if ($element->hasAttribute('data-e-pagination-link') && $element->hasAttribute('href')) {
                $element->setAttribute('href', remove_query_arg(self::PARAM, $element->getAttribute('href')));
            }
        }
        return $doc->saveHTML($loop) ?: null;
    }
}
