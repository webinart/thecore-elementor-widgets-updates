<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Elements\Form;

use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Chips_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Number_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Select_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Switch_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Text_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Textarea_Control;
use Elementor\Modules\AtomicWidgets\DynamicTags\Dynamic_Prop_Type;
use Elementor\Modules\AtomicWidgets\Elements\Base\Atomic_Element_Base;
use Elementor\Modules\AtomicWidgets\Elements\Base\Has_Element_Template;
use Elementor\Modules\AtomicWidgets\Elements\Base\Widget_Builder;
use Elementor\Modules\AtomicWidgets\PropDependencies\Manager as Dependency_Manager;
use Elementor\Modules\AtomicWidgets\PropTypes\Classes_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Html_V3_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Boolean_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Number_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Array_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Size_Prop_Type;
use Elementor\Modules\AtomicWidgets\Styles\Style_Definition;
use Elementor\Modules\AtomicWidgets\Styles\Style_Variant;
use Elementor\Modules\Components\PropTypes\Overridable_Prop_Type;
use TheCore\ElementorWidgets\Forms\Controller;
use TheCore\ElementorWidgets\Assets\FormMediaAssets;
use TheCore\ElementorWidgets\Elementor\Atomic\Controls\Types\FormFlowEditorControl;
use TheCore\ElementorWidgets\Forms\Api\ApiModule;
use TheCore\ElementorWidgets\Forms\FormDefinition;
use TheCore\ElementorWidgets\Forms\FormsModule;
use TheCore\ElementorWidgets\Forms\MailPoet\MailPoetClient;
use TheCore\ElementorWidgets\FormSecurity\Support\ContextToken;
use TheCore\ElementorWidgets\FormSecurity\Support\FormContext;
use TheCore\ElementorWidgets\FormSecurity\Support\Secrets;
use TheCore\ElementorWidgets\FormSecurity\Support\SecuritySettings;
use Throwable;

final class Form extends Atomic_Element_Base
{
    use Has_Element_Template {
        render_children_to_html as private renderNativeChildren;
    }

    private string $fieldPrefix = '';
    private string $initiallyVisibleStep = '';
    private bool $pendingSubmit = false;

    public static $widget_description = 'The Core form container with native atomic fields and independent secure processing.';

    public function __construct($data = [], $args = null)
    {
        parent::__construct($data, $args);
        $this->meta('is_container', true);
    }

    public static function get_type()
    {
        return FormDefinition::TYPE;
    }

    public static function get_element_type(): string
    {
        return self::get_type();
    }

    public function get_title()
    {
        return esc_html__('Formulaire The Core', 'thecore-elementor-widgets');
    }

    public function get_icon()
    {
        return 'eicon-form-horizontal';
    }

    public function get_keywords()
    {
        return ['form', 'formulaire', 'contact', 'thecore', 'atomic'];
    }

    public function get_script_depends()
    {
        $scripts = $this->hasMediaField() ? [FormMediaAssets::HANDLE, FormsModule::SCRIPT] : [FormsModule::SCRIPT];
        if ($this->hasElementType('thecore-form-group')) {
            array_unshift($scripts, 'thecore-form-flow');
        }
        return $scripts;
    }

    public function get_style_depends()
    {
        return $this->hasElementType('thecore-form-group') ? ['thecore-form-flow', FormsModule::SCRIPT] : [FormsModule::SCRIPT];
    }

    protected static function define_props_schema(): array
    {
        $props = ['classes' => Classes_Prop_Type::make()->default([])];
        $mailpoet = Dependency_Manager::make()->where([
            'operator' => 'contains', 'path' => ['actions-after-submit'], 'value' => 'mailpoet', 'effect' => 'hide',
        ])->get();
        $email = Dependency_Manager::make()->where([
            'operator' => 'contains', 'path' => ['actions-after-submit'], 'value' => 'email', 'effect' => 'hide',
        ])->get();
        $autoresponder = Dependency_Manager::make()->where([
            'operator' => 'contains', 'path' => ['actions-after-submit'], 'value' => 'autoresponder', 'effect' => 'hide',
        ])->get();
        $api = Dependency_Manager::make()->where([
            'operator' => 'contains', 'path' => ['actions-after-submit'], 'value' => 'api', 'effect' => 'hide',
        ])->get();
        foreach (['api-connection', 'api-mapping'] as $key) {
            $props[$key] = String_Prop_Type::make()->default('')->set_dependencies($api)
                ->meta(Dynamic_Prop_Type::ignore())->meta(Overridable_Prop_Type::ignore());
        }
        $storage = Dependency_Manager::make()->where([
            'operator' => 'eq', 'path' => ['store-submissions'], 'value' => true, 'effect' => 'hide',
        ])->get();
        foreach (
            ['form-name' => 'Contact', 'recipient' => '', 'subject' => 'Contact', 'reply-to-field' => '',
            'success-message' => 'Votre message a bien ete envoye.'] as $key => $default
        ) {
            $props[$key] = String_Prop_Type::make()->default($default)
                ->meta(Dynamic_Prop_Type::ignore())->meta(Overridable_Prop_Type::ignore());
            if (in_array($key, ['recipient', 'subject', 'reply-to-field'], true)) {
                $props[$key]->set_dependencies($email);
            }
        }
        $defaultActions = [String_Prop_Type::generate('email')];
        $props['email-format'] = String_Prop_Type::make()->default('plain')->enum(['plain', 'html'])
            ->meta(Dynamic_Prop_Type::ignore())->meta(Overridable_Prop_Type::ignore());
        $props['actions-after-submit'] = String_Array_Prop_Type::make()->default($defaultActions)->initial_value($defaultActions)
            ->meta(Dynamic_Prop_Type::ignore())->meta(Overridable_Prop_Type::ignore());
        $props['mailpoet-lists'] = String_Array_Prop_Type::make()->default([])->set_dependencies($mailpoet)
            ->meta(Dynamic_Prop_Type::ignore())->meta(Overridable_Prop_Type::ignore());
        foreach (['email' => 'thecore-field-email', 'first-name' => '', 'last-name' => '', 'consent' => ''] as $key => $default) {
            $props['mailpoet-' . $key . '-field'] = String_Prop_Type::make()->default($default)->set_dependencies($mailpoet)
                ->meta(Dynamic_Prop_Type::ignore())->meta(Overridable_Prop_Type::ignore());
        }
        $props['allow-tests'] = Boolean_Prop_Type::make()->default(false)
            ->meta(Dynamic_Prop_Type::ignore())->meta(Overridable_Prop_Type::ignore());
        $props['flow-smooth-transitions'] = Boolean_Prop_Type::make()->default(false)
            ->meta(Dynamic_Prop_Type::ignore())->meta(Overridable_Prop_Type::ignore());
        $props['flow-pending-submit'] = Boolean_Prop_Type::make()->default(false)
            ->meta(Dynamic_Prop_Type::ignore())->meta(Overridable_Prop_Type::ignore());
        foreach (
            ['autoresponder-email-field' => '', 'autoresponder-subject' => 'Votre demande a bien ete recue',
            'autoresponder-message' => "Bonjour,\n\nNous avons bien recu votre demande et vous recontacterons prochainement."] as $key => $default
        ) {
            $props[$key] = String_Prop_Type::make()->default($default)->set_dependencies($autoresponder)
                ->meta(Dynamic_Prop_Type::ignore())->meta(Overridable_Prop_Type::ignore());
        }
        $props['store-submissions'] = Boolean_Prop_Type::make()->default(false)
            ->meta(Dynamic_Prop_Type::ignore())->meta(Overridable_Prop_Type::ignore());
        $props['log-blocked-submissions'] = Boolean_Prop_Type::make()->default(false)
            ->meta(Dynamic_Prop_Type::ignore())->meta(Overridable_Prop_Type::ignore());
        $props['submission-retention-days'] = Number_Prop_Type::make()->default(90)->set_dependencies($storage)
            ->meta(Dynamic_Prop_Type::ignore())->meta(Overridable_Prop_Type::ignore());
        return $props;
    }

    protected function define_atomic_controls(): array
    {
        $retentionControl = Number_Control::bind_to('submission-retention-days')
            ->set_label(__('Conservation en jours', 'thecore-elementor-widgets'))
            ->set_min(1)->set_max(365)->set_step(1);
        if (method_exists($retentionControl, 'set_should_force_int')) {
            $retentionControl->set_should_force_int(true);
        }
        $apiOptions = [['label' => __('Choisir une connexion', 'thecore-elementor-widgets'), 'value' => '']];
        foreach (ApiModule::connectionOptions() as $id => $label) {
            $apiOptions[] = ['label' => $label, 'value' => $id];
        }
        $listOptions = [];
        $description = __('MailPoet doit etre actif. Recharger l\'editeur apres avoir modifie les listes. La confirmation et les emails MailPoet suivent sa configuration.', 'thecore-elementor-widgets');
        if (current_user_can('edit_posts') || current_user_can('edit_pages')) {
            try {
                foreach (MailPoetClient::activeLists((new MailPoetClient())->lists()) as $id => $name) {
                    $listOptions[] = ['label' => $name . ' (#' . $id . ')', 'value' => (string) $id];
                }
            } catch (Throwable) {
                $description = __('MailPoet est indisponible. Activer le plugin puis recharger l\'editeur pour choisir les listes.', 'thecore-elementor-widgets');
            }
        }
        return [
            Section::make()->set_label(__('Parcours du formulaire', 'thecore-elementor-widgets'))->set_items([
                FormFlowEditorControl::make()->set_label(__('Affichage dans l’éditeur', 'thecore-elementor-widgets'))
                    ->set_meta(['layout' => 'custom']),
                Switch_Control::bind_to('flow-smooth-transitions')->set_label(__('Transitions fluides des étapes et branches', 'thecore-elementor-widgets'))
                    ->set_description(__('Facultatif, pour les groupes / étapes The Core. Adapte la hauteur du formulaire sans retarder la validation et respecte la réduction des animations.', 'thecore-elementor-widgets')),
                Switch_Control::bind_to('flow-pending-submit')->set_label(__('Afficher le bouton d’envoi avant le choix du parcours', 'thecore-elementor-widgets'))
                    ->set_description(__('Le bouton conserve son apparence et reste désactivé tant que le choix requis de la première étape n’est pas renseigné.', 'thecore-elementor-widgets')),
            ]),
            Section::make()->set_label(__('Traitement', 'thecore-elementor-widgets'))->set_items([
                Text_Control::bind_to('form-name')->set_label(__('Nom du formulaire', 'thecore-elementor-widgets')),
                Chips_Control::bind_to('actions-after-submit')->set_label(__('Actions apres soumission', 'thecore-elementor-widgets'))
                    ->set_options([
                        ['label' => __('Email', 'thecore-elementor-widgets'), 'value' => 'email'],
                        ['label' => __('Envoyer à une API', 'thecore-elementor-widgets'), 'value' => 'api'],
                        ['label' => __('Ajout MailPoet', 'thecore-elementor-widgets'), 'value' => 'mailpoet'],
                        ['label' => __('Accuse de reception visiteur', 'thecore-elementor-widgets'), 'value' => 'autoresponder'],
                    ])->set_description(__('Choisir au moins une action. Pour une newsletter seule, retirer Email.', 'thecore-elementor-widgets')),
                Text_Control::bind_to('recipient')->set_label(__('Destinataires email', 'thecore-elementor-widgets'))
                    ->set_description(__('Adresses séparées par une virgule ou un point-virgule (20 maximum). Vide : email administrateur WordPress.', 'thecore-elementor-widgets')),
                Text_Control::bind_to('subject')->set_label(__('Objet de l\'email', 'thecore-elementor-widgets')),
                Select_Control::bind_to('email-format')->set_label(__('Présentation des emails', 'thecore-elementor-widgets'))
                    ->set_options([
                        ['label' => __('Texte simple', 'thecore-elementor-widgets'), 'value' => 'plain'],
                        ['label' => __('Modèle de marque HTML', 'thecore-elementor-widgets'), 'value' => 'html'],
                    ])->set_description(__('S’applique à la notification et à l’accusé de réception. L’identité provient du profil email du site ; le contenu de l’accusé reste du texte statique.', 'thecore-elementor-widgets')),
                Text_Control::bind_to('reply-to-field')->set_label(__('ID CSS du champ Repondre a', 'thecore-elementor-widgets'))
                    ->set_description(__('Facultatif : champ de type Email. Ajoute Reply-To sans modifier l\'expediteur.', 'thecore-elementor-widgets')),
                Textarea_Control::bind_to('success-message')->set_label(__('Message de confirmation', 'thecore-elementor-widgets')),
            ]),
            Section::make()->set_label(__('Envoyer à une API', 'thecore-elementor-widgets'))->set_items([
                Select_Control::bind_to('api-connection')->set_label(__('Connexion', 'thecore-elementor-widgets'))
                    ->set_options($apiOptions)
                    ->set_description(__('À configurer dans The Core – Widgets → Connexions API. Rechargez l’éditeur après l’ajout d’une connexion.', 'thecore-elementor-widgets')),
                Textarea_Control::bind_to('api-mapping')->set_label(__('Correspondance des champs (JSON)', 'thecore-elementor-widgets'))
                    ->set_description(__('source : ID CSS du champ sans # ; target : propriété attendue par l’API ; type : string, integer, number, boolean ou string_list. Utilisez value pour une valeur fixe. Aucun secret dans ce JSON. Exemple : ', 'thecore-elementor-widgets') . ApiModule::mappingExample()),
            ]),
            Section::make()->set_label(__('Accuse de reception', 'thecore-elementor-widgets'))->set_items([
                Text_Control::bind_to('autoresponder-email-field')->set_label(__('ID CSS du champ email visiteur', 'thecore-elementor-widgets'))
                    ->set_description(__('Champ de type Email sauvegarde, sans #. Aucune adresse fournie par le navigateur ne peut remplacer ce mapping.', 'thecore-elementor-widgets')),
                Text_Control::bind_to('autoresponder-subject')->set_label(__('Objet de l\'accuse de reception', 'thecore-elementor-widgets')),
                Textarea_Control::bind_to('autoresponder-message')->set_label(__('Message de l\'accuse de reception', 'thecore-elementor-widgets'))
                    ->set_description(__('Texte statique uniquement : les valeurs saisies par le visiteur ne sont jamais reprises dans cet email.', 'thecore-elementor-widgets')),
            ]),
            Section::make()->set_label(__('Conservation des demandes', 'thecore-elementor-widgets'))->set_items([
                Switch_Control::bind_to('store-submissions')->set_label(__('Conserver les demandes', 'thecore-elementor-widgets'))
                    ->set_description(__('Desactive par defaut. Les demandes sont gerees dans l\'interface The Core, independamment des Soumissions Elementor.', 'thecore-elementor-widgets')),
                $retentionControl,
                Switch_Control::bind_to('log-blocked-submissions')->set_label(__('Conserver les details des spams bloques', 'thecore-elementor-widgets'))
                    ->set_description(__('Desactive par defaut. Utilise le journal anti-spam global, ses quotas et sa conservation (30 jours par defaut). Les donnees sont minimisees.', 'thecore-elementor-widgets')),
            ]),
            Section::make()->set_label(__('MailPoet', 'thecore-elementor-widgets'))->set_description($description)->set_items([
                Chips_Control::bind_to('mailpoet-lists')->set_label(__('Listes de destination', 'thecore-elementor-widgets'))
                    ->set_options($listOptions)->set_description(__('Une ou plusieurs listes standards actives.', 'thecore-elementor-widgets')),
                Text_Control::bind_to('mailpoet-email-field')->set_label(__('ID CSS du champ email', 'thecore-elementor-widgets'))
                    ->set_description(__('ID sauvegarde sans #, champ de type Email obligatoire pour cette action.', 'thecore-elementor-widgets')),
                Text_Control::bind_to('mailpoet-first-name-field')->set_label(__('ID CSS du champ prenom', 'thecore-elementor-widgets'))
                    ->set_description(__('Facultatif. Champ de type Texte.', 'thecore-elementor-widgets')),
                Text_Control::bind_to('mailpoet-last-name-field')->set_label(__('ID CSS du champ nom', 'thecore-elementor-widgets'))
                    ->set_description(__('Facultatif. Champ de type Texte.', 'thecore-elementor-widgets')),
                Text_Control::bind_to('mailpoet-consent-field')->set_label(__('ID CSS de la case de consentement', 'thecore-elementor-widgets'))
                    ->set_description(__('Facultatif : si renseigne, inscription uniquement si la case est cochee. Sinon le formulaire doit etre explicitement dedie a l\'inscription.', 'thecore-elementor-widgets')),
            ]),
            Section::make()->set_label(__('Suivi de flotte', 'thecore-elementor-widgets'))->set_items([
                Switch_Control::bind_to('allow-tests')->set_label(__('Autoriser les tests signes', 'thecore-elementor-widgets'))
                    ->set_description(__('Customer Agent requis. Validation sans email, sans inscription MailPoet, sans conservation de donnees et sans contournement anti-spam. Les visiteurs restent en mode normal.', 'thecore-elementor-widgets')),
            ]),
        ];
    }

    public static function get_computed_html_tag(array $settings): string
    {
        return 'form';
    }

    protected function define_default_html_tag()
    {
        return 'form';
    }

    protected function define_base_styles(): array
    {
        return ['base' => Style_Definition::make()->add_variant(Style_Variant::make()
            ->add_prop('display', String_Prop_Type::generate('flex'))
            ->add_prop('flex-direction', String_Prop_Type::generate('column'))
            ->add_prop('row-gap', Size_Prop_Type::generate(['size' => 12, 'unit' => 'px'])))];
    }

    protected function define_default_children()
    {
        $children = [];
        foreach (['name' => ['Nom', 'text'], 'email' => ['Email', 'email'], 'message' => ['Message', 'textarea']] as $name => [$label, $type]) {
            $domId = 'thecore-field-' . $name;
            $children[] = Widget_Builder::make('e-form-label')->settings([
                'text' => self::html($label), 'input-id' => String_Prop_Type::generate($domId),
            ])->build();
            $props = ['_cssid' => String_Prop_Type::generate($domId), 'required' => Boolean_Prop_Type::generate(true)];
            if ($type !== 'textarea') {
                $props['type'] = String_Prop_Type::generate($type);
            }
            $children[] = Widget_Builder::make($type === 'textarea' ? 'e-form-textarea' : 'e-form-input')
                ->settings($props)->build();
        }
        $children[] = Widget_Builder::make('e-form-submit-button')->settings(['text' => self::html('Envoyer')])->build();
        return $children;
    }

    protected function get_templates(): array
    {
        return ['thecore/form' => __DIR__ . '/form.html.twig'];
    }

    protected function build_template_context(): array
    {
        $this->initiallyVisibleStep = '';
        $this->pendingSubmit = false;
        $context = $this->build_base_template_context();
        $context['endpoint'] = rest_url(Controller::NAMESPACE . Controller::ROUTE);
        $context['form_config'] = '';
        $context['configuration_error'] = '';
        $context['flow_enabled'] = false;
        $context['editor_preview'] = \Elementor\Plugin::$instance->editor->is_edit_mode();
        if ($context['editor_preview']) {
            return $context;
        }
        try {
            $data = $this->get_data();
            $data['elType'] = self::get_type();
            $definition = FormDefinition::fromElement($data);
            $this->initiallyVisibleStep = $definition->initiallyVisibleStep();
            $this->pendingSubmit = ($definition->flow['pendingSubmit'] ?? false) === true;
            $postId = (int) \ElementorPro\Core\Utils::get_current_post_id();
            $this->fieldPrefix = wp_unique_id('tc-' . $this->get_id() . '-');
            $publicFields = $definition->publicFields();
            foreach ($publicFields as &$field) {
                $field['domId'] = $this->fieldPrefix . $field['domId'];
            }
            unset($field);
            $formContext = new FormContext($postId, $this->get_id(), FormDefinition::SECURITY_FIELD);
            $token = (new ContextToken(Secrets::contextSigning()))->encode($formContext);
            $config = [
                'version' => 1, 'postId' => $postId, 'formId' => $this->get_id(),
                'context' => $token, 'endpoint' => $context['endpoint'],
                'challengeUrl' => add_query_arg('context', $token, rest_url(Controller::NAMESPACE . FormsModule::CHALLENGE_ROUTE)),
                'minDuration' => (new SecuritySettings())->challengeMinimumSeconds() * 1000,
                'apiEnabled' => in_array('api', $definition->settings['actions-after-submit'], true),
                'apiScope' => 'atomic:' . get_current_blog_id() . ':' . $postId . ':' . $this->get_id(),
                'fields' => $publicFields, 'testMode' => $definition->settings['allow-tests'] ? 'signed-dry-run' : 'disabled',
            ];
            if (array_filter($definition->fields, static fn (array $field): bool => $field['type'] === 'media') !== []) {
                $config['mediaEndpoint'] = rest_url(Controller::NAMESPACE . '/forms/media/');
            }
            if ($definition->flow !== []) {
                $config['flow'] = $definition->flow;
                $context['flow_enabled'] = true;
            }
            $context['form_config'] = wp_json_encode($config);
        } catch (Throwable $error) {
            $context['configuration_error'] = current_user_can('edit_posts')
                ? $error->getMessage() : __('Ce formulaire est momentanement indisponible.', 'thecore-elementor-widgets');
        }
        return $context;
    }

    protected function render_children_to_html(): string
    {
        $html = $this->renderNativeChildren();
        if ($this->fieldPrefix === '') {
            return $html;
        }
        $processor = new \WP_HTML_Tag_Processor($html);
        while ($processor->next_tag()) {
            if (
                $this->initiallyVisibleStep !== ''
                && $processor->get_attribute('data-thecore-form-group') === $this->initiallyVisibleStep
            ) {
                $processor->remove_attribute('data-thecore-flow-initial-hidden');
            }
            $tag = $processor->get_tag();
            if (
                $this->pendingSubmit && in_array($tag, ['BUTTON', 'INPUT'], true)
                && $processor->get_attribute('type') === 'submit'
                && $processor->get_attribute('data-thecore-flow-next') === null
                && $processor->get_attribute('data-thecore-flow-previous') === null
                && ! preg_match('/(?:^|\s)thecore-flow-(?:next|previous)(?:\s|$)/', (string) $processor->get_attribute('class'))
            ) {
                $processor->set_attribute('data-thecore-flow-pending-submit', '1');
                if ($processor->get_attribute('disabled') === null) {
                    $processor->set_attribute('data-thecore-flow-pending-disabled', '1');
                    $processor->set_attribute('disabled', true);
                }
            }
            $attribute = $tag === 'LABEL' ? 'for' : 'id';
            if (! in_array($tag, ['LABEL', 'INPUT', 'SELECT', 'TEXTAREA'], true)) {
                continue;
            }
            $id = $processor->get_attribute($attribute);
            if (is_string($id) && $id !== '') {
                $processor->set_attribute($attribute, $this->fieldPrefix . $id);
            }
            if ($tag === 'INPUT' && $processor->get_attribute('type') === 'radio') {
                $name = $processor->get_attribute('name');
                if (is_string($name)) {
                    $processor->set_attribute('name', $this->fieldPrefix . $name);
                }
            }
        }
        return $processor->get_updated_html();
    }

    private static function html(string $text): array
    {
        // Match the native label/button schema across Elementor V4 releases.
        if (class_exists('\\Elementor\\Modules\\AtomicWidgets\\PropTypes\\Escaped_Html_Prop_Type')) {
            return \Elementor\Modules\AtomicWidgets\PropTypes\Escaped_Html_Prop_Type::generate($text);
        }
        return Html_V3_Prop_Type::generate(['content' => String_Prop_Type::generate($text), 'children' => []]);
    }

    private function hasMediaField(): bool
    {
        return $this->hasElementType('thecore-form-media');
    }

    private function hasElementType(string $type): bool
    {
        // Elementor also queries asset dependencies on the empty registered type.
        // That prototype has no raw data and must not enter Controls_Stack::get_data().
        if ($this->is_type_instance()) {
            return false;
        }

        $elements = $this->get_data('elements');
        $pending = is_array($elements) ? $elements : [];
        $visited = 0;
        while ($pending !== [] && ++$visited <= 500) {
            $node = array_pop($pending);
            if (! is_array($node)) {
                continue;
            }
            if (($node['widgetType'] ?? $node['elType'] ?? '') === $type) {
                return true;
            }
            $children = $node['elements'] ?? [];
            foreach (is_array($children) ? $children : [] as $child) {
                if (is_array($child)) {
                    $pending[] = $child;
                }
            }
        }
        return false;
    }
}
