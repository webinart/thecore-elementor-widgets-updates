<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Elements\FormGroup;

use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Switch_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Text_Control;
use Elementor\Modules\AtomicWidgets\DynamicTags\Dynamic_Prop_Type;
use Elementor\Modules\AtomicWidgets\Elements\Base\Atomic_Element_Base;
use Elementor\Modules\AtomicWidgets\Elements\Base\Has_Element_Template;
use Elementor\Modules\AtomicWidgets\PropTypes\Classes_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Boolean_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Size_Prop_Type;
use Elementor\Modules\AtomicWidgets\Styles\Style_Definition;
use Elementor\Modules\AtomicWidgets\Styles\Style_Variant;
use Elementor\Modules\Components\PropTypes\Overridable_Prop_Type;
use TheCore\ElementorWidgets\Elementor\Atomic\Controls\Types\FormFlowEditorControl;
use TheCore\ElementorWidgets\Forms\Flow\Compiler;

/** Native nested group: presentation is editable; validation is saved, static policy. */
final class FormGroup extends Atomic_Element_Base
{
    use Has_Element_Template;

    public static $widget_description = 'A conditional field group or step inside a The Core V4 form.';

    public function __construct($data = [], $args = null)
    {
        parent::__construct($data, $args);
        $this->meta('is_container', true);
    }

    public static function get_type()
    {
        return Compiler::GROUP_TYPE;
    }

    public static function get_element_type(): string
    {
        return self::get_type();
    }

    public function get_title()
    {
        return esc_html__('Groupe / étape de formulaire', 'thecore-elementor-widgets');
    }

    public function get_icon()
    {
        return 'eicon-form-horizontal';
    }

    public function get_keywords()
    {
        return ['form', 'formulaire', 'step', 'étape', 'condition', 'thecore', 'atomic'];
    }

    public function get_script_depends()
    {
        return [];
    }

    public function get_style_depends()
    {
        return [];
    }

    protected static function define_props_schema(): array
    {
        $props = ['classes' => Classes_Prop_Type::make()->default([])];
        foreach (['label', 'condition-field', 'condition-value', 'require-field'] as $key) {
            $props[$key] = String_Prop_Type::make()->default('')
                ->meta(Dynamic_Prop_Type::ignore())->meta(Overridable_Prop_Type::ignore());
        }
        $props['is-step'] = Boolean_Prop_Type::make()->default(false)
            ->meta(Dynamic_Prop_Type::ignore())->meta(Overridable_Prop_Type::ignore());
        return $props;
    }

    protected function define_atomic_controls(): array
    {
        return [Section::make()->set_label(__('Parcours du formulaire', 'thecore-elementor-widgets'))->set_items([
            FormFlowEditorControl::make()->set_label(__('Affichage dans l’éditeur', 'thecore-elementor-widgets'))
                ->set_meta(['layout' => 'custom']),
            Text_Control::bind_to('label')->set_label(__('Titre du groupe / de l’étape', 'thecore-elementor-widgets')),
            Switch_Control::bind_to('is-step')->set_label(__('Utiliser comme étape', 'thecore-elementor-widgets'))
                ->set_description(__('12 étapes maximum, sans étape imbriquée. Les groupes ordinaires peuvent être imbriqués.', 'thecore-elementor-widgets')),
            Text_Control::bind_to('condition-field')->set_label(__('ID CSS du champ de condition', 'thecore-elementor-widgets'))
                ->set_description(__('Facultatif : choix ou case enregistrée située avant ce groupe. Vide : groupe toujours actif.', 'thecore-elementor-widgets')),
            Text_Control::bind_to('condition-value')->set_label(__('Valeur qui active le groupe', 'thecore-elementor-widgets')),
            Text_Control::bind_to('require-field')->set_label(__('ID CSS du champ à rendre obligatoire', 'thecore-elementor-widgets'))
                ->set_description(__('Facultatif : champ antérieur qui devient obligatoire lorsque ce groupe est actif (par exemple un téléphone pour un rappel).', 'thecore-elementor-widgets')),
        ])];
    }

    public static function get_computed_html_tag(array $settings): string
    {
        return 'div';
    }

    protected function define_default_html_tag()
    {
        return 'div';
    }

    protected function define_base_styles(): array
    {
        return ['base' => Style_Definition::make()->add_variant(Style_Variant::make()
            ->add_prop('display', String_Prop_Type::generate('flex'))
            ->add_prop('flex-direction', String_Prop_Type::generate('column'))
            ->add_prop('row-gap', Size_Prop_Type::generate(['size' => 12, 'unit' => 'px'])))];
    }

    protected function define_default_children()
    {
        return [];
    }

    protected function get_templates(): array
    {
        return ['thecore/form-group' => __DIR__ . '/form-group.html.twig'];
    }

    protected function build_template_context(): array
    {
        $context = $this->build_base_template_context();
        $settings = $context['settings'] ?? [];
        $context['initial_hidden'] = ($settings['condition-field'] ?? '') !== '' || ($settings['is-step'] ?? false) === true;
        return $context;
    }
}
