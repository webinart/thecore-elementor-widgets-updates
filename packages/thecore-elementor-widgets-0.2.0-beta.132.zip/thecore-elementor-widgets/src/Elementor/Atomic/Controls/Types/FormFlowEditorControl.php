<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Controls\Types;

use Elementor\Modules\AtomicWidgets\Controls\Base\Element_Control_Base;

/** Editor-only view state: deliberately not bound to a saved form property. */
final class FormFlowEditorControl extends Element_Control_Base
{
    public function get_type(): string
    {
        return 'thecore-form-flow-editor';
    }

    public function get_props(): array
    {
        return [];
    }
}
