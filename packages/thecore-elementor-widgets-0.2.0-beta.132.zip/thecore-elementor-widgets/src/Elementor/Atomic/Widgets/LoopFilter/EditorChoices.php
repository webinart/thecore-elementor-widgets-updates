<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\LoopFilter;

use Elementor\Plugin;

/** Authoring only: offer saved loops from the document being edited, not from other pages. */
final class EditorChoices
{
    public static function loops(): array
    {
        return self::documentChoices()['loops'];
    }

    /** An editor preview uses real term names from this document, never fabricated examples. */
    public static function previewTerms(): string
    {
        $html = '';
        foreach (self::documentChoices()['taxonomies'] as $taxonomy) {
            $terms = get_terms(['taxonomy' => $taxonomy, 'hide_empty' => true, 'orderby' => 'name', 'order' => 'ASC', 'number' => 60]);
            if (is_wp_error($terms) || !$terms) {
                continue;
            }
            $html .= "{% if (settings.taxonomy | default('category')) == '" . $taxonomy . "' %}";
            foreach ($terms as $term) {
                // This is literal text inside a Twig *source*, not a template expression.
                $label = str_replace('{', '&#123;', esc_html($term->name));
                $html .= '<span data-tc-term="">' . $label . '</span>';
            }
            $html .= '{% endif %}';
        }
        return $html;
    }

    private static function documentChoices(): array
    {
        static $cache = [];
        $result = ['loops' => [], 'taxonomies' => []];
        $editor = Plugin::$instance->editor ?? null;
        $document = Plugin::$instance->documents->get_current();
        $id = $editor ? (int) $editor->get_post_id() : 0;
        if (!$id && $document) {
            $id = (int) $document->get_main_id();
        }
        if (!$id || !current_user_can('edit_post', $id)) {
            return $result;
        }
        $cacheKey = get_current_blog_id() . ':' . $id;
        if (isset($cache[$cacheKey])) {
            return $cache[$cacheKey];
        }
        $json = get_post_meta($id, '_elementor_data', true);
        $roots = is_string($json) ? json_decode($json, true) : $json;
        $visit = static function (array $nodes) use (&$visit, &$result): void {
            foreach ($nodes as $node) {
                if (!is_array($node)) {
                    continue;
                }
                $target = Config::target($node['id'] ?? null);
                if ($target !== '' && ($node['elType'] ?? '') === 'e-collection-loop') {
                    $name = $node['editor_settings']['title'] ?? '';
                    $label = is_string($name) && trim($name) !== '' ? wp_strip_all_tags($name) : __('Boucle', 'thecore-elementor-widgets');
                    $result['loops'][] = ['value' => $target, 'label' => $label . ' · ' . $target];
                }
                if (($node['widgetType'] ?? '') === 'thecore-loop-filter') {
                    $tax = Config::taxonomy($node['settings']['taxonomy']['value'] ?? 'category');
                    if ($tax !== '') {
                        $result['taxonomies'][$tax] = $tax;
                    }
                }
                if (!empty($node['elements']) && is_array($node['elements'])) {
                    $visit($node['elements']);
                }
            }
        };
        $visit(is_array($roots) ? $roots : []);
        if ($result['loops'] && Config::taxonomy('category') !== '') {
            $result['taxonomies']['category'] = 'category';
        }
        return $cache[$cacheKey] = $result;
    }

    public static function taxonomies(): array
    {
        $options = [];
        foreach (get_taxonomies(['public' => true, 'publicly_queryable' => true], 'objects') as $taxonomy) {
            $options[] = ['value' => $taxonomy->name, 'label' => $taxonomy->labels->name . ' · ' . $taxonomy->name];
        }
        return $options;
    }
}
