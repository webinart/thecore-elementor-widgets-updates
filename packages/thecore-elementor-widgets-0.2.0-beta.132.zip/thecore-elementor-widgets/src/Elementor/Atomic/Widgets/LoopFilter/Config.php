<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\LoopFilter;

/** Shared by the widget and its server query: an invalid author setting cannot change WP routing. */
final class Config
{
    public static function target(mixed $value): string
    {
        return is_string($value) && preg_match('/^[a-zA-Z0-9_-]{1,64}$/D', $value) === 1 ? $value : '';
    }

    public static function taxonomy(mixed $value): string
    {
        if (!is_string($value) || preg_match('/^[a-z0-9_-]{1,32}$/D', $value) !== 1) {
            return '';
        }
        $object = get_taxonomy($value);
        return $object && $object->public && $object->publicly_queryable ? $value : '';
    }

    public static function key(mixed $requested, string $target): string
    {
        global $wp;
        $fallback = 'tcf-' . $target;
        if (!is_string($requested) || preg_match('/^[a-z][a-z0-9_-]{0,47}$/D', $requested) !== 1) {
            return $fallback;
        }
        $reserved = ['tc_loop_fragment', 'rest_route', 'elementor-preview', 'action', 'doing_wp_cron'];
        if (is_object($wp)) {
            $reserved = array_merge($reserved, $wp->public_query_vars ?? [], $wp->private_query_vars ?? []);
        }
        if (in_array($requested, $reserved, true) || str_starts_with($requested, 'e-page-') || str_starts_with($requested, 'tcf-')) {
            return $fallback;
        }
        return $requested;
    }
}
