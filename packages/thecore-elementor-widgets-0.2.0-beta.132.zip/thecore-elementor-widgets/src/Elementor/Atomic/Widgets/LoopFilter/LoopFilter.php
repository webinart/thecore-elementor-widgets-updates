<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\LoopFilter;

use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Select_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Text_Control;
use Elementor\Modules\AtomicWidgets\DynamicTags\Dynamic_Prop_Type;
use Elementor\Modules\AtomicWidgets\Elements\Base\Atomic_Widget_Base;
use Elementor\Modules\AtomicWidgets\Elements\Base\Has_Template;
use Elementor\Modules\AtomicWidgets\PropTypes\Classes_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\Components\PropTypes\Overridable_Prop_Type;

final class LoopFilter extends Atomic_Widget_Base
{
    use Has_Template {
        get_templates_contents as private originalTemplates;
    }

    private const HANDLE = 'thecore-loop-filter';
    private const TEMPLATE = 'thecore/elements/loop-filter';

    public static function get_element_type(): string
    {
        return 'thecore-loop-filter';
    }

    public function get_title(): string
    {
        return __('Filtre de boucle (V4)', 'thecore-elementor-widgets');
    }

    public function get_icon(): string
    {
        return 'eicon-filter';
    }

    public function get_keywords(): array
    {
        return ['filtre', 'boucle', 'loop', 'filter', 'taxonomy', 'catégorie', 'ajax'];
    }

    public function get_script_depends(): array
    {
        return [self::HANDLE];
    }

    public function get_style_depends(): array
    {
        return [self::HANDLE];
    }

    protected static function define_props_schema(): array
    {
        $schema = ['classes' => Classes_Prop_Type::make()->default([])];
        foreach (['target_loop' => '', 'taxonomy' => 'category', 'url_key' => '', 'all_label' => '', 'aria_label' => ''] as $name => $default) {
            $schema[$name] = String_Prop_Type::make()->default($default)
                ->meta(Dynamic_Prop_Type::ignore())->meta(Overridable_Prop_Type::ignore());
        }
        return $schema;
    }

    protected function define_atomic_controls(): array
    {
        $loops = EditorChoices::loops();
        $target = $loops ? Select_Control::bind_to('target_loop')->set_options($loops) : Text_Control::bind_to('target_loop');
        return [Section::make()->set_label(__('Filtrage', 'thecore-elementor-widgets'))->set_items([
            $target->set_label(__('Boucle à filtrer', 'thecore-elementor-widgets'))
                ->set_description($loops
                    ? __('Choisissez une boucle Elementor V4 de cette page. Enregistrez puis rouvrez l’éditeur pour voir une nouvelle boucle.', 'thecore-elementor-widgets')
                    : __('Saisissez l’identifiant Elementor de la boucle ou enregistrez la page puis rouvrez l’éditeur pour la choisir.', 'thecore-elementor-widgets')),
            Select_Control::bind_to('taxonomy')->set_label(__('Taxonomie', 'thecore-elementor-widgets'))
                ->set_options(EditorChoices::taxonomies()),
            Text_Control::bind_to('all_label')->set_label(__('Libellé du lien sans filtre', 'thecore-elementor-widgets'))
                ->set_placeholder(__('Tous', 'thecore-elementor-widgets')),
            Text_Control::bind_to('aria_label')->set_label(__('Nom accessible du filtre', 'thecore-elementor-widgets'))
                ->set_placeholder(__('Filtrer les résultats', 'thecore-elementor-widgets')),
            Text_Control::bind_to('url_key')->set_label(__('Paramètre d’URL (facultatif)', 'thecore-elementor-widgets'))
                ->set_description(__('Laissez vide pour utiliser un paramètre propre à la boucle. Sur une même page, chaque boucle doit avoir son propre paramètre.', 'thecore-elementor-widgets')),
        ])];
    }

    protected function get_templates(): array
    {
        return [self::TEMPLATE => __DIR__ . '/loop-filter.html.twig'];
    }

    protected function get_templates_contents()
    {
        $templates = $this->originalTemplates();
        $templates[self::TEMPLATE] = str_replace('<!--tc-editor-terms-->', EditorChoices::previewTerms(), $templates[self::TEMPLATE]);
        return $templates;
    }

    protected function render()
    {
        $settings = $this->get_atomic_settings();
        $target = Config::target($settings['target_loop'] ?? '');
        $tax = Config::taxonomy($settings['taxonomy'] ?? 'category');
        $permalink = get_permalink(get_queried_object_id());
        if ($target === '' || $tax === '' || !$permalink) {
            return;
        }
        $key = Config::key($settings['url_key'] ?? '', $target);
        $terms = get_terms(['taxonomy' => $tax, 'hide_empty' => true, 'orderby' => 'name', 'order' => 'ASC']);
        if (is_wp_error($terms) || !$terms) {
            return;
        }
        $current = isset($_GET[$key]) && is_string($_GET[$key]) ? wp_unslash($_GET[$key]) : '';
        $all = trim((string) ($settings['all_label'] ?? '')) ?: __('Tous', 'thecore-elementor-widgets');
        $aria = trim((string) ($settings['aria_label'] ?? '')) ?: __('Filtrer les résultats', 'thecore-elementor-widgets');
        $query = wp_parse_url(wp_unslash($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_QUERY);
        $base = $permalink;
        if (is_string($query) && $query !== '') {
            // Use the actual site permalink, never a request-controlled host or path.
            $base .= (str_contains($base, '?') ? '&' : '?') . $query;
        }
        $base = remove_query_arg([$key, 'e-page-' . $target, 'tc_loop_fragment'], $base);
        $classes = array_merge(['tc-loop-filter'], (array) ($settings['classes'] ?? []));
        $this->add_render_attribute('nav', [
            'class' => $classes,
            'data-id' => $this->get_id(),
            'data-e-type' => 'widget',
            'data-interaction-id' => $this->get_interaction_id(),
            'data-tc-loop-filter' => $target,
            'data-tc-filter-key' => $key,
            'data-tc-status-label' => __('Page %s', 'thecore-elementor-widgets'),
            'aria-label' => $aria,
        ]);
        if (!empty($settings['_cssid'])) {
            $this->add_render_attribute('nav', 'id', $settings['_cssid']);
        }
        echo '<nav ' . $this->get_render_attribute_string('nav') . '>';
        self::link($base, '', $all, $current);
        foreach ($terms as $term) {
            self::link(add_query_arg($key, rawurlencode($term->slug), $base), $term->slug, $term->name, $current);
        }
        echo '</nav>';
    }

    private static function link(string $href, string $slug, string $label, string $current): void
    {
        echo '<a href="' . esc_url($href) . '" data-tc-term="' . esc_attr($slug) . '"'
            . ($slug === $current ? ' aria-current="true"' : '') . '>' . esc_html($label) . '</a>';
    }
}
