<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\FormMedia;

/** Presentation only; upload authorization and policy are compiled again on the server. */
final class MarkupBuilder
{
    public function build(array $settings, string $elementId, array $attributes = []): string
    {
        $mode = $settings['media-mode'] ?? 'both';
        if (! in_array($mode, ['photos', 'videos', 'both'], true)) {
            $mode = 'both';
        }
        $defaultLabel = match ($mode) {
            'photos' => 'Photos', 'videos' => 'Vidéos', default => 'Photos et vidéos',
        };
        $label = is_string($settings['label'] ?? null) && trim($settings['label']) !== '' ? trim($settings['label']) : $defaultLabel;
        $inputId = is_string($settings['_cssid'] ?? null) && trim($settings['_cssid']) !== ''
            ? $settings['_cssid'] : 'thecore-media-' . $elementId;
        $required = ($settings['required'] ?? false) === true;
        $accept = [];
        if ($mode !== 'videos') {
            $accept = ['image/jpeg', 'image/png', 'image/webp', '.jpg', '.jpeg', '.png', '.webp'];
        }
        if ($mode !== 'photos') {
            $accept = [...$accept, 'video/mp4', 'video/quicktime', 'video/webm', '.mp4', '.m4v', '.mov', '.webm'];
        }
        $count = min(10, max(1, (int) ($settings['max-files'] ?? 5)));
        $size = min(150, max(1, (int) ($settings['max-file-size-mb'] ?? 25)));
        // _cssid belongs to the input, not also to its wrapper.
        unset($attributes['id']);
        $attributes['data-thecore-form-media'] = '1';
        $attributes['data-field-id'] = $elementId;
        $attributes = array_merge($attributes, (new Appearance())->attributes($settings));
        $html = '<div';
        foreach ($attributes as $name => $value) {
            $html .= ' ' . esc_attr($name) . '="' . esc_attr((string) $value) . '"';
        }
        $html .= '><label class="tc-form-media__label" for="' . esc_attr($inputId) . '">' . esc_html($label);
        $html .= $required ? ' <span aria-hidden="true">*</span>' : ' <span class="tc-form-media__optional">(facultatif)</span>';
        $html .= '</label><input type="file" id="' . esc_attr($inputId) . '" data-thecore-media-input multiple accept="' . esc_attr(implode(',', $accept)) . '"';
        if ($required) {
            // Required media validates received files, not a transient file-picker selection.
            $html .= ' aria-required="true"';
        }
        $html .= '><div data-thecore-media-ui></div><p class="tc-form-media__hint">';
        $formats = match ($mode) {
            'photos' => 'JPG, PNG ou WebP', 'videos' => 'MP4, MOV ou WebM', default => 'JPG, PNG, WebP, MP4, MOV ou WebM',
        };
        $html .= esc_html($count . ' fichier' . ($count > 1 ? 's' : '') . ' maximum · ' . $size . ' Mio par fichier · ' . $formats . '.');
        $html .= '</p><p data-thecore-media-status role="status" aria-live="polite" tabindex="-1"></p>';
        $html .= '<noscript>JavaScript est nécessaire pour ajouter des fichiers à ce formulaire.</noscript></div>';
        return $html;
    }
}
