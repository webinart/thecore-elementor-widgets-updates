<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\Gallery;

use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Number_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Select_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Switch_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Text_Control;
use Elementor\Modules\AtomicWidgets\DynamicTags\Dynamic_Prop_Type;
use Elementor\Modules\AtomicWidgets\Elements\Base\Atomic_Widget_Base;
use Elementor\Modules\AtomicWidgets\Elements\Base\Has_Template;
use Elementor\Modules\AtomicWidgets\PropTypes\Classes_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Boolean_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Number_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\AtomicWidgets\Styles\Style_Definition;
use Elementor\Modules\AtomicWidgets\Styles\Style_Variant;
use TheCore\ElementorWidgets\Gallery\GalleryData;
use TheCore\ElementorWidgets\Gallery\GalleryModule;
use TheCore\ElementorWidgets\Gallery\GalleryRepository;
use TheCore\ElementorWidgets\Plugin;

final class Gallery extends Atomic_Widget_Base
{
    use Has_Template;

    public static $widget_description = 'Publication media galleries with per-instance masonry or thumbnail layouts and The Core image lightbox.';

    public static function get_element_type(): string
    {
        return 'thecore-gallery';
    }

    public function get_title(): string
    {
        return esc_html__('Galerie The Core (V4)', 'thecore-elementor-widgets');
    }

    public function get_icon(): string
    {
        return 'eicon-gallery-masonry';
    }

    public function get_keywords(): array
    {
        return ['galerie', 'gallery', 'images', 'photos', 'masonry', 'meta', 'atomic'];
    }

    public function get_script_depends(): array
    {
        return [GalleryModule::SCRIPT];
    }

    public function get_style_depends(): array
    {
        return [GalleryModule::STYLE];
    }

    protected function is_dynamic_content(): bool
    {
        return true;
    }

    protected static function define_props_schema(): array
    {
        $props = ['classes' => Classes_Prop_Type::make()->default([])];
        foreach (
            [
            'gallery_key' => GalleryData::DEFAULT_KEY,
            'layout' => 'masonry',
            'ratio' => '4/3',
            'aria_label' => 'Galerie de photos',
            ] as $name => $default
        ) {
            $props[$name] = String_Prop_Type::make()->default($default)->meta(Dynamic_Prop_Type::ignore());
        }
        $props['layout']->enum(['masonry', 'tiles']);
        $props['ratio']->enum(['1/1', '4/3', '3/2', '16/9']);
        foreach (['columns' => 4, 'tablet_columns' => 2, 'mobile_columns' => 1, 'gap' => 10] as $name => $default) {
            $props[$name] = Number_Prop_Type::make()->default($default)->meta(Dynamic_Prop_Type::ignore());
        }
        foreach (['captions', 'lightbox'] as $name) {
            $props[$name] = Boolean_Prop_Type::make()->default(true)->meta(Dynamic_Prop_Type::ignore());
        }
        return $props;
    }

    protected function define_base_styles(): array
    {
        return ['base' => Style_Definition::make()->add_variant(
            Style_Variant::make()->add_prop('width', \Elementor\Modules\AtomicWidgets\PropTypes\Size_Prop_Type::generate(['size' => 100, 'unit' => '%']))
        )];
    }

    protected function define_atomic_controls(): array
    {
        return [
            Section::make()->set_label(__('Source', 'thecore-elementor-widgets'))->set_items([
                Text_Control::bind_to('gallery_key')->set_label(__('Identifiant de la galerie', 'thecore-elementor-widgets'))
                    ->set_description(__('Lit la méta Galeries de la publication courante. Recopiez son identifiant, par exemple principale ou travaux. Les images se gèrent dans la publication, pas dans ce widget.', 'thecore-elementor-widgets')),
                Text_Control::bind_to('aria_label')->set_label(__('Libellé accessible', 'thecore-elementor-widgets')),
            ]),
            Section::make()->set_label(__('Présentation', 'thecore-elementor-widgets'))->set_items([
                Select_Control::bind_to('layout')->set_label(__('Disposition', 'thecore-elementor-widgets'))->set_options([
                    ['label' => __('Maçonnerie', 'thecore-elementor-widgets'), 'value' => 'masonry'],
                    ['label' => __('Vignettes', 'thecore-elementor-widgets'), 'value' => 'tiles'],
                ]),
                self::numberControl('columns', __('Colonnes ordinateur', 'thecore-elementor-widgets'), 1, 6),
                self::numberControl('tablet_columns', __('Colonnes tablette', 'thecore-elementor-widgets'), 1, 6),
                self::numberControl('mobile_columns', __('Colonnes mobile', 'thecore-elementor-widgets'), 1, 4),
                self::numberControl('gap', __('Espacement (px)', 'thecore-elementor-widgets'), 0, 80),
                Select_Control::bind_to('ratio')->set_label(__('Format des vignettes', 'thecore-elementor-widgets'))->set_options([
                    ['label' => 'Carré (1:1)', 'value' => '1/1'],
                    ['label' => '4:3', 'value' => '4/3'],
                    ['label' => '3:2', 'value' => '3/2'],
                    ['label' => '16:9', 'value' => '16/9'],
                ])->set_description(__('Utilisé uniquement en mode Vignettes. La maçonnerie conserve les proportions des images.', 'thecore-elementor-widgets')),
                Switch_Control::bind_to('captions')->set_label(__('Afficher les légendes', 'thecore-elementor-widgets')),
                Switch_Control::bind_to('lightbox')->set_label(__('Agrandir dans la visionneuse', 'thecore-elementor-widgets'))
                    ->set_description(__('Nécessite la fonctionnalité Visionneuse d’images The Core.', 'thecore-elementor-widgets')),
            ]),
            Section::make()->set_label(__('Réglages', 'thecore-elementor-widgets'))->set_id('settings')->set_items([
                Text_Control::bind_to('_cssid')->set_label(__('ID', 'thecore-elementor-widgets'))->set_meta($this->get_css_id_control_meta()),
            ]),
        ];
    }

    protected function get_templates(): array
    {
        return ['thecore/elements/gallery' => __DIR__ . '/gallery.html.twig'];
    }

    protected function render()
    {
        $raw = $this->get_atomic_settings();
        $settings = (new DisplaySettings())->normalize($raw);
        $settings['lightbox'] = $settings['lightbox'] && Plugin::instance()->isFeatureEnabled('image-lightbox');
        $images = (new GalleryRepository())->images(GalleryRepository::currentPostId(), $settings['gallery_key']);
        $attributes = [
            'class' => implode(' ', array_merge([$this->get_base_styles_dictionary()['base'] ?? ''], (array) ($raw['classes'] ?? []))),
            'data-id' => $this->get_id(),
            'data-interaction-id' => $this->get_interaction_id(),
        ];
        $cssId = $this->get_atomic_setting('_cssid');
        if (is_string($cssId) && '' !== trim($cssId)) {
            $attributes['id'] = $cssId;
        }
        if ([] !== $images) {
            wp_enqueue_style(GalleryModule::STYLE);
            wp_enqueue_script(GalleryModule::SCRIPT);
            if ($settings['lightbox']) {
                do_action('thecore/image-lightbox/enqueue');
            }
        }
        echo (new MarkupBuilder())->build($images, $settings, $attributes);
    }

    private static function numberControl(string $name, string $label, int $minimum, int $maximum): Number_Control
    {
        return Number_Control::bind_to($name)->set_label($label)->set_min($minimum)->set_max($maximum)
            ->set_step(1)->set_should_force_int(true);
    }
}
