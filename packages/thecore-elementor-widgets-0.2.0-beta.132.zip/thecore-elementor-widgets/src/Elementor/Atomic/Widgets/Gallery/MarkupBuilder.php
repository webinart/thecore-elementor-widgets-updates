<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\Gallery;

final class MarkupBuilder
{
    public function build(array $images, array $settings, array $attributes = []): string
    {
        if ([] === $images) {
            return '';
        }
        $settings = (new DisplaySettings())->normalize($settings);
        $attributes = array_intersect_key($attributes, array_flip(['id', 'class', 'data-id', 'data-interaction-id']));
        $attributes['class'] = trim('thecore-gallery ' . ($attributes['class'] ?? ''));
        $attributes['data-thecore-gallery-layout'] = $settings['layout'];
        $attributes['data-thecore-gallery-columns'] = (string) min($settings['columns'], count($images));
        $attributes['data-thecore-gallery-tablet-columns'] = (string) min($settings['tablet_columns'], count($images));
        $attributes['data-thecore-gallery-mobile-columns'] = (string) min($settings['mobile_columns'], count($images));
        $attributes['data-thecore-gallery-gap'] = (string) $settings['gap'];
        $attributes['data-thecore-gallery-ratio'] = $settings['ratio'];
        $attributes['role'] = 'group';
        $attributes['aria-label'] = $settings['aria_label'];
        $attributes['style'] = sprintf(
            '--thecore-gallery-columns:%d;--thecore-gallery-tablet-columns:%d;--thecore-gallery-mobile-columns:%d;--thecore-gallery-gap:%dpx;--thecore-gallery-ratio:%s',
            min($settings['columns'], count($images)),
            min($settings['tablet_columns'], count($images)),
            min($settings['mobile_columns'], count($images)),
            $settings['gap'],
            $settings['ratio']
        );
        if ($settings['lightbox']) {
            $attributes['data-thecore-gallery'] = 'thecore-gallery-' . ($attributes['data-id'] ?? 'photos');
        }
        $html = '<div' . $this->attributes($attributes) . '>';
        foreach ($images as $index => $image) {
            $html .= '<figure class="thecore-gallery__item" data-thecore-gallery-item>';
            $tag = $settings['lightbox'] ? 'a' : 'div';
            $link = ['class' => 'thecore-gallery__media'];
            if ($settings['lightbox']) {
                $label = $image['alt'] ?: ($image['caption'] ?: sprintf(__('Photo %d', 'thecore-elementor-widgets'), $index + 1));
                $link += [
                    'href' => esc_url($image['full_src']),
                    'data-pswp-width' => (string) $image['full_width'],
                    'data-pswp-height' => (string) $image['full_height'],
                    'aria-label' => sprintf(__('Agrandir : %s', 'thecore-elementor-widgets'), $label),
                ];
                if ('' !== $image['caption']) {
                    $link['data-thecore-caption'] = $image['caption'];
                }
            }
            $photo = [
                'class' => 'thecore-gallery__image',
                'src' => esc_url($image['src']),
                'alt' => $image['alt'],
                'width' => (string) $image['width'],
                'height' => (string) $image['height'],
                'loading' => 'lazy',
                'decoding' => 'async',
            ];
            foreach (['srcset', 'sizes'] as $key) {
                if ('' !== $image[$key]) {
                    $photo[$key] = $image[$key];
                }
            }
            $html .= '<' . $tag . $this->attributes($link) . '><img' . $this->attributes($photo) . '></' . $tag . '>';
            if ($settings['captions'] && '' !== $image['caption']) {
                $html .= '<figcaption class="thecore-gallery__caption">' . esc_html($image['caption']) . '</figcaption>';
            }
            $html .= '</figure>';
        }
        return $html . '</div>';
    }

    private function attributes(array $attributes): string
    {
        $html = '';
        foreach ($attributes as $name => $value) {
            $html .= ' ' . $name . '="' . esc_attr((string) $value) . '"';
        }
        return $html;
    }
}
