<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\Gallery;

use TheCore\ElementorWidgets\Gallery\GalleryData;

final class DisplaySettings
{
    public function normalize(array $settings): array
    {
        return [
            'gallery_key' => substr(sanitize_key(GalleryData::text($settings['gallery_key'] ?? GalleryData::DEFAULT_KEY)), 0, 64) ?: GalleryData::DEFAULT_KEY,
            'layout' => in_array($settings['layout'] ?? '', ['masonry', 'tiles'], true) ? $settings['layout'] : 'masonry',
            'columns' => $this->number($settings['columns'] ?? null, 4, 1, 6),
            'tablet_columns' => $this->number($settings['tablet_columns'] ?? null, 2, 1, 6),
            'mobile_columns' => $this->number($settings['mobile_columns'] ?? null, 1, 1, 4),
            'gap' => $this->number($settings['gap'] ?? null, 10, 0, 80),
            'ratio' => in_array($settings['ratio'] ?? '', ['1/1', '4/3', '3/2', '16/9'], true) ? $settings['ratio'] : '4/3',
            'captions' => $this->boolean($settings['captions'] ?? true),
            'lightbox' => $this->boolean($settings['lightbox'] ?? true),
            'aria_label' => GalleryData::text($settings['aria_label'] ?? '') ?: __('Galerie de photos', 'thecore-elementor-widgets'),
        ];
    }

    private function number(mixed $value, int $default, int $minimum, int $maximum): int
    {
        return is_numeric($value) && is_finite((float) $value)
            ? max($minimum, min($maximum, (int) $value)) : $default;
    }

    private function boolean(mixed $value): bool
    {
        return in_array($value, [true, 1, '1', 'true', 'yes'], true);
    }
}
