<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets;

use TheCore\ElementorWidgets\Admin\AdminMenu;
use TheCore\ElementorWidgets\Assets\AdminAssets;
use TheCore\ElementorWidgets\Assets\EditorAssets;
use TheCore\ElementorWidgets\Assets\FrontendAssets;
use TheCore\ElementorWidgets\Assets\FormMediaAssets;
use TheCore\ElementorWidgets\Assets\FormFlowAssets;
use TheCore\ElementorWidgets\CookieConsent\CookieConsentModule;
use TheCore\ElementorWidgets\Contracts\Bootable;
use TheCore\ElementorWidgets\FormSecurity\Admin\BlockedSubmissionsPage;
use TheCore\ElementorWidgets\FormSecurity\FormSecurityModule;
use TheCore\ElementorWidgets\Forms\FormsModule;
use TheCore\ElementorWidgets\Forms\Media\Module as FormMediaModule;
use TheCore\ElementorWidgets\Forms\Api\ApiModule;
use TheCore\ElementorWidgets\Forms\Classic\NativeModule;
use TheCore\ElementorWidgets\Forms\Submissions\Installer as FormSubmissionsInstaller;
use TheCore\ElementorWidgets\Forms\Submissions\SubmissionsModule;
use TheCore\ElementorWidgets\FormSecurity\Infrastructure\BlockedSubmissionDataPurger;
use TheCore\ElementorWidgets\FormSecurity\Infrastructure\BlockedSubmissionStore;
use TheCore\ElementorWidgets\FormSecurity\Infrastructure\Installer as FormSecurityInstaller;
use TheCore\ElementorWidgets\FormSecurity\Infrastructure\Maintenance as FormSecurityMaintenance;
use TheCore\ElementorWidgets\FormSecurity\Infrastructure\SecurityStore as FormSecurityStore;
use TheCore\ElementorWidgets\FormSecurity\Privacy\BlockedSubmissionsPrivacy;
use TheCore\ElementorWidgets\FormSecurity\Support\DisabledProtectionGuard;
use TheCore\ElementorWidgets\FormSecurity\Support\FormContextResolver;
use TheCore\ElementorWidgets\ImageLightbox\ImageLightboxModule;
use TheCore\ElementorWidgets\LoopFilter\Runtime as LoopFilterRuntime;
use TheCore\ElementorWidgets\Gallery\GalleryModule;
use TheCore\ElementorWidgets\Modules\WidgetsModule;
use TheCore\ElementorWidgets\NativeInteractions\NativeInteractionsModule;
use TheCore\ElementorWidgets\Notice\AdminNoticeManager;
use TheCore\ElementorWidgets\Options\OptionsRepository;
use TheCore\ElementorWidgets\Options\StateSanitizer;
use TheCore\ElementorWidgets\Registry\FeaturesRegistry;
use TheCore\ElementorWidgets\Registry\WidgetsRegistry;
use TheCore\ElementorWidgets\Search\SearchModalAjaxHandler;
use TheCore\ElementorWidgets\Support\ElementorDocumentSaveSanitizer;
use TheCore\ElementorWidgets\Support\RequirementsChecker;
use TheCore\ElementorWidgets\TChat\Infrastructure\Installer as TChatInstaller;
use TheCore\ElementorWidgets\TChat\TChatModule;
use TheCore\ElementorWidgets\Update\PluginUpdater;

final class Plugin
{
    private static ?self $instance = null;

    private bool $booted = false;

    private WidgetsRegistry $widgetsRegistry;
    private FeaturesRegistry $featuresRegistry;
    private OptionsRepository $optionsRepository;
    private RequirementsChecker $requirementsChecker;

    /**
     * @var Bootable[]
     */
    private array $services = [];

    private function __construct()
    {
        $this->widgetsRegistry = new WidgetsRegistry();
        $this->featuresRegistry = new FeaturesRegistry();
        $this->optionsRepository = new OptionsRepository(new StateSanitizer());
        $this->requirementsChecker = new RequirementsChecker();
    }

    public static function instance(): self
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public static function activate(): void
    {
        $plugin = self::instance();

        $plugin->optionsRepository->initializeDefaults(
            $plugin->widgetsRegistry->defaults(),
            $plugin->featuresRegistry->defaults()
        );

        TChatInstaller::install();
        FormSecurityInstaller::install();
        FormSubmissionsInstaller::install();
    }

    public static function deactivate(bool $networkDeactivating = false): void
    {
        $purged = (new BlockedSubmissionDataPurger())->purgeForDeactivation(
            $networkDeactivating
        );

        if (! $purged) {
            wp_die(
                esc_html__(
                    'La table temporaire des soumissions bloquées n’a pas pu être supprimée. Le plugin reste actif afin de ne pas laisser de données personnelles orphelines.',
                    'thecore-elementor-widgets'
                )
            );
        }

        if (function_exists('wp_clear_scheduled_hook')) {
            wp_clear_scheduled_hook(FormSecurityMaintenance::CLEANUP_HOOK);
            SubmissionsModule::unschedule($networkDeactivating);
            self::forMediaSites($networkDeactivating, static fn () => FormMediaModule::deactivate());
        }
    }

    public function boot(): void
    {
        if ($this->booted) {
            return;
        }

        add_action('init', [$this, 'loadTextDomain']);

        $this->optionsRepository->initializeDefaults(
            $this->widgetsRegistry->defaults(),
            $this->featuresRegistry->defaults()
        );

        $widgetState = $this->optionsRepository->getWidgetsState($this->widgetsRegistry->defaults());
        $featureState = $this->optionsRepository->getFeaturesState($this->featuresRegistry->defaults());
        $formSecurityEnabled = ! empty($featureState['form-security']);
        $blockedSubmissionStore = new BlockedSubmissionStore();

        $this->services = [
            new AdminAssets(),
            new EditorAssets(),
            new FormMediaAssets(),
            new FormFlowAssets(),
            new PluginUpdater(),
            new ElementorDocumentSaveSanitizer(),
            new SearchModalAjaxHandler(),
            new FrontendAssets($this->optionsRepository, $this->featuresRegistry),
            new AdminMenu(
                $this->widgetsRegistry,
                $this->featuresRegistry,
                $this->optionsRepository,
                $this->requirementsChecker
            ),
            new AdminNoticeManager($this->requirementsChecker),
            new WidgetsModule(
                $this->widgetsRegistry,
                $this->optionsRepository,
                $this->requirementsChecker
            ),
            new FormSecurityMaintenance(new FormSecurityStore(), $blockedSubmissionStore),
            new BlockedSubmissionsPage($blockedSubmissionStore),
            BlockedSubmissionsPrivacy::fromStore($blockedSubmissionStore),
            new SubmissionsModule(),
            new FormMediaModule(),
            new ApiModule(),
            new NativeModule(),
            new DisabledProtectionGuard(
                new FormContextResolver(),
                $formSecurityEnabled
            ),
        ];

        if ($formSecurityEnabled) {
            $this->services[] = new FormSecurityModule();
        }

        if (! empty($featureState['image-lightbox'])) {
            $this->services[] = new ImageLightboxModule();
        }

        if (! empty($widgetState['gallery'])) {
            $this->services[] = new GalleryModule();
        }

        if (! empty($widgetState['loop-filter'])) {
            $this->services[] = new LoopFilterRuntime();
        }

        if (! empty($featureState['responsive-disclosure']) || ! empty($featureState['click-to-play-video'])) {
            $this->services[] = new NativeInteractionsModule(
                ! empty($featureState['responsive-disclosure']),
                ! empty($featureState['click-to-play-video'])
            );
        }

        if (! empty($widgetState['form'])) {
            $this->services[] = new FormsModule($formSecurityEnabled);
        }

        if (! empty($widgetState['cookie-consent'])) {
            $this->services[] = new CookieConsentModule();
        }

        if (! empty($widgetState['tchat'])) {
            $this->services[] = new TChatModule();
        }

        foreach ($this->services as $service) {
            $service->register();
        }

        $this->booted = true;
    }

    public function loadTextDomain(): void
    {
        load_plugin_textdomain(
            'thecore-elementor-widgets',
            false,
            dirname(THECORE_ELEMENTOR_WIDGETS_BASENAME) . '/languages'
        );
    }

    public function isFeatureEnabled(string $featureId): bool
    {
        $state = $this->optionsRepository->getFeaturesState($this->featuresRegistry->defaults());

        return ! empty($state[$featureId]);
    }

    private static function forMediaSites(bool $networkWide, callable $callback): void
    {
        if (! $networkWide || ! is_multisite()) {
            $callback();
            return;
        }
        foreach (get_sites(['fields' => 'ids', 'number' => 0]) as $blogId) {
            switch_to_blog((int) $blogId);
            try {
                $callback();
            } finally {
                restore_current_blog();
            }
        }
    }
}
