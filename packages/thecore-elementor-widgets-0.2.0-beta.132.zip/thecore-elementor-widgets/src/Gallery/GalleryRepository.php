<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Gallery;

final class GalleryRepository
{
    public function all(int $postId): array
    {
        return $postId > 0 ? GalleryData::normalize(get_post_meta($postId, GalleryData::META_KEY, true)) : [];
    }

    public function get(int $postId, string $key): array
    {
        foreach ($this->all($postId) as $gallery) {
            if ($gallery['key'] === $key) {
                return $gallery;
            }
        }
        return ['key' => $key, 'title' => '', 'images' => []];
    }

    public function images(int $postId, string $key): array
    {
        $images = [];
        foreach ($this->get($postId, $key)['images'] as $imageId) {
            if (! wp_attachment_is_image($imageId)) {
                continue;
            }
            $source = wp_get_attachment_image_src($imageId, 'large');
            $full = wp_get_attachment_image_src($imageId, 'full');
            if (! $source || ! $full || $source[1] < 1 || $source[2] < 1 || $full[1] < 1 || $full[2] < 1) {
                continue;
            }
            $images[] = [
                'id' => $imageId,
                'src' => esc_url_raw((string) $source[0]),
                'width' => (int) $source[1],
                'height' => (int) $source[2],
                'srcset' => (string) (wp_get_attachment_image_srcset($imageId, 'large') ?: ''),
                'sizes' => (string) (wp_get_attachment_image_sizes($imageId, 'large') ?: ''),
                'full_src' => esc_url_raw((string) $full[0]),
                'full_width' => (int) $full[1],
                'full_height' => (int) $full[2],
                'alt' => GalleryData::text(get_post_meta($imageId, '_wp_attachment_image_alt', true)),
                'caption' => GalleryData::text(wp_get_attachment_caption($imageId)),
            ];
        }
        return $images;
    }

    public static function currentPostId(): int
    {
        foreach ([(int) get_the_ID(), (int) get_queried_object_id()] as $postId) {
            if ($postId > 0 && ! in_array(get_post_type($postId), ['elementor_library', 'revision', false], true)) {
                return $postId;
            }
        }
        if (class_exists('\Elementor\Plugin')) {
            $document = \Elementor\Plugin::$instance->documents->get_current();
            if ($document) {
                return (int) $document->get_main_id();
            }
        }
        return 0;
    }
}
