<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Gallery;

final class GalleryData
{
    public const META_KEY = '_thecore_galleries';
    public const DEFAULT_KEY = 'principale';
    public const MAX_GALLERIES = 20;
    public const MAX_IMAGES = 500;

    public static function normalize(mixed $value): array
    {
        if (! is_array($value)) {
            return [];
        }
        $galleries = [];
        foreach (array_slice($value, 0, self::MAX_GALLERIES) as $row) {
            if (! is_array($row) || ! is_string($row['key'] ?? null)) {
                continue;
            }
            $key = substr(sanitize_key($row['key']), 0, 64);
            if ('' === $key || isset($galleries[$key])) {
                continue;
            }
            $images = [];
            foreach (array_slice(is_array($row['images'] ?? null) ? $row['images'] : [], 0, self::MAX_IMAGES) as $image) {
                if (! is_int($image) && ! (is_string($image) && ctype_digit($image))) {
                    continue;
                }
                $imageId = filter_var($image, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
                if (false !== $imageId) {
                    $images[$imageId] = $imageId;
                }
            }
            $galleries[$key] = [
                'key' => $key,
                'title' => self::text($row['title'] ?? ''),
                'images' => array_values($images),
            ];
        }
        return array_values($galleries);
    }

    public static function text(mixed $value): string
    {
        return is_string($value) ? sanitize_text_field($value) : '';
    }
}
