<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Assets;

use TheCore\ElementorWidgets\Contracts\Bootable;

/** Native form groups opt in to these assets; old forms retain their dependencies. */
final class FormFlowAssets implements Bootable
{
    public const HANDLE = 'thecore-form-flow';

    public function register(): void
    {
        add_action('wp_enqueue_scripts', [$this, 'registerAssets'], 6);
        add_action('elementor/editor/before_enqueue_scripts', [$this, 'registerAssets'], 6);
    }

    public function registerAssets(): void
    {
        wp_register_script(self::HANDLE, THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/form-flow.js', [], THECORE_ELEMENTOR_WIDGETS_VERSION, true);
        wp_register_style(self::HANDLE, THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/form-flow.css', [], THECORE_ELEMENTOR_WIDGETS_VERSION);
    }
}
