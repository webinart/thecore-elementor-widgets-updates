<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Assets;

use TheCore\ElementorWidgets\Contracts\Bootable;

final class EditorAssets implements Bootable
{
    public const ATOMIC_CONTROLS_SCRIPT = 'thecore-atomic-controls';
    public const FORM_FLOW_EDITOR = 'thecore-form-flow-editor';

    public function register(): void
    {
        add_action('elementor/editor/after_enqueue_scripts', [$this, 'enqueueScripts']);
    }

    public function enqueueScripts(): void
    {
        wp_enqueue_script(
            self::ATOMIC_CONTROLS_SCRIPT,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/editor/atomic-controls.js',
            ['elementor-editor'],
            THECORE_ELEMENTOR_WIDGETS_VERSION,
            true
        );
        wp_enqueue_script(
            self::FORM_FLOW_EDITOR,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/editor/form-flow-editor.js',
            [self::ATOMIC_CONTROLS_SCRIPT, 'elementor-editor'],
            THECORE_ELEMENTOR_WIDGETS_VERSION,
            true
        );
        wp_enqueue_style(
            self::FORM_FLOW_EDITOR,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/editor/form-flow-editor.css',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION
        );
    }
}
