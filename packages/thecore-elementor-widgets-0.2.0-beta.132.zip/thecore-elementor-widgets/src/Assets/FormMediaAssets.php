<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Assets;

use TheCore\ElementorWidgets\Contracts\Bootable;

/** Registration is cheap; assets are enqueued only by an actual media field. */
final class FormMediaAssets implements Bootable
{
    public const HANDLE = 'thecore-form-media';

    public function register(): void
    {
        add_action('wp_enqueue_scripts', [$this, 'registerAssets'], 6);
        add_action('elementor/editor/before_enqueue_scripts', [$this, 'registerAssets'], 6);
    }

    public function registerAssets(): void
    {
        wp_register_script(self::HANDLE, THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/form-media.js', [], THECORE_ELEMENTOR_WIDGETS_VERSION, true);
        wp_register_style(self::HANDLE, THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/form-media.css', [], THECORE_ELEMENTOR_WIDGETS_VERSION);
        wp_add_inline_script(self::HANDLE, 'window.TheCoreAtomicFormMediaAssets = ' . wp_json_encode([
            'qrCodeUrl' => add_query_arg('ver', THECORE_ELEMENTOR_WIDGETS_VERSION, THECORE_ELEMENTOR_WIDGETS_URL . 'assets/vendor/qrcode/qrcode.js'),
        ]) . ';', 'before');
    }
}
