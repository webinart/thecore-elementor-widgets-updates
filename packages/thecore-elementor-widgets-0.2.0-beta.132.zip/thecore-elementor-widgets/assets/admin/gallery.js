(() => {
    'use strict';
    const labels = window.TheCoreGalleryAdmin || {};
    const create = (tag, text = '', className = '') => {
        const element = document.createElement(tag);
        element.textContent = text;
        if (className) element.className = className;
        return element;
    };
    const safeUrl = value => {
        try {
            const url = new URL(value, location.href);
            return ['http:', 'https:'].includes(url.protocol) ? url.href : '';
        } catch { return ''; }
    };
    for (const editor of document.querySelectorAll('[data-thecore-gallery-editor-admin]')) {
        const payload = editor.querySelector('[name="thecore_galleries_payload"]');
        const list = editor.querySelector('[data-thecore-gallery-list]');
        let galleries;
        try { galleries = JSON.parse(payload.value); } catch { continue; }
        if (!Array.isArray(galleries)) continue;
        const sync = () => { payload.value = JSON.stringify(galleries); };
        const button = (text, action) => {
            const element = create('button', text, 'button');
            element.type = 'button';
            element.addEventListener('click', action);
            return element;
        };
        const validate = () => {
            const keys = galleries.map(gallery => gallery.key);
            list.querySelectorAll('[data-gallery-key]').forEach((input, index) => {
                const valid = /^[a-z0-9_-]{1,64}$/.test(keys[index]) && keys.filter(key => key === keys[index]).length === 1;
                input.setCustomValidity(valid ? '' : labels.keyError);
                input.setAttribute('aria-invalid', String(!valid));
            });
            return keys.every(key => /^[a-z0-9_-]{1,64}$/.test(key) && keys.filter(candidate => candidate === key).length === 1);
        };
        const render = () => {
            list.replaceChildren();
            if (!galleries.length) list.append(create('p', labels.empty));
            galleries.forEach(gallery => {
                const panel = create('section', '', 'thecore-gallery-editor__gallery');
                const fields = create('div', '', 'thecore-gallery-editor__fields');
                for (const [property, label] of [['key', labels.key], ['title', labels.title]]) {
                    const field = create('label', label);
                    const input = create('input');
                    input.type = 'text';
                    input.value = gallery[property];
                    input.maxLength = property === 'key' ? 64 : 200;
                    if (property === 'key') {
                        input.required = true;
                        input.dataset.galleryKey = 'true';
                        input.pattern = '[a-z0-9_-]{1,64}';
                    }
                    input.addEventListener('input', () => { gallery[property] = input.value; sync(); validate(); });
                    field.append(input);
                    fields.append(field);
                }
                const actions = create('div', '', 'thecore-gallery-editor__actions');
                actions.append(button(labels.choose, () => {
                    const frame = window.wp.media({ title: labels.choose, button: { text: labels.use }, library: { type: 'image' }, multiple: true });
                    frame.on('open', () => {
                        const selection = frame.state().get('selection');
                        gallery.images.forEach(imageId => selection.add(window.wp.media.attachment(imageId)));
                    });
                    frame.on('select', () => {
                        const selected = frame.state().get('selection').models.map(model => model.id);
                        if (selected.length > 500) { window.alert(labels.limit); return; }
                        gallery.images = [...new Set(selected)];
                        sync(); render();
                    });
                    frame.open();
                }), button(labels.removeGallery, () => {
                    if (!window.confirm(labels.confirmRemove)) return;
                    galleries = galleries.filter(candidate => candidate !== gallery);
                    sync(); render();
                }));
                const photos = create('ol', '', 'thecore-gallery-editor__photos');
                gallery.images.forEach((imageId, index) => {
                    const photo = create('li', '', 'thecore-gallery-editor__photo');
                    const image = create('img');
                    image.alt = `${labels.photo} ${index + 1}`;
                    image.loading = 'lazy';
                    const attachment = window.wp.media.attachment(imageId);
                    const update = () => {
                        const data = attachment.toJSON();
                        const url = safeUrl(data.sizes?.thumbnail?.url || data.url || '');
                        if (url) image.src = url;
                    };
                    update();
                    if (!attachment.get('url')) attachment.fetch().then(update).catch(() => {});
                    photo.append(image);
                    for (const [label, offset] of [[labels.up, -1], [labels.down, 1]]) {
                        const move = button(label, () => {
                            const galleryIndex = galleries.indexOf(gallery);
                            const destination = index + offset;
                            [gallery.images[index], gallery.images[destination]] = [gallery.images[destination], gallery.images[index]];
                            sync(); render();
                            list.children[galleryIndex]?.querySelectorAll('.thecore-gallery-editor__photos button')[destination * 3]?.focus();
                        });
                        move.disabled = index + offset < 0 || index + offset >= gallery.images.length;
                        move.setAttribute('aria-label', `${label} : ${labels.photo} ${index + 1}`);
                        photo.append(move);
                    }
                    photo.append(button(labels.remove, () => { gallery.images.splice(index, 1); sync(); render(); }));
                    photos.append(photo);
                });
                panel.append(fields, actions, photos);
                list.append(panel);
            });
            validate();
        };
        editor.querySelector('[data-thecore-gallery-add]').addEventListener('click', () => {
            if (galleries.length >= 20) { window.alert(labels.limit); return; }
            let key = 'principale';
            let index = galleries.length + 1;
            while (galleries.some(gallery => gallery.key === key)) key = `galerie-${index++}`;
            galleries.push({ key, title: '', images: [] });
            sync(); render();
            list.querySelector('section:last-child input')?.focus();
        });
        editor.closest('form')?.addEventListener('submit', event => {
            if (!validate()) {
                event.preventDefault();
                list.querySelector('[aria-invalid="true"]')?.reportValidity();
            }
        });
        render();
    }
})();
