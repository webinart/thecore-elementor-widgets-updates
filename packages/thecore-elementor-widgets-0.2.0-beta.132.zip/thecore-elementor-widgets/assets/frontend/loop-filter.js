/* Progressive enhancement of published, server-rendered Collection Loop filters. */
(() => {
    'use strict';

    const LOOP = '[data-e-type="e-collection-loop"][data-id]';
    const NAV = '[data-tc-loop-filter][data-tc-filter-key]';
    const TERM = 'a[href][data-tc-term]';
    const PAGE = 'a[href][data-e-pagination-link]';
    const transport = 'tc_loop_fragment';

    function init() {
        if (!window.fetch || !window.AbortController || !history.pushState || !Element.prototype.replaceChildren ||
            document.body.classList.contains('elementor-editor-active') || new URL(location.href).searchParams.has('elementor-preview')) return;

        const listings = [];
        // Disable Ajax for ambiguous targets (e.g. a repeated template or two widgets sharing a URL key).
        const navs = Array.from(document.querySelectorAll(NAV));
        const loops = Array.from(document.querySelectorAll(LOOP));
        for (const nav of navs) {
            const id = nav.dataset.tcLoopFilter, key = nav.dataset.tcFilterKey;
            const matches = loops.filter(el => el.dataset.id === id);
            if (!id || !key || matches.length !== 1 || navs.some(el => el !== nav &&
                (el.dataset.tcLoopFilter === id || el.dataset.tcFilterKey === key))) continue;
            const loop = matches[0], terms = new Map(Array.from(nav.querySelectorAll(TERM), a => [a.dataset.tcTerm, a]));
            if (!terms.has('')) continue;
            const listing = { id, key, pageKey: 'e-page-' + id, loop, nav, terms, job: null, route: null };
            // A CMS may expose numbered paths for the primary collection. One pathname can own only one page number.
            if (nav.dataset.tcPageBase) {
                if (navs.length !== 1) continue;
                try {
                    const base = new URL(nav.dataset.tcPageBase);
                    if (base.origin !== location.origin || base.search || base.hash || base.username || base.password) continue;
                    listing.route = base.pathname.replace(/\/?$/, '/');
                } catch { continue; }
            }
            listing.shown = readState(listing, new URL(location.href));
            if (!listing.shown) continue;
            const status = document.createElement('span');
            status.className = 'tc-loop-filter-status';
            status.setAttribute('role', 'status');
            status.setAttribute('aria-atomic', 'true');
            nav.after(status);
            listing.status = status;
            listings.push(listing);
        }
        if (!listings.length) return;

        function pathPage(l, u) {
            if (u.pathname === l.route.slice(0, -1) || u.pathname === l.route) return '1';
            if (!u.pathname.startsWith(l.route)) return null;
            return /^([1-9]\d{0,3})\/?$/.exec(u.pathname.slice(l.route.length))?.[1] || null;
        }

        function readState(listing, url) {
            const segment = listing.route ? pathPage(listing, url) : '1';
            if (!segment) return null;
            const term = url.searchParams.get(listing.key) || '', page = url.searchParams.get(listing.pageKey) || segment;
            const validPage = listing.route ? /^[1-9]\d{0,3}$/ : /^[1-9]\d{0,8}$/;
            return listing.terms.has(term) && validPage.test(page) ? {term, page: Number(page)} : null;
        }

        function urlFor(listing, state, fragment = false) {
            const u = new URL(location.href);
            u.hash = '';
            u.searchParams.delete(transport);
            if (state.term) u.searchParams.set(listing.key, state.term); else u.searchParams.delete(listing.key);
            if (listing.route) u.pathname = listing.route + (!fragment && state.page !== 1 ? state.page + '/' : '');
            if (state.page !== 1 && (fragment || !listing.route)) u.searchParams.set(listing.pageKey, String(state.page)); else u.searchParams.delete(listing.pageKey);
            return u;
        }

        function publicUrl(l, a) {
            const u = new URL(a.href), current = new URL(location.href);
            return u.origin === current.origin && (l.route ? pathPage(l, u) : u.pathname === current.pathname) && !u.searchParams.has(transport) &&
                ['p', 'page_id'].every(key => current.searchParams.get(key) === u.searchParams.get(key)) ? u : null;
        }

        function syncCanonical(l, state) {
            if (!l.route || l.nav.dataset.tcCanonicalSync !== '1') return;
            const canonical = document.querySelector('link[rel~="canonical"]');
            if (canonical) canonical.href = new URL(l.route + (!state.term && state.page > 1 ? state.page + '/' : ''), location.origin).href;
        }

        function syncLinks() {
            // Even Ctrl/Cmd+click on an untouched sibling filter must preserve the other loop’s state.
            for (const l of listings) {
                for (const [term, a] of l.terms) {
                    if (publicUrl(l, a)) a.href = urlFor(l, {term, page: 1}).href;
                    if (term === l.shown.term) a.setAttribute('aria-current', 'true'); else a.removeAttribute('aria-current');
                }
                for (const a of l.loop.querySelectorAll(PAGE)) {
                    const url = publicUrl(l, a);
                    if (!url || a.closest(LOOP) !== l.loop) continue;
                    const page = readState(l, url)?.page;
                    if (page) a.href = urlFor(l, {term: l.shown.term, page}).href;
                }
            }
        }

        function finish(l, job) {
            if (!job || l.job !== job) return;
            clearTimeout(job.timeout);
            clearTimeout(job.indicator);
            l.loop.removeAttribute('aria-busy');
            l.loop.removeAttribute('data-tc-loop-waiting');
            job.trigger?.removeAttribute('data-tc-loop-pending');
            l.job = null;
        }

        function cancel(l) {
            if (!l.job) return;
            l.job.controller.abort();
            finish(l, l.job);
        }

        function same(a, b) { return a && b && a.term === b.term && a.page === b.page; }

        async function show(l, state, mode, trigger) {
            if (mode !== 'pop' && same(l.job?.state, state)) return;
            cancel(l);
            if (same(l.shown, state)) return;
            const job = {state, trigger, controller: new AbortController()};
            l.job = job;
            l.loop.setAttribute('aria-busy', 'true');
            trigger?.setAttribute('data-tc-loop-pending', '');
            job.indicator = setTimeout(() => l.loop.setAttribute('data-tc-loop-waiting', ''), 150);
            job.timeout = setTimeout(() => job.controller.abort(), 12000);
            try {
                const u = urlFor(l, state, true);
                u.searchParams.set(transport, l.id);
                const response = await fetch(u, {signal: job.controller.signal, credentials: 'same-origin', redirect: 'error', headers: {Accept: 'application/json'}});
                if (!response.ok || !response.headers.get('Content-Type')?.includes('application/json')) throw Error('No fragment');
                const data = await response.json();
                if (l.job !== job) return;
                if (data.loop !== l.id || data.term !== state.term || data.page !== state.page || typeof data.html !== 'string') throw Error('Unexpected state');
                const holder = document.createElement('template');
                holder.innerHTML = data.html; // Trusted, same-origin published loop, checked by the server before serialization.
                const next = holder.content.firstElementChild;
                const grid = next?.querySelector('[role="list"]');
                if (holder.content.childElementCount !== 1 || !next.matches(LOOP) || next.dataset.id !== l.id || !grid ||
                    next.querySelector('script, iframe, object, embed, template, form')) throw Error('Use full navigation');
                const nativeStatus = next.querySelector('[data-e-pagination-status]');
                const pageLabel = nativeStatus?.textContent.trim() || (l.nav.dataset.tcStatusLabel || 'Page %s').replace('%s', String(state.page));
                // The new fragment’s status isn't present until insertion; use one stable live region.
                nativeStatus?.removeAttribute('role');
                nativeStatus?.removeAttribute('aria-live');
                const hadFocus = l.loop.contains(document.activeElement);
                if (mode !== 'pop') {
                    const href = urlFor(l, state).href;
                    if (location.href !== href) history.pushState(history.state, '', href);
                }
                l.loop.replaceChildren(...next.childNodes);
                l.shown = state;
                syncLinks();
                syncCanonical(l, state);
                if (mode === 'page' || hadFocus) {
                    const destination = grid.getClientRects().length ? grid : l.loop;
                    destination.setAttribute('tabindex', '-1');
                    destination.focus({preventScroll: true});
                    if (mode === 'page') destination.scrollIntoView({block: 'start', behavior: 'auto'});
                }
                l.status.textContent = [l.terms.get(state.term).textContent.trim(), pageLabel].filter(Boolean).join(' — ');
                l.loop.dispatchEvent(new CustomEvent('thecore:loop-updated', {bubbles: true, detail: {loop: l.id, term: state.term, page: state.page}}));
            } catch {
                if (l.job !== job) return;
                // A disabled endpoint, incompatible card, or expired session must still lead to the actual page.
                if (mode === 'pop') location.reload(); else location.assign(urlFor(l, state).href);
            } finally { finish(l, job); }
        }

        document.addEventListener('click', event => {
            if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
            const a = event.target.closest?.('a[href]');
            if (!a || (a.target && a.target !== '_self') || a.hasAttribute('download')) return;
            const nav = a.closest(NAV), loop = a.closest(LOOP);
            const l = listings.find(l => (l.nav === nav && a.matches(TERM)) || (l.loop === loop && a.matches(PAGE)));
            if (!l) return;
            const url = publicUrl(l, a), state = url && readState(l, url);
            if (!state) return;
            event.preventDefault();
            // Only registered filter controls and native pagination reach this branch. Avoid a second Elementor Ajax handler.
            event.stopPropagation();
            void show(l, state, l.nav === nav ? 'filter' : 'page', a);
        }, true);
        window.addEventListener('popstate', () => {
            const url = new URL(location.href);
            for (const l of listings) {
                const state = readState(l, url);
                if (!state) { location.reload(); return; }
                void show(l, state, 'pop', null);
            }
            syncLinks();
        });
        window.addEventListener('pagehide', () => listings.forEach(cancel));
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once: true}); else init();
})();
