(() => {
    const ROOT_SELECTOR = '[data-thecore-marquee-carousel="true"]';
    const TRACK_SELECTOR = '[data-thecore-marquee-track="true"]';
    const TOGGLE_SELECTOR = '[data-thecore-marquee-toggle="true"]';
    const ITEM_SELECTOR = '[data-thecore-marquee-item-index]';
    const RUNTIME_CLONE_ATTRIBUTE = 'data-thecore-marquee-runtime-clone';
    const initializedRoots = new Set();
    const resizeObservers = new WeakMap();
    const refreshFrames = new WeakMap();
    const entranceControllers = new WeakMap();
    const rootCleanup = new WeakMap();

    // The marquee owns clone coverage and track playback. The theme, when present,
    // owns animation playback; the native WAAPI fallback keeps the widget portable.
    const createEntrance = (root, track) => {
        const preference = window.matchMedia?.('(prefers-reduced-motion: reduce)');
        if (root.dataset.thecoreMarqueeEntrance !== 'cascade' || root.dataset.thecoreMarqueeEntranceComplete === '1' || preference?.matches ||
            typeof Element.prototype.animate !== 'function' || !('IntersectionObserver' in window)) {
            return null;
        }

        const integer = (name, fallback, min, max) => {
            const value = Number(root.getAttribute(`data-thecore-marquee-entrance-${name}`));
            return Math.max(min, Math.min(max, Number.isFinite(value) && root.hasAttribute(`data-thecore-marquee-entrance-${name}`) ? value : fallback));
        };
        const duration = integer('duration', 550, 100, 2000);
        const stagger = integer('stagger', 100, 0, 500);
        const percent = integer('offset-percent', 100, 0, 100);
        const firstBound = integer('offset-min', 80, 0, 2000);
        const secondBound = integer('offset-max', 200, 0, 2000);
        const min = Math.min(firstBound, secondBound);
        const max = Math.max(firstBound, secondBound);
        const animations = new Set();
        let observer;
        let scope;
        let finished = false;
        let started = false;
        let fallbackTimer;
        let cachedBottom = 0;
        root.classList.add('is-intro-pending');

        const finish = () => {
            if (finished) return;
            finished = true;
            observer?.disconnect();
            window.clearTimeout(fallbackTimer);
            animations.forEach((animation) => animation.cancel());
            animations.clear();
            scope?.destroy();
            root.classList.remove('is-intro-pending', 'is-intro-running');
            root.dataset.thecoreMarqueeEntranceComplete = '1';
        };

        const start = () => {
            if (started || finished || !root.isConnected) return;
            if (document.hidden || preference?.matches || root.contains(document.activeElement)) {
                finish();
                return;
            }
            started = true;
            observer?.disconnect();
            window.clearTimeout(fallbackTimer);
            const bounds = root.getBoundingClientRect();
            const items = Array.from(track.children).filter((item) => {
                if (!(item instanceof HTMLElement) || !item.matches(ITEM_SELECTOR)) return false;
                const rect = item.getBoundingClientRect();
                return rect.right > bounds.left && rect.left < bounds.right;
            });
            if (items.length === 0) {
                finish();
                return;
            }
            root.classList.replace('is-intro-pending', 'is-intro-running');
            if (typeof window.TheCoreAnimations?.createScope === 'function') {
                scope = window.TheCoreAnimations.createScope();
            }
            let remaining = items.length;
            items.forEach((item, index) => {
                const frames = [{ opacity: 0, transform: 'translateY(12px)' }, { opacity: 1, transform: 'translateY(0)' }];
                const options = { duration, delay: index * stagger, easing: 'cubic-bezier(0.2, 0.65, 0.3, 1)', fill: 'both' };
                try {
                    const animation = scope ? scope.animate(item, frames, options) : item.animate(frames, options);
                    if (!animation) return;
                    animations.add(animation);
                    animation.addEventListener('finish', () => {
                        remaining -= 1;
                        if (remaining === 0) finish();
                    }, { once: true });
                } catch (_) { /* The deadline below always restores visible content. */ }
            });
            // Also releases content if a browser cancels/does not finish a WAAPI animation.
            fallbackTimer = window.setTimeout(finish, duration + (items.length - 1) * stagger + 100);
        };

        const refresh = () => {
            if (finished || started || !track.classList.contains('is-ready')) return;
            observer?.disconnect();
            window.clearTimeout(fallbackTimer);
            const helper = window.TheCoreEntranceTrigger;
            const height = helper ? helper.height(root) : root.offsetHeight;
            const distance = helper
                ? -helper.distance({ unit: 'element', value: percent, min, max }, root, height)
                : -(percent === 0 || height <= 0 ? 0 : Math.max(min, Math.min(max, height * percent / 100)));
            cachedBottom = root.getBoundingClientRect().bottom + (window.scrollY || 0);
            try {
                observer = new IntersectionObserver((entries) => {
                    if (entries.some((entry) => entry.isIntersecting)) start();
                }, { rootMargin: `0px 0px ${distance}px 0px`, threshold: 0 });
                observer.observe(root);
                checkPageEnd();
            } catch (_) { finish(); }
        };

        const changedPreference = () => { if (preference.matches) finish(); };
        const changedVisibility = () => { if (document.hidden) finish(); };
        const checkPageEnd = () => {
            if (finished || started || !cachedBottom) return;
            const viewportBottom = (window.scrollY || 0) + window.innerHeight;
            const documentBottom = Math.max(document.documentElement.scrollHeight, document.body.scrollHeight);
            if (viewportBottom >= documentBottom - 2 && cachedBottom <= viewportBottom && cachedBottom > (window.scrollY || 0)) start();
        };
        const onFocus = () => finish();
        root.addEventListener('focusin', onFocus);
        document.addEventListener('visibilitychange', changedVisibility);
        window.addEventListener('scroll', checkPageEnd, { passive: true });
        window.addEventListener('beforeprint', finish);
        preference?.addEventListener?.('change', changedPreference);
        return {
            refresh,
            loading() {
                if (finished || started) return;
                // Loading may fail; waiting below the fold must never consume this deadline.
                window.clearTimeout(fallbackTimer);
                fallbackTimer = window.setTimeout(finish, 12000);
            },
            destroy() {
                finish();
                root.removeEventListener('focusin', onFocus);
                document.removeEventListener('visibilitychange', changedVisibility);
                window.removeEventListener('scroll', checkPageEnd);
                window.removeEventListener('beforeprint', finish);
                preference?.removeEventListener?.('change', changedPreference);
            },
        };
    };

    const nextFrame = (callback) => {
        window.requestAnimationFrame(() => window.requestAnimationFrame(callback));
    };

    const loadTrackImages = (track) => {
        track.querySelectorAll('img[data-thecore-marquee-src]').forEach((image) => {
            const source = image.getAttribute('data-thecore-marquee-src');
            const srcset = image.getAttribute('data-thecore-marquee-srcset');
            const sizes = image.getAttribute('data-thecore-marquee-sizes');

            if (!source) {
                return;
            }

            // Every logo contributes to the loop width, including those outside the mobile viewport.
            image.setAttribute('loading', 'eager');

            if (srcset) {
                image.setAttribute('srcset', srcset);
            }

            if (sizes) {
                image.setAttribute('sizes', sizes);
            }

            image.setAttribute('src', source);
            image.removeAttribute('data-thecore-marquee-src');
            image.removeAttribute('data-thecore-marquee-srcset');
            image.removeAttribute('data-thecore-marquee-sizes');
            image.classList.remove('is-lazy');
        });
    };

    const waitForTrackImages = (track, callback) => {
        const pendingImages = Array.from(track.querySelectorAll('img')).filter(
            (image) => !image.complete
        );

        if (pendingImages.length === 0) {
            nextFrame(callback);
            return;
        }

        let pending = pendingImages.length;

        const finish = () => {
            pending -= 1;

            if (pending === 0) {
                nextFrame(callback);
            }
        };

        pendingImages.forEach((image) => {
            let imageSettled = false;
            const settleImage = () => {
                if (imageSettled) {
                    return;
                }

                imageSettled = true;
                finish();
            };

            image.addEventListener('load', settleImage, { once: true });
            image.addEventListener('error', settleImage, { once: true });

            // The request can settle between the initial check and listener registration.
            if (image.complete) {
                settleImage();
            }
        });
    };

    const getSequenceItems = (track) => {
        const items = Array.from(track.children).filter(
            (item) =>
                item instanceof HTMLElement &&
                item.matches(ITEM_SELECTOR) &&
                item.getAttribute(RUNTIME_CLONE_ATTRIBUTE) !== '1'
        );

        if (items.length === 0) {
            return [];
        }

        const firstIndex = items[0].dataset.thecoreMarqueeItemIndex;
        const repeatedStart = items.findIndex(
            (item, index) =>
                index > 0 && item.dataset.thecoreMarqueeItemIndex === firstIndex
        );

        return repeatedStart > 0 ? items.slice(0, repeatedStart) : items;
    };

    const getSequenceDistance = (track, sequenceItems) => {
        const firstItem = sequenceItems[0];

        if (!(firstItem instanceof HTMLElement)) {
            return 0;
        }

        const firstIndex = firstItem.dataset.thecoreMarqueeItemIndex;
        const secondSequenceStart = Array.from(track.children).find(
            (item) =>
                item instanceof HTMLElement &&
                item !== firstItem &&
                item.getAttribute(RUNTIME_CLONE_ATTRIBUTE) !== '1' &&
                item.dataset.thecoreMarqueeItemIndex === firstIndex
        );

        if (!(secondSequenceStart instanceof HTMLElement)) {
            return 0;
        }

        return Math.max(secondSequenceStart.offsetLeft - firstItem.offsetLeft, 0);
    };

    const appendSequenceClone = (track, sequenceItems) => {
        sequenceItems.forEach((item) => {
            const clone = item.cloneNode(true);

            if (!(clone instanceof HTMLElement)) {
                return;
            }

            clone.setAttribute(RUNTIME_CLONE_ATTRIBUTE, '1');
            clone.setAttribute('aria-hidden', 'true');
            clone.querySelectorAll('img').forEach((image) => image.setAttribute('alt', ''));
            clone
                .querySelectorAll('a, button, input, select, textarea, [tabindex]')
                .forEach((element) => element.setAttribute('tabindex', '-1'));
            track.appendChild(clone);
        });
    };

    const ensureTrackCoverage = (root, track, sequenceItems, sequenceDistance) => {
        if (!(root instanceof HTMLElement) || sequenceDistance <= 0) {
            return;
        }

        const requiredWidth = root.clientWidth + sequenceDistance;
        let appendedSequences = 0;

        while (track.scrollWidth < requiredWidth && appendedSequences < 20) {
            appendSequenceClone(track, sequenceItems);
            appendedSequences += 1;
        }
    };

    const refreshTrack = (track) => {
        if (!(track instanceof HTMLElement) || !track.isConnected) {
            return;
        }

        waitForTrackImages(track, () => {
            if (!track.isConnected) return;
            const root = track.closest(ROOT_SELECTOR);
            const sequenceItems = getSequenceItems(track);
            const distance = getSequenceDistance(track, sequenceItems);

            if (!distance) {
                track.classList.remove('is-ready');
                return;
            }

            ensureTrackCoverage(root, track, sequenceItems, distance);
            track.style.setProperty('--thecore-marquee-distance', `${distance}px`);
            track.classList.add('is-ready');
            entranceControllers.get(root)?.refresh();
        });
    };

    const scheduleRefresh = (track) => {
        const previousFrame = refreshFrames.get(track);

        if (previousFrame) {
            window.cancelAnimationFrame(previousFrame);
        }

        refreshFrames.set(
            track,
            window.requestAnimationFrame(() => {
                refreshFrames.delete(track);
                track.classList.remove('is-ready');
                refreshTrack(track);
            })
        );
    };

    const updateToggle = (root, paused) => {
        const toggle = root.querySelector(TOGGLE_SELECTOR);

        if (!(toggle instanceof HTMLButtonElement)) {
            return;
        }

        toggle.setAttribute('aria-pressed', paused ? 'true' : 'false');
        toggle.setAttribute(
            'aria-label',
            paused
                ? toggle.dataset.playLabel || 'Relancer le carrousel de logos'
                : toggle.dataset.pauseLabel || 'Mettre le carrousel de logos en pause'
        );
    };

    const setupToggle = (root) => {
        const toggle = root.querySelector(TOGGLE_SELECTOR);

        if (!(toggle instanceof HTMLButtonElement)) {
            return;
        }

        const togglePause = () => {
            const paused = !root.classList.contains('is-paused');
            root.classList.toggle('is-paused', paused);
            updateToggle(root, paused);
        };
        toggle.addEventListener('click', togglePause);
        rootCleanup.get(root).push(() => toggle.removeEventListener('click', togglePause));
    };

    const setupVisibilityObserver = (root) => {
        if (!('IntersectionObserver' in window)) {
            return;
        }

        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    if (entry.target !== root) {
                        return;
                    }

                    root.dataset.thecoreMarqueeVisible = entry.isIntersecting ? '1' : '0';
                    root.classList.toggle('is-auto-paused', !entry.isIntersecting || document.hidden);
                });
            },
            { rootMargin: '200px' }
        );

        observer.observe(root);
        rootCleanup.get(root).push(() => observer.disconnect());
    };

    const primeTrack = (track) => {
        if (!track.isConnected) return;
        entranceControllers.get(track.closest(ROOT_SELECTOR))?.loading();
        loadTrackImages(track);
        scheduleRefresh(track);
    };

    const setupLazyLoading = (track) => {
        if (track.dataset.lazy !== '1') {
            entranceControllers.get(track.closest(ROOT_SELECTOR))?.loading();
            scheduleRefresh(track);
            return;
        }

        if (track.dataset.lazyMethod === 'delay') {
            const parsedDelay = Number.parseInt(track.dataset.lazyDelay || '1000', 10);
            const timer = window.setTimeout(() => primeTrack(track), Number.isNaN(parsedDelay) ? 1000 : parsedDelay);
            rootCleanup.get(track.closest(ROOT_SELECTOR)).push(() => window.clearTimeout(timer));
            return;
        }

        if (!('IntersectionObserver' in window)) {
            primeTrack(track);
            return;
        }

        const observer = new IntersectionObserver(
            (entries, instance) => {
                entries.forEach((entry) => {
                    if (!entry.isIntersecting) {
                        return;
                    }

                    primeTrack(track);
                    instance.unobserve(entry.target);
                });
            },
            { rootMargin: '200px' }
        );

        observer.observe(track);
        rootCleanup.get(track.closest(ROOT_SELECTOR)).push(() => observer.disconnect());
    };

    const initRoot = (root) => {
        if (!(root instanceof HTMLElement) || root.dataset.thecoreMarqueeInitialized === '1') {
            return;
        }

        const track = root.querySelector(TRACK_SELECTOR);

        if (!(track instanceof HTMLElement)) {
            return;
        }

        root.dataset.thecoreMarqueeInitialized = '1';
        initializedRoots.add(root);
        rootCleanup.set(root, []);
        const entrance = createEntrance(root, track);
        if (entrance) entranceControllers.set(root, entrance);
        setupToggle(root);
        setupVisibilityObserver(root);
        setupLazyLoading(track);

        if ('ResizeObserver' in window) {
            const observer = new ResizeObserver(() => {
                if (!track.querySelector('img[data-thecore-marquee-src]')) {
                    scheduleRefresh(track);
                }
            });
            observer.observe(root);
            resizeObservers.set(root, observer);
        }
    };

    const initWithin = (context = document) => {
        if (context instanceof HTMLElement && context.matches(ROOT_SELECTOR)) {
            initRoot(context);
        }

        if (!context || typeof context.querySelectorAll !== 'function') {
            return;
        }

        context.querySelectorAll(ROOT_SELECTOR).forEach(initRoot);
    };

    const cleanupRoot = (root) => {
        resizeObservers.get(root)?.disconnect();
        resizeObservers.delete(root);
        entranceControllers.get(root)?.destroy();
        entranceControllers.delete(root);
        rootCleanup.get(root)?.forEach((cleanup) => cleanup());
        rootCleanup.delete(root);
        const track = root.querySelector(TRACK_SELECTOR);
        const frame = track && refreshFrames.get(track);
        if (frame) window.cancelAnimationFrame(frame);
        if (track) refreshFrames.delete(track);
        initializedRoots.delete(root);
        delete root.dataset.thecoreMarqueeInitialized;
    };

    const refreshInitialized = () => {
        initializedRoots.forEach((root) => {
            if (!root.isConnected) {
                cleanupRoot(root);
                return;
            }

            const track = root.querySelector(TRACK_SELECTOR);

            if (track instanceof HTMLElement && !track.querySelector('img[data-thecore-marquee-src]')) {
                scheduleRefresh(track);
            }

            root.classList.toggle(
                'is-auto-paused',
                document.hidden || root.dataset.thecoreMarqueeVisible === '0'
            );
        });
    };

    const boot = () => {
        initWithin(document);

        const observer = new MutationObserver((mutations) => {
            initializedRoots.forEach((root) => { if (!root.isConnected) cleanupRoot(root); });
            mutations.forEach((mutation) => {
                mutation.addedNodes.forEach((node) => {
                    if (node instanceof HTMLElement) {
                        initWithin(node);
                    }
                });
            });
        });

        observer.observe(document.body, { childList: true, subtree: true });
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot, { once: true });
    } else {
        boot();
    }

    window.addEventListener('load', refreshInitialized);
    window.addEventListener('resize', refreshInitialized);
    window.addEventListener('orientationchange', refreshInitialized);
    document.addEventListener('visibilitychange', refreshInitialized);
})();
