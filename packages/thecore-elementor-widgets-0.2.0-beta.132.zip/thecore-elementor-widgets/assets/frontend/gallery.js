(() => {
    'use strict';
    if (window.TheCoreGalleryRuntime) return;
    window.TheCoreGalleryRuntime = true;
    const selector = '.thecore-gallery[data-thecore-gallery-layout]';
    const galleries = new Map();
    const requests = new Map();
    const pending = new Set();
    const config = window.TheCoreGalleryConfig || {};
    let frame = 0;

    const bounded = (value, fallback, minimum, maximum) => {
        const number = Number(value);
        return value !== undefined && Number.isFinite(number) ? Math.max(minimum, Math.min(maximum, Math.trunc(number))) : fallback;
    };
    const itemsFor = root => [...root.children].filter(item => item.hasAttribute('data-thecore-gallery-item'));
    const setStyle = (element, property, value) => {
        if (element.style.getPropertyValue(property) !== value) element.style.setProperty(property, value);
    };
    const safeUrl = value => {
        try {
            const url = new URL(value, document.baseURI);
            return ['http:', 'https:'].includes(url.protocol) ? url.href : '';
        } catch { return ''; }
    };

    function layout(root) {
        const items = itemsFor(root);
        const count = Math.max(1, items.length);
        setStyle(root, '--thecore-gallery-columns', String(Math.min(count, bounded(root.dataset.thecoreGalleryColumns, 4, 1, 6))));
        setStyle(root, '--thecore-gallery-tablet-columns', String(Math.min(count, bounded(root.dataset.thecoreGalleryTabletColumns, 2, 1, 6))));
        setStyle(root, '--thecore-gallery-mobile-columns', String(Math.min(count, bounded(root.dataset.thecoreGalleryMobileColumns, 1, 1, 4))));
        setStyle(root, '--thecore-gallery-gap', `${bounded(root.dataset.thecoreGalleryGap, 10, 0, 80)}px`);
        const ratio = ['1/1', '4/3', '3/2', '16/9'].includes(root.dataset.thecoreGalleryRatio) ? root.dataset.thecoreGalleryRatio : '4/3';
        setStyle(root, '--thecore-gallery-ratio', ratio);
        const styles = getComputedStyle(root);
        const columns = styles.gridTemplateColumns.split(/\s+/).filter(track => parseFloat(track) > 0).length;
        if (root.dataset.thecoreGalleryLayout !== 'masonry' || columns < 2 || !items.length) {
            for (const property of ['grid-auto-rows', 'grid-auto-flow', 'row-gap']) {
                if (root.style.getPropertyValue(property)) root.style.removeProperty(property);
            }
            for (const item of items) if (item.style.gridRowEnd) item.style.removeProperty('grid-row-end');
            return;
        }
        const gap = parseFloat(styles.columnGap) || 0;
        const heights = items.map(item => Math.max(1, Math.ceil(item.getBoundingClientRect().height + gap)));
        setStyle(root, 'grid-auto-rows', '1px');
        setStyle(root, 'grid-auto-flow', 'dense');
        setStyle(root, 'row-gap', '0px');
        items.forEach((item, index) => setStyle(item, 'grid-row-end', `span ${heights[index]}`));
    }

    function schedule(root) {
        pending.add(root);
        if (frame) return;
        frame = requestAnimationFrame(() => {
            frame = 0;
            for (const target of pending) if (target.isConnected) layout(target);
            pending.clear();
        });
    }

    function status(root, text, error = false) {
        const message = document.createElement('p');
        message.className = 'thecore-gallery__status';
        message.setAttribute('role', error ? 'alert' : 'status');
        message.textContent = text;
        root.replaceChildren(message);
        schedule(root);
    }

    function previewImages(root, images) {
        const fragment = document.createDocumentFragment();
        const lightbox = root.dataset.thecoreGalleryLightbox !== '0' && config.lightbox === true;
        if (lightbox) root.dataset.thecoreGallery = `thecore-gallery-${root.dataset.id || 'preview'}`;
        else root.removeAttribute('data-thecore-gallery');
        for (const [index, image] of images.entries()) {
            const src = safeUrl(image.src);
            const full = safeUrl(image.full_src);
            if (!src || !full || !(image.width > 0) || !(image.height > 0)) continue;
            const item = document.createElement('figure');
            item.className = 'thecore-gallery__item';
            item.dataset.thecoreGalleryItem = '';
            const media = document.createElement(lightbox ? 'a' : 'div');
            media.className = 'thecore-gallery__media';
            if (lightbox) {
                media.href = full;
                media.dataset.pswpWidth = String(image.full_width);
                media.dataset.pswpHeight = String(image.full_height);
                media.setAttribute('aria-label', `${config.enlarge || 'Agrandir'} : ${image.alt || image.caption || `Photo ${index + 1}`}`);
                if (image.caption) media.dataset.thecoreCaption = image.caption;
            }
            const photo = document.createElement('img');
            photo.className = 'thecore-gallery__image';
            photo.src = src;
            photo.alt = image.alt || '';
            photo.width = image.width;
            photo.height = image.height;
            photo.loading = 'lazy';
            photo.decoding = 'async';
            if (image.srcset) photo.srcset = image.srcset;
            if (image.sizes) photo.sizes = image.sizes;
            media.append(photo);
            item.append(media);
            if (image.caption && root.dataset.thecoreGalleryCaptions !== '0') {
                const caption = document.createElement('figcaption');
                caption.className = 'thecore-gallery__caption';
                caption.textContent = image.caption;
                item.append(caption);
            }
            fragment.append(item);
        }
        root.replaceChildren(fragment);
        if (!itemsFor(root).length) status(root, config.empty || 'Aucune photo dans cette galerie.');
        schedule(root);
    }

    async function hydrate(root, state) {
        if (!root.hasAttribute('data-thecore-gallery-editor')) return;
        let postId = bounded(config.postId, 0, 0, Number.MAX_SAFE_INTEGER);
        try {
            const documentId = window.parent?.elementor?.config?.document?.id;
            if (documentId) postId = bounded(documentId, postId, 1, Number.MAX_SAFE_INTEGER);
        } catch {}
        const key = root.dataset.thecoreGalleryKey || 'principale';
        const signature = `${postId}:${key}:${root.dataset.thecoreGalleryCaptions}:${root.dataset.thecoreGalleryLightbox}`;
        if (state.signature === signature) return;
        state.signature = signature;
        if (!postId || !config.restUrl || !config.nonce) {
            status(root, config.empty || 'Renseignez une galerie dans la publication pour afficher ses photos.');
            return;
        }
        try {
            const endpoint = new URL(`${config.restUrl}${postId}`, document.baseURI);
            endpoint.searchParams.set('gallery', key);
            const requestKey = endpoint.href;
            if (!requests.has(requestKey)) {
                const request = fetch(endpoint.href, { credentials: 'same-origin', headers: { 'X-WP-Nonce': config.nonce } }).then(response => {
                    if (!response.ok) throw new Error(`HTTP ${response.status}`);
                    return response.json();
                });
                requests.set(requestKey, request);
                request.catch(() => requests.delete(requestKey));
            }
            const data = await requests.get(requestKey);
            if (root.isConnected && state.signature === signature) previewImages(root, Array.isArray(data.images) ? data.images : []);
        } catch {
            if (root.isConnected && state.signature === signature) status(root, config.error || 'Impossible de charger la galerie.', true);
        }
    }

    function initialize(root) {
        let state = galleries.get(root);
        if (!state) {
            state = { observer: typeof ResizeObserver === 'function' ? new ResizeObserver(() => schedule(root)) : null, items: new Set(), signature: null };
            state.observer?.observe(root);
            root.addEventListener('load', event => { if (event.target instanceof HTMLImageElement) schedule(root); }, true);
            galleries.set(root, state);
        }
        const current = new Set(itemsFor(root));
        for (const item of state.items) if (!current.has(item)) state.observer?.unobserve(item);
        for (const item of current) if (!state.items.has(item)) state.observer?.observe(item);
        state.items = current;
        hydrate(root, state);
        schedule(root);
    }

    function scan() {
        for (const [root, state] of galleries) {
            if (!root.isConnected) {
                state.observer?.disconnect();
                galleries.delete(root);
                pending.delete(root);
            }
        }
        document.querySelectorAll(selector).forEach(initialize);
    }

    function start() {
        scan();
        const attributes = ['data-thecore-gallery-layout', 'data-thecore-gallery-key', 'data-thecore-gallery-columns', 'data-thecore-gallery-tablet-columns', 'data-thecore-gallery-mobile-columns', 'data-thecore-gallery-gap', 'data-thecore-gallery-ratio', 'data-thecore-gallery-captions', 'data-thecore-gallery-lightbox'];
        new MutationObserver(records => {
            if (records.some(record => record.type === 'childList' || attributes.includes(record.attributeName))) scan();
        }).observe(document.body, { subtree: true, childList: true, attributes: true, attributeFilter: attributes });
        addEventListener('resize', () => galleries.forEach((state, root) => schedule(root)), { passive: true });
        document.fonts?.ready.then(() => galleries.forEach((state, root) => schedule(root)));
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true });
    else start();
})();
