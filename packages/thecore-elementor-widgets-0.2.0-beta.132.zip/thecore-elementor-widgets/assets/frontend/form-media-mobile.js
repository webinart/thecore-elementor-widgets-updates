( function () {
	'use strict';
	// Consume the bearer fragment before any request or UI work. It never enters storage.
	let fragment = window.location.hash.slice( 1 );
	try { window.history.replaceState( null, '', window.location.pathname + window.location.search ); }
	catch ( error ) { fragment = ''; /* Do not exchange credentials if they could not be scrubbed. */ }
	const unavailable = 'Cette connexion est indisponible. Affichez un nouveau QR code sur l’ordinateur.';
	const accepts = { photos: 'image/jpeg,image/png,image/webp', videos: 'video/mp4,video/quicktime,video/webm' };
	function node( tag, text, className ) {
		const el = document.createElement( tag ); if ( text ) { el.textContent = text; } if ( className ) { el.className = className; } return el;
	}
	function sameOrigin( value ) {
		if ( typeof value !== 'string' || ! value ) { throw new Error( unavailable ); }
		const url = new URL( value, window.location.href );
		if ( url.origin !== window.location.origin || url.username || url.password || ! [ 'http:', 'https:' ].includes( url.protocol ) ) { throw new Error( unavailable ); }
		return url.href;
	}
	function boot() {
		const root = document.querySelector( '[data-thecore-media-mobile]' ); if ( ! root ) { return; }
		const output = root.querySelector( '[data-thecore-mobile-status]' ) || root.appendChild( node( 'p' ) );
		const ui = root.querySelector( '[data-thecore-mobile-ui]' ) || root.appendChild( node( 'div' ) );
		root.classList.add( 'tc-form-media-mobile' ); ui.replaceChildren(); output.tabIndex = -1;
		output.setAttribute( 'aria-live', 'polite' ); output.setAttribute( 'role', 'status' );
		let endpoint;
		let session;
		let policy;
		let pollTimer;
		let state = 'pending';
		let busy = false;
		let count = 0;
		let progress;
		let countNode;
		let finished = false;
		function say( message, error = false ) {
			output.textContent = message; output.setAttribute( 'role', error ? 'alert' : 'status' );
			output.setAttribute( 'aria-live', error ? 'assertive' : 'polite' );
		}
		function setBusy( value ) {
			busy = value; root.setAttribute( 'aria-busy', value ? 'true' : 'false' );
			ui.querySelectorAll( 'button,input' ).forEach( el => { el.disabled = value || state !== 'approved' || finished; } );
		}
		async function request( action, payload, multipart = false ) {
			const abort = new AbortController();
			const timer = window.setTimeout( () => abort.abort(), multipart ? 180000 : 30000 );
			try {
				const response = await fetch( sameOrigin( endpoint.replace( /\/$/, '' ) + '/' + action ), {
					method: 'POST', credentials: 'same-origin', cache: 'no-store', redirect: 'error', signal: abort.signal,
					headers: multipart ? {} : { 'Content-Type': 'application/json' }, body: multipart ? payload : JSON.stringify( payload ),
					// Some upstream upload guards require a public referrer. Never disclose this page's query or bearer fragment.
					...( multipart ? { referrer: window.location.origin + '/', referrerPolicy: 'same-origin' } : {} ),
				} );
				let result; try { result = await response.json(); } catch ( error ) { throw new Error( unavailable ); }
				if ( ! response.ok ) { const error = new Error( result.message || unavailable ); error.status = response.status; throw error; }
				return result;
			} finally { window.clearTimeout( timer ); abort.abort(); }
		}
		function auth() { return { session: session.session, mobile: session.mobile }; }
		function updateCount() { if ( countNode ) { countNode.textContent = count + ' / ' + policy.max_files + ' fichiers ajoutés au formulaire'; } }
		function poll() {
			window.clearTimeout( pollTimer );
			if ( finished ) { return; }
			pollTimer = window.setTimeout( async () => {
				try {
					const result = await request( 'mobile-status', auth() );
					state = result.state;
					if ( typeof result.count === 'number' ) { count = result.count; updateCount(); }
					if ( state === 'approved' ) {
						if ( ! progress ) { buildUploader(); say( 'Téléphone connecté. Ajoutez vos fichiers ici, puis reprenez le formulaire sur l’ordinateur.' ); }
						setBusy( busy );
					} else if ( state === 'pending' ) { /* Keep the pairing code visible. */ }
					else { finished = true; setBusy( false ); say( 'Cette connexion au téléphone est terminée. Les fichiers déjà reçus sont conservés sur l’ordinateur.' ); return; }
				} catch ( error ) {
					say( error.message || 'Connexion interrompue. Vérifiez votre connexion ou scannez un nouveau QR code.', true );
					if ( [ 401, 403, 404, 410 ].includes( error.status ) ) { finished = true; setBusy( false ); return; }
				}
				poll();
			}, 2000 );
		}
		async function addFiles( selected ) {
			const files = Array.from( selected );
			if ( ! files.length || busy || state !== 'approved' || finished ) { return; }
			setBusy( true );
			try {
				if ( count + files.length > policy.max_files ) { throw new Error( 'Vous pouvez ajouter au maximum ' + policy.max_files + ' fichiers au total.' ); }
				for ( const file of files ) {
					const type = file.type || '';
					if ( policy.mode === 'photos' && ! type.startsWith( 'image/' ) || policy.mode === 'videos' && ! type.startsWith( 'video/' ) || ! /^(image|video)\//.test( type ) ) { throw new Error( 'Ce type de fichier n’est pas autorisé.' ); }
					if ( file.size < 1 || file.size > policy.max_file_size_mb * 1048576 ) { throw new Error( 'Le fichier doit contenir des données et ne pas dépasser ' + policy.max_file_size_mb + ' Mo.' ); }
				}
				for ( const file of files ) {
					const payload = new FormData(); payload.append( 'session', session.session ); payload.append( 'mobile', session.mobile ); payload.append( 'file', file );
					say( 'Transfert de « ' + file.name + ' »… Gardez cette page ouverte.' );
					progress.hidden = false; progress.removeAttribute( 'value' );
					const result = await request( 'upload', payload, true );
					count = typeof result.count === 'number' ? result.count : count + 1; updateCount();
				}
				say( 'Transfert confirmé. Vos fichiers sont maintenant disponibles sur l’ordinateur.' );
			} catch ( error ) { say( error.message || 'Transfert non confirmé. Vérifiez les fichiers reçus sur l’ordinateur avant de réessayer.', true ); }
			finally { progress.hidden = true; setBusy( false ); }
		}
		function buildUploader() {
			ui.replaceChildren();
			const mode = policy.mode;
			const actions = node( 'div', '', 'tc-form-media-mobile__actions' );
			function picker( label, kind, capture = false ) {
				const input = node( 'input' ); input.type = 'file'; input.multiple = ! capture;
				input.accept = kind === 'both' ? accepts.photos + ',' + accepts.videos : accepts[ kind ];
				input.className = 'tc-form-media-mobile__input'; input.tabIndex = -1; input.setAttribute( 'aria-label', label );
				if ( capture ) { input.setAttribute( 'capture', 'environment' ); }
				input.addEventListener( 'change', () => { const files = Array.from( input.files ); input.value = ''; void addFiles( files ); } );
				const control = node( 'button', label ); control.type = 'button'; control.addEventListener( 'click', () => input.click() ); actions.append( input, control );
			}
			if ( mode !== 'videos' ) { picker( 'Prendre une photo', 'photos', true ); }
			if ( mode !== 'photos' ) { picker( 'Filmer une vidéo', 'videos', true ); }
			picker( mode === 'photos' ? 'Choisir des photos dans la galerie' : mode === 'videos' ? 'Choisir des vidéos dans la galerie' : 'Choisir dans la galerie', mode );
			countNode = node( 'p' ); updateCount();
			progress = node( 'progress' ); progress.max = 100; progress.hidden = true; progress.setAttribute( 'aria-label', 'Transfert du fichier en cours' );
			const finish = node( 'button', 'J’ai terminé les transferts' ); finish.type = 'button';
			finish.addEventListener( 'click', async () => {
				if ( busy || finished ) { return; }
				setBusy( true );
				try { await request( 'finish', auth() ); finished = true; window.clearTimeout( pollTimer ); say( 'C’est terminé. Vous pouvez fermer cette page et poursuivre le formulaire sur l’ordinateur.' ); output.focus(); }
				catch ( error ) { say( error.message || unavailable, true ); }
				finally { setBusy( false ); }
			} );
			ui.append( node( 'p', 'Jusqu’à ' + policy.max_files + ' fichiers au total, ' + policy.max_file_size_mb + ' Mo par fichier. Ne rechargez pas cette page pendant les transferts.' ), actions, countNode, progress, finish );
		}
		async function connect() {
			try {
				endpoint = sameOrigin( window.TheCoreFormMediaMobile?.endpoint );
				if ( ! /^[a-f0-9]{32}\.[a-f0-9]{64}$/i.test( fragment ) ) { throw new Error( unavailable ); }
				const [ bridge, secret ] = fragment.split( '.' ); fragment = '';
				say( 'Connexion sécurisée au formulaire…' );
				const result = await request( 'exchange', { bridge, secret } );
				if ( typeof result.session !== 'string' || typeof result.mobile !== 'string' || ! result.policy || ! /^\d{6}$/.test( String( result.pair_code ) ) ) { throw new Error( unavailable ); }
				session = { session: result.session, mobile: result.mobile }; policy = result.policy;
				if ( ! [ 'photos', 'videos', 'both' ].includes( policy.mode ) ) { throw new Error( unavailable ); }
				const heading = root.querySelector( 'h1' );
				if ( heading ) { heading.textContent = policy.mode === 'photos' ? 'Ajouter des photos' : policy.mode === 'videos' ? 'Ajouter des vidéos' : 'Ajouter des photos ou vidéos'; }
				const code = node( 'p', String( result.pair_code ), 'tc-form-media-mobile__code' ); code.setAttribute( 'aria-label', 'Code de connexion : ' + String( result.pair_code ).split( '' ).join( ' ' ) );
				ui.append( node( 'p', 'Confirmez ce code sur l’ordinateur pour autoriser les transferts :' ), code );
				say( 'En attente de confirmation sur l’ordinateur. Le téléphone ne peut accéder qu’au dépôt des fichiers.' );
				poll();
			} catch ( error ) { say( error.message || unavailable, true ); }
		}
		void connect();
	}
	if ( document.readyState === 'loading' ) { document.addEventListener( 'DOMContentLoaded', boot, { once: true } ); }
	else { boot(); }
}() );
