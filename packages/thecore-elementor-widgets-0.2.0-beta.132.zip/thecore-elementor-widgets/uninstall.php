<?php

declare(strict_types=1);

if (! defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

require_once __DIR__ . '/src/Infrastructure/Autoloader.php';

(new \TheCore\ElementorWidgets\Infrastructure\Autoloader())->register();

// Private media must not be orphaned when the optional request archive is disabled.
try {
    $sites = is_multisite() ? get_sites(['fields' => 'ids', 'number' => 0]) : [get_current_blog_id()];
    foreach ($sites as $blogId) {
        $switch = (int) $blogId !== get_current_blog_id();
        if ($switch) {
            switch_to_blog((int) $blogId);
        }
        try {
            \TheCore\ElementorWidgets\Forms\Media\Module::uninstall();
        } finally {
            if ($switch) {
                restore_current_blog();
            }
        }
    }
} catch (\Throwable) {
    wp_die(esc_html__('Les fichiers privés n’ont pas pu être supprimés. La désinstallation est interrompue pour éviter de laisser des données personnelles orphelines.', 'thecore-elementor-widgets'));
    return;
}

$purged = (new \TheCore\ElementorWidgets\FormSecurity\Infrastructure\BlockedSubmissionDataPurger())
    ->purgeForUninstall();

if (! $purged) {
    wp_die(
        esc_html__(
            'La table temporaire des soumissions bloquées n’a pas pu être supprimée. La désinstallation est interrompue afin de ne pas laisser de données personnelles orphelines.',
            'thecore-elementor-widgets'
        )
    );
}

if (! \TheCore\ElementorWidgets\Forms\Submissions\Installer::purgeForUninstall()) {
    wp_die(
        esc_html__(
            'Les demandes conservées n’ont pas pu être supprimées. La désinstallation est interrompue afin de ne pas laisser de données personnelles orphelines.',
            'thecore-elementor-widgets'
        )
    );
}

\TheCore\ElementorWidgets\Forms\Submissions\SubmissionsModule::unschedule(is_multisite());
