<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Modules;

use TheCore\ElementorWidgets\Contracts\Bootable;
use TheCore\ElementorWidgets\Elementor\Atomic\Widgets\FullscreenMenu\FullscreenMenu;
use TheCore\ElementorWidgets\Options\OptionsRepository;
use TheCore\ElementorWidgets\Registry\WidgetsRegistry;
use TheCore\ElementorWidgets\Support\RequirementsChecker;

final class WidgetsModule implements Bootable
{
    public function __construct(
        private readonly WidgetsRegistry $widgetsRegistry,
        private readonly OptionsRepository $optionsRepository,
        private readonly RequirementsChecker $requirementsChecker
    ) {
    }

    public function register(): void
    {
        add_action('elementor/widgets/register', [$this, 'registerWidgets']);
    }

    public function registerWidgets(object $widgetsManager): void
    {
        if (! $this->requirementsChecker->canRegisterAtomicWidgets()) {
            return;
        }

        $state = $this->optionsRepository->getWidgetsState($this->widgetsRegistry->defaults());

        if (empty($state['classic-menu'])) {
            return;
        }

        if (method_exists($widgetsManager, 'register')) {
            $widgetsManager->register(new FullscreenMenu());
        }
    }
}
