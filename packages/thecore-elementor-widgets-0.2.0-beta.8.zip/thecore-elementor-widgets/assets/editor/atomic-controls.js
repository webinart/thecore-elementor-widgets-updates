(() => {
    const registerControls = () => {
        const elementorV2 = window.elementorV2 || {};
        const registry = elementorV2.editorEditingPanel && elementorV2.editorEditingPanel.controlsRegistry;
        const controls = elementorV2.editorControls;
        const props = elementorV2.editorProps;

        if (!registry || !controls || !props) {
            return false;
        }

        const hasColorControl =
            typeof registry.get === 'function' ? Boolean(registry.get('thecore-color')) : false;
        const hasFontFamilyControl =
            typeof registry.get === 'function' ? Boolean(registry.get('thecore-font-family')) : false;
        const hasZeroDefaultSizeControl =
            typeof registry.get === 'function' ? Boolean(registry.get('thecore-size-zero-default')) : false;

        if (!hasColorControl) {
            registry.register('thecore-color', controls.ColorControl, 'full', props.colorPropTypeUtil);
        }

        if (!hasFontFamilyControl) {
            const React = window.React;

            const FontFamilyControl = (controlProps) => {
                const { value, setValue } = controls.useBoundProp(props.stringPropTypeUtil);
                const options = Array.isArray(controlProps.options) ? controlProps.options : [];
                const normalizedValue = typeof value === 'string' ? value : '';
                const hasPreset = options.some((option) => option && option.value === normalizedValue);
                const customOptionValue = '__custom__';
                const [selectedValue, setSelectedValue] = React.useState(
                    hasPreset ? normalizedValue : customOptionValue
                );

                React.useEffect(() => {
                    setSelectedValue(hasPreset ? normalizedValue : customOptionValue);
                }, [hasPreset, normalizedValue]);

                return React.createElement(
                    'div',
                    {
                        style: {
                            display: 'grid',
                            gap: '8px',
                        },
                    },
                    React.createElement(
                        'select',
                        {
                            value: selectedValue,
                            onChange: (event) => {
                                const nextValue = event.target.value;
                                setSelectedValue(nextValue);

                                if (customOptionValue === nextValue) {
                                    return;
                                }

                                setValue(nextValue);
                            },
                            style: {
                                width: '100%',
                                minHeight: '34px',
                                border: '1px solid #d5d8dc',
                                borderRadius: '6px',
                                padding: '0 10px',
                                backgroundColor: '#fff',
                                color: '#1c1f23',
                            },
                        },
                            options.map((option) =>
                                React.createElement(
                                    'option',
                                    {
                                    key: option.value,
                                    value: option.value,
                                },
                                option.label
                            )
                        ),
                        React.createElement(
                            'option',
                            {
                                value: customOptionValue,
                            },
                            'Custom value'
                        )
                    ),
                    selectedValue === customOptionValue
                        ? React.createElement('input', {
                            type: 'text',
                            value: normalizedValue,
                            placeholder: controlProps.placeholder || 'Enter a custom font-family value',
                            onChange: (event) => {
                                setValue(event.target.value);
                            },
                            style: {
                                width: '100%',
                                minHeight: '34px',
                                border: '1px solid #d5d8dc',
                                borderRadius: '6px',
                                padding: '0 10px',
                                backgroundColor: '#fff',
                                color: '#1c1f23',
                            },
                        })
                        : null
                );
            };

            registry.register('thecore-font-family', FontFamilyControl, 'full', props.stringPropTypeUtil);
        }

        if (!hasZeroDefaultSizeControl) {
            const React = window.React;

            const normalizeSizeValue = (value, defaultUnit, units) => {
                const fallbackUnit =
                    typeof defaultUnit === 'string' && units.includes(defaultUnit) ? defaultUnit : units[0] || 'px';

                if (!value || typeof value !== 'object') {
                    return {
                        size: 0,
                        unit: fallbackUnit,
                    };
                }

                const nextUnit =
                    typeof value.unit === 'string' && value.unit.trim() !== '' && units.includes(value.unit)
                        ? value.unit
                        : fallbackUnit;

                const size = value.size;

                if (typeof size === 'number' && !Number.isNaN(size)) {
                    return {
                        size,
                        unit: nextUnit,
                    };
                }

                if (typeof size === 'string' && size.trim() !== '' && !Number.isNaN(Number(size))) {
                    return {
                        size: Number(size),
                        unit: nextUnit,
                    };
                }

                return {
                    size: 0,
                    unit: nextUnit,
                };
            };

            const isValidSizeValue = (value, units) => {
                if (!value || typeof value !== 'object') {
                    return false;
                }

                if (typeof value.unit !== 'string' || !units.includes(value.unit)) {
                    return false;
                }

                return typeof value.size === 'number' && !Number.isNaN(value.size);
            };

            const ZeroDefaultSizeControl = (controlProps) => {
                const { value, setValue } = controls.useBoundProp(props.sizePropTypeUtil);
                const units = Array.isArray(controlProps.units) && controlProps.units.length > 0
                    ? controlProps.units
                    : ['px'];
                const defaultUnit = typeof controlProps.defaultUnit === 'string' ? controlProps.defaultUnit : units[0];
                const normalizedValue = React.useMemo(
                    () => normalizeSizeValue(value, defaultUnit, units),
                    [value, defaultUnit, units]
                );

                React.useEffect(() => {
                    if (!isValidSizeValue(value, units)) {
                        setValue(normalizedValue);
                    }
                }, [normalizedValue, setValue, units, value]);

                return React.createElement(controls.SizeControl, {
                    ...controlProps,
                });
            };

            registry.register(
                'thecore-size-zero-default',
                ZeroDefaultSizeControl,
                'full',
                props.sizePropTypeUtil
            );
        }

        return true;
    };

    const boot = () => {
        if (registerControls()) {
            return;
        }

        let attempts = 0;
        const maxAttempts = 40;
        const timer = window.setInterval(() => {
            attempts += 1;

            if (registerControls() || attempts >= maxAttempts) {
                window.clearInterval(timer);
            }
        }, 250);
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot, { once: true });
        return;
    }

    boot();
})();
