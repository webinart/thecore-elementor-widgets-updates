<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Gallery;

use TheCore\ElementorWidgets\Contracts\Bootable;
use TheCore\ElementorWidgets\Plugin;

final class GalleryModule implements Bootable
{
    public const SCRIPT = 'thecore-gallery';
    public const STYLE = 'thecore-gallery';
    public const REST_NAMESPACE = 'thecore-elementor-widgets/v1';

    private array $postTypes = [];

    public function register(): void
    {
        add_action('init', [$this, 'registerMeta'], 100);
        add_action('add_meta_boxes', [$this, 'addMetaBox'], 10, 2);
        add_action('save_post', [$this, 'save'], 20, 2);
        add_action('admin_enqueue_scripts', [$this, 'enqueueAdmin']);
        add_action('wp_enqueue_scripts', [$this, 'registerAssets']);
        add_action('elementor/editor/before_enqueue_scripts', [$this, 'enqueueEditor']);
        add_action('elementor/preview/enqueue_scripts', [$this, 'enqueueEditor']);
        add_action('elementor/atomic-widgets/frontend/loader/scripts/register', [$this, 'registerAssets']);
        add_action('rest_api_init', [$this, 'registerRoutes']);
    }

    public function registerMeta(): void
    {
        $types = apply_filters('thecore/gallery/post_types', get_post_types(['public' => true], 'names'));
        $this->postTypes = array_values(array_filter((array) $types, static fn ($type): bool => is_string($type) && 'attachment' !== $type && post_type_exists($type)));
        foreach ($this->postTypes as $postType) {
            register_post_meta($postType, GalleryData::META_KEY, [
                'type' => 'array',
                'single' => true,
                'default' => [],
                'show_in_rest' => false,
                'sanitize_callback' => [$this, 'sanitize'],
                'auth_callback' => [$this, 'authorizeMeta'],
                'revisions_enabled' => post_type_supports($postType, 'revisions'),
            ]);
        }
    }

    public function sanitize(mixed $value): array
    {
        $galleries = GalleryData::normalize($value);
        foreach ($galleries as &$gallery) {
            $gallery['images'] = array_values(array_filter($gallery['images'], static fn (int $imageId): bool => wp_attachment_is_image($imageId)));
        }
        unset($gallery);
        return $galleries;
    }

    public function authorizeMeta(mixed $allowed, string $key, int $postId): bool
    {
        return in_array(get_post_type($postId), $this->postTypes, true) && current_user_can('edit_post', $postId);
    }

    public function addMetaBox(string $postType, object $post): void
    {
        if (! in_array($postType, $this->postTypes, true) || ! current_user_can('edit_post', $post->ID)) {
            return;
        }
        add_meta_box('thecore-galleries', __('Galeries The Core', 'thecore-elementor-widgets'), [$this, 'renderMetaBox'], $postType, 'normal');
    }

    public function renderMetaBox(object $post): void
    {
        wp_nonce_field('thecore_galleries_save', 'thecore_galleries_nonce');
        echo '<div class="thecore-gallery-editor" data-thecore-gallery-editor-admin>';
        echo '<input type="hidden" name="thecore_galleries_payload" value="' . esc_attr((string) wp_json_encode((new GalleryRepository())->all((int) $post->ID))) . '">';
        echo '<p>' . esc_html__('Sélectionnez les photos dans la médiathèque. Chaque galerie possède un identifiant à renseigner dans le widget Galerie The Core.', 'thecore-elementor-widgets') . '</p>';
        echo '<div data-thecore-gallery-list></div>';
        echo '<button type="button" class="button" data-thecore-gallery-add>' . esc_html__('Ajouter une galerie', 'thecore-elementor-widgets') . '</button>';
        echo '</div>';
    }

    public function save(int $postId, object $post): void
    {
        if (
            ! in_array($post->post_type, $this->postTypes, true)
            || wp_is_post_revision($postId) || wp_is_post_autosave($postId)
            || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
            || ! current_user_can('edit_post', $postId)
            || ! is_string($_POST['thecore_galleries_nonce'] ?? null)
            || ! wp_verify_nonce(wp_unslash($_POST['thecore_galleries_nonce']), 'thecore_galleries_save')
            || ! is_string($_POST['thecore_galleries_payload'] ?? null)
        ) {
            return;
        }
        $payload = wp_unslash($_POST['thecore_galleries_payload']);
        if (strlen($payload) > 2000000 || ! str_starts_with(ltrim($payload), '[')) {
            return;
        }
        try {
            $raw = json_decode($payload, true, 64, JSON_THROW_ON_ERROR);
        } catch (\JsonException) {
            return;
        }
        if (! is_array($raw)) {
            return;
        }
        $galleries = $this->sanitize($raw);
        if ([] === $galleries) {
            delete_post_meta($postId, GalleryData::META_KEY);
        } else {
            update_post_meta($postId, GalleryData::META_KEY, $galleries);
        }
        clean_post_cache($postId);
        do_action('thecore/gallery/updated', $postId);
    }

    public function enqueueAdmin(string $hook): void
    {
        if (! in_array($hook, ['post.php', 'post-new.php'], true)) {
            return;
        }
        $screen = get_current_screen();
        if (! $screen || ! in_array($screen->post_type, $this->postTypes, true)) {
            return;
        }
        wp_enqueue_media();
        wp_enqueue_style('thecore-gallery-admin', THECORE_ELEMENTOR_WIDGETS_URL . 'assets/admin/gallery.css', [], THECORE_ELEMENTOR_WIDGETS_VERSION);
        wp_enqueue_script('thecore-gallery-admin', THECORE_ELEMENTOR_WIDGETS_URL . 'assets/admin/gallery.js', ['media-views'], THECORE_ELEMENTOR_WIDGETS_VERSION, true);
        wp_localize_script('thecore-gallery-admin', 'TheCoreGalleryAdmin', [
            'add' => __('Ajouter une galerie', 'thecore-elementor-widgets'),
            'empty' => __('Aucune galerie renseignée.', 'thecore-elementor-widgets'),
            'key' => __('Identifiant de la galerie', 'thecore-elementor-widgets'),
            'title' => __('Nom de la galerie', 'thecore-elementor-widgets'),
            'choose' => __('Sélectionner les photos', 'thecore-elementor-widgets'),
            'use' => __('Utiliser ces photos', 'thecore-elementor-widgets'),
            'removeGallery' => __('Supprimer cette galerie', 'thecore-elementor-widgets'),
            'confirmRemove' => __('Supprimer cette galerie de la publication ? Les fichiers restent dans la médiathèque.', 'thecore-elementor-widgets'),
            'up' => __('Monter', 'thecore-elementor-widgets'),
            'down' => __('Descendre', 'thecore-elementor-widgets'),
            'remove' => __('Retirer', 'thecore-elementor-widgets'),
            'photo' => __('Photo', 'thecore-elementor-widgets'),
            'keyError' => __('Chaque galerie doit avoir un identifiant unique : lettres minuscules, chiffres, tirets ou underscores.', 'thecore-elementor-widgets'),
            'limit' => __('Maximum : 20 galeries de 500 photos par publication.', 'thecore-elementor-widgets'),
        ]);
    }

    public function registerAssets(mixed $loader = null): void
    {
        wp_register_style(self::STYLE, THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/gallery.css', [], THECORE_ELEMENTOR_WIDGETS_VERSION);
        wp_register_script(self::SCRIPT, THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/gallery.js', [], THECORE_ELEMENTOR_WIDGETS_VERSION, true);
        if (is_user_logged_in()) {
            wp_localize_script(self::SCRIPT, 'TheCoreGalleryConfig', [
                'restUrl' => rest_url(self::REST_NAMESPACE . '/galleries/'),
                'nonce' => wp_create_nonce('wp_rest'),
                'postId' => GalleryRepository::currentPostId(),
                'lightbox' => Plugin::instance()->isFeatureEnabled('image-lightbox'),
                'enlarge' => __('Agrandir', 'thecore-elementor-widgets'),
                'empty' => __('Aucune photo dans cette galerie. Renseignez-la dans les Galeries The Core de la publication et vérifiez son identifiant.', 'thecore-elementor-widgets'),
                'error' => __('Impossible de charger la galerie. Vérifiez votre connexion et vos droits sur cette publication.', 'thecore-elementor-widgets'),
            ]);
        }
    }

    public function enqueueEditor(): void
    {
        $this->registerAssets();
        wp_enqueue_style(self::STYLE);
        wp_enqueue_script(self::SCRIPT);
        if (Plugin::instance()->isFeatureEnabled('image-lightbox')) {
            do_action('thecore/image-lightbox/enqueue');
        }
    }

    public function registerRoutes(): void
    {
        register_rest_route(self::REST_NAMESPACE, '/galleries/(?P<id>\d+)', [
            'methods' => 'GET',
            'permission_callback' => [$this, 'canRead'],
            'callback' => [$this, 'read'],
            'args' => [
                'id' => ['required' => true, 'sanitize_callback' => 'absint'],
                'gallery' => ['default' => GalleryData::DEFAULT_KEY, 'sanitize_callback' => 'sanitize_key'],
            ],
        ]);
    }

    public function canRead(object $request): bool
    {
        $postId = (int) $request->get_param('id');
        return in_array(get_post_type($postId), $this->postTypes, true) && current_user_can('edit_post', $postId);
    }

    public function read(object $request): array
    {
        $postId = (int) $request->get_param('id');
        $key = substr(sanitize_key((string) $request->get_param('gallery')), 0, 64);
        $repository = new GalleryRepository();
        return [
            'gallery' => $key,
            'images' => $repository->images($postId, $key),
            'available' => array_column($repository->all($postId), 'key'),
        ];
    }
}
