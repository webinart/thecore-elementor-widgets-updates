( function () {
	'use strict';
	if ( window.theCoreAtomicFormFlow ) { return; }
	function node( tag, text, className ) {
		const element = document.createElement( tag );
		if ( text ) { element.textContent = text; }
		if ( className ) { element.className = className; }
		return element;
	}
	function init( { form, config, controls } ) {
		if ( ! config.flow || ! Array.isArray( config.flow.groups ) ) { return null; }
		const definitions = new Map( config.fields.map( field => [ field.id, field ] ) );
		const originalDisabled = new Map( Array.from( controls, ( [ id, control ] ) => [ id, control.disabled ] ) );
		const originalRequired = new Map( Array.from( controls, ( [ id, control ] ) => [ id, control.required ] ) );
		const groups = config.flow.groups.map( group => {
			const matches = Array.from( form.querySelectorAll( '[data-thecore-form-group]' ) ).filter( element => element.dataset.thecoreFormGroup === group.id );
			if ( matches.length !== 1 || ! Array.isArray( group.fields ) ) { throw new Error( 'Le parcours du formulaire est momentanément indisponible.' ); }
			return { ...group, element: matches[ 0 ] };
		} );
		const fieldGroups = new Map( Array.from( controls.keys(), id => [ id, groups.filter( group => group.fields.includes( id ) ) ] ) );
		const submitButtons = Array.from( form.querySelectorAll( 'button[type="submit"],input[type="submit"]' ) ).filter( button => ! button.matches( '[data-thecore-flow-next],[data-thecore-flow-previous],.thecore-flow-next,.thecore-flow-previous' ) );
		let activeSteps = [], current = null, submitting = false, resetTimer;
		const status = node( 'p', '', 'tc-form-flow__announcement' );
		status.setAttribute( 'role', 'status' ); status.setAttribute( 'aria-live', 'polite' );
		form.append( status );
		let progress = form.querySelector( '[data-thecore-flow-progress],.thecore-flow-progress' );
		if ( ! progress ) { progress = node( 'div', '', 'tc-form-flow__progress' ); form.prepend( progress ); }
		progress.setAttribute( 'aria-label', 'Étapes du formulaire' );
		let next = form.querySelector( '[data-thecore-flow-next],.thecore-flow-next' );
		let previous = form.querySelector( '[data-thecore-flow-previous],.thecore-flow-previous' );
		if ( ! next || ! previous ) {
			const navigation = node( 'div', '', 'tc-form-flow__navigation' );
			if ( ! previous ) { previous = node( 'button', 'Retour', 'tc-form-flow__previous' ); previous.type = 'button'; navigation.append( previous ); }
			if ( ! next ) { next = node( 'button', 'Continuer', 'tc-form-flow__next' ); next.type = 'button'; navigation.append( next ); }
			if ( submitButtons[ 0 ] ) { submitButtons[ 0 ].insertAdjacentElement( 'beforebegin', navigation ); }
			else { form.append( navigation ); }
		}
		next.type = previous.type = 'button';
		const summaries = Array.from( form.querySelectorAll( '[data-thecore-flow-summary],.thecore-flow-summary' ) );
		form.noValidate = true;
		form.dataset.thecoreFlowReady = '1';

		function value( id ) {
			const control = controls.get( id );
			if ( ! control ) { return ''; }
			return [ 'radio', 'checkbox' ].includes( control.type ) && ! control.checked ? '' : control.value;
		}
		function matches( conditions ) {
			return ! conditions || conditions.every( condition => isActive( condition.field ) && value( condition.field ) === String( condition.value ) );
		}
		function isActive( id ) {
			const field = definitions.get( id );
			return !! field && matches( field.conditions ) && ( fieldGroups.get( id ) || [] ).every( group => matches( group.conditions ) );
		}
		function activeIds() { return new Set( Array.from( controls.keys() ).filter( isActive ) ); }
		function stepFor( id ) { return ( fieldGroups.get( id ) || [] ).filter( group => group.step && matches( group.conditions ) ).at( -1 ); }
		function isCurrent( id ) { const step = stepFor( id ); return ! step || step.id === current; }
		function isRequired( id ) {
			return originalRequired.get( id ) || ( config.flow.requiredRules || [] ).some( rule => rule.field === id && matches( rule.conditions ) );
		}
		function setShown( element, shown ) {
			element.hidden = ! shown;
			// Native element display styles can otherwise override the HTML hidden attribute.
			element.classList.toggle( 'tc-form-flow--hidden', ! shown );
		}
		function initialChoiceReady() {
			const controllers = new Set( groups.flatMap( group => ( group.conditions || [] ).map( condition => condition.field ) ) );
			for ( const id of controllers ) {
				const control = controls.get( id );
				if ( ! control || ! isActive( id ) || ! isRequired( id ) || stepFor( id )?.id !== activeSteps[ 0 ]?.id ) { continue; }
				if ( control.type === 'radio' ) {
					if ( ! Array.from( controls.values() ).some( other => other.type === 'radio' && other.name === control.name && other.checked ) ) { return false; }
				} else if ( ! value( id ) ) { return false; }
			}
			return true;
		}
		function summaryValue( id, control ) {
			if ( control.type === 'file' ) {
				return Array.from( control.closest( '[data-thecore-form-media]' )?.querySelectorAll( '.tc-form-media__file > span' ) || [], element => element.textContent ).join( ', ' );
			}
			if ( [ 'radio', 'checkbox' ].includes( control.type ) ) { return control.checked ? control.value : ''; }
			if ( control.tagName === 'SELECT' ) { return Array.from( control.selectedOptions ).filter( option => option.value ).map( option => option.textContent ).join( ', ' ); }
			return control.value;
		}
		function renderSummary() {
			for ( const summary of summaries ) {
				const contents = node( 'dl', '', 'tc-form-flow__summary-list' );
				for ( const [ id, control ] of controls ) {
					if ( ! isActive( id ) || originalDisabled.get( id ) || [ 'password', 'hidden' ].includes( control.type ) ) { continue; }
					const answer = summaryValue( id, control );
					if ( ! answer ) { continue; }
					const row = node( 'div', '', 'tc-form-flow__summary-row' );
					const definition = definitions.get( id );
					const label = definition.label || Array.from( form.querySelectorAll( 'label' ) ).find( element => element.htmlFor === control.id )?.textContent || 'Réponse';
					row.append( node( 'dt', label ), node( 'dd', answer ) );
					const step = stepFor( id );
					if ( step && step.id !== current ) {
						const edit = node( 'button', 'Modifier', 'tc-form-flow__edit' ); edit.type = 'button';
						edit.setAttribute( 'aria-label', 'Modifier : ' + label );
						edit.addEventListener( 'click', () => { go( step.id ); control.focus(); } ); row.append( edit );
					}
					contents.append( row );
				}
				summary.replaceChildren( contents );
			}
		}
		function renderProgress() {
			const list = node( 'ol', '', 'tc-form-flow__steps' );
			activeSteps.forEach( ( step, index ) => {
				const item = node( 'li', ( index + 1 ) + ' · ' + ( step.label || 'Étape ' + ( index + 1 ) ) );
				if ( step.id === current ) { item.setAttribute( 'aria-current', 'step' ); }
				list.append( item );
			} );
			progress.replaceChildren( list ); setShown( progress, activeSteps.length > 1 );
		}
		function sync() {
			activeSteps = groups.filter( group => group.step && matches( group.conditions ) );
			if ( ! activeSteps.some( step => step.id === current ) ) { current = activeSteps[ 0 ]?.id || null; }
			for ( const group of groups ) { setShown( group.element, matches( group.conditions ) && ( ! group.step || group.id === current ) ); }
			for ( const [ id, control ] of controls ) {
				control.disabled = submitting || !! originalDisabled.get( id ) || ! isActive( id ) || ! isCurrent( id );
				control.required = definitions.get( id ).type !== 'media' && isActive( id ) && !! isRequired( id );
			}
			const index = activeSteps.findIndex( step => step.id === current );
			setShown( previous, index > 0 ); setShown( next, index >= 0 && index < activeSteps.length - 1 && initialChoiceReady() );
			for ( const button of submitButtons ) { setShown( button, ( index < 0 || index === activeSteps.length - 1 ) && initialChoiceReady() ); }
			previous.disabled = next.disabled = submitting;
			renderProgress(); renderSummary();
		}
		function go( id, responseError = false ) {
			if ( submitting && ! responseError || ! activeSteps.some( step => step.id === id ) ) { return; }
			current = id; sync();
			const group = activeSteps.find( step => step.id === id );
			const heading = group?.element.querySelector( '[data-thecore-flow-heading],legend,h2,h3,h4' ) || group?.element;
			if ( heading ) { heading.tabIndex = -1; heading.focus(); }
			status.textContent = 'Étape ' + ( activeSteps.indexOf( group ) + 1 ) + ' sur ' + activeSteps.length + ' : ' + ( group?.label || '' );
		}
		function validate( all = false, beforeCheck ) {
			sync();
			if ( all ) { for ( const [ id, control ] of controls ) { control.disabled = !! originalDisabled.get( id ) || ! isActive( id ); } }
			beforeCheck?.( activeIds() );
			let invalid;
			for ( const [ id, control ] of controls ) {
				if ( ! originalDisabled.get( id ) && isActive( id ) && ( all || isCurrent( id ) ) && ! control.checkValidity() ) { invalid = { id, control }; break; }
			}
			if ( invalid ) {
				const step = stepFor( invalid.id );
				if ( step ) { go( step.id ); } else { sync(); }
				invalid.control.focus(); invalid.control.reportValidity(); return false;
			}
			sync(); return true;
		}
		function advance( beforeCheck ) {
			if ( submitting || ! validate( false, beforeCheck ) ) { return false; }
			const index = activeSteps.findIndex( step => step.id === current );
			if ( index >= 0 && index < activeSteps.length - 1 ) { go( activeSteps[ index + 1 ].id ); return true; }
			return false;
		}
		next.addEventListener( 'click', event => { event.preventDefault(); advance( adapter.validateMedia ); } );
		previous.addEventListener( 'click', event => {
			event.preventDefault();
			if ( submitting ) { return; }
			const index = activeSteps.findIndex( step => step.id === current ); if ( index > 0 ) { go( activeSteps[ index - 1 ].id ); }
		} );
		const adapter = { validateMedia: null };
		form.addEventListener( 'input', sync ); form.addEventListener( 'change', sync );
		form.addEventListener( 'reset', () => { clearTimeout( resetTimer ); resetTimer = window.setTimeout( () => { current = null; sync(); }, 0 ); } );
		form.addEventListener( 'thecore:form-result', event => { if ( ! event.detail?.success ) { renderSummary(); } } );
		sync();
		return {
			activeIds, isActive, sync,
			setMediaValidation: action => { adapter.validateMedia = action; },
			isLastStep: () => { sync(); return ! activeSteps.length || activeSteps.at( -1 ).id === current; },
			next: () => advance( adapter.validateMedia ),
			validateAll: () => validate( true, adapter.validateMedia ),
			showField: id => { const step = stepFor( id ); if ( step ) { go( step.id, true ); } },
			setSubmitting: value => { submitting = value; sync(); },
		};
	}
	window.theCoreAtomicFormFlow = { init };
	window.dispatchEvent( new Event( 'thecore:form-flow-ready' ) );
}() );
