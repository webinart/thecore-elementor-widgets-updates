<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\FullscreenMenu;

use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Number_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Select_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Size_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Switch_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Text_Control;
use Elementor\Modules\AtomicWidgets\DynamicTags\Dynamic_Prop_Type;
use Elementor\Modules\AtomicWidgets\Elements\Base\Atomic_Widget_Base;
use Elementor\Modules\AtomicWidgets\Elements\Base\Has_Template;
use Elementor\Modules\AtomicWidgets\PropTypes\Attributes_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Color_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Boolean_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Number_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Size_Prop_Type;
use Elementor\Modules\Components\PropTypes\Overridable_Prop_Type;
use TheCore\ElementorWidgets\Assets\FrontendAssets;
use TheCore\ElementorWidgets\Elementor\Atomic\Controls\Types\ColorControl;
use TheCore\ElementorWidgets\Elementor\Atomic\Controls\Types\FontFamilyControl;
use TheCore\ElementorWidgets\Elementor\Atomic\Controls\Types\ZeroDefaultSizeControl;
use TheCore\ElementorWidgets\Elementor\Atomic\PropTypes\ZeroableSizePropType;
use TheCore\ElementorWidgets\Plugin;

final class FullscreenMenu extends Atomic_Widget_Base
{
    use Has_Template;

    public static $widget_description = 'Fullscreen navigation menu with a mobile overlay and top-level WordPress menu items.';

    public static function get_element_type(): string
    {
        return 'thecore-classic-menu';
    }

    public function get_title(): string
    {
        return esc_html__('Fullscreen Menu', 'thecore-elementor-widgets');
    }

    public function get_icon(): string
    {
        return 'eicon-menu-toggle';
    }

    public function get_keywords(): array
    {
        return ['menu', 'navigation', 'fullscreen', 'overlay', 'hamburger', 'atomic'];
    }

    public function get_style_depends(): array
    {
        return [FrontendAssets::FULLSCREEN_MENU_STYLE];
    }

    public function get_script_depends(): array
    {
        return [FrontendAssets::FULLSCREEN_MENU_SCRIPT];
    }

    protected static function define_props_schema(): array
    {
        return [
            'menu_id' => String_Prop_Type::make()->default(''),
            'overlay_only' => Boolean_Prop_Type::make()->default(false),
            'mobile_breakpoint' => Number_Prop_Type::make()->default(DisplaySettings::DEFAULT_MOBILE_BREAKPOINT),
            'toggle_color' => Color_Prop_Type::make()->default(DisplaySettings::DEFAULT_TOGGLE_COLOR),
            'toggle_open_color' => Color_Prop_Type::make()->default(DisplaySettings::DEFAULT_TOGGLE_OPEN_COLOR),
            'overlay_background_color' => Color_Prop_Type::make()->default(DisplaySettings::DEFAULT_OVERLAY_COLOR),
            'overlay_opacity' => Number_Prop_Type::make()->default(DisplaySettings::DEFAULT_OVERLAY_OPACITY),
            'toggle_position_top' => Number_Prop_Type::make()->default(DisplaySettings::DEFAULT_TOGGLE_POSITION_TOP),
            'toggle_position_right' => Number_Prop_Type::make()->default(DisplaySettings::DEFAULT_TOGGLE_POSITION_RIGHT),
            'desktop_link_color' => Color_Prop_Type::make()->default(DisplaySettings::DEFAULT_DESKTOP_LINK_COLOR),
            'desktop_font_family' => String_Prop_Type::make()->default(DisplaySettings::DEFAULT_FONT_FAMILY),
            'desktop_font_size' => Size_Prop_Type::make()
                ->units(['px', 'em', 'rem'])
                ->default_unit('px')
                ->default(DisplaySettings::DEFAULT_FONT_SIZE),
            'desktop_font_weight' => String_Prop_Type::make()->enum(self::fontWeightValues())->default('400'),
            'desktop_line_height' => Size_Prop_Type::make()
                ->units(['em', 'px', 'rem'])
                ->default_unit('em')
                ->default(DisplaySettings::DEFAULT_LINE_HEIGHT),
            'desktop_letter_spacing' => ZeroableSizePropType::make()
                ->units(['px', 'em', 'rem'])
                ->default_unit('px')
                ->meta(Dynamic_Prop_Type::ignore())
                ->meta(Overridable_Prop_Type::ignore())
                ->initial_value(DisplaySettings::DEFAULT_LETTER_SPACING)
                ->default(DisplaySettings::DEFAULT_LETTER_SPACING),
            'desktop_font_style' => String_Prop_Type::make()->enum(self::fontStyleValues())->default('normal'),
            'desktop_text_decoration' => String_Prop_Type::make()->enum(self::textDecorationValues())->default('none'),
            'desktop_text_transform' => String_Prop_Type::make()->enum(self::textTransformValues())->default('none'),
            'overlay_link_color' => Color_Prop_Type::make()->default(DisplaySettings::DEFAULT_OVERLAY_LINK_COLOR),
            'overlay_font_family' => String_Prop_Type::make()->default(DisplaySettings::DEFAULT_FONT_FAMILY),
            'overlay_font_size' => Size_Prop_Type::make()
                ->units(['px', 'em', 'rem'])
                ->default_unit('px')
                ->default(DisplaySettings::DEFAULT_FONT_SIZE),
            'overlay_font_weight' => String_Prop_Type::make()->enum(self::fontWeightValues())->default('400'),
            'overlay_line_height' => Size_Prop_Type::make()
                ->units(['em', 'px', 'rem'])
                ->default_unit('em')
                ->default(DisplaySettings::DEFAULT_LINE_HEIGHT),
            'overlay_letter_spacing' => ZeroableSizePropType::make()
                ->units(['px', 'em', 'rem'])
                ->default_unit('px')
                ->meta(Dynamic_Prop_Type::ignore())
                ->meta(Overridable_Prop_Type::ignore())
                ->initial_value(DisplaySettings::DEFAULT_LETTER_SPACING)
                ->default(DisplaySettings::DEFAULT_LETTER_SPACING),
            'overlay_font_style' => String_Prop_Type::make()->enum(self::fontStyleValues())->default('normal'),
            'overlay_text_decoration' => String_Prop_Type::make()->enum(self::textDecorationValues())->default('none'),
            'overlay_text_transform' => String_Prop_Type::make()->enum(self::textTransformValues())->default('none'),
            'attributes' => Attributes_Prop_Type::make()->meta(Overridable_Prop_Type::ignore()),
        ];
    }

    protected function define_atomic_controls(): array
    {
        $menuOptionsProvider = new MenuOptionsProvider();

        return [
            Section::make()
                ->set_label(__('Content', 'thecore-elementor-widgets'))
                ->set_items([
                    Select_Control::bind_to('menu_id')
                        ->set_label(__('WordPress Menu', 'thecore-elementor-widgets'))
                        ->set_options($menuOptionsProvider->getOptions())
                        ->set_placeholder(__('Select a menu', 'thecore-elementor-widgets'))
                        ->set_description(__('Reads the top-level items of the selected WordPress menu.', 'thecore-elementor-widgets')),
                ]),
            Section::make()
                ->set_label(__('Responsive', 'thecore-elementor-widgets'))
                ->set_items([
                    Switch_Control::bind_to('overlay_only')
                        ->set_label(__('Overlay only', 'thecore-elementor-widgets'))
                        ->set_description(__('Keeps the hamburger/overlay version active on every breakpoint.', 'thecore-elementor-widgets')),
                    Number_Control::bind_to('mobile_breakpoint')
                        ->set_label(__('Mobile breakpoint (px)', 'thecore-elementor-widgets'))
                        ->set_min(320)
                        ->set_max(1920)
                        ->set_step(1)
                        ->set_should_force_int(true),
                ]),
            Section::make()
                ->set_label(__('Overlay Behavior', 'thecore-elementor-widgets'))
                ->set_items([
                    ColorControl::bind_to('overlay_background_color')
                        ->set_label(__('Background color', 'thecore-elementor-widgets')),
                    Number_Control::bind_to('overlay_opacity')
                        ->set_label(__('Opacity (%)', 'thecore-elementor-widgets'))
                        ->set_min(0)
                        ->set_max(100)
                        ->set_step(1)
                        ->set_should_force_int(true),
                ]),
            Section::make()
                ->set_label(__('Toggle', 'thecore-elementor-widgets'))
                ->set_items([
                    ColorControl::bind_to('toggle_color')
                        ->set_label(__('Color', 'thecore-elementor-widgets')),
                    ColorControl::bind_to('toggle_open_color')
                        ->set_label(__('Open color', 'thecore-elementor-widgets')),
                    Number_Control::bind_to('toggle_position_top')
                        ->set_label(__('Top offset (%)', 'thecore-elementor-widgets'))
                        ->set_min(0)
                        ->set_max(100)
                        ->set_step(1)
                        ->set_should_force_int(true),
                    Number_Control::bind_to('toggle_position_right')
                        ->set_label(__('Right offset (%)', 'thecore-elementor-widgets'))
                        ->set_min(0)
                        ->set_max(100)
                        ->set_step(1)
                        ->set_should_force_int(true),
                ]),
            Section::make()
                ->set_label(__('Desktop Links', 'thecore-elementor-widgets'))
                ->set_items([
                    ColorControl::bind_to('desktop_link_color')
                        ->set_label(__('Color', 'thecore-elementor-widgets')),
                    FontFamilyControl::bind_to('desktop_font_family')
                        ->set_label(__('Font family', 'thecore-elementor-widgets')),
                    Size_Control::bind_to('desktop_font_size')
                        ->set_label(__('Font size', 'thecore-elementor-widgets'))
                        ->set_units(['px', 'em', 'rem'])
                        ->set_default_unit('px')
                        ->set_disable_custom(true),
                    Select_Control::bind_to('desktop_font_weight')
                        ->set_label(__('Font weight', 'thecore-elementor-widgets'))
                        ->set_options(self::fontWeightOptions()),
                    Size_Control::bind_to('desktop_line_height')
                        ->set_label(__('Line height', 'thecore-elementor-widgets'))
                        ->set_units(['em', 'px', 'rem'])
                        ->set_default_unit('em')
                        ->set_disable_custom(true),
                    ZeroDefaultSizeControl::bind_to('desktop_letter_spacing')
                        ->set_label(__('Letter spacing', 'thecore-elementor-widgets'))
                        ->set_units(['px', 'em', 'rem'])
                        ->set_default_unit('px')
                        ->set_disable_custom(true),
                    Select_Control::bind_to('desktop_font_style')
                        ->set_label(__('Font style', 'thecore-elementor-widgets'))
                        ->set_options(self::fontStyleOptions()),
                    Select_Control::bind_to('desktop_text_decoration')
                        ->set_label(__('Text decoration', 'thecore-elementor-widgets'))
                        ->set_options(self::textDecorationOptions()),
                    Select_Control::bind_to('desktop_text_transform')
                        ->set_label(__('Text transform', 'thecore-elementor-widgets'))
                        ->set_options(self::textTransformOptions()),
                ]),
            Section::make()
                ->set_label(__('Overlay Links', 'thecore-elementor-widgets'))
                ->set_items([
                    ColorControl::bind_to('overlay_link_color')
                        ->set_label(__('Color', 'thecore-elementor-widgets')),
                    FontFamilyControl::bind_to('overlay_font_family')
                        ->set_label(__('Font family', 'thecore-elementor-widgets')),
                    Size_Control::bind_to('overlay_font_size')
                        ->set_label(__('Font size', 'thecore-elementor-widgets'))
                        ->set_units(['px', 'em', 'rem'])
                        ->set_default_unit('px')
                        ->set_disable_custom(true),
                    Select_Control::bind_to('overlay_font_weight')
                        ->set_label(__('Font weight', 'thecore-elementor-widgets'))
                        ->set_options(self::fontWeightOptions()),
                    Size_Control::bind_to('overlay_line_height')
                        ->set_label(__('Line height', 'thecore-elementor-widgets'))
                        ->set_units(['em', 'px', 'rem'])
                        ->set_default_unit('em')
                        ->set_disable_custom(true),
                    ZeroDefaultSizeControl::bind_to('overlay_letter_spacing')
                        ->set_label(__('Letter spacing', 'thecore-elementor-widgets'))
                        ->set_units(['px', 'em', 'rem'])
                        ->set_default_unit('px')
                        ->set_disable_custom(true),
                    Select_Control::bind_to('overlay_font_style')
                        ->set_label(__('Font style', 'thecore-elementor-widgets'))
                        ->set_options(self::fontStyleOptions()),
                    Select_Control::bind_to('overlay_text_decoration')
                        ->set_label(__('Text decoration', 'thecore-elementor-widgets'))
                        ->set_options(self::textDecorationOptions()),
                    Select_Control::bind_to('overlay_text_transform')
                        ->set_label(__('Text transform', 'thecore-elementor-widgets'))
                        ->set_options(self::textTransformOptions()),
                ]),
            Section::make()
                ->set_label(__('Settings', 'thecore-elementor-widgets'))
                ->set_id('settings')
                ->set_items([
                    Text_Control::bind_to('_cssid')
                        ->set_label(__('ID', 'thecore-elementor-widgets'))
                        ->set_meta($this->get_css_id_control_meta()),
                ]),
        ];
    }

    protected function get_templates(): array
    {
        return [
            'thecore/elements/fullscreen-menu' => __DIR__ . '/fullscreen-menu.html.twig',
        ];
    }

    protected function render()
    {
        $settings = (new DisplaySettings())->normalize($this->get_atomic_settings());
        $renderer = new MenuRenderer();
        $cssId = trim((string) $this->get_atomic_setting('_cssid'));
        $scope = $this->buildScopeValue();
        $scopeSelector = '[data-thecore-fullscreen-menu-scope="' . $scope . '"]';
        $styleMarkup = (new InlineStylesBuilder())->build($scopeSelector, $settings);
        $menuMarkup = $renderer->render((int) $settings['menu_id'], $this->get_id());

        if ('' === $menuMarkup) {
            return;
        }

        $attributes = [
            'class' => 'thecore-fullscreen-menu',
            'data-thecore-fullscreen-menu' => 'true',
            'data-thecore-fullscreen-menu-scope' => $scope,
            'data-overlay-only' => ! empty($settings['overlay_only']) ? '1' : '0',
            'data-mobile-breakpoint' => (string) $settings['mobile_breakpoint'],
            'data-scroll-lock' => Plugin::instance()->isFeatureEnabled('overlay-scroll-lock') ? '1' : '0',
        ];

        if ('' !== $cssId) {
            $attributes['id'] = $cssId;
        }

        echo '<style>' . $styleMarkup . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo '<div' . $this->buildAttributes($attributes) . '>';
        echo $menuMarkup; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo '</div>';
    }

    /**
     * @return array<int, array{label: string, value: string}>
     */
    private static function fontWeightOptions(): array
    {
        return array_map(
            static fn (string $value): array => [
                'label' => $value,
                'value' => $value,
            ],
            self::fontWeightValues()
        );
    }

    /**
     * @return array<int, string>
     */
    private static function fontWeightValues(): array
    {
        return ['100', '200', '300', '400', '500', '600', '700', '800', '900'];
    }

    /**
     * @return array<int, array{label: string, value: string}>
     */
    private static function fontStyleOptions(): array
    {
        return [
            [
                'label' => __('Normal', 'thecore-elementor-widgets'),
                'value' => 'normal',
            ],
            [
                'label' => __('Italic', 'thecore-elementor-widgets'),
                'value' => 'italic',
            ],
            [
                'label' => __('Oblique', 'thecore-elementor-widgets'),
                'value' => 'oblique',
            ],
        ];
    }

    /**
     * @return array<int, string>
     */
    private static function fontStyleValues(): array
    {
        return ['normal', 'italic', 'oblique'];
    }

    /**
     * @return array<int, array{label: string, value: string}>
     */
    private static function textDecorationOptions(): array
    {
        return [
            [
                'label' => __('None', 'thecore-elementor-widgets'),
                'value' => 'none',
            ],
            [
                'label' => __('Underline', 'thecore-elementor-widgets'),
                'value' => 'underline',
            ],
            [
                'label' => __('Line Through', 'thecore-elementor-widgets'),
                'value' => 'line-through',
            ],
            [
                'label' => __('Overline', 'thecore-elementor-widgets'),
                'value' => 'overline',
            ],
        ];
    }

    /**
     * @return array<int, string>
     */
    private static function textDecorationValues(): array
    {
        return ['none', 'underline', 'line-through', 'overline'];
    }

    /**
     * @return array<int, array{label: string, value: string}>
     */
    private static function textTransformOptions(): array
    {
        return [
            [
                'label' => __('None', 'thecore-elementor-widgets'),
                'value' => 'none',
            ],
            [
                'label' => __('Uppercase', 'thecore-elementor-widgets'),
                'value' => 'uppercase',
            ],
            [
                'label' => __('Lowercase', 'thecore-elementor-widgets'),
                'value' => 'lowercase',
            ],
            [
                'label' => __('Capitalize', 'thecore-elementor-widgets'),
                'value' => 'capitalize',
            ],
        ];
    }

    /**
     * @return array<int, string>
     */
    private static function textTransformValues(): array
    {
        return ['none', 'uppercase', 'lowercase', 'capitalize'];
    }

    private function buildScopeValue(): string
    {
        return 'thecore-fsm-' . sanitize_html_class($this->get_id());
    }

    /**
     * @param array<string, string> $attributes
     */
    private function buildAttributes(array $attributes): string
    {
        $markup = '';

        foreach ($attributes as $name => $value) {
            $markup .= sprintf(
                ' %s="%s"',
                esc_attr($name),
                esc_attr($value)
            );
        }

        return $markup;
    }
}
