# Changelog

## 0.2.0-beta.123

- Compact soft media file rows and their remove controls while preserving legibility, keyboard focus and touch targets.
- Reconcile soft file rows by identifier so unchanged polling results preserve their DOM and do not replay entry animations.
- Fade in only newly added visible rows, respecting reduced motion and reusing the existing opt-in form-flow height transition without a second resizing engine.

## 0.2.0-beta.122

- Highlight the soft phone-transfer panel’s six-digit pairing code in a legible badge, without changing explicit approval or the Standard appearance.
- Add an opt-in native optical QR outdent (0–12 px, default 0) to align the QR drawing with surrounding controls while preserving its white scanning margin; only enable it where the field has sufficient inner space.
- Cover pending, invalid, confirmed and terminal code states in the QR presentation browser suite.

## 0.2.0-beta.121

- Keep the one-use ALTCHA proof host hidden, inert and outside accessibility/focus before mounting, using supported display configuration without weakening verification or lazy loading.
- Show localized verification/loading feedback in the phone-transfer trigger, restoring its original label, dimensions and accessibility state on success or error.
- Add real ALTCHA library/worker coverage for in-flight visibility, errors and proof cleanup, alongside existing media/security regressions.

## 0.2.0-beta.120

- Simplify the opt-in soft media field’s inline phone-transfer panel: group the QR code, connection instructions, expiry and controls without redundant headings, nested frames or detached ready messages.
- Preserve explicit pairing approval, existing transfer security and the default presentation; add responsive layout and bridge-state regression coverage.

## 0.2.0-beta.119

- Add an opt-in soft appearance for the native media field, with editable label typography, colors, secondary buttons and responsive action alignment.
- Keep the default appearance and all upload, phone-transfer, validation and delivery behavior unchanged. Share sanitized appearance values between PHP and editor rendering.

## 0.2.0-beta.118

- Add an opt-in native Form setting for smooth conditional-branch and step transitions. Animate the form height and newly visible content without changing the validation, focus, field or delivery contracts.
- Respect reduced motion and the initial no-flash render; restart interrupted transitions safely and release temporary dimensions after asynchronous content changes.
- Keep existing forms unchanged unless the new option is enabled. Add normalization, rendering and browser regression coverage.

## 0.2.0-beta.117

- Add an opt-in one-time viewport entrance cascade to Marquee Carousel, with native interval, duration and bounded relative trigger controls. Pause the loop during the intro and include only visible logos, including required clones, before resuming seamless scrolling.
- Reuse The Core animation playback and trigger helpers when available, with a native Web Animations fallback, no dependency on the theme, and no additional library or request. Preserve default behavior, reduced-motion/no-JS visibility and focus/print access.
- Clean up entrance animations, observers, lazy timers and toggle listeners when Elementor removes an instance. Add normalization and real-browser lifecycle coverage.

## 0.2.0-beta.116

- After confirmed form success, drop local credentials for submitted media without attempting to revoke the already-sealed server session. Keep abandoned-branch media untouched and preserve uncertain/error replies for safe retries.
- Add regression coverage for successful media delivery without a forbidden post-commit revoke.

## 0.2.0-beta.115

- Keep phone-transfer documents on `no-referrer`, while multipart uploads explicitly send only the public same-origin root as their referrer for upload-firewall compatibility. No source-page path, query, fragment, pairing capability or form answer is exposed.
- Preserve strict same-origin endpoints, refused redirects, private capabilities and explicit pairing; add browser checks for the exact upload referrer and no-referrer JSON operations.

## 0.2.0-beta.114

- Add opt-in native FormGroup containers for saved conditional branches and non-nested form steps, with per-group labels and conditional required fields.
- Add shared accessible next/back navigation, progress and editable summaries; retain answers in memory and validate every active step before final delivery.
- Resolve saved conditions independently on the server, exclude abandoned-branch values and media sessions from actions, archives and blocked-submission details, and reject invalid/forward/cyclic condition definitions.
- Preserve plain forms and media behavior without flow groups; scope assets and SSR no-flash structure to forms that opt in. Add backend/security and browser regression tests.

## 0.2.0-beta.113

- Add the opt-in native Atomic Photos and videos field: per-field photos/videos/both selection, required state, count/size limits and independent QR phone-transfer switch.
- Add first-party upload sessions and a single-use QR invitation with desktop pairing approval. Phone credentials permit upload only; existing forms and classic site-specific adapters are not migrated.
- Validate actual media formats server-side and store files outside the web root with bounded quotas, protected administrator downloads, independent retention and WordPress privacy erasure/export.
- Bind final media references to the saved form and seal files before delivery, preserving uncertain deliveries without automatic resubmission. Keep signed dry-runs read-only and media-session anti-abuse quotas separate from final sends.
- Load media assets only for media fields and the local MIT QR library on demand. Add PHP security/lifecycle/pipeline tests and synthetic desktop/mobile browser regression suites.

## 0.2.0-beta.112

- Allow up to 20 internal email recipients, separated by commas or semicolons, in the existing Atomic form Email action without changing saved forms or the visitor acknowledgement.
- Validate the complete list before any action or archive write, reject invalid/empty entries and header control characters, and deduplicate addresses case-insensitively.
- Preserve the single-address mail contract, administrator fallback, Reply-To and dry-run behavior; document the shared To notification and add recipient/pipeline regression tests.

## 0.2.0-beta.111

- Add the Atomic Galerie The Core widget with per-instance masonry/thumbnail layouts, responsive columns, gaps, captions and optional existing The Core lightbox.
- Add named publication galleries stored as ordered media IDs, native media selection and protected metadata with revision support.
- Add an authenticated editor preview endpoint and gallery-scoped assets without migrating or changing existing publications.
- Preserve image dimension aspect ratios with automatic responsive sizes, preventing 150px image boxes and horizontal whitespace in recent Chrome versions.
- Refresh gallery stylesheet URLs from their content hash without changing the plugin version; cover automatic sizes in desktop, tablet and mobile browser tests.

## 0.2.0-beta.110

- Declare the native classic form runtime and the script dependencies of its present field types, including Form Security, even when cached field HTML skips rendering side effects.
- Add an additive dependency filter for site-specific form adapters, preserving required field scripts and deduplicating handles for WordPress and The Core's deferred asset graph.
- Preserve the legacy and Elementor editor dependency paths, field markup, server security and submission actions. Add PHP coverage for protected/unprotected forms, cached declarations and adapter filters.

## 0.2.0-beta.109

- Add opt-in responsive disclosures for native V4 contents menus: server-rendered content remains readable without JavaScript, while mobile toggles synchronize visibility, keyboard focus and deep links.
- Add opt-in click-to-play YouTube/Vimeo players: no third-party request before deliberate activation, strict provider/ID validation, YouTube privacy-enhanced domain and a persistent external-link fallback.
- Inline CSS and vanilla JavaScript are loaded only for marked documents. Preserve the existing site attribute policy, independent image-lightbox module and native classic form runtime introduced in beta.108.
- Document native markup contracts and add PHP/JavaScript lifecycle coverage.

## 0.2.0-beta.108

- Pont opt-in pour les formulaires Elementor classiques : moteur The Core sans
  jQuery, navigation par étapes, validation, envoi fetch et messages accessibles.
- Conservation des champs, modèles, identifiants et du traitement PHP Elementor
  Pro existant, de Form Security et des actions métier enregistrées par le site.
- Dispatcher isolé pour empêcher le moteur Pro de traiter aussi une instance
  native lorsque les scripts Elementor sont présents, notamment en connexion.
- Événements natifs de préparation annulable, départ de requête et résultat
  terminal, y compris lors d’une interruption réseau ; aucune reprise automatique.
- Préparation de l’identifiant API avant les captures métier, conservation au
  rejeu et remise à zéro uniquement après un succès confirmé.
- Remise à zéro ALTCHA après erreur native sans dépendance aux événements jQuery.
- Tests PHP et navigateur synthétique sans requête métier externe.

## 0.2.0-beta.107

- Visionneuse d'images generique et opt-in, rattachee aux galeries natives
  marquees `data-thecore-gallery`, sans nouveau widget ni dependance au theme.
- PhotoSwipe 5.4.4 auto-heberge sous licence MIT, charge uniquement a la
  premiere ouverture ; bootstrap et CSS overlay inline sur les seules pages
  concernees, sans jQuery ni runtime frontend Elementor.
- Detection du graphe V4 avant le head et repli sur le HTML rendu, y compris
  les templates caches ; liens vers les images conserves sans JavaScript
  et en cas d'echec reseau.
- Contrat de donnees V4 preserve via le transformateur natif : seules les quatre
  metadonnees de la visionneuse sont validees et rendues, sans elargir la
  politique d'attributs existante ni reecrire le HTML.
- Navigation clavier et tactile, zoom, compteur, fermeture Echap, focus
  contenu dans la modale et rendu au declencheur, libelles traduisibles et
  transitions desactivees pour le mouvement reduit.
- Tests PHP du chargement conditionnel et du cache, tests JavaScript du
  premier clic, du chargement paresseux, du focus et des replis.

## 0.2.0-beta.106

- Diaporama de fond Atomic V4 reutilisable, desactive par defaut et activable
  par site : images ordonnables, fondu et zoom Ken Burns reglables.
- Premiere image rendue cote serveur avec sources responsives WordPress ;
  images suivantes inertes puis chargees progressivement, deux couches au plus.
- Taille d'image mobile optionnelle avec sources picture natives ; exclusion
  du lazy-load global The Core pour conserver un chargement autonome.
- Runtime autonome sans jQuery, Swiper ou scripts frontend Elementor ; assets
  uniquement pour les instances utilisees, compatibles avec les controles
  natifs d'injection inline du theme.
- Pause locale ou via le panneau d'accessibilite, mouvement reduit statique,
  suspension hors ecran et dans les onglets masques, reprise sans saut.
- Tests PHP, cycle de vie JavaScript et integration Atomic.

## 0.2.0-beta.105

- Consentement cookies compatible avec un HTML partagé en cache : les codes
  par catégorie sont livrés en JSON inerte puis exécutés côté navigateur
  uniquement après un consentement valide, sans dépendre du cookie reçu en PHP.
- Conservation du placement head/footer, de l'ordre des scripts dépendants,
  des modules, de l'async explicite et des attributs nonce/SRI ; aucune
  exécution répétée lors des mises à jour du DOM ou des bannières multiples.
- Événement `thecore:cookie-consent-changed` pour les intégrations et la
  révocation. Le rechargement natif reste disponible et ne déclenche pas
  les nouveaux traceurs avant la navigation afin d'éviter un double envoi.
- Tests PHP et navigateur isolés du cache commun, des cookies invalides,
  des dépendances, modules, choix, révocations et rechargements.

## 0.2.0-beta.104

- Formulaires Atomic : chargement du solveur ALTCHA et de son registre PBKDF2
  au premier clic/toucher ou focus clavier dans un formulaire, partagé entre
  les instances ; aucun téléchargement antispam au chargement de la page.
- Une soumission immédiate attend le chargement puis la preuve antispam.
  En cas d'échec réseau, aucun envoi ne part et une nouvelle tentative peut
  recharger les scripts. Les intégrations classiques restent indépendantes.

## 0.2.0-beta.103

- Publication sur le canal bêta du connecteur générique « Envoyer à une API »
  pour les formulaires Atomic et Elementor Pro, avec les connexions serveur
  et le mapping typé introduits en beta.101.
- Inclusion du correctif beta.102 qui conserve les tentatives d’envoi pendant
  la vérification antispam et respecte les validations natives du formulaire.
- Alignement de la version du plugin et de sa documentation pour la distribution.

## 0.2.0-beta.102

- Protection antispam : un réessai rapide après une erreur Elementor attend
  la fin de la remise à zéro avant de relancer la vérification ; les réponses
  renseignées sont conservées et le formulaire peut être envoyé à nouveau.
- Un clic pendant la vérification reste en attente puis reprend avec les
  validations natives des champs obligatoires ; aucun clic de réessai perdu.
- Test navigateur isolé de la course entre remise à zéro, focus et soumission.

## 0.2.0-beta.101

- Connecteur générique « Envoyer à une API » pour le Formulaire The Core Atomic
  et le formulaire classique Elementor Pro, indépendant du thème
- Connexions HTTPS centralisées dans WordPress, authentification Bearer facultative,
  secrets absents des contrôles Elementor, administration protégée par droits et nonces
- Mapping JSON versionné et typé, objets/tableaux, constantes et identifiants de
  soumission conservés entre tentatives ; aucune transmission de métadonnées implicites
- Client HTTP borné sans redirection, confirmation sur réponses2xx dont202,
  échec explicite sans exposer le corps distant ; aucune relance automatique
- Intégration opt-in conservant les actions existantes et les protections antispam,
  tests PHP et navigateur isolés ; aucun formulaire public raccordé automatiquement

## 0.2.0-beta.100

- Accessibilite : memorisation du declencheur lors d'une ouverture par ancre,
  y compris avant l'initialisation du JS retarde, et retour du focus a la fermeture
- Repli vers un acces visible et disponible si le declencheur a ete retire,
  masque ou desactive ; conservation du focus lors d'une ouverture deja effective
- Entree du focus dans le panneau apres rendu de sa transition d'apparition,
  sans reprendre le focus si l'utilisateur l'a deja deplace
- Tests des ouvertures anticipees souris/clavier, de la fermeture par Echap
  ou bouton, des ancres open/toggle et des acces de secours

## 0.2.0-beta.99

- Texte anime V4 : zone d'ecriture vide dans le HTML initial et pendant le
  delai avant la premiere lettre, avec emplacement reserve et JS toujours differe
- Ajout du reglage `Afficher le texte sans JavaScript`, active par defaut,
  avec repli noscript independant du mode mobile et du mouvement reduit
- Attente de l'initialisation du controle de pause global sans affichage
  transitoire du texte fixe avant l'ecriture
- Tests du rendu serveur, du JS retarde, du repli active/desactive, de la
  stabilite de mise en page et de l'apercu Elementor/Twing

## 0.2.0-beta.98

- Ajout de `Texte animé (V4)`, widget Atomic autonome d'écriture progressive,
  avec phrases éditables et réglages d'écriture, d'effacement et de pause
- Rendu serveur visible sans JavaScript, typographie et styles V4 natifs,
  emplacement réservé, prise en charge des caractères composés et aperçu éditeur
- Alternative fixe sur mobile et avec réduction des mouvements ; arrêt hors
  écran et dans les onglets masqués ; contrôle de pause local facultatif et
  intégration avec le panneau d'accessibilité existant
- Widget désactivé par défaut, conservant les activations locales existantes
  et les instances `thecore-animated-text` déjà enregistrées
- Fiabilisation de l'initialisation du panneau d'accessibilité avant le DOM,
  synchronisation ARIA des déclencheurs et visibilité des contenus à l'arrêt

## 0.2.0-beta.97

- Ajout de `Counter (V4)`, widget Atomic autonome sans jQuery, jQuery Numerator
  ni dependance aux scripts frontend Elementor ; animation unique au viewport
  avec duree, delai individuel et progression `easeOutQuad`
- Valeurs negatives, decimales et decroissantes, prefixe/suffixe/libelle et
  format numerique configurable ; preservation des valeurs nulles et du
  separateur vide dans les controles et les donnees sauvegardees
- Valeur finale rendue cote serveur, statique sans JavaScript, en edition et
  avec reduction des mouvements ; nom accessible immuable pendant l'animation
- Detection des insertions dynamiques et nettoyage des animations/timers des
  compteurs retires, sans rejeu au scroll ni restauration de l'historique
- Integration optionnelle dans le registre existant, sans reinitialiser les
  reglages ni remplacer automatiquement les anciens compteurs Elementor
- Tests PHP de formats/rendu/compatibilite des reglages, tests JS de lifecycle
  et recette Chromium/Twing sur fixtures WordPress privees ; aucun changement
  des traitements des formulaires ni filtre de rendu des widgets natifs

## 0.2.0-beta.96

- Conservation facultative des demandes V4 dans une archive privee, avec duree
  configurable, statuts des actions, purge horaire et installation versionnee
  activation/admin/WP-CLI ; aucun changement du schema anti-spam existant
- Administration `The Core > Demandes recues`, acces reserve aux administrateurs,
  export et effacement WordPress, y compris des demandes expirees avant la purge
- Reply-To vers un champ Email declare et accuse de reception statique facultatif,
  sans reutiliser l'adresse visiteur comme expediteur ni recopier le message recu
- Journal detaille des rejets V4 active explicitement par formulaire, reutilisant
  la minimisation, les quotas et les outils de confidentialite du journal existant
- Aucune collecte ni action en mode test signe ; erreurs partielles explicites,
  sans nouvel envoi automatique lorsque la notification ou son suivi echoue
- Nouveaux reglages desactives par defaut ; Email/MailPoet et formulaires legacy
  inchanges, sans conversion ni import automatique des donnees historiques
- 411 tests PHP / 1 570 assertions, controles JS et recettes locales privees
  sans aucun mail reel ; documentation de configuration et de deploiement completee

## 0.2.0-beta.95

- Ajout de `Cookie Consent (V4)`, widget Atomic Elementor, avec maintien du
  widget V3 sous le nom `Cookie Consent (Legacy)` ; aucune conversion automatique
- Moteur de consentement, configuration WordPress et presets CSS partages
  entre les deux widgets, avec impression du seul preset selectionne en front
- Styles natifs V4 responsives pour le panneau et controles internes dedies
  au texte, aux categories et aux boutons ; ces controles internes restent globaux
- Apercu Twig/Twing avec categories virtuelles, sans modification de la
  configuration publique ni exposition du code des categories
- Tests PHP et navigateur des quatre presets, du JS differe, du consentement,
  des styles du panneau et de l'affichage mobile ; parcours complet
  d'edition/enregistrement Elementor encore a valider manuellement

## 0.2.0-beta.94

- Compatibilite du formulaire V4 avec les labels natifs `escaped-html`
  d'Elementor 4.3, sans retirer le support du format `html-v3` precedent
- Declaration de la balise `form` via la nouvelle API Elementor et adaptation
  des textes par defaut au schema natif disponible, avec repli sur les anciennes versions
- Tests de non-regression des labels et des correspondances MailPoet ;
  les regles de securite et les traitements Email/MailPoet restent inchanges

## 0.2.0-beta.93

- Separation des actions du formulaire V4 : Email, Ajout MailPoet ou les deux,
  avec conservation de l'action Email pour les formulaires existants
- Selection des listes MailPoet actives et correspondance des champs email,
  prenom, nom et consentement optionnel dans les controles Elementor
- Respect de la confirmation MailPoet, gestion des doublons et refus de
  reactiver automatiquement les abonnes desabonnes, inactifs ou en corbeille
- Mode test signe sans creation d'abonne ni email, avec indication des actions
  validees et ignorees ; un refus de newsletter ne bloque pas l'email de contact
- Tests PHP et parcours Chromium Email/MailPoet avec API newsletter simulee ;
  validation sur une installation MailPoet reelle encore necessaire

## 0.2.0-beta.92

- Ajout du conteneur atomic `Formulaire The Core` avec les champs natifs
  Elementor Pro et un traitement JS/PHP independant des formulaires Elementor
- Validation serveur, gestion accessible des erreurs, ALTCHA auto-heberge,
  quotas, protection anti-rejeu et deduplication obligatoires
- Ajout d'un mode test signe par formulaire, sans envoi d'email ni contournement
  de l'anti-spam, avec contrat d'integration pour Webinart Customer Agent
- Ajout de tests PHP et d'un scenario Chromium couvrant le rendu V4, ALTCHA,
  les tests signes et les soumissions, sans envoyer d'email reel

## 0.2.0-beta.91

- Ajout de controles Elementor natifs et responsives au widget `Cookie Consent`
  pour la typographie et les espacements de sa racine et de son panneau
- Ajout du rayon des cartes de categorie et d'un pilotage responsive de la
  direction, de la largeur et du comportement flex des boutons
- Le bouton principal peut definir sa largeur et son comportement flex
  independamment des autres actions

## 0.2.0-beta.90

- Ajout de controles responsives au bouton du widget `Search Modal (Legacy)`
  pour sa pleine largeur, sa hauteur minimale et son espacement interieur
- Ajout d'un controle permettant de conserver le libelle du bouton de recherche
  sur mobile

## 0.2.0-beta.87

- Consolidation du widget Atomic `Marquee Carousel` sans dépendance externe : démarrage après chargement ou échec réel des images, distance de boucle exacte et recalcul au redimensionnement
- Images responsives avec dimensions intrinsèques, `srcset` et `sizes` quand un média WordPress est disponible, tout en conservant le fallback par URL
- Ajout d’un contrôle pause/lecture accessible, de la pause au survol/focus, hors viewport et lorsque la page est masquée, avec respect de `prefers-reduced-motion`
- Amélioration du contrôle d’items V4 avec réordonnancement au clavier et duplication
- Alignement du rendu PHP et de la prévisualisation Twig pour les liens, les clones masqués et les contrôles du marquee

## 0.2.0-beta.86

- Ajout d’un journal temporaire pour certains motifs de blocage de `Elementor
  Form Security`, avec résumé Nom/E-mail/Message, vue détaillée et suppression
  dans l’administration
- Minimisation du journal : exclusion des IP, User-Agent, honeypots, preuves
  ALTCHA, champs cachés, mots de passe et pièces jointes ; expiration après 30
  jours par défaut puis suppression par lots via WP-Cron
- Ajout des exporteurs et effaceurs WordPress de données personnelles avec
  recherche par HMAC d’e-mail à clé persistante, ainsi que d’une quatrième
  table InnoDB installée par la migration Form Security v2
- Journal limité aux motifs de rejet utiles à la qualification, à 200 entrées
  par jour et 16 Kio de champs par entrée par défaut, sans aucun envoi d’e-mail
- Séparation du journal secondaire et des trois tables opérationnelles afin
  qu’une migration v2 échouée ne coupe pas le moteur anti-spam v1 déjà installé
- Erreurs de stockage rendues explicites dans l’administration et les outils de
  confidentialité, avec purge de la seule table de données personnelles lors
  d’une désactivation ou d’une désinstallation volontaire du plugin
- Priorité donnée au nom, au premier e-mail valide et au message lorsque le
  payload borné doit être tronqué ; index RGPD calculé avant cette troncature

## 0.2.0-beta.84

- Correction de l'erreur fatale de l'éditeur Elementor provoquée par les
  bornes décimales du contrôle de ratio du widget Atomic `Icon Text`
- Ajout d'un contrôle serveur compatible avec les décimales qui conserve le
  composant numérique natif d'Elementor et le pas de réglage `0,05`
- Déclaration explicite du ratio comme nombre flottant dans le schéma Atomic
  afin de préserver les valeurs telles que `1,5`

## 0.2.0-beta.83

- Correction du blocage de l'éditeur Elementor provoqué par le bundle ESM
  d'ALTCHA lorsqu'il était chargé par WordPress comme script classique
- Isolation du runtime ALTCHA dans une portée stricte, avec nouvelle URL
  d'asset pour invalider les caches sans modifier l'ordre ALTCHA, PBKDF2 puis
  contrôleur du formulaire
- Ajout d'un test JavaScript empêchant toute nouvelle collision avec la
  variable globale `_` utilisée par Underscore et Backbone dans WordPress

## 0.2.0-beta.82

- Ajout de la feature opt-in `Elementor Form Security` pour les Forms legacy
  Elementor Pro, avec champ réutilisable sur n’importe quel formulaire
- Intégration locale d’ALTCHA 3.2.1 et du sous-ensemble PHP PBKDF2/SHA-256
  compatible 2.1.0, sans dépendance Composer en production ni appel externe
- Ajout des protections serveur atomiques : quotas distincts, preuve à usage
  unique, déduplication et nettoyage horaire dans trois tables InnoDB
- Minimisation des nouvelles données des formulaires protégés : retrait de
  l’adresse IP et du User-Agent, suppression des paramètres de tracking de
  l’URL source et exclusion des champs techniques des actions Elementor
- Ajout du garde d’échec fermé, du schéma auto-installé/versionné, des commandes
  WP-CLI de diagnostic et des tests unitaires du moteur de sécurité
- Durcissement du paquet de distribution pour conserver les assets ALTCHA
  runtime tout en excluant le `vendor/` Composer racine, avec contrôle
  d’intégrité avant création du ZIP
- Validation anti-spam déplacée après les validateurs Elementor, champ
  technique exclu du contrôle `Required`, plafond global désactivé pour rester
  compatible avec les formulaires d’upload et URL du worker injectée
  explicitement pour résister à la concaténation des assets
- Compatibilité des champs téléphone protégés avec les espaces et `/`, tout en
  conservant le jeu de caractères autorisé par le validateur Elementor

## 0.2.0-beta.80

- Correction du widget `Cookie Consent` pour préserver les backgrounds gradients Elementor du panneau et limiter le contrôle d’overlay aux presets avec backdrop

## 0.2.0-beta.79

- Correction du widget Atomic `Icon Text` pour dimensionner le conteneur d’icône indépendamment du pictogramme, avec ratio largeur/hauteur configurable et carré `1:1` par défaut

## 0.2.0-beta.78

- Ajout du widget Atomic `Icon Text`, avec icône décorative accessible, texte éditable, contrôles de position/alignement et styles inline pour l’icône et la typographie

## 0.2.0-beta.77

- Ajout d’un garde critique `Cookie Consent` pour éviter le flash de bannière sur pages cachées quand le consentement existe déjà et que le JavaScript principal est différé

## 0.2.0-beta.76

- Désactivation complète des modules `Cookie Consent` et `TChat` quand leurs widgets sont coupés dans l’admin, avec arrêt de leurs hooks front/admin et blocage du `TChat Trigger` si le module `TChat` est désactivé

## 0.2.0-beta.75

- Ajout du widget Atomic `Breadcrumb`, avec génération dynamique du fil d’ariane WordPress, rendu accessible `nav > ol > li`, item courant annoncé via `aria-current`, et contrôles de style/labels dans Elementor

## 0.2.0-beta.74

- Correction du module `TChat` pour préserver les caractères littéraux comme `<` dans les messages visiteurs et agents, sans les altérer à l’enregistrement

## 0.2.0-beta.73

- Ajout d’un filtre `Ouvertes / Archivées / Toutes` dans l’admin `TChat`, avec affichage des conversations archivées et action de restauration depuis le tableau des conversations

## 0.2.0-beta.72

- Ajout du sous-menu `Tools` dans l’admin `TChat`, avec un premier outil de suppression totale des conversations protégé par une double confirmation côté UI et une validation serveur stricte (`SUPPRIMER` + case à cocher)

## 0.2.0-beta.71

- Correction du module `TChat` pour ne plus créer de conversation à la simple visite de page : la conversation n’est désormais créée qu’au premier message visiteur, avec reprise éventuelle d’une conversation déjà ouverte lors de l’ouverture du chat

## 0.2.0-beta.70

- Ajout du widget Atomic `Text List`, réécrit proprement depuis le legacy avec sémantique verrouillée (`unordered`, `ordered`, `plain`), saisie des items ligne par ligne, styles inline et intégration complète au registre/admin V4

## 0.2.0-beta.69

- Allègement du module `Accessibility (Legacy)` avec suppression de larges blocs CSS morts, mutualisation des définitions de features entre l’UI Elementor et la normalisation des settings, et activation des écouteurs du `reading mask` uniquement quand la feature est active

## 0.2.0-beta.68

- Nettoyage du widget `Cookie Consent` après correction du moteur d’animations côté thème : suppression des contournements CSS/JS temporaires dans le plugin et conservation d’un simple marqueur `data-thecore-anim-viewport-proxy="1"` sur le module pour laisser le thème décider correctement du `force-load`

## 0.2.0-beta.67

- Correction complémentaire du rendu initial du widget `Cookie Consent` sur les sites utilisant le white labelling The Core : la garde CSS inline cible désormais uniquement le `data-id` du widget pour éviter la réécriture du sélecteur `cookie-consent` et permettre l’affichage de la bannière avant l’injection du JS

## 0.2.0-beta.66

- Correction du rendu initial du widget `Cookie Consent` pour que la bannière puisse être visible sans attendre le JS delayed quand aucun consentement n’est encore posé, tout en restant masquée dès le rendu PHP si le cookie de consentement existe déjà

## 0.2.0-beta.65

- Correction du widget `Cookie Consent` lorsqu’une animation d’entrée Elementor est combinée avec l’override d’animation The Core et l’option `Force animation on load` : le wrapper du widget est désormais activé explicitement pour éviter qu’il reste bloqué en état `pending` et masque la bannière

## 0.2.0-beta.64

- Refactor CSS du module `Cookie Consent` pour réduire les surcharges sur `.thecore-cc` et `.thecore-cc__container`
- Passage du socle CSS manuscrit en mobile-first pour le banner cookies, avec presets recentrés sur des variables de layout et meilleure compatibilité avec les styles générés par Elementor

## 0.2.0-beta.63

- Correction du preset `Default` de `Cookie Consent` : suppression du `display:block` inline qui empêchait l’état caché `thecore-cc--hidden` de fermer visuellement la bannière

## 0.2.0-beta.62

- Alignement du runtime `Cookie Consent` sur le plugin d’origine pour la détection de consentement : la présence brute du cookie masque désormais la bannière, même si sa valeur ne peut pas être parsée en JSON

## 0.2.0-beta.61

- Suppression de `aria-hidden` sur le module `Cookie Consent` et nettoyage du focus avant fermeture, pour éliminer l’avertissement d’accessibilité sur les boutons de consentement

## 0.2.0-beta.60

- Inlining complet des layouts de presets `Cookie Consent` dans le widget Elementor, avec suppression des fichiers `cookie-consent-theme-*.css`
- Suppression de la dépendance front aux fichiers de preset, pour que tous les modèles `Default`, `Labs`, `Sidecar` et `Lowkey` s’impriment correctement en front

## 0.2.0-beta.59

- Nettoyage des styles natifs `Cookie Consent` pour ne conserver dans les fichiers CSS que le structurel, avec injection des valeurs de skin par le widget Elementor

## 0.2.0-beta.58

- Ajout de contrôles d’alignement Elementor pour le widget `Cookie Consent` : texte de notice, contenu des catégories, ligne inline des catégories et boutons

## 0.2.0-beta.57

- Renommage du runtime front `Cookie Consent` de `cookie-consent` vers `cc` dans le HTML, le CSS et le JS, pour éviter la réécriture de classes du module de whitelabelling du thème

## 0.2.0-beta.56

- Chargement de tous les presets `Cookie Consent` dans l’éditeur Elementor pour que le changement de modèle ait un effet visuel immédiat en preview, tout en gardant un chargement ciblé `base + preset` sur le front

## 0.2.0-beta.55

- Séparation propre du module `Cookie Consent` : la config fonctionnelle reste dans `Cookies > Config`, tandis que le widget Elementor ne garde plus que le preset visuel et des aides de preview
- Découpage du CSS `Cookie Consent` en un socle commun et un fichier par preset, pour ne charger en front que le modèle visuel réellement utilisé

## 0.2.0-beta.54

- Rapprochement du preset `Default` de `Cookie Consent` avec le plugin d’origine : vraie bannière sticky en pied de page, rendu plus simple et catégories inline par défaut

## 0.2.0-beta.53

- Correction du preset par défaut du module `Cookie Consent` pour retrouver le style horizontal sticky d’origine au lieu de `Sidecar`

## 0.2.0-beta.52

- Unification de la source de vérité du module `Cookie Consent` autour des réglages du widget Elementor, pour que le preset et le fonctionnel du front suivent bien le widget affiché

## 0.2.0-beta.51

- Restauration de l’admin cookies historique côté fonctionnel avec les onglets `General Settings`, `Essential Cookies`, `Functional Cookies`, `Marketing Cookies`, `Consent Settings` et `Consent Statistics`, tout en laissant le design au widget Elementor
- Correction du save par onglet pour préserver les réglages non soumis des autres sections

## 0.2.0-beta.50

- Restauration d’une admin globale `Cookies` avec `Config` et `Cookie Consents`, sans onglet design, le design restant piloté par le widget Elementor

## 0.2.0-beta.49

- Portage complet du module `Cookie Consent` du thème en widget Elementor, avec logging des consentements, shortcode de revoke, statut, blocage des embeds et injection conditionnelle de code par catégorie

## 0.2.0-beta.48

- Correction du garde CSS critique des modales `Accessibility Module` et `TChat Module` pour ne plus bloquer leur ouverture après chargement du CSS principal

## 0.2.0-beta.47

- Ajout d’un CSS critique minimal injecté une seule fois pour garder les modales `Accessibility Module` et `TChat Module` masquées avant chargement du CSS complet

## 0.2.0-beta.46

- Ajout de réglages de couleurs normales et hover pour le bouton d’envoi du widget `TChat Module`

## 0.2.0-beta.45

- Ajout de champs éditables pour renommer les libellés des boutons `Close` et `Restore defaults` du widget `Accessibility Module`

## 0.2.0-beta.44

- Ajout de champs éditables pour renommer les titres des trois sections du widget `Accessibility Module`

## 0.2.0-beta.43

- Ajout d’un champ de label custom sous chaque feature du widget `Accessibility Module`, pour renommer librement les cards activées

## 0.2.0-beta.42

- Renforcement supplémentaire du suivi du `reading mask` avec écoute redondante sur `window`, `document`, le backdrop et le panel du module d’accessibilité

## 0.2.0-beta.41

- Renforcement du suivi du `reading mask` du module d’accessibilité avec écoute `window` en `mousemove`, `pointermove` et `touchmove`

## 0.2.0-beta.40

- Correction du `reading mask` du module d’accessibilité, qui restait actif mais se retrouvait visuellement masqué par le nouveau backdrop de fermeture

## 0.2.0-beta.39

- Alignement du comportement du module d’accessibilité sur le TChat : trigger en vrai toggle et fermeture via backdrop cliquable
- Suppression de la fermeture globale au clic document au profit d’un flux d’interaction plus simple et plus robuste

## 0.2.0-beta.38

- Correction de l’ouverture du module d’accessibilité en frontend via des binds directs sur les triggers externes
- Nettoyage de la logique de clic global du runtime accessibilité pour limiter son rôle à la fermeture au clic extérieur

## 0.2.0-beta.37

- Simplification du runtime du module d’accessibilité pour mieux cibler l’instance active après rerender Elementor
- Suppression du rendu preview spécial du `TChat Module`, tout en gardant la désactivation du bootstrap réseau/polling dans l’éditeur
- Ajout d’un vrai bouton d’envoi mobile dans le TChat

## 0.2.0-beta.36

- Renforcement du runtime du module d’accessibilité pour recacher/rebinder correctement le DOM après rerender Elementor
- Réactivation plus fiable des ouvertures/fermetures du panneau accessibilité sur le front et dans l’éditeur

## 0.2.0-beta.35

- Allègement du mode preview Elementor du `TChat Module` pour éviter de casser le canvas avec une vraie modale fullscreen
- Désactivation du bootstrap réseau/polling TChat dans le preview Elementor, tout en gardant une vue stylable de la modale

## 0.2.0-beta.34

- Correction du comportement des modales `Accessibility` et `TChat` dans l’éditeur Elementor après rerender du canvas
- Rebinding correct du toolbar accessibilité pour réactiver fermeture et interactions après refresh preview
- Runtime TChat rendu résilient aux remounts du DOM, avec module forcé ouvert en mode édition/preview

## 0.2.0-beta.33

- Correction des URLs REST du runtime TChat côté frontend pour supprimer les espaces parasites sur `conversations` et `persist`
- Nettoyage de quelques chaînes cassées du runtime TChat : cookie visiteur, fallback UUID et classe CSS des messages

## 0.2.0-beta.32

- Refactor du TChat en deux widgets Elementor : `TChat Module` et `TChat Trigger`
- Ajout d’un trigger TChat séparé avec la même surface de contrôle que le trigger du panneau d’accessibilité
- Ajout de vrais réglages de style pour la modale TChat : panel, header, messages et input
- Refonte du runtime/frontend TChat pour piloter une structure HTML rendue côté PHP au lieu d’injecter toute la modale en JS

## 0.2.0-beta.31

- Ajout d’un widget Elementor `TChat` minimal qui monte le module frontend existant sans dupliquer la logique métier
- Réutilisation du même mount que le shortcode `[tchat]` pour le widget Elementor
- Enregistrement propre des handles CSS/JS TChat pour qu’ils puissent être déclarés comme dépendances du widget

## 0.2.0-beta.30

- Intégration du module `TChat` directement dans `thecore-elementor-widgets`, avec transport configurable `polling`, `sse` ou `auto`
- Ajout de l’admin `TChat`, du shortcode `[tchat]` et du relay SSE optionnel côté WordPress
- Renommage du menu admin principal en `The Core - Widgets`
- Correction du `Overlay Scroll Lock` pour compenser la largeur de scrollbar et éviter le layout shift à l’ouverture du menu

## 0.2.0-beta.29

- Correction de l’alignement horizontal du `Accessibility Module (Legacy)` pour que le mode gauche/droite positionne réellement le panneau
- `Title` et `Subtitle` du module d’accessibilité peuvent maintenant être laissés vides, sans fallback forcé au rendu

## 0.2.0-beta.28

- Ajout des widgets legacy `Accessibility Module` et `Accessibility Trigger` issus de The Core Accessibility
- Pilotage des fonctions d’accessibilité et du skip link directement depuis les contrôles Elementor du module
- Retrait de l’option `Sitemap` du module d’accessibilité
- Ajout d’un mode `Hide skip link visually` pour rendre le skip link invisible avec une taille `0 x 0`
- Correction d’un freeze dans l’éditeur Elementor causé par le runtime de montage du skip link et du reading mask

## 0.2.0-beta.27

- Bump de version après revert du correctif d'opacité de l'overlay sur `Fullscreen Menu`

## 0.2.0-beta.25

- Suppression du texte visible à côté du burger sur `Header Menu (Legacy)`
- Retrait du contrôle Elementor et du setting associés au label mobile du toggle

## 0.2.0-beta.24

- Correction du `Header Menu (Legacy)` : la media query inline du breakpoint mobile est maintenant rendue correctement, ce qui permet enfin le passage en mode burger

## 0.2.0-beta.23

- Import des widgets legacy `Header Menu` et `Search Modal` depuis Bellevue avec renommage The Core
- Ajout du handler AJAX de recherche et des tests de normalisation associés
- Correction du `Header Menu (Legacy)` pour que le layout mobile soit rendu nativement via CSS/media queries, sans dépendre du JS pour le premier affichage

## 0.2.0-beta.22

- Fusion des correctifs de chargement d'assets sur la base beta.21
- Chargement normalise des CSS et JS des widgets via leurs dependances WordPress standards
- Retrait du reliquat `inline_asset_injection` sur `Fullscreen Menu`

## 0.2.0-beta.21

- Suppression complete du systeme de delaying embarque dans le plugin
- Retrait des reglages admin et des controles widget associes
- Retour a un chargement normal des assets, pour laisser cette responsabilite au theme

## 0.2.0-beta.20

- Desactivation simple et centrale du systeme embarque de delaying des assets du plugin, pour laisser un chargement immediat des widgets

## 0.2.0-beta.19

- Renforcement de la robustesse visuelle du `Marquee Banner (Legacy)` sur mobile et vieux navigateurs
- Suppression du double lazy loading et démarrage de l'animation après chargement et mesure réels des images
- Calcul de la distance de défilement en pixels avec recalcul au chargement, resize et changement d'orientation

## 0.2.0-beta.18

- Ajout du widget Elementor classique `Marquee Banner (Legacy)` en parallele du widget V4
- Ajout du support du delaying CSS et JS global/widget sur ce marquee legacy
- Separation claire entre l'enregistrement des widgets classiques Elementor et des widgets Atomic

## 0.2.0-beta.17

- Correction du chargement CSS et JS des widgets dans le preview Elementor en traitant correctement les contextes `editor` et `preview`
- Enregistrement des handles d'assets aussi sur les hooks d'editor Elementor pour fiabiliser le rendu du canvas

## 0.2.0-beta.16

- Ajout d'un vrai switch widget `Enable delaying` separe pour le CSS et le JS
- Possibilite de desactiver explicitement le delaying au niveau d'un widget sans toucher aux triggers

## 0.2.0-beta.15

- Ajout du trigger `Fallback only` dans le socle de delaying CSS/JS global et widget
- Forcage automatique du fallback quand ce trigger est selectionne

## 0.2.0-beta.14

- Ajout d'un socle unifie de delaying CSS et JS pour les widgets, avec resolution globale vs widget
- Ajout d'une section globale `Asset Delivery` dans la page `Features`
- Ajout de reglages `CSS Delivery` et `JS Delivery` dans `Fullscreen Menu` et `Marquee Carousel`
- Delivery frontend unifie avec triggers `viewport` ou `interaction`, fallback temporise, et runtime commun

## 0.2.0-beta.13

- Revert du montage externe de l'overlay du `Fullscreen Menu` pour revenir a un rendu entierement contenu dans le header/widget
- Suppression du reglages `Overlay mount target` et du toggle porte associe

## 0.2.0-beta.12

- Ajout d'un toggle de fermeture porté au-dessus de l'overlay du `Fullscreen Menu`
- Correction du cas où le bouton d'ouverture passait sous l'overlay et ne permettait plus de refermer le menu
- Synchronisation de l'état visuel du toggle entre le bouton source et le bouton porté

## 0.2.0-beta.11

- Ajout d'un réglage `Overlay mount target` dans le `Fullscreen Menu`
- Support des cibles `Closest header`, `Body` et `Custom selector` pour choisir où monter l'overlay
- Propagation du sélecteur custom jusqu'au runtime frontend avec fallback silencieux sur `body`

## 0.2.0-beta.10

- Déplacement de l'overlay du `Fullscreen Menu` hors du container du widget pour éviter qu'un ancêtre transformé ne bloque son `position: fixed`
- Montage automatique de l'overlay sous le `header` ancêtre le plus proche, ou sous `body` à défaut
- Synchronisation des variables CSS du widget vers l'overlay déplacé afin de conserver les styles configurés

## 0.2.0-beta.9

- Décision du mode responsive du `Fullscreen Menu` côté serveur pour éviter le basculement de layout au premier paint
- Suppression du pilotage du layout initial par JS afin de réduire le risque de CLS, notamment en `overlay only`
- Ajout d'un switch `Inline asset injection` dans le widget pour choisir entre assets inline et fichiers externes côté frontoffice
- Alignement du preview Elementor et du rendu frontend sur les nouvelles règles de layout du menu

## 0.2.0-beta.8

- Restauration de la cible `base` du `Fullscreen Menu` pour réactiver les réglages de spacing du wrapper dans l’onglet `Style`
- Réintégration des classes Atomic du widget dans le rendu preview/front pour que les styles V4 appliqués au wrapper aient de nouveau un effet

## 0.2.0-beta.7

- Stabilisation des contrôles custom du `Fullscreen Menu` dans l’éditeur Atomic V4
- Correction de la validation des champs `letter spacing` au save
- Ajout de vrais contrôles `font-family` avec presets et valeur custom conditionnelle
- Ajout d’un sanitiseur de document Elementor pour fiabiliser les payloads du widget

## 0.2.0-beta.6

- Correction de l'application des styles de typo du `Fullscreen Menu`
- Ajout de styles de typo distincts pour les liens desktop et les liens d'overlay
- Ajout du mode `Overlay only` pour conserver le hamburger sur tous les écrans

## 0.2.0-beta.5

- Suppression de la dépendance frontend du `Fullscreen Menu` au runtime Atomic d'Elementor

## 0.2.0-beta.4

- Correction du chargement trop tôt du domaine de traduction pour éviter le notice `_load_textdomain_just_in_time`

## 0.2.0-beta.3

- Intégration du wrapper `Fullscreen Menu` en `display: flex`
- Bump de version pour publication du canal beta

## 0.2.0-beta.2

- Bump de version pour test end-to-end de la pipeline d’update GitHub

## 0.2.0-beta.1

- Ajout du `PluginUpdater` GitHub avec manifest public `beta` / `prod`
- Ajout de la workflow GitHub de publication vers `webinart/thecore-elementor-widgets-updates`
- Remplacement du widget `Classic Menu` par le port V4 du widget legacy `Fullscreen Menu`
- Nettoyage de l’ancienne implémentation multi-niveaux et de ses assets hamburger dédiés
- Ajout d’une normalisation testée des réglages d’affichage du `Fullscreen Menu`

## 0.1.0

- Initialisation du plugin `The Core - Elementor Widgets`
- Mise en place de l’admin `The Core` avec pages `Widgets` et `Features`
- Ajout du socle Atomic pour `Classic Menu`
- Mise en place de l’outillage local Composer, PHPUnit et PHPCS
- Ajout du choix d’effet d’animation du hamburger
- Ajout du breakpoint mobile configurable par widget
- Chargement conditionnel des styles d’effet du hamburger par page
