<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\CookieConsent;

use WP_Query;

final class AdminPage
{
    private const MENU_SLUG = 'thecore-cookies';
    private const CONSENTS_SUBMENU_SLUG = 'edit.php?post_type=' . Logger::POST_TYPE;
    private const SAVE_ACTION = 'thecore_cookie_consent_save_config';

    /**
     * @var array<string, string>
     */
    private const TABS = [
        'general_settings' => 'General Settings',
        'category_essential' => 'Essential Cookies',
        'category_functional' => 'Functional Cookies',
        'category_marketing' => 'Marketing Cookies',
        'consent_settings' => 'Consent Settings',
        'consent_statistics' => 'Consent Statistics',
    ];

    public function __construct(
        private readonly ConfigRepository $configRepository
    ) {
    }

    public function registerHooks(): void
    {
        add_action('admin_menu', [$this, 'registerMenu']);
        add_action('admin_post_' . self::SAVE_ACTION, [$this, 'handleSave']);
        add_filter('parent_file', [$this, 'filterParentFile']);
        add_filter('submenu_file', [$this, 'filterSubmenuFile']);
    }

    public function registerMenu(): void
    {
        add_menu_page(
            __('Cookies', 'thecore-elementor-widgets'),
            __('Cookies', 'thecore-elementor-widgets'),
            'manage_options',
            self::MENU_SLUG,
            [$this, 'renderConfigPage'],
            'dashicons-shield-alt',
            59
        );

        add_submenu_page(
            self::MENU_SLUG,
            __('Config', 'thecore-elementor-widgets'),
            __('Config', 'thecore-elementor-widgets'),
            'manage_options',
            self::MENU_SLUG,
            [$this, 'renderConfigPage']
        );

        add_submenu_page(
            self::MENU_SLUG,
            __('Cookie Consents', 'thecore-elementor-widgets'),
            __('Cookie Consents', 'thecore-elementor-widgets'),
            'manage_options',
            self::CONSENTS_SUBMENU_SLUG
        );
    }

    public function renderConfigPage(): void
    {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('You are not allowed to access this page.', 'thecore-elementor-widgets'));
        }

        $config = $this->configRepository->active();
        $activeTab = $this->activeTab();
        ?>
        <div class="wrap thecore-admin">
            <h1><?php echo esc_html__('Cookies', 'thecore-elementor-widgets'); ?></h1>
            <p class="thecore-admin__intro">
                <?php esc_html_e('This admin keeps the original functional tabs of the cookie module. Design settings are no longer managed here and stay in the Elementor widget.', 'thecore-elementor-widgets'); ?>
            </p>
            <?php $this->renderTabs($activeTab, ! empty($config['log_consents'])); ?>
            <?php $this->renderUpdatedNotice(); ?>

            <?php if ('consent_statistics' === $activeTab) : ?>
                <?php $this->renderConsentStatistics($config); ?>
            <?php else : ?>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="thecore-admin__form">
                    <input type="hidden" name="action" value="<?php echo esc_attr(self::SAVE_ACTION); ?>">
                    <input type="hidden" name="tab" value="<?php echo esc_attr($activeTab); ?>">
                    <?php wp_nonce_field(self::SAVE_ACTION); ?>

                    <div class="thecore-admin__cards">
                        <?php
                        switch ($activeTab) {
                            case 'category_essential':
                            case 'category_functional':
                            case 'category_marketing':
                                $this->renderCategoryTab($config, $activeTab);
                                break;
                            case 'consent_settings':
                                $this->renderConsentSettingsTab($config);
                                break;
                            case 'general_settings':
                            default:
                                $this->renderGeneralSettingsTab($config);
                                break;
                        }
                        ?>
                    </div>

                    <p class="submit">
                        <button type="submit" class="button button-primary">
                            <?php esc_html_e('Save changes', 'thecore-elementor-widgets'); ?>
                        </button>
                    </p>
                </form>
            <?php endif; ?>
        </div>
        <?php
    }

    public function handleSave(): void
    {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('You are not allowed to perform this action.', 'thecore-elementor-widgets'));
        }

        check_admin_referer(self::SAVE_ACTION);

        $tab = $this->sanitizeTab($_POST['tab'] ?? '');
        $submitted = isset($_POST['cookie_consent']) && is_array($_POST['cookie_consent'])
            ? wp_unslash($_POST['cookie_consent'])
            : [];

        $current = $this->flattenConfig($this->configRepository->active());
        $merged = array_merge($current, is_array($submitted) ? $submitted : []);
        $normalized = (new \TheCore\ElementorWidgets\Elementor\Legacy\Widgets\CookieConsent\DisplaySettings())->normalize($merged);

        $normalized['theme_preset'] = is_string($this->configRepository->active()['theme_preset'] ?? null)
            ? (string) $this->configRepository->active()['theme_preset']
            : CookieConsentModule::DEFAULT_THEME_PRESET;
        $normalized['privacy_policy_external'] = ! empty($this->configRepository->active()['privacy_policy_external']);

        $this->configRepository->saveOverride($normalized);

        wp_safe_redirect(
            add_query_arg(
                [
                    'page' => self::MENU_SLUG,
                    'tab' => $tab,
                    'updated' => '1',
                ],
                admin_url('admin.php')
            )
        );
        exit;
    }

    public function filterParentFile(string $parentFile): string
    {
        if ($this->isCookieConsentScreen()) {
            return self::MENU_SLUG;
        }

        return $parentFile;
    }

    public function filterSubmenuFile(?string $submenuFile): ?string
    {
        if ($this->isCookieConsentScreen()) {
            return self::CONSENTS_SUBMENU_SLUG;
        }

        return $submenuFile;
    }

    /**
     * @param array<string, mixed> $config
     */
    private function renderGeneralSettingsTab(array $config): void
    {
        ?>
        <section class="thecore-admin__card">
            <div class="thecore-admin__card-content">
                <h2><?php echo esc_html__('General Settings', 'thecore-elementor-widgets'); ?></h2>
                <p><?php esc_html_e('Notice text, button labels and general embed behavior of the cookie module.', 'thecore-elementor-widgets'); ?></p>
            </div>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><label for="cookie_consent_notice_text"><?php esc_html_e('Notice Text', 'thecore-elementor-widgets'); ?></label></th>
                    <td><textarea class="large-text" rows="5" id="cookie_consent_notice_text" name="cookie_consent[notice_text]"><?php echo esc_textarea((string) ($config['notice_text'] ?? '')); ?></textarea></td>
                </tr>
                <tr>
                    <th scope="row"><label for="cookie_consent_accept_button_label"><?php esc_html_e('Accept Button Text', 'thecore-elementor-widgets'); ?></label></th>
                    <td><input class="regular-text" id="cookie_consent_accept_button_label" name="cookie_consent[accept_button_label]" type="text" value="<?php echo esc_attr((string) (($config['buttons']['accept'] ?? ''))); ?>"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="cookie_consent_confirm_choice_button_label"><?php esc_html_e('Confirm Choice Button Text', 'thecore-elementor-widgets'); ?></label></th>
                    <td><input class="regular-text" id="cookie_consent_confirm_choice_button_label" name="cookie_consent[confirm_choice_button_label]" type="text" value="<?php echo esc_attr((string) (($config['buttons']['confirm'] ?? ''))); ?>"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="cookie_consent_reject_button_label"><?php esc_html_e('Reject Button Text', 'thecore-elementor-widgets'); ?></label></th>
                    <td><input class="regular-text" id="cookie_consent_reject_button_label" name="cookie_consent[reject_button_label]" type="text" value="<?php echo esc_attr((string) (($config['buttons']['reject'] ?? ''))); ?>"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="cookie_consent_privacy_policy_button_label"><?php esc_html_e('Privacy Policy Button Text', 'thecore-elementor-widgets'); ?></label></th>
                    <td><input class="regular-text" id="cookie_consent_privacy_policy_button_label" name="cookie_consent[privacy_policy_button_label]" type="text" value="<?php echo esc_attr((string) (($config['buttons']['privacy'] ?? ''))); ?>"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="cookie_consent_revoke_consent_button_label"><?php esc_html_e('Revoke Consent Button Text', 'thecore-elementor-widgets'); ?></label></th>
                    <td><input class="regular-text" id="cookie_consent_revoke_consent_button_label" name="cookie_consent[revoke_consent_button_label]" type="text" value="<?php echo esc_attr((string) ($config['revoke_consent_button_label'] ?? '')); ?>"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="cookie_consent_privacy_policy_url"><?php esc_html_e('Privacy Policy URL', 'thecore-elementor-widgets'); ?></label></th>
                    <td><input class="regular-text" id="cookie_consent_privacy_policy_url" name="cookie_consent[privacy_policy_url]" type="url" value="<?php echo esc_attr((string) ($config['privacy_policy_url'] ?? '')); ?>"></td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e('Reload Page', 'thecore-elementor-widgets'); ?></th>
                    <td><?php $this->renderCheckbox('cookie_consent[reload_on_set]', ! empty($config['reload_on_set']), __('Reload page after cookie choice has been saved', 'thecore-elementor-widgets')); ?></td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e('Block embeds', 'thecore-elementor-widgets'); ?></th>
                    <td><?php $this->renderCheckbox('cookie_consent[block_embeds]', ! empty($config['block_embeds']), __('Block embedded external content until consent is given via Functional Cookies', 'thecore-elementor-widgets')); ?></td>
                </tr>
            </table>
        </section>
        <?php
    }

    /**
     * @param array<string, mixed> $config
     */
    private function renderCategoryTab(array $config, string $tab): void
    {
        $category = $this->findCategoryConfig($config, $tab);

        if ($category === null) {
            return;
        }

        ?>
        <section class="thecore-admin__card">
            <div class="thecore-admin__card-content">
                <h2><?php echo esc_html((string) ($category['label'] ?? $tab)); ?></h2>
                <p><?php echo esc_html((string) ($category['description'] ?? '')); ?></p>
            </div>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><?php esc_html_e('Status', 'thecore-elementor-widgets'); ?></th>
                    <td><?php $this->renderCheckbox('cookie_consent[' . $tab . '_active]', ! empty($category['active']), __('Activate this cookie category and output its code if accepted', 'thecore-elementor-widgets')); ?></td>
                </tr>
                <tr>
                    <th scope="row"><label for="<?php echo esc_attr($tab . '_label'); ?>"><?php esc_html_e('Label', 'thecore-elementor-widgets'); ?></label></th>
                    <td><input class="regular-text" id="<?php echo esc_attr($tab . '_label'); ?>" name="<?php echo esc_attr('cookie_consent[' . $tab . '_label]'); ?>" type="text" value="<?php echo esc_attr((string) ($category['label'] ?? '')); ?>"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="<?php echo esc_attr($tab . '_description'); ?>"><?php esc_html_e('Description', 'thecore-elementor-widgets'); ?></label></th>
                    <td><textarea class="large-text" rows="4" id="<?php echo esc_attr($tab . '_description'); ?>" name="<?php echo esc_attr('cookie_consent[' . $tab . '_description]'); ?>"><?php echo esc_textarea((string) ($category['description'] ?? '')); ?></textarea></td>
                </tr>
                <tr>
                    <th scope="row"><label for="<?php echo esc_attr($tab . '_code'); ?>"><?php esc_html_e('Code', 'thecore-elementor-widgets'); ?></label></th>
                    <td>
                        <textarea class="large-text code" rows="10" id="<?php echo esc_attr($tab . '_code'); ?>" name="<?php echo esc_attr('cookie_consent[' . $tab . '_code]'); ?>"><?php echo esc_textarea((string) ($category['code'] ?? '')); ?></textarea>
                        <p class="description"><?php esc_html_e('Scripts and code that will be output if the category gets the user consent.', 'thecore-elementor-widgets'); ?></p>
                    </td>
                </tr>
            </table>
        </section>
        <?php
    }

    /**
     * @param array<string, mixed> $config
     */
    private function renderConsentSettingsTab(array $config): void
    {
        ?>
        <section class="thecore-admin__card">
            <div class="thecore-admin__card-content">
                <h2><?php echo esc_html__('Consent Settings', 'thecore-elementor-widgets'); ?></h2>
                <p><?php esc_html_e('Manage settings related to consents and logging.', 'thecore-elementor-widgets'); ?></p>
            </div>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><?php esc_html_e('Log Consents', 'thecore-elementor-widgets'); ?></th>
                    <td><?php $this->renderCheckbox('cookie_consent[log_consents]', ! empty($config['log_consents']), __('Log cookie consents', 'thecore-elementor-widgets')); ?></td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e('Anonymize IPs', 'thecore-elementor-widgets'); ?></th>
                    <td><?php $this->renderCheckbox('cookie_consent[anonymize_consent_log_ips]', ! empty($config['anonymize_consent_log_ips']), __('Anonymize IP address of saved logs', 'thecore-elementor-widgets')); ?></td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e('Auto-Purge Consents', 'thecore-elementor-widgets'); ?></th>
                    <td>
                        <?php $this->renderCheckbox('cookie_consent[auto_purge_consents]', ! empty($config['auto_purge_consents']), __('Automatically delete cookie consent logs older than', 'thecore-elementor-widgets')); ?>
                        <p style="margin-top:8px">
                            <select id="cookie_consent_auto_purge_consents_interval" name="cookie_consent[auto_purge_consents_interval]">
                                <?php foreach ($this->purgeIntervals() as $value => $label) : ?>
                                    <option value="<?php echo esc_attr($value); ?>" <?php selected((string) ($config['auto_purge_consents_interval'] ?? ''), $value); ?>><?php echo esc_html($label); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e('Purge cookies on revoke', 'thecore-elementor-widgets'); ?></th>
                    <td><?php $this->renderCheckbox('cookie_consent[revoke_delete_all]', ! empty($config['revoke_delete_all']), __('Delete all saved cookies when using the revoke consent button', 'thecore-elementor-widgets')); ?></td>
                </tr>
            </table>
        </section>
        <?php
    }

    /**
     * @param array<string, mixed> $config
     */
    private function renderConsentStatistics(array $config): void
    {
        if (empty($config['log_consents'])) {
            echo '<p>' . esc_html__('Consent logging is disabled.', 'thecore-elementor-widgets') . '</p>';

            return;
        }

        $latestConsents = new WP_Query(
            [
                'post_type' => Logger::POST_TYPE,
                'posts_per_page' => 5,
            ]
        );

        if (! $latestConsents->have_posts()) {
            echo '<p>' . esc_html__('No data yet. Please check back later.', 'thecore-elementor-widgets') . '</p>';

            return;
        }

        ?>
        <h2><?php esc_html_e('Latest consents', 'thecore-elementor-widgets'); ?></h2>
        <table class="wp-list-table widefat striped">
            <thead>
                <tr>
                    <th><?php esc_html_e('Date/Time', 'thecore-elementor-widgets'); ?></th>
                    <th><?php esc_html_e('UUID', 'thecore-elementor-widgets'); ?></th>
                    <th><?php esc_html_e('Cookie Categories', 'thecore-elementor-widgets'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php while ($latestConsents->have_posts()) : ?>
                    <?php $latestConsents->the_post(); ?>
                    <tr>
                        <td><?php echo esc_html(get_the_date((string) get_option('date_format')) . ' ' . get_the_time((string) get_option('time_format'))); ?></td>
                        <td><?php the_title(); ?></td>
                        <td><?php echo esc_html((new Helper($this->configRepository))->prettyPrintLoggedCategories((int) get_the_ID())); ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <p><a href="<?php echo esc_url(admin_url('edit.php?post_type=' . Logger::POST_TYPE)); ?>" class="button button-primary"><?php esc_html_e('View all consents', 'thecore-elementor-widgets'); ?></a></p>
        <?php
        wp_reset_postdata();

        $helper = new Helper($this->configRepository);
        $categories = array_merge(['total' => __('Total', 'thecore-elementor-widgets')], $helper->getRegisteredCookieCategories());
        $timeframes = [7, 30];

        echo '<h2 class="cnc__bar-chart__title">' . esc_html__('Cookie Categories', 'thecore-elementor-widgets') . '</h2>';

        foreach ($timeframes as $timeframe) {
            $queries = [];

            foreach (array_keys($categories) as $category) {
                $queries[$category] = new WP_Query(
                    [
                        'post_type' => Logger::POST_TYPE,
                        'fields' => 'ids',
                        'date_query' => [
                            [
                                'after' => $timeframe . ' days ago',
                            ],
                        ],
                        'meta_query' => 'total' !== $category
                            ? [
                                [
                                    'key' => 'categories',
                                    'compare' => 'LIKE',
                                    'value' => $category,
                                ],
                            ]
                            : [],
                    ]
                );
            }

            $total = $queries['total']->found_posts;
            ?>
            <div class="cnc__bar-chart">
                <div class="cnc__bar-chart__legend">
                    <?php echo esc_html(sprintf(__('Last %s days', 'thecore-elementor-widgets'), $timeframe)); ?>
                    <span><?php echo esc_html(sprintf(_n('%s consent log', '%s consent logs', $total, 'thecore-elementor-widgets'), number_format_i18n($total))); ?></span>
                </div>
                <?php foreach ($queries as $slug => $query) : ?>
                    <?php if ('total' === $slug) : ?>
                        <?php continue; ?>
                    <?php endif; ?>
                    <?php $count = $query->found_posts; ?>
                    <?php $percentage = $total > 0 ? (int) round($count / $total * 100) : 0; ?>
                    <div class="cnc__bar-chart__bar" style="width:<?php echo esc_attr((string) $percentage); ?>%">
                        <span class="cnc__bar-chart__label"><?php echo esc_html($categories[$slug]); ?></span>
                        <span class="cnc__bar-chart__percentage"><?php echo esc_html((string) $percentage); ?> %</span>
                        <span class="cnc__bar-chart__value">(<?php echo esc_html(number_format_i18n($count)); ?>)</span>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php
        }
    }

    private function renderTabs(string $activeTab, bool $loggingEnabled): void
    {
        echo '<nav class="nav-tab-wrapper">';

        foreach (self::TABS as $slug => $label) {
            if ('consent_statistics' === $slug && ! $loggingEnabled) {
                continue;
            }

            $activeClass = $slug === $activeTab ? ' nav-tab-active' : '';

            printf(
                '<a href="%1$s" class="nav-tab%2$s">%3$s</a>',
                esc_url(
                    add_query_arg(
                        [
                            'page' => self::MENU_SLUG,
                            'tab' => $slug,
                        ],
                        admin_url('admin.php')
                    )
                ),
                esc_attr($activeClass),
                esc_html(__($label, 'thecore-elementor-widgets'))
            );
        }

        echo '</nav>';
    }

    private function renderUpdatedNotice(): void
    {
        if ((string) ($_GET['updated'] ?? '') !== '1') {
            return;
        }

        echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Cookie settings saved.', 'thecore-elementor-widgets') . '</p></div>';
    }

    private function activeTab(): string
    {
        return $this->sanitizeTab($_GET['tab'] ?? '');
    }

    private function sanitizeTab(mixed $tab): string
    {
        $tab = is_scalar($tab) ? sanitize_key((string) $tab) : '';

        return array_key_exists($tab, self::TABS)
            ? $tab
            : 'general_settings';
    }

    private function isCookieConsentScreen(): bool
    {
        $postType = '';

        if (isset($_GET['post_type']) && is_scalar($_GET['post_type'])) {
            $postType = sanitize_key((string) wp_unslash((string) $_GET['post_type']));
        } elseif (isset($_GET['post']) && is_numeric($_GET['post'])) {
            $postType = (string) get_post_type((int) $_GET['post']);
        }

        return Logger::POST_TYPE === $postType;
    }

    private function renderCheckbox(string $name, bool $checked, string $label): void
    {
        printf(
            '<input type="hidden" name="%1$s" value="0"><label><input type="checkbox" name="%1$s" value="yes" %2$s> %3$s</label>',
            esc_attr($name),
            checked($checked, true, false),
            esc_html($label)
        );
    }

    /**
     * @param array<string, mixed> $config
     *
     * @return array<string, mixed>|null
     */
    private function findCategoryConfig(array $config, string $slug): ?array
    {
        $categories = is_array($config['categories'] ?? null) ? $config['categories'] : [];

        foreach ($categories as $category) {
            if (is_array($category) && ($category['slug'] ?? null) === $slug) {
                return $category;
            }
        }

        return null;
    }

    /**
     * @param array<string, mixed> $config
     *
     * @return array<string, mixed>
     */
    private function flattenConfig(array $config): array
    {
        $settings = [
            'notice_text' => $config['notice_text'] ?? CookieConsentModule::DEFAULT_NOTICE_TEXT,
            'reload_on_set' => ! empty($config['reload_on_set']) ? 'yes' : '0',
            'privacy_policy_url' => [
                'url' => $config['privacy_policy_url'] ?? '',
                'is_external' => ! empty($config['privacy_policy_external']) ? 'yes' : '',
            ],
            'accept_button_label' => $config['buttons']['accept'] ?? CookieConsentModule::DEFAULT_ACCEPT_BUTTON_LABEL,
            'confirm_choice_button_label' => $config['buttons']['confirm'] ?? CookieConsentModule::DEFAULT_CONFIRM_BUTTON_LABEL,
            'reject_button_label' => $config['buttons']['reject'] ?? CookieConsentModule::DEFAULT_REJECT_BUTTON_LABEL,
            'privacy_policy_button_label' => $config['buttons']['privacy'] ?? CookieConsentModule::DEFAULT_PRIVACY_BUTTON_LABEL,
            'revoke_consent_button_label' => $config['revoke_consent_button_label'] ?? CookieConsentModule::DEFAULT_REVOKE_BUTTON_LABEL,
            'block_embeds' => ! empty($config['block_embeds']) ? 'yes' : '0',
            'show_category_descriptions' => ! empty($config['show_category_descriptions']) ? 'yes' : '0',
            'cookie_expiration_days' => $config['cookie_expiration_days'] ?? CookieConsentModule::DEFAULT_COOKIE_EXPIRATION_DAYS,
            'log_consents' => ! empty($config['log_consents']) ? 'yes' : '0',
            'anonymize_consent_log_ips' => ! empty($config['anonymize_consent_log_ips']) ? 'yes' : '0',
            'auto_purge_consents' => ! empty($config['auto_purge_consents']) ? 'yes' : '0',
            'auto_purge_consents_interval' => $config['auto_purge_consents_interval'] ?? CookieConsentModule::DEFAULT_AUTO_PURGE_INTERVAL,
            'revoke_delete_all' => ! empty($config['revoke_delete_all']) ? 'yes' : '0',
        ];

        $categories = is_array($config['categories'] ?? null) ? $config['categories'] : [];

        foreach ($categories as $category) {
            if (! is_array($category) || ! is_string($category['slug'] ?? null)) {
                continue;
            }

            $slug = (string) $category['slug'];
            $settings[$slug . '_active'] = ! empty($category['active']) ? 'yes' : '0';
            $settings[$slug . '_label'] = $category['label'] ?? '';
            $settings[$slug . '_description'] = $category['description'] ?? '';
            $settings[$slug . '_code'] = $category['code'] ?? '';
        }

        return $settings;
    }

    /**
     * @return array<string, string>
     */
    private function purgeIntervals(): array
    {
        return [
            '1 month' => __('1 month', 'thecore-elementor-widgets'),
            '3 months' => __('3 months', 'thecore-elementor-widgets'),
            '6 months' => __('6 months', 'thecore-elementor-widgets'),
            '1 year' => __('1 year', 'thecore-elementor-widgets'),
            '2 years' => __('2 years', 'thecore-elementor-widgets'),
            '5 years' => __('5 years', 'thecore-elementor-widgets'),
        ];
    }
}
