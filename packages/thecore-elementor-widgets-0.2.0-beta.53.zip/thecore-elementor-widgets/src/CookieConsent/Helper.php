<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\CookieConsent;

final class Helper
{
    public function __construct(
        private readonly ConfigRepository $configRepository
    ) {
    }

    public function isCookieConsentSet(): bool
    {
        return isset($_COOKIE[CookieConsentModule::COOKIE_NAME]);
    }

    public function isCookieCategoryAccepted(string $category): bool
    {
        if (! $this->isCookieConsentSet()) {
            return false;
        }

        $category = 0 === strpos($category, 'category_') ? $category : 'category_' . $category;

        $cookieData = json_decode(stripslashes((string) $_COOKIE[CookieConsentModule::COOKIE_NAME]), true);

        if (! is_array($cookieData)) {
            return false;
        }

        if ('category_essential' === $category) {
            return true;
        }

        $acceptedCategories = $cookieData['cookie_categories'] ?? [];

        return is_array($acceptedCategories) && in_array($category, $acceptedCategories, true);
    }

    /**
     * @return array<string, string>
     */
    public function getRegisteredCookieCategories(): array
    {
        $categories = [];

        foreach ($this->configRepository->active()['categories'] ?? [] as $category) {
            if (! is_array($category)) {
                continue;
            }

            $slug = isset($category['slug']) && is_string($category['slug']) ? $category['slug'] : '';
            $label = isset($category['label']) && is_string($category['label']) ? $category['label'] : '';
            $active = ! empty($category['active']);

            if ($slug === '' || $label === '' || ! $active) {
                continue;
            }

            $categories[$slug] = $label;
        }

        return $categories;
    }

    /**
     * @return string[]
     */
    public function getActiveCookieCategories(): array
    {
        return array_keys($this->getRegisteredCookieCategories());
    }

    /**
     * @param string[] $categories
     *
     * @return string[]
     */
    public function filterAllowedCookieCategories(array $categories): array
    {
        return array_values(
            array_intersect(
                $this->getActiveCookieCategories(),
                $categories
            )
        );
    }

    public function currentPrivacyPolicyUrl(): string
    {
        $config = $this->configRepository->active();
        $configuredUrl = $config['privacy_policy_url'] ?? '';

        if (is_string($configuredUrl) && '' !== trim($configuredUrl)) {
            return $configuredUrl;
        }

        return function_exists('get_privacy_policy_url')
            ? (string) get_privacy_policy_url()
            : '';
    }

    public function prettyPrintLoggedCategories(int $postId): string
    {
        $stored = get_post_meta($postId, 'categories', true);
        $categories = maybe_unserialize($stored);

        if (! is_array($categories) || [] === $categories) {
            return '';
        }

        $labels = $this->getRegisteredCookieCategories();
        $pretty = [];

        foreach ($categories as $category) {
            if (! is_string($category) || '' === $category) {
                continue;
            }

            $pretty[] = $labels[$category] ?? ucwords(str_replace(['category_', '_'], ['', ' '], $category));
        }

        return implode(', ', $pretty);
    }

    /**
     * @return array<string, array<string, array<int, string>>>
     */
    public function getAllowedHtml(): array
    {
        return array_merge(
            wp_kses_allowed_html('post'),
            [
                'script' => [
                    'type' => [],
                    'src' => [],
                    'charset' => [],
                    'async' => [],
                    'defer' => [],
                    'id' => [],
                ],
                'noscript' => [],
                'style' => [
                    'type' => [],
                    'id' => [],
                ],
                'iframe' => [
                    'src' => [],
                    'height' => [],
                    'width' => [],
                    'frameborder' => [],
                    'allowfullscreen' => [],
                    'loading' => [],
                    'allow' => [],
                    'referrerpolicy' => [],
                    'title' => [],
                ],
            ]
        );
    }
}
