<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\CookieConsent;

use TheCore\ElementorWidgets\Assets\FrontendAssets;

final class Shortcodes
{
    public function __construct(
        private readonly ConfigRepository $configRepository,
        private readonly Helper $helper
    ) {
    }

    public function registerHooks(): void
    {
        if (! shortcode_exists('revoke_cookie_consent')) {
            add_shortcode('revoke_cookie_consent', [$this, 'shortcodeRevokeCookieConsent']);
        }

        if (! shortcode_exists('cookie_consent_status')) {
            add_shortcode('cookie_consent_status', [$this, 'shortcodeCookieConsentStatus']);
        }
    }

    /**
     * @param array<string, mixed> $args
     */
    public function shortcodeRevokeCookieConsent(array $args = [], string $content = ''): string
    {
        unset($args, $content);

        wp_enqueue_script(FrontendAssets::COOKIE_CONSENT_SCRIPT);
        wp_enqueue_style(FrontendAssets::COOKIE_CONSENT_STYLE);

        $config = $this->configRepository->active();
        $label = is_string($config['revoke_consent_button_label'] ?? null) && '' !== trim((string) $config['revoke_consent_button_label'])
            ? (string) $config['revoke_consent_button_label']
            : CookieConsentModule::DEFAULT_REVOKE_BUTTON_LABEL;

        return wpautop(
            sprintf(
                '<a href="#cookies-revoked" id="thecore-cookie-consent__revoke-button" class="thecore-cookie-consent__revoke-button thecore-cookie-consent__button thecore-cookie-consent__button--inline" title="%1$s">%2$s</a>',
                esc_attr($label),
                esc_html($label)
            )
        );
    }

    /**
     * @param array<string, mixed> $args
     */
    public function shortcodeCookieConsentStatus(array $args = [], string $content = ''): string
    {
        unset($args, $content);

        $status = '<p class="thecore-cookie-consent__status">';
        $status .= esc_html__('Cookie consent status', 'thecore-elementor-widgets') . ': ';

        if (! $this->helper->isCookieConsentSet()) {
            $status .= esc_html__('No consent given', 'thecore-elementor-widgets');
        } else {
            $status .= esc_html__('Consent given for', 'thecore-elementor-widgets') . ' ';

            $acceptedCategories = [];

            foreach ($this->helper->getRegisteredCookieCategories() as $slug => $label) {
                if ($this->helper->isCookieCategoryAccepted($slug)) {
                    $acceptedCategories[] = $label;
                }
            }

            if ([] !== $acceptedCategories) {
                $status .= '<em>' . implode(
                    '</em>, <em>',
                    array_map(
                        static fn(string $label): string => esc_html($label),
                        $acceptedCategories
                    )
                ) . '</em>';
            } else {
                $status .= esc_html__('no category', 'thecore-elementor-widgets');
            }
        }

        $status .= '.</p>';

        return $status;
    }
}
