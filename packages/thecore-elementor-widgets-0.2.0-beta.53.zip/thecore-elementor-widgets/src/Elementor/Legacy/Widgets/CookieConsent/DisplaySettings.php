<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Legacy\Widgets\CookieConsent;

use TheCore\ElementorWidgets\CookieConsent\CookieConsentModule;

final class DisplaySettings
{
    public const DEFAULT_CATEGORY_SETTINGS = [
        'category_essential' => [
            'label' => 'Cookies essentiels',
            'description' => 'Cookies indispensables au fonctionnement du site. Ils ne peuvent pas être refusés.',
            'required' => true,
            'active' => true,
            'code' => '',
        ],
        'category_functional' => [
            'label' => 'Cookies fonctionnels',
            'description' => 'Cookies qui assurent des fonctionnalités de base et améliorent l’expérience utilisateur.',
            'required' => false,
            'active' => true,
            'code' => '',
        ],
        'category_marketing' => [
            'label' => 'Cookies marketing',
            'description' => 'Cookies utilisés pour le marketing, la publicité et le ciblage.',
            'required' => false,
            'active' => true,
            'code' => '',
        ],
    ];

    /**
     * @return string[]
     */
    private function autoPurgeIntervals(): array
    {
        return ['1 month', '3 months', '6 months', '1 year', '2 years', '5 years'];
    }

    /**
     * @param array<string, mixed> $settings
     *
     * @return array{
     *     notice_text: string,
     *     theme_preset: string,
     *     show_category_descriptions: bool,
     *     reload_on_set: bool,
     *     cookie_expiration_days: int,
     *     privacy_policy_url: string,
     *     privacy_policy_external: bool,
     *     revoke_consent_button_label: string,
     *     block_embeds: bool,
     *     log_consents: bool,
     *     anonymize_consent_log_ips: bool,
     *     auto_purge_consents: bool,
     *     auto_purge_consents_interval: string,
     *     revoke_delete_all: bool,
     *     buttons: array{accept: string, confirm: string, reject: string, privacy: string},
     *     categories: array<int, array{slug: string, label: string, description: string, active: bool, required: bool, code: string}>
     * }
     */
    public function normalize(array $settings): array
    {
        return [
            'notice_text' => $this->sanitizeNoticeText(
                $settings['notice_text'] ?? CookieConsentModule::DEFAULT_NOTICE_TEXT
            ),
            'theme_preset' => $this->sanitizeThemePreset(
                $settings['theme_preset'] ?? CookieConsentModule::DEFAULT_THEME_PRESET
            ),
            'show_category_descriptions' => $this->toBool($settings['show_category_descriptions'] ?? 'yes'),
            'reload_on_set' => $this->toBool($settings['reload_on_set'] ?? ''),
            'cookie_expiration_days' => $this->clampInt(
                $settings['cookie_expiration_days'] ?? CookieConsentModule::DEFAULT_COOKIE_EXPIRATION_DAYS,
                1,
                365,
                CookieConsentModule::DEFAULT_COOKIE_EXPIRATION_DAYS
            ),
            'privacy_policy_url' => $this->sanitizeUrl(
                $settings['privacy_policy_url'] ?? $this->defaultPrivacyPolicyUrl()
            ),
            'privacy_policy_external' => $this->toExternalTarget($settings['privacy_policy_url'] ?? []),
            'revoke_consent_button_label' => $this->sanitizeOptionalText(
                $settings['revoke_consent_button_label'] ?? CookieConsentModule::DEFAULT_REVOKE_BUTTON_LABEL
            ),
            'block_embeds' => $this->toBool($settings['block_embeds'] ?? ''),
            'log_consents' => $this->toBool($settings['log_consents'] ?? 'yes'),
            'anonymize_consent_log_ips' => $this->toBool($settings['anonymize_consent_log_ips'] ?? 'yes'),
            'auto_purge_consents' => $this->toBool($settings['auto_purge_consents'] ?? ''),
            'auto_purge_consents_interval' => $this->sanitizeAutoPurgeInterval(
                $settings['auto_purge_consents_interval'] ?? CookieConsentModule::DEFAULT_AUTO_PURGE_INTERVAL
            ),
            'revoke_delete_all' => $this->toBool($settings['revoke_delete_all'] ?? 'yes'),
            'buttons' => [
                'accept' => $this->sanitizeOptionalText(
                    $settings['accept_button_label'] ?? CookieConsentModule::DEFAULT_ACCEPT_BUTTON_LABEL
                ),
                'confirm' => $this->sanitizeOptionalText(
                    $settings['confirm_choice_button_label'] ?? CookieConsentModule::DEFAULT_CONFIRM_BUTTON_LABEL
                ),
                'reject' => $this->sanitizeOptionalText(
                    $settings['reject_button_label'] ?? CookieConsentModule::DEFAULT_REJECT_BUTTON_LABEL
                ),
                'privacy' => $this->sanitizeOptionalText(
                    $settings['privacy_policy_button_label'] ?? CookieConsentModule::DEFAULT_PRIVACY_BUTTON_LABEL
                ),
            ],
            'categories' => $this->sanitizeCategories($settings),
        ];
    }

    /**
     * @param array<string, mixed> $settings
     *
     * @return array<int, array{slug: string, label: string, description: string, active: bool, required: bool, code: string}>
     */
    private function sanitizeCategories(array $settings): array
    {
        $categories = [];

        foreach (self::DEFAULT_CATEGORY_SETTINGS as $slug => $defaults) {
            $categories[] = [
                'slug' => $slug,
                'label' => $this->sanitizeText(
                    $settings[$slug . '_label'] ?? $defaults['label'],
                    $defaults['label']
                ),
                'description' => $this->sanitizeOptionalTextarea(
                    $settings[$slug . '_description'] ?? $defaults['description']
                ),
                'active' => $this->toBool($settings[$slug . '_active'] ?? ($defaults['active'] ? 'yes' : '')),
                'required' => (bool) $defaults['required'],
                'code' => $this->sanitizeOptionalCode($settings[$slug . '_code'] ?? $defaults['code']),
            ];
        }

        return $categories;
    }

    private function defaultPrivacyPolicyUrl(): string
    {
        return function_exists('get_privacy_policy_url')
            ? (string) get_privacy_policy_url()
            : '';
    }

    private function sanitizeThemePreset(mixed $value): string
    {
        if (! is_string($value)) {
            return CookieConsentModule::DEFAULT_THEME_PRESET;
        }

        return in_array($value, ['default', 'labs', 'sidecar', 'lowkey'], true)
            ? $value
            : CookieConsentModule::DEFAULT_THEME_PRESET;
    }

    private function sanitizeAutoPurgeInterval(mixed $value): string
    {
        if (! is_string($value)) {
            return CookieConsentModule::DEFAULT_AUTO_PURGE_INTERVAL;
        }

        $value = trim($value);

        return in_array($value, $this->autoPurgeIntervals(), true)
            ? $value
            : CookieConsentModule::DEFAULT_AUTO_PURGE_INTERVAL;
    }

    private function clampInt(mixed $value, int $min, int $max, int $default): int
    {
        if (! is_numeric($value)) {
            return $default;
        }

        return max($min, min($max, (int) $value));
    }

    private function toBool(mixed $value): bool
    {
        if (is_bool($value)) {
            return $value;
        }

        if (is_numeric($value)) {
            return 1 === (int) $value;
        }

        return is_string($value) && in_array(strtolower($value), ['yes', 'true', 'on'], true);
    }

    private function toExternalTarget(mixed $value): bool
    {
        return is_array($value) && ! empty($value['is_external']);
    }

    private function sanitizeNoticeText(mixed $value): string
    {
        if (! is_scalar($value)) {
            return CookieConsentModule::DEFAULT_NOTICE_TEXT;
        }

        return trim((string) $value);
    }

    private function sanitizeText(mixed $value, string $default): string
    {
        if (! is_scalar($value)) {
            return $default;
        }

        $sanitized = sanitize_text_field((string) $value);

        return '' !== $sanitized ? $sanitized : $default;
    }

    private function sanitizeOptionalText(mixed $value): string
    {
        if (! is_scalar($value)) {
            return '';
        }

        return sanitize_text_field((string) $value);
    }

    private function sanitizeOptionalTextarea(mixed $value): string
    {
        if (! is_scalar($value)) {
            return '';
        }

        return sanitize_textarea_field((string) $value);
    }

    private function sanitizeOptionalCode(mixed $value): string
    {
        if (! is_scalar($value)) {
            return '';
        }

        return trim((string) $value);
    }

    private function sanitizeUrl(mixed $value): string
    {
        if (is_array($value)) {
            $value = $value['url'] ?? '';
        }

        return is_scalar($value) ? esc_url_raw((string) $value) : '';
    }
}
