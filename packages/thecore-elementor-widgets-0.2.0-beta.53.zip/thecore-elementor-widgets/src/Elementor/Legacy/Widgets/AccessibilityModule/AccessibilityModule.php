<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Legacy\Widgets\AccessibilityModule;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;
use TheCore\ElementorWidgets\Assets\FrontendAssets;

final class AccessibilityModule extends Widget_Base
{
    private ?ToolbarRenderer $toolbarRenderer = null;

    public function get_name(): string
    {
        return 'thecore-accessibility-module-legacy';
    }

    public function get_title(): string
    {
        return esc_html__('Accessibility Module (Legacy)', 'thecore-elementor-widgets');
    }

    public function get_icon(): string
    {
        return 'eicon-menu-bar';
    }

    public function get_categories(): array
    {
        return ['general'];
    }

    public function get_keywords(): array
    {
        return ['accessibility', 'a11y', 'ally', 'toolbar', 'module', 'panel'];
    }

    public function get_style_depends(): array
    {
        return [FrontendAssets::ACCESSIBILITY_LEGACY_STYLE];
    }

    public function get_script_depends(): array
    {
        return [FrontendAssets::ACCESSIBILITY_LEGACY_SCRIPT];
    }

    protected function register_controls(): void
    {
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Module', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'module_notice',
            [
                'type' => Controls_Manager::RAW_HTML,
                'raw' => esc_html__(
                    'This widget renders the accessibility panel only. Use the Accessibility Trigger widget to open it.',
                    'thecore-elementor-widgets'
                ),
                'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
            ]
        );

        $this->add_control(
            'header_eyebrow_text',
            [
                'label' => esc_html__('Eyebrow', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXT,
                'default' => '',
                'placeholder' => esc_html__('Accessibility', 'thecore-elementor-widgets'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'header_title_text',
            [
                'label' => esc_html__('Title', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXT,
                'default' => '',
                'placeholder' => esc_html__('Accessibility Tools', 'thecore-elementor-widgets'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'header_subtitle_text',
            [
                'label' => esc_html__('Subtitle', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => '',
                'placeholder' => esc_html__('Adjust the website experience to match your needs.', 'thecore-elementor-widgets'),
                'rows' => 3,
            ]
        );

        $this->add_control(
            'close_button_label',
            [
                'label' => esc_html__('Close button label', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXT,
                'default' => DisplaySettings::DEFAULT_CLOSE_BUTTON_LABEL,
                'label_block' => true,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_features',
            [
                'label' => esc_html__('Features', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        foreach ($this->getFeatureControlLabels() as $setting => $label) {
            $this->add_control(
                $setting,
                [
                    'label' => $label,
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => esc_html__('Yes', 'thecore-elementor-widgets'),
                    'label_off' => esc_html__('No', 'thecore-elementor-widgets'),
                    'return_value' => 'yes',
                    'default' => 'yes',
                ]
            );

            $this->add_control(
                $setting . '_label',
                [
                    'label' => esc_html__('Feature label', 'thecore-elementor-widgets'),
                    'type' => Controls_Manager::TEXT,
                    'default' => $label,
                    'placeholder' => $label,
                    'label_block' => true,
                    'condition' => [
                        $setting => 'yes',
                    ],
                ]
            );
        }

        $this->add_control(
            'section_content_adjustments_title',
            [
                'label' => esc_html__('Content section title', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXT,
                'default' => DisplaySettings::DEFAULT_SECTION_TITLES['section_content_adjustments_title'],
                'label_block' => true,
            ]
        );

        $this->add_control(
            'section_orientation_adjustments_title',
            [
                'label' => esc_html__('Orientation section title', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXT,
                'default' => DisplaySettings::DEFAULT_SECTION_TITLES['section_orientation_adjustments_title'],
                'label_block' => true,
            ]
        );

        $this->add_control(
            'section_color_adjustments_title',
            [
                'label' => esc_html__('Color section title', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXT,
                'default' => DisplaySettings::DEFAULT_SECTION_TITLES['section_color_adjustments_title'],
                'label_block' => true,
            ]
        );

        $this->add_control(
            'reset_label',
            [
                'label' => esc_html__('Reset button label', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXT,
                'default' => DisplaySettings::DEFAULT_RESET_LABEL,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'help_label',
            [
                'label' => esc_html__('Help label', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXT,
                'default' => DisplaySettings::DEFAULT_HELP_LABEL,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'help_url',
            [
                'label' => esc_html__('Help URL', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::URL,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'feedback_label',
            [
                'label' => esc_html__('Feedback label', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXT,
                'default' => DisplaySettings::DEFAULT_FEEDBACK_LABEL,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'feedback_url',
            [
                'label' => esc_html__('Feedback URL', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::URL,
                'label_block' => true,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_skip_link',
            [
                'label' => esc_html__('Skip Link', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'skip_link_enabled',
            [
                'label' => esc_html__('Enable skip link', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'thecore-elementor-widgets'),
                'label_off' => esc_html__('No', 'thecore-elementor-widgets'),
                'return_value' => 'yes',
                'default' => '',
            ]
        );

        $this->add_control(
            'skip_link_label',
            [
                'label' => esc_html__('Label', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXT,
                'default' => DisplaySettings::DEFAULT_SKIP_LINK_LABEL,
                'label_block' => true,
                'condition' => [
                    'skip_link_enabled' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'skip_link_hidden',
            [
                'label' => esc_html__('Hide skip link visually', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'thecore-elementor-widgets'),
                'label_off' => esc_html__('No', 'thecore-elementor-widgets'),
                'return_value' => 'yes',
                'default' => '',
                'condition' => [
                    'skip_link_enabled' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'skip_link_target_selector',
            [
                'label' => esc_html__('Content target selector', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXT,
                'default' => DisplaySettings::DEFAULT_SKIP_LINK_TARGET_SELECTOR,
                'label_block' => true,
                'condition' => [
                    'skip_link_enabled' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'skip_link_mount_selector',
            [
                'label' => esc_html__('Mount selector', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::TEXT,
                'default' => DisplaySettings::DEFAULT_SKIP_LINK_MOUNT_SELECTOR,
                'label_block' => true,
                'condition' => [
                    'skip_link_enabled' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_panel',
            [
                'label' => esc_html__('Panel', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'panel_width',
            [
                'label' => esc_html__('Width', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'vw'],
                'range' => [
                    'px' => [
                        'min' => 280,
                        'max' => 560,
                    ],
                    'vw' => [
                        'min' => 30,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} #thecore-accessibility-toolbar' => '--thecore-accessibility-panel-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'module_height',
            [
                'label' => esc_html__('Height', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'vh'],
                'range' => [
                    'px' => [
                        'min' => 320,
                        'max' => 1000,
                    ],
                    'vh' => [
                        'min' => 40,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} #thecore-accessibility-toolbar' => '--thecore-accessibility-module-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'module_vertical_position',
            [
                'label' => esc_html__('Vertical Position', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'top' => [
                        'title' => esc_html__('Top', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-v-align-top',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-v-align-middle',
                    ],
                    'bottom' => [
                        'title' => esc_html__('Bottom', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-v-align-bottom',
                    ],
                ],
                'default' => 'bottom',
                'toggle' => false,
            ]
        );

        $this->add_control(
            'module_horizontal_position',
            [
                'label' => esc_html__('Horizontal Position', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-h-align-left',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-h-align-right',
                    ],
                ],
                'default' => 'right',
                'toggle' => false,
            ]
        );

        $this->add_responsive_control(
            'module_top_gap',
            [
                'label' => esc_html__('Top Margin', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'vh'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                    ],
                    'vh' => [
                        'min' => 0,
                        'max' => 30,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 16,
                ],
                'selectors' => [
                    '{{WRAPPER}} #thecore-accessibility-toolbar' => '--thecore-accessibility-viewport-gap-top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'module_bottom_gap',
            [
                'label' => esc_html__('Bottom Margin', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'vh'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                    ],
                    'vh' => [
                        'min' => 0,
                        'max' => 30,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 16,
                ],
                'selectors' => [
                    '{{WRAPPER}} #thecore-accessibility-toolbar' => '--thecore-accessibility-viewport-gap-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'panel_background_color',
            [
                'label' => esc_html__('Background Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-shell' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'panel_border',
                'selector' => '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-shell',
            ]
        );

        $this->add_responsive_control(
            'panel_border_radius',
            [
                'label' => esc_html__('Border Radius', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem'],
                'selectors' => [
                    '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-shell' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'panel_shadow',
                'selector' => '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-shell',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_header',
            [
                'label' => esc_html__('Header', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'header_background',
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-header',
            ]
        );

        $this->add_control(
            'header_eyebrow_color',
            [
                'label' => esc_html__('Eyebrow Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-eyebrow' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-title',
            ]
        );

        $this->add_control(
            'header_title_color',
            [
                'label' => esc_html__('Title Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'subtitle_typography',
                'selector' => '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-subtitle',
            ]
        );

        $this->add_control(
            'header_subtitle_color',
            [
                'label' => esc_html__('Subtitle Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-subtitle' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_cards',
            [
                'label' => esc_html__('Cards', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'card_background_color',
            [
                'label' => esc_html__('Background Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-card' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'card_text_color',
            [
                'label' => esc_html__('Text Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-card' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'card_typography',
                'selector' => '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-text',
            ]
        );

        $this->add_control(
            'card_border_color',
            [
                'label' => esc_html__('Border Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-card' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_border_radius',
            [
                'label' => esc_html__('Border Radius', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem'],
                'selectors' => [
                    '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_padding',
            [
                'label' => esc_html__('Padding', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem'],
                'selectors' => [
                    '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_min_height',
            [
                'label' => esc_html__('Card Height', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => [
                        'min' => 72,
                        'max' => 220,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-card' => 'min-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_icon_size',
            [
                'label' => esc_html__('Icon Size', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => [
                        'min' => 12,
                        'max' => 48,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-icon' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_content_gap',
            [
                'label' => esc_html__('Icon/Text Spacing', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 48,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-card' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'card_hover_background_color',
            [
                'label' => esc_html__('Hover Background', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-card:hover, {{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-card:focus-visible' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'card_hover_border_color',
            [
                'label' => esc_html__('Hover Border', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-card:hover, {{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-card:focus-visible' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'card_icon_background_color',
            [
                'label' => esc_html__('Icon Background', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-icon-wrap' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'card_icon_color',
            [
                'label' => esc_html__('Icon Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-icon-wrap' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'card_active_background_color',
            [
                'label' => esc_html__('Active Background', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-card.is-active' => 'background-color: {{VALUE}}; border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'card_active_text_color',
            [
                'label' => esc_html__('Active Text Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-card.is-active' => 'color: {{VALUE}};',
                    '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-card.is-active .thecore-accessibility-toolbar-icon-wrap' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_footer',
            [
                'label' => esc_html__('Footer Buttons', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'footer_button_background_color',
            [
                'label' => esc_html__('Secondary Background', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-footer-button:not(.thecore-accessibility-toolbar-footer-button-primary), {{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-footer-button:not(.thecore-accessibility-toolbar-footer-button-primary):hover, {{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-footer-button:not(.thecore-accessibility-toolbar-footer-button-primary):focus-visible' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'footer_button_text_color',
            [
                'label' => esc_html__('Secondary Text Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-footer-button:not(.thecore-accessibility-toolbar-footer-button-primary), {{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-footer-button:not(.thecore-accessibility-toolbar-footer-button-primary):hover, {{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-footer-button:not(.thecore-accessibility-toolbar-footer-button-primary):focus-visible' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'footer_button_border_color',
            [
                'label' => esc_html__('Secondary Border Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-footer-button:not(.thecore-accessibility-toolbar-footer-button-primary), {{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-footer-button:not(.thecore-accessibility-toolbar-footer-button-primary):hover, {{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-footer-button:not(.thecore-accessibility-toolbar-footer-button-primary):focus-visible' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'footer_primary_background_color',
            [
                'label' => esc_html__('Primary Background', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-footer-button-primary, {{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-footer-button-primary:hover, {{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-footer-button-primary:focus-visible' => 'background-color: {{VALUE}}; border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'footer_primary_text_color',
            [
                'label' => esc_html__('Primary Text Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-footer-button-primary, {{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-footer-button-primary:hover, {{WRAPPER}} #thecore-accessibility-toolbar .thecore-accessibility-toolbar-footer-button-primary:focus-visible' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render(): void
    {
        $settings = (new DisplaySettings())->normalize($this->get_settings_for_display());

        FrontendAssets::renderCriticalModalCss();

        $this->getToolbarRenderer()->render(
            $this->buildToolbarData($settings),
            $this->shouldForceToolbarOpen()
        );
    }

    private function getToolbarRenderer(): ToolbarRenderer
    {
        if ($this->toolbarRenderer === null) {
            $this->toolbarRenderer = new ToolbarRenderer();
        }

        return $this->toolbarRenderer;
    }

    /**
     * @param array<string, bool|string> $settings
     *
     * @return array<string, mixed>
     */
    private function buildToolbarData(array $settings): array
    {
        $wrapperClasses = ['thecore-accessibility-toolbar-without-toggle'];
        $wrapperClasses[] = 'thecore-accessibility-modal-position-' . $settings['module_vertical_position'];

        if ($settings['module_horizontal_position'] === 'left') {
            $wrapperClasses[] = 'thecore-accessibility-align-left';
        }

        return [
            'eyebrow' => (string) $settings['header_eyebrow_text'],
            'title' => (string) $settings['header_title_text'],
            'subtitle' => (string) $settings['header_subtitle_text'],
            'close_button_label' => (string) $settings['close_button_label'],
            'wrapper_classes' => $wrapperClasses,
            'sections' => $this->buildSections($settings),
            'footer_buttons' => $this->buildFooterButtons($settings),
            'skip_link' => [
                'enabled' => (bool) $settings['skip_link_enabled'],
                'label' => (string) $settings['skip_link_label'],
                'hidden' => (bool) $settings['skip_link_hidden'],
                'target_selector' => (string) $settings['skip_link_target_selector'],
                'mount_selector' => (string) $settings['skip_link_mount_selector'],
            ],
        ];
    }

    /**
     * @param array<string, bool|string> $settings
     *
     * @return array<int, array{title: string, items: array<int, array<string, string>>}>
     */
    private function buildSections(array $settings): array
    {
        $sections = [];

        foreach ($this->getSectionDefinitions() as $section) {
            $items = [];

            foreach ($section['items'] as $key => $definition) {
                if (empty($settings['feature_' . str_replace('-', '_', $key)])) {
                    continue;
                }

                $items[] = $this->makeActionButton(
                    $key,
                    (string) ($settings[$this->getFeatureLabelSettingName($key)] ?? $definition['label']),
                    $definition['icon']
                );
            }

            if ($items === []) {
                continue;
            }

            $sections[] = [
                'title' => (string) ($settings[$section['title_setting']] ?? $section['title']),
                'items' => $items,
            ];
        }

        return $sections;
    }

    /**
     * @param array<string, bool|string> $settings
     *
     * @return array<int, array<string, string>>
     */
    private function buildFooterButtons(array $settings): array
    {
        $buttons = [
            $this->makeActionButton(
                'reset',
                (string) $settings['reset_label'],
                'reset',
                'thecore-accessibility-toolbar-footer-button thecore-accessibility-toolbar-footer-button-primary'
            ),
        ];

        if ($settings['help_url'] !== '') {
            $buttons[] = $this->makeLinkButton(
                (string) $settings['help_url'],
                (string) $settings['help_label'],
                'help',
                'thecore-accessibility-toolbar-footer-button'
            );
        }

        if ($settings['feedback_url'] !== '') {
            $buttons[] = $this->makeLinkButton(
                (string) $settings['feedback_url'],
                (string) $settings['feedback_label'],
                'feedback',
                'thecore-accessibility-toolbar-footer-button'
            );
        }

        return $buttons;
    }

    /**
     * @return array<string, string>
     */
    private function getFeatureControlLabels(): array
    {
        return [
            'feature_bigger_text' => esc_html__('Bigger text', 'thecore-elementor-widgets'),
            'feature_bigger_line_height' => esc_html__('Bigger line height', 'thecore-elementor-widgets'),
            'feature_text_align' => esc_html__('Text align', 'thecore-elementor-widgets'),
            'feature_readable_font' => esc_html__('Readable font', 'thecore-elementor-widgets'),
            'feature_grayscale' => esc_html__('Greyscale', 'thecore-elementor-widgets'),
            'feature_contrast' => esc_html__('Contrast', 'thecore-elementor-widgets'),
            'feature_page_structure' => esc_html__('Page structure', 'thecore-elementor-widgets'),
            'feature_reading_mask' => esc_html__('Reading mask', 'thecore-elementor-widgets'),
            'feature_hide_images' => esc_html__('Hide images', 'thecore-elementor-widgets'),
            'feature_pause_animations' => esc_html__('Pause animations', 'thecore-elementor-widgets'),
            'feature_highlight_links' => esc_html__('Highlight links', 'thecore-elementor-widgets'),
            'feature_focus_outline' => esc_html__('Outline focus', 'thecore-elementor-widgets'),
        ];
    }

    private function getFeatureLabelSettingName(string $actionKey): string
    {
        return 'feature_' . str_replace('-', '_', $actionKey) . '_label';
    }

    /**
     * @return array<int, array{title: string, title_setting: string, items: array<string, array{label: string, icon: string}>}>
     */
    private function getSectionDefinitions(): array
    {
        return [
            [
                'title' => esc_html__('Content Adjustments', 'thecore-elementor-widgets'),
                'title_setting' => 'section_content_adjustments_title',
                'items' => [
                    'bigger-text' => ['label' => esc_html__('Bigger text', 'thecore-elementor-widgets'), 'icon' => 'bigger-text'],
                    'bigger-line-height' => ['label' => esc_html__('Bigger line height', 'thecore-elementor-widgets'), 'icon' => 'bigger-line-height'],
                    'text-align' => ['label' => esc_html__('Text align', 'thecore-elementor-widgets'), 'icon' => 'text-align'],
                    'readable-font' => ['label' => esc_html__('Readable font', 'thecore-elementor-widgets'), 'icon' => 'readable-font'],
                ],
            ],
            [
                'title' => esc_html__('Orientation Adjustments', 'thecore-elementor-widgets'),
                'title_setting' => 'section_orientation_adjustments_title',
                'items' => [
                    'page-structure' => ['label' => esc_html__('Page structure', 'thecore-elementor-widgets'), 'icon' => 'page-structure'],
                    'reading-mask' => ['label' => esc_html__('Reading mask', 'thecore-elementor-widgets'), 'icon' => 'reading-mask'],
                    'hide-images' => ['label' => esc_html__('Hide images', 'thecore-elementor-widgets'), 'icon' => 'hide-images'],
                    'pause-animations' => ['label' => esc_html__('Pause animations', 'thecore-elementor-widgets'), 'icon' => 'pause-animations'],
                    'highlight-links' => ['label' => esc_html__('Highlight links', 'thecore-elementor-widgets'), 'icon' => 'highlight-links'],
                    'focus-outline' => ['label' => esc_html__('Outline focus', 'thecore-elementor-widgets'), 'icon' => 'focus-outline'],
                ],
            ],
            [
                'title' => esc_html__('Color Adjustments', 'thecore-elementor-widgets'),
                'title_setting' => 'section_color_adjustments_title',
                'items' => [
                    'grayscale' => ['label' => esc_html__('Greyscale', 'thecore-elementor-widgets'), 'icon' => 'grayscale'],
                    'contrast' => ['label' => esc_html__('Contrast', 'thecore-elementor-widgets'), 'icon' => 'contrast'],
                ],
            ],
        ];
    }

    /**
     * @return array<string, string>
     */
    private function makeActionButton(string $action, string $label, string $icon, string $className = ''): array
    {
        return [
            'type' => 'action',
            'action' => $action,
            'label' => $label,
            'icon' => $icon,
            'class' => trim('thecore-accessibility-btn-' . sanitize_html_class($action) . ' ' . $className),
        ];
    }

    /**
     * @return array<string, string>
     */
    private function makeLinkButton(string $url, string $label, string $icon, string $className = ''): array
    {
        return [
            'type' => 'link',
            'url' => $url,
            'label' => $label,
            'icon' => $icon,
            'class' => trim($className),
        ];
    }

    private function shouldForceToolbarOpen(): bool
    {
        if (! class_exists(\Elementor\Plugin::class) || ! isset(\Elementor\Plugin::$instance)) {
            return false;
        }

        try {
            $plugin = \Elementor\Plugin::$instance;

            if (
                isset($plugin->editor)
                && is_object($plugin->editor)
                && method_exists($plugin->editor, 'is_edit_mode')
                && $plugin->editor->is_edit_mode()
            ) {
                return true;
            }

            if (
                isset($plugin->preview)
                && is_object($plugin->preview)
                && method_exists($plugin->preview, 'is_preview_mode')
            ) {
                return (bool) $plugin->preview->is_preview_mode();
            }
        } catch (\Throwable $exception) {
            return false;
        }

        return false;
    }
}
