<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Assets;

use TheCore\ElementorWidgets\Contracts\Bootable;
use TheCore\ElementorWidgets\Options\OptionsRepository;
use TheCore\ElementorWidgets\Registry\FeaturesRegistry;
use TheCore\ElementorWidgets\TChat\Support\ModuleSettings;

final class FrontendAssets implements Bootable
{
    public const FULLSCREEN_MENU_SCRIPT = 'thecore-fullscreen-menu';
    public const FULLSCREEN_MENU_STYLE = 'thecore-fullscreen-menu';
    public const MARQUEE_CAROUSEL_SCRIPT = 'thecore-marquee-carousel';
    public const MARQUEE_CAROUSEL_STYLE = 'thecore-marquee-carousel';
    public const MARQUEE_BANNER_LEGACY_SCRIPT = 'thecore-marquee-banner-legacy';
    public const MARQUEE_BANNER_LEGACY_STYLE = 'thecore-marquee-banner-legacy';
    public const HEADER_MENU_LEGACY_SCRIPT = 'thecore-header-menu-legacy';
    public const HEADER_MENU_LEGACY_STYLE = 'thecore-header-menu-legacy';
    public const SEARCH_MODAL_LEGACY_SCRIPT = 'thecore-search-modal-legacy';
    public const SEARCH_MODAL_LEGACY_STYLE = 'thecore-search-modal-legacy';
    public const ACCESSIBILITY_LEGACY_SCRIPT = 'thecore-accessibility-legacy';
    public const ACCESSIBILITY_LEGACY_STYLE = 'thecore-accessibility-legacy';
    public const COOKIE_CONSENT_SCRIPT = 'thecore-cookie-consent';
    public const COOKIE_CONSENT_STYLE = 'thecore-cookie-consent';
    public const TCHAT_WIDGET_SCRIPT = 'thecore-tchat-widget';
    public const TCHAT_WIDGET_STYLE = 'thecore-tchat-widget';

    private static bool $criticalModalCssRendered = false;
    private bool $stylesRegistered = false;
    private bool $scriptsRegistered = false;

    public function __construct(
        private readonly OptionsRepository $optionsRepository,
        private readonly FeaturesRegistry $featuresRegistry
    ) {
    }

    public function register(): void
    {
        add_action('wp_enqueue_scripts', [$this, 'registerStyles']);
        add_action('wp_enqueue_scripts', [$this, 'registerScripts']);
        add_action('elementor/editor/before_enqueue_styles', [$this, 'registerStyles']);
        add_action('elementor/editor/before_enqueue_scripts', [$this, 'registerScripts']);
        add_action('elementor/atomic-widgets/frontend/loader/scripts/register', [$this, 'registerScripts']);
    }

    public function registerStyles(): void
    {
        if ($this->stylesRegistered) {
            return;
        }

        wp_register_style(
            self::FULLSCREEN_MENU_STYLE,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/fullscreen-menu.css',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION
        );

        wp_register_style(
            self::MARQUEE_CAROUSEL_STYLE,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/marquee-carousel.css',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION
        );

        wp_register_style(
            self::MARQUEE_BANNER_LEGACY_STYLE,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/marquee-banner-legacy.css',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION
        );

        wp_register_style(
            self::HEADER_MENU_LEGACY_STYLE,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/header-menu-legacy.css',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION
        );

        wp_register_style(
            self::SEARCH_MODAL_LEGACY_STYLE,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/search-modal-legacy.css',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION
        );

        wp_register_style(
            self::ACCESSIBILITY_LEGACY_STYLE,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/accessibility-legacy.css',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION
        );

        wp_register_style(
            self::COOKIE_CONSENT_STYLE,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/cookie-consent.css',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION
        );

        wp_register_style(
            self::TCHAT_WIDGET_STYLE,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/tchat-widget.css',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION
        );

        $this->stylesRegistered = true;
    }

    public function registerScripts(mixed $loader = null): void
    {
        if ($this->scriptsRegistered) {
            return;
        }

        wp_register_script(
            self::FULLSCREEN_MENU_SCRIPT,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/fullscreen-menu.js',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION,
            true
        );

        wp_add_inline_script(
            self::FULLSCREEN_MENU_SCRIPT,
            $this->buildFullscreenMenuConfigScript(),
            'before'
        );

        wp_register_script(
            self::MARQUEE_CAROUSEL_SCRIPT,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/marquee-carousel.js',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION,
            true
        );

        wp_register_script(
            self::MARQUEE_BANNER_LEGACY_SCRIPT,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/marquee-banner-legacy.js',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION,
            true
        );

        wp_register_script(
            self::HEADER_MENU_LEGACY_SCRIPT,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/header-menu-legacy.js',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION,
            true
        );

        wp_register_script(
            self::SEARCH_MODAL_LEGACY_SCRIPT,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/search-modal-legacy.js',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION,
            true
        );

        wp_register_script(
            self::ACCESSIBILITY_LEGACY_SCRIPT,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/accessibility-legacy.js',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION,
            true
        );

        wp_register_script(
            self::COOKIE_CONSENT_SCRIPT,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/cookie-consent.js',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION,
            true
        );

        wp_register_script(
            self::TCHAT_WIDGET_SCRIPT,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/tchat-widget.js',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION,
            true
        );

        wp_add_inline_script(
            self::ACCESSIBILITY_LEGACY_SCRIPT,
            'window.TheCoreElementorWidgetsAccessibilityConfig = ' . wp_json_encode(
                [
                    'openHash' => '#thecore-accessibility-open',
                    'toggleHash' => '#thecore-accessibility-toggle',
                    'storageKey' => 'thecore-elementor-widgets-accessibility',
                    'removeLinkTarget' => false,
                    'addRoleLinks' => false,
                    'alwaysFocusable' => false,
                    'enableSave' => true,
                    'saveExpirationHours' => 12,
                ]
            ) . ';',
            'before'
        );

        wp_add_inline_script(
            self::COOKIE_CONSENT_SCRIPT,
            'window.TheCoreElementorWidgetsCookieConsentConfig = ' . wp_json_encode(
                [
                    'cookieName' => \TheCore\ElementorWidgets\CookieConsent\CookieConsentModule::COOKIE_NAME,
                    'secure' => is_ssl(),
                ]
            ) . ';',
            'before'
        );

        wp_localize_script(
            self::SEARCH_MODAL_LEGACY_SCRIPT,
            'TheCoreElementorWidgetsSearchModal',
            [
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce(\TheCore\ElementorWidgets\Search\SearchModalAjaxHandler::NONCE_ACTION),
                'action' => \TheCore\ElementorWidgets\Search\SearchModalAjaxHandler::ACTION,
            ]
        );

        wp_localize_script(
            self::TCHAT_WIDGET_SCRIPT,
            'TCHAT_SETTINGS',
            [
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('tchat_nonce'),
                'restNonce' => wp_create_nonce('wp_rest'),
                'restUrl' => rest_url('tchat/v1'),
                'userName' => is_user_logged_in() ? wp_get_current_user()->display_name : null,
                'transport' => ModuleSettings::getFrontendSettings(),
            ]
        );

        $this->scriptsRegistered = true;
    }

    private function buildFullscreenMenuConfigScript(): string
    {
        $featureState = $this->optionsRepository->getFeaturesState($this->featuresRegistry->defaults());

        return 'window.TheCoreElementorWidgetsConfig = ' . wp_json_encode(
            [
                'features' => [
                    'overlayScrollLock' => ! empty($featureState['overlay-scroll-lock']),
                ],
                'bodyLockClass' => 'thecore-elementor-widgets-lock-scroll',
            ]
        ) . ';';
    }

    public static function renderCriticalModalCss(): void
    {
        if (self::$criticalModalCssRendered) {
            return;
        }

        self::$criticalModalCssRendered = true;

        echo '<style id="thecore-critical-modal-css">#thecore-accessibility-toolbar.thecore-accessibility-toolbar-without-toggle:not(.thecore-accessibility-toolbar-open):not(.thecore-accessibility-toolbar-preview-open){visibility:hidden;opacity:0;pointer-events:none}#thecore-tchat-dialog[aria-hidden="true"]{visibility:hidden;opacity:0;pointer-events:none}</style>';
    }
}
