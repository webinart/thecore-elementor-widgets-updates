<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\IconText;

use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Number_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Select_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Size_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Text_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Textarea_Control;
use Elementor\Modules\AtomicWidgets\DynamicTags\Dynamic_Prop_Type;
use Elementor\Modules\AtomicWidgets\Elements\Base\Atomic_Widget_Base;
use Elementor\Modules\AtomicWidgets\Elements\Base\Has_Template;
use Elementor\Modules\AtomicWidgets\PropTypes\Attributes_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Classes_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Color_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Dimensions_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Number_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Size_Prop_Type;
use Elementor\Modules\AtomicWidgets\Styles\Style_Definition;
use Elementor\Modules\AtomicWidgets\Styles\Style_Variant;
use Elementor\Modules\Components\PropTypes\Overridable_Prop_Type;
use TheCore\ElementorWidgets\Elementor\Atomic\Controls\Types\ColorControl;
use TheCore\ElementorWidgets\Elementor\Atomic\Controls\Types\FontFamilyControl;
use TheCore\ElementorWidgets\Elementor\Atomic\Controls\Types\ZeroDefaultSizeControl;
use TheCore\ElementorWidgets\Elementor\Atomic\PropTypes\ZeroableSizePropType;

final class IconText extends Atomic_Widget_Base
{
    use Has_Template;

    public static $widget_description = 'Accessible atomic element that renders one decorative icon next to editable text.';

    public static function get_element_type(): string
    {
        return 'thecore-icon-text';
    }

    public function get_title(): string
    {
        return esc_html__('Icon Text', 'thecore-elementor-widgets');
    }

    public function get_icon(): string
    {
        return 'eicon-icon-box';
    }

    public function get_keywords(): array
    {
        return ['icon', 'text', 'inline', 'atomic'];
    }

    protected static function define_props_schema(): array
    {
        return [
            'classes' => Classes_Prop_Type::make()->default([]),
            'text' => String_Prop_Type::make()
                ->default(DisplaySettings::DEFAULT_TEXT)
                ->meta(Dynamic_Prop_Type::ignore())
                ->meta(Overridable_Prop_Type::ignore()),
            'html_tag' => String_Prop_Type::make()
                ->enum(['div', 'p', 'span'])
                ->default(DisplaySettings::DEFAULT_HTML_TAG)
                ->meta(Dynamic_Prop_Type::ignore())
                ->meta(Overridable_Prop_Type::ignore()),
            'icon_type' => String_Prop_Type::make()
                ->enum(['glyph', 'svg'])
                ->default(DisplaySettings::DEFAULT_ICON_TYPE)
                ->meta(Dynamic_Prop_Type::ignore())
                ->meta(Overridable_Prop_Type::ignore()),
            'icon_glyph' => String_Prop_Type::make()
                ->default(DisplaySettings::DEFAULT_ICON_GLYPH)
                ->meta(Dynamic_Prop_Type::ignore())
                ->meta(Overridable_Prop_Type::ignore()),
            'icon_svg' => String_Prop_Type::make()
                ->default(DisplaySettings::DEFAULT_ICON_SVG)
                ->meta(Dynamic_Prop_Type::ignore())
                ->meta(Overridable_Prop_Type::ignore()),
            'icon_position' => String_Prop_Type::make()
                ->enum(['before', 'after'])
                ->default(DisplaySettings::DEFAULT_ICON_POSITION)
                ->meta(Dynamic_Prop_Type::ignore())
                ->meta(Overridable_Prop_Type::ignore()),
            'alignment' => String_Prop_Type::make()
                ->enum(['flex-start', 'center', 'flex-end'])
                ->default(DisplaySettings::DEFAULT_ALIGNMENT)
                ->meta(Dynamic_Prop_Type::ignore())
                ->meta(Overridable_Prop_Type::ignore()),
            'vertical_alignment' => String_Prop_Type::make()
                ->enum(['flex-start', 'center', 'flex-end', 'baseline'])
                ->default(DisplaySettings::DEFAULT_VERTICAL_ALIGNMENT)
                ->meta(Dynamic_Prop_Type::ignore())
                ->meta(Overridable_Prop_Type::ignore()),
            'gap' => Number_Prop_Type::make()->default(DisplaySettings::DEFAULT_GAP),
            'icon_color' => Color_Prop_Type::make()->default(DisplaySettings::DEFAULT_ICON_COLOR),
            'icon_background_color' => Color_Prop_Type::make()->default(DisplaySettings::DEFAULT_ICON_BACKGROUND_COLOR),
            'icon_box_width' => Size_Prop_Type::make()
                ->units(['px', 'em', 'rem'])
                ->default_unit('px')
                ->default(DisplaySettings::DEFAULT_ICON_BOX_WIDTH),
            'icon_box_ratio' => Number_Prop_Type::make()->default(DisplaySettings::DEFAULT_ICON_BOX_RATIO),
            'icon_size' => Size_Prop_Type::make()
                ->units(['px', 'em', 'rem'])
                ->default_unit('px')
                ->default(DisplaySettings::DEFAULT_ICON_SIZE),
            'icon_padding' => Number_Prop_Type::make()->default(DisplaySettings::DEFAULT_ICON_PADDING),
            'icon_radius' => Number_Prop_Type::make()->default(DisplaySettings::DEFAULT_ICON_RADIUS),
            'text_color' => Color_Prop_Type::make()->default(DisplaySettings::DEFAULT_TEXT_COLOR),
            'font_family' => String_Prop_Type::make()->default(DisplaySettings::DEFAULT_FONT_FAMILY),
            'font_size' => Size_Prop_Type::make()
                ->units(['px', 'em', 'rem'])
                ->default_unit('px')
                ->default(DisplaySettings::DEFAULT_FONT_SIZE),
            'font_weight' => String_Prop_Type::make()->enum(self::fontWeightValues())->default(DisplaySettings::DEFAULT_FONT_WEIGHT),
            'line_height' => Size_Prop_Type::make()
                ->units(['em', 'px', 'rem'])
                ->default_unit('em')
                ->default(DisplaySettings::DEFAULT_LINE_HEIGHT),
            'letter_spacing' => ZeroableSizePropType::make()
                ->units(['px', 'em', 'rem'])
                ->default_unit('px')
                ->meta(Dynamic_Prop_Type::ignore())
                ->meta(Overridable_Prop_Type::ignore())
                ->initial_value(DisplaySettings::DEFAULT_LETTER_SPACING)
                ->default(DisplaySettings::DEFAULT_LETTER_SPACING),
            'text_transform' => String_Prop_Type::make()->enum(self::textTransformValues())->default(DisplaySettings::DEFAULT_TEXT_TRANSFORM),
            'attributes' => Attributes_Prop_Type::make()->meta(Overridable_Prop_Type::ignore()),
        ];
    }

    protected function define_base_styles(): array
    {
        $zeroSize = Size_Prop_Type::generate([
            'size' => 0,
            'unit' => 'px',
        ]);

        $spacingValue = Dimensions_Prop_Type::generate([
            'block-start' => $zeroSize,
            'inline-end' => $zeroSize,
            'block-end' => $zeroSize,
            'inline-start' => $zeroSize,
        ]);

        return [
            'base' => Style_Definition::make()
                ->add_variant(
                    Style_Variant::make()
                        ->add_prop('padding', $spacingValue)
                        ->add_prop('margin', $spacingValue)
                ),
        ];
    }

    protected function define_atomic_controls(): array
    {
        return [
            Section::make()
                ->set_label(__('Content', 'thecore-elementor-widgets'))
                ->set_items([
                    Textarea_Control::bind_to('text')
                        ->set_label(__('Text', 'thecore-elementor-widgets')),
                    Select_Control::bind_to('html_tag')
                        ->set_label(__('HTML tag', 'thecore-elementor-widgets'))
                        ->set_options([
                            ['label' => 'div', 'value' => 'div'],
                            ['label' => 'p', 'value' => 'p'],
                            ['label' => 'span', 'value' => 'span'],
                        ]),
                    Select_Control::bind_to('icon_type')
                        ->set_label(__('Icon type', 'thecore-elementor-widgets'))
                        ->set_options([
                            [
                                'label' => __('Glyph / text', 'thecore-elementor-widgets'),
                                'value' => 'glyph',
                            ],
                            [
                                'label' => __('Inline SVG', 'thecore-elementor-widgets'),
                                'value' => 'svg',
                            ],
                        ]),
                    Text_Control::bind_to('icon_glyph')
                        ->set_label(__('Icon glyph', 'thecore-elementor-widgets'))
                        ->set_description(__('Used when Icon type is Glyph / text.', 'thecore-elementor-widgets')),
                    Textarea_Control::bind_to('icon_svg')
                        ->set_label(__('Inline SVG', 'thecore-elementor-widgets'))
                        ->set_description(__('Paste a simple SVG. Scripts and unsafe tags are stripped on render.', 'thecore-elementor-widgets')),
                    Select_Control::bind_to('icon_position')
                        ->set_label(__('Icon position', 'thecore-elementor-widgets'))
                        ->set_options([
                            [
                                'label' => __('Before text', 'thecore-elementor-widgets'),
                                'value' => 'before',
                            ],
                            [
                                'label' => __('After text', 'thecore-elementor-widgets'),
                                'value' => 'after',
                            ],
                        ]),
                ]),
            Section::make()
                ->set_label(__('Layout', 'thecore-elementor-widgets'))
                ->set_items([
                    Select_Control::bind_to('alignment')
                        ->set_label(__('Horizontal alignment', 'thecore-elementor-widgets'))
                        ->set_options([
                            [
                                'label' => __('Start', 'thecore-elementor-widgets'),
                                'value' => 'flex-start',
                            ],
                            [
                                'label' => __('Center', 'thecore-elementor-widgets'),
                                'value' => 'center',
                            ],
                            [
                                'label' => __('End', 'thecore-elementor-widgets'),
                                'value' => 'flex-end',
                            ],
                        ]),
                    Select_Control::bind_to('vertical_alignment')
                        ->set_label(__('Vertical alignment', 'thecore-elementor-widgets'))
                        ->set_options([
                            [
                                'label' => __('Start', 'thecore-elementor-widgets'),
                                'value' => 'flex-start',
                            ],
                            [
                                'label' => __('Center', 'thecore-elementor-widgets'),
                                'value' => 'center',
                            ],
                            [
                                'label' => __('End', 'thecore-elementor-widgets'),
                                'value' => 'flex-end',
                            ],
                            [
                                'label' => __('Baseline', 'thecore-elementor-widgets'),
                                'value' => 'baseline',
                            ],
                        ]),
                    Number_Control::bind_to('gap')
                        ->set_label(__('Gap (px)', 'thecore-elementor-widgets'))
                        ->set_min(0)
                        ->set_max(100)
                        ->set_step(1)
                        ->set_should_force_int(true),
                ]),
            Section::make()
                ->set_label(__('Icon style', 'thecore-elementor-widgets'))
                ->set_items([
                    ColorControl::bind_to('icon_color')
                        ->set_label(__('Icon color', 'thecore-elementor-widgets')),
                    ColorControl::bind_to('icon_background_color')
                        ->set_label(__('Icon background', 'thecore-elementor-widgets')),
                    Size_Control::bind_to('icon_box_width')
                        ->set_label(__('Icon container width', 'thecore-elementor-widgets'))
                        ->set_units(['px', 'em', 'rem'])
                        ->set_default_unit('px')
                        ->set_disable_custom(true),
                    Number_Control::bind_to('icon_box_ratio')
                        ->set_label(__('Icon container ratio', 'thecore-elementor-widgets'))
                        ->set_min(0.25)
                        ->set_max(4)
                        ->set_step(0.05)
                        ->set_description(__('Width / height ratio. Use 1 for a square, 1.5 for a wide thumbnail.', 'thecore-elementor-widgets')),
                    Size_Control::bind_to('icon_size')
                        ->set_label(__('Inner icon size', 'thecore-elementor-widgets'))
                        ->set_units(['px', 'em', 'rem'])
                        ->set_default_unit('px')
                        ->set_disable_custom(true),
                    Number_Control::bind_to('icon_padding')
                        ->set_label(__('Icon padding (px)', 'thecore-elementor-widgets'))
                        ->set_min(0)
                        ->set_max(80)
                        ->set_step(1)
                        ->set_should_force_int(true),
                    Number_Control::bind_to('icon_radius')
                        ->set_label(__('Icon radius (px)', 'thecore-elementor-widgets'))
                        ->set_min(0)
                        ->set_max(120)
                        ->set_step(1)
                        ->set_should_force_int(true),
                ]),
            Section::make()
                ->set_label(__('Text style', 'thecore-elementor-widgets'))
                ->set_items([
                    ColorControl::bind_to('text_color')
                        ->set_label(__('Text color', 'thecore-elementor-widgets')),
                    FontFamilyControl::bind_to('font_family')
                        ->set_label(__('Font family', 'thecore-elementor-widgets')),
                    Size_Control::bind_to('font_size')
                        ->set_label(__('Font size', 'thecore-elementor-widgets'))
                        ->set_units(['px', 'em', 'rem'])
                        ->set_default_unit('px')
                        ->set_disable_custom(true),
                    Select_Control::bind_to('font_weight')
                        ->set_label(__('Font weight', 'thecore-elementor-widgets'))
                        ->set_options(self::fontWeightOptions()),
                    Size_Control::bind_to('line_height')
                        ->set_label(__('Line height', 'thecore-elementor-widgets'))
                        ->set_units(['em', 'px', 'rem'])
                        ->set_default_unit('em')
                        ->set_disable_custom(true),
                    ZeroDefaultSizeControl::bind_to('letter_spacing')
                        ->set_label(__('Letter spacing', 'thecore-elementor-widgets'))
                        ->set_units(['px', 'em', 'rem'])
                        ->set_default_unit('px')
                        ->set_disable_custom(true),
                    Select_Control::bind_to('text_transform')
                        ->set_label(__('Text transform', 'thecore-elementor-widgets'))
                        ->set_options(self::textTransformOptions()),
                ]),
            Section::make()
                ->set_label(__('Settings', 'thecore-elementor-widgets'))
                ->set_id('settings')
                ->set_items([
                    Text_Control::bind_to('_cssid')
                        ->set_label(__('ID', 'thecore-elementor-widgets'))
                        ->set_meta($this->get_css_id_control_meta()),
                ]),
        ];
    }

    protected function get_templates(): array
    {
        return [
            'thecore/elements/icon-text' => __DIR__ . '/icon-text.html.twig',
        ];
    }

    protected function render()
    {
        $atomicSettings = $this->get_atomic_settings();
        $settings = (new DisplaySettings())->normalize($atomicSettings);
        $markup = (new MarkupBuilder())->build($settings);

        if ('' === $markup) {
            return;
        }

        $cssId = trim((string) $this->get_atomic_setting('_cssid'));
        $scope = $this->buildScopeValue();
        $scopeSelector = '[data-thecore-icon-text-scope="' . $scope . '"]';
        $styleMarkup = (new InlineStylesBuilder())->build($scopeSelector, $settings);
        $classes = array_filter(array_merge(
            ['thecore-icon-text', $this->get_base_styles_dictionary()['base'] ?? ''],
            is_array($atomicSettings['classes'] ?? null) ? $atomicSettings['classes'] : []
        ));
        $attributes = [
            'class' => implode(' ', array_unique($classes)),
            'data-thecore-icon-text' => 'true',
            'data-thecore-icon-text-scope' => $scope,
        ];

        if ('' !== $cssId) {
            $attributes['id'] = $cssId;
        }

        echo '<style>' . $styleMarkup . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo '<div' . $this->buildAttributes($attributes) . '>';
        echo $markup; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo '</div>';
    }

    /**
     * @return array<int, array{label: string, value: string}>
     */
    private static function fontWeightOptions(): array
    {
        return array_map(
            static fn (string $value): array => [
                'label' => $value,
                'value' => $value,
            ],
            self::fontWeightValues()
        );
    }

    /**
     * @return array<int, string>
     */
    private static function fontWeightValues(): array
    {
        return ['100', '200', '300', '400', '500', '600', '700', '800', '900'];
    }

    /**
     * @return array<int, array{label: string, value: string}>
     */
    private static function textTransformOptions(): array
    {
        return [
            [
                'label' => __('None', 'thecore-elementor-widgets'),
                'value' => 'none',
            ],
            [
                'label' => __('Uppercase', 'thecore-elementor-widgets'),
                'value' => 'uppercase',
            ],
            [
                'label' => __('Lowercase', 'thecore-elementor-widgets'),
                'value' => 'lowercase',
            ],
            [
                'label' => __('Capitalize', 'thecore-elementor-widgets'),
                'value' => 'capitalize',
            ],
        ];
    }

    /**
     * @return array<int, string>
     */
    private static function textTransformValues(): array
    {
        return ['none', 'uppercase', 'lowercase', 'capitalize'];
    }

    private function buildScopeValue(): string
    {
        return 'thecore-icon-text-' . sanitize_html_class($this->get_id());
    }

    /**
     * @param array<string, string> $attributes
     */
    private function buildAttributes(array $attributes): string
    {
        $markup = '';

        foreach ($attributes as $name => $value) {
            $markup .= sprintf(
                ' %s="%s"',
                esc_attr($name),
                esc_attr($value)
            );
        }

        return $markup;
    }
}
