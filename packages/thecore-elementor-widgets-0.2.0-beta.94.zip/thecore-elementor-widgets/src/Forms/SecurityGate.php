<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms;

use TheCore\ElementorWidgets\FormSecurity\Infrastructure\Installer;
use TheCore\ElementorWidgets\FormSecurity\Infrastructure\SecurityStore;
use TheCore\ElementorWidgets\FormSecurity\Security\AltchaService;
use TheCore\ElementorWidgets\FormSecurity\Support\ChallengeContext;
use TheCore\ElementorWidgets\FormSecurity\Support\ClientIdentity;
use TheCore\ElementorWidgets\FormSecurity\Support\FormContext;
use TheCore\ElementorWidgets\FormSecurity\Support\OriginPolicy;
use TheCore\ElementorWidgets\FormSecurity\Support\Secrets;
use TheCore\ElementorWidgets\FormSecurity\Support\SecuritySettings;

final class SecurityGate implements SubmissionProtection
{
    public function __construct(
        private readonly SecurityStore $store,
        private readonly SecuritySettings $settings,
        private readonly AltchaService $altcha,
        private readonly bool $enabled
    ) {
    }

    public function check(FormContext $context, array $request): void
    {
        if (! $this->enabled || ! Installer::isOperationallyReady()) {
            throw new SubmissionException('security_unavailable', 'Protection indisponible. Veuillez reessayer plus tard.', 503);
        }
        if (! (new OriginPolicy())->isAllowed($_SERVER, home_url('/'))) {
            throw new SubmissionException('origin_forbidden', 'Requete non autorisee.', 403);
        }
        $client = (new ClientIdentity(Secrets::privacy()))->hash($_SERVER);
        $this->rate($client, 'attempt', $this->settings->attemptRateWindow(), $this->settings->attemptRateLimit());
        if (! is_string($request['website'] ?? '') || ($request['website'] ?? '') !== '') {
            throw new SubmissionException('spam_rejected', 'La verification anti-spam a echoue.', 403);
        }
        $proof = $request['proof'] ?? '';
        if (! is_string($proof) || strlen($proof) > 16384) {
            throw new SubmissionException('proof_invalid', 'Controle anti-spam invalide.', 403);
        }
        $verification = $this->altcha->verifyPayload($proof, ChallengeContext::forForm($context));
        if (
            $verification['status'] !== 'valid' || ! is_string($verification['replayKey'])
            || ! is_int($verification['expiresAt'])
        ) {
            throw new SubmissionException('proof_invalid', 'Veuillez relancer la verification anti-spam.', 403);
        }
        $consumed = $this->store->consumeReplay($verification['replayKey'], $verification['expiresAt'], time());
        if ($consumed !== 'consumed') {
            throw new SubmissionException('proof_replayed', 'Verification expiree ou deja utilisee.', $consumed === 'replay' ? 409 : 503);
        }
        $this->rate($client, 'submission', $this->settings->submissionRateWindow(), $this->settings->submissionRateLimit());
    }

    public function reserve(FormContext $context, array $values, ?string $testRun): void
    {
        $fingerprint = hash_hmac('sha256', 'atomic-v1|' . $context->fingerprint()
            . '|' . ($testRun ?? 'live') . '|' . wp_json_encode($values), Secrets::privacy());
        $status = $this->store->acquireDeduplication($fingerprint, $this->settings->deduplicationTtl(), time());
        if ($status !== 'acquired') {
            throw new SubmissionException('submission_duplicate', 'Envoi deja traite ou en cours. Veuillez patienter avant de reessayer.', $status === 'duplicate' ? 409 : 503);
        }
    }

    private function rate(string $client, string $purpose, int $window, int $limit): void
    {
        $status = $this->store->consumeRateLimit($purpose, $client, $window, $limit, time());
        if ($status !== 'allowed') {
            throw new SubmissionException('rate_limited', 'Veuillez patienter avant de reessayer.', $status === 'limited' ? 429 : 503);
        }
    }
}
