<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\MailPoet;

use TheCore\ElementorWidgets\Forms\SubmissionException;
use Throwable;
use UnexpectedValueException;

/** Only MailPoet's public API; no internal models or direct table writes. */
final class MailPoetClient implements MailPoetGateway
{
    private const OPTIONS = ['send_confirmation_email' => true, 'schedule_welcome_email' => true,
        'skip_subscriber_notification' => false];

    public function __construct(private ?object $api = null)
    {
    }

    public function lists(): array
    {
        return $this->request('getLists');
    }

    public function fields(): array
    {
        return $this->request('getSubscriberFields');
    }

    public function subscriber(string $email): ?array
    {
        return $this->request('getSubscriber', [$email], 4);
    }

    public function add(array $subscriber, array $lists): bool
    {
        return $this->request('addSubscriber', [$subscriber, $lists, self::OPTIONS], 12) !== null;
    }

    public function subscribe(string $email, array $lists): void
    {
        $this->request('subscribeToLists', [$email, $lists, self::OPTIONS]);
    }

    public static function activeLists(array $lists): array
    {
        $result = [];
        foreach ($lists as $list) {
            if (
                is_array($list) && ($list['type'] ?? '') === 'default' && empty($list['deleted_at'])
                && preg_match('/\A[1-9][0-9]{0,10}\z/', (string) ($list['id'] ?? ''))
                && is_string($list['name'] ?? null)
            ) {
                $result[(int) $list['id']] = $list['name'];
            }
        }
        return $result;
    }

    private function request(string $method, array $args = [], ?int $allowedError = null): ?array
    {
        try {
            if ($this->api === null) {
                if (! is_callable(['MailPoet\\API\\API', 'MP'])) {
                    throw new SubmissionException('mailpoet_unavailable', 'Le service newsletter MailPoet est indisponible.', 503);
                }
                $this->api = \MailPoet\API\API::MP('v1');
            }
            $result = $this->api->$method(...$args);
            if (! is_array($result)) {
                throw new UnexpectedValueException('Unexpected MailPoet response.');
            }
            if (in_array($method, ['getSubscriber', 'addSubscriber', 'subscribeToLists'], true) && empty($result['id'])) {
                throw new UnexpectedValueException('MailPoet subscriber missing from response.');
            }
            return $result;
        } catch (Throwable $error) {
            if ($error instanceof SubmissionException) {
                throw $error;
            }
            if (is_a($error, 'MailPoet\\API\\MP\\v1\\APIException') && $error->getCode() === $allowedError) {
                return null;
            }
            // API exception messages can contain subscriber data; never expose them.
            throw new SubmissionException('mailpoet_failed', 'L\'inscription newsletter n\'a pas pu etre confirmee. Veuillez contacter le site.', 503);
        }
    }
}
