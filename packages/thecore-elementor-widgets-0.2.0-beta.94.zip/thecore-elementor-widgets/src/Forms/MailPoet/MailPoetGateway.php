<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\MailPoet;

interface MailPoetGateway
{
    public function lists(): array;

    public function fields(): array;

    public function subscriber(string $email): ?array;

    /** Returns false only when an existing subscriber raced with creation. */
    public function add(array $subscriber, array $lists): bool;

    public function subscribe(string $email, array $lists): void;
}
