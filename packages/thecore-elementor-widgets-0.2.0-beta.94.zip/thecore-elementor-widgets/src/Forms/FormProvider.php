<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms;

interface FormProvider
{
    public function find(int $postId, string $formId): FormDefinition;
}
