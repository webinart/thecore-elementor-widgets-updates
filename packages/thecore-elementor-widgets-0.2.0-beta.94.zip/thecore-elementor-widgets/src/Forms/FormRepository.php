<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms;

final class FormRepository implements FormProvider
{
    public function find(int $postId, string $formId): FormDefinition
    {
        $post = get_post($postId);
        if (
            ! $post || $post->post_status !== 'publish' || $post->post_password !== ''
            || ! class_exists('\Elementor\Plugin')
        ) {
            throw new ConfigurationException('Form document unavailable.');
        }
        $document = \Elementor\Plugin::$instance->documents->get($postId);
        if (! $document) {
            throw new ConfigurationException('Form document unavailable.');
        }
        $element = \Elementor\Utils::find_element_recursive($document->get_elements_data(), $formId);
        if (! is_array($element)) {
            throw new ConfigurationException('Form not found.');
        }
        return FormDefinition::fromElement($element);
    }
}
