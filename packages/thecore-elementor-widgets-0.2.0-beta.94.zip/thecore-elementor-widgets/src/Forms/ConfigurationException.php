<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms;

final class ConfigurationException extends \RuntimeException
{
}
