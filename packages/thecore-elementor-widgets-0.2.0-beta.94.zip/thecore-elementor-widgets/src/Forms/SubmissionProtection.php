<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms;

use TheCore\ElementorWidgets\FormSecurity\Support\FormContext;

interface SubmissionProtection
{
    public function check(FormContext $context, array $request): void;

    public function reserve(FormContext $context, array $values, ?string $testRun): void;
}
