<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms;

use TheCore\ElementorWidgets\Contracts\Bootable;
use TheCore\ElementorWidgets\Elementor\Atomic\Elements\Form\Form;
use TheCore\ElementorWidgets\FormSecurity\Assets;
use TheCore\ElementorWidgets\FormSecurity\Infrastructure\SecurityStore;
use TheCore\ElementorWidgets\FormSecurity\Http\ChallengeController;
use TheCore\ElementorWidgets\FormSecurity\Security\AltchaService;
use TheCore\ElementorWidgets\FormSecurity\Support\ContextToken;
use TheCore\ElementorWidgets\FormSecurity\Support\ClientIdentity;
use TheCore\ElementorWidgets\FormSecurity\Support\Metrics;
use TheCore\ElementorWidgets\FormSecurity\Support\OriginPolicy;
use TheCore\ElementorWidgets\FormSecurity\Support\Secrets;
use TheCore\ElementorWidgets\FormSecurity\Support\SecuritySettings;
use TheCore\ElementorWidgets\Support\RequirementsChecker;

final class FormsModule implements Bootable
{
    public const SCRIPT = 'thecore-atomic-form';
    public const CHALLENGE_ROUTE = '/forms/challenge';

    public function __construct(private readonly bool $securityEnabled)
    {
    }

    public function register(): void
    {
        $uri = isset($_SERVER['REQUEST_URI']) && is_string($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
        $route = isset($_GET['rest_route']) && is_string($_GET['rest_route']) ? $_GET['rest_route'] : '';
        if (
            str_contains(rawurldecode($uri), Controller::NAMESPACE . '/forms/')
            || str_starts_with($route, '/' . Controller::NAMESPACE . '/forms/')
        ) {
            if (! defined('DONOTCACHEPAGE')) {
                define('DONOTCACHEPAGE', true);
            }
        }
        add_action('elementor/elements/elements_registered', [$this, 'registerElement']);
        add_action('wp_enqueue_scripts', [$this, 'registerAssets'], 6);
        add_action('elementor/editor/before_enqueue_scripts', [$this, 'registerAssets'], 6);
        add_action('rest_api_init', [$this, 'registerRoutes']);
    }

    public function registerElement(object $manager): void
    {
        if (
            (new RequirementsChecker())->canRegisterAtomicWidgets()
            && class_exists('\ElementorPro\Modules\AtomicForm\Input\Input')
            && class_exists('\Elementor\Modules\AtomicWidgets\Elements\Base\Atomic_Element_Base')
            && method_exists($manager, 'register_element_type')
        ) {
            $manager->register_element_type(new Form());
        }
    }

    public function registerAssets(): void
    {
        if (! $this->securityEnabled) {
            // Share the solver, without enabling the optional classic-form integration.
            (new Assets())->registerAssets();
        }
        wp_register_script(self::SCRIPT, THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/atomic-form.js', [Assets::PBKDF2_SCRIPT], THECORE_ELEMENTOR_WIDGETS_VERSION, true);
        wp_register_style(self::SCRIPT, THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/atomic-form.css', [], THECORE_ELEMENTOR_WIDGETS_VERSION);
    }

    public function registerRoutes(): void
    {
        $settings = new SecuritySettings();
        $store = new SecurityStore();
        $altcha = new AltchaService(
            Secrets::challengeSigning(),
            Secrets::challengeKeySigning(),
            $settings->altchaCost(),
            $settings->counterMinimum(),
            $settings->counterMaximum(),
            $settings->challengeMinimumSeconds(),
            $settings->challengeMaximumSeconds()
        );
        $service = new SubmissionService(
            new FormRepository(),
            new SecurityGate($store, $settings, $altcha, true),
            new CustomerAgentBridge($store),
            new ContextToken(Secrets::contextSigning())
        );
        (new Controller($service))->register();
        $challenge = new ChallengeController(
            new ContextToken(Secrets::contextSigning()),
            new OriginPolicy(),
            new ClientIdentity(Secrets::privacy()),
            $store,
            $altcha,
            $settings,
            new Metrics()
        );
        register_rest_route(Controller::NAMESPACE, self::CHALLENGE_ROUTE, [
            'methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => [$challenge, 'serve'],
        ]);
    }
}
