<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms;

use Throwable;
use WP_REST_Request;
use WP_REST_Response;

final class Controller
{
    public const NAMESPACE = 'thecore-elementor-widgets/v1';
    public const ROUTE = '/forms/submit';
    public const MAX_BYTES = 131072;

    public function __construct(private readonly SubmissionService $service)
    {
    }

    public function register(): void
    {
        register_rest_route(self::NAMESPACE, self::ROUTE, [
            'methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => [$this, 'submit'],
        ]);
    }

    public function submit(WP_REST_Request $request): WP_REST_Response
    {
        $status = 200;
        try {
            if (strlen($request->get_body()) > self::MAX_BYTES || $request->get_file_params() !== []) {
                throw new SubmissionException('payload_too_large', 'Requete trop volumineuse ou fichiers non pris en charge.', 413);
            }
            $params = $request->get_json_params();
            if (! is_array($params)) {
                throw new SubmissionException('invalid_request', 'Le formulaire necessite JavaScript et une requete JSON.');
            }
            $data = $this->service->submit($params);
        } catch (SubmissionException $error) {
            $status = $error->status;
            $data = ['success' => false, 'code' => $error->errorCode, 'message' => $error->getMessage(), 'fields' => $error->fields];
        } catch (Throwable) {
            $status = 503;
            $data = ['success' => false, 'code' => 'form_unavailable', 'message' => 'Ce formulaire est momentanement indisponible.'];
        }
        $response = new WP_REST_Response($data, $status);
        $response->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $response->header('X-Robots-Tag', 'noindex, nofollow');
        return $response;
    }
}
