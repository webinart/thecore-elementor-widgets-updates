<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms;

/** Compiles only saved, static rules. Browser metadata never defines validation. */
final class FormDefinition
{
    public const TYPE = 'thecore-form';
    public const SECURITY_FIELD = 'thecore_atomic_security';
    public const MAX_FIELDS = 50;

    public function __construct(
        public readonly array $settings,
        public readonly array $fields
    ) {
    }

    public static function fromElement(array $element): self
    {
        if (($element['elType'] ?? '') !== self::TYPE) {
            throw new ConfigurationException('Not a The Core form.');
        }

        $settings = self::settings($element['settings'] ?? []);
        $settings += [
            'form-name' => 'Contact',
            'recipient' => '',
            'subject' => 'Contact',
            'success-message' => 'Votre message a bien ete envoye.',
            'allow-tests' => false,
            'actions-after-submit' => ['email'],
            'mailpoet-lists' => [],
            'mailpoet-email-field' => 'thecore-field-email',
            'mailpoet-first-name-field' => '',
            'mailpoet-last-name-field' => '',
            'mailpoet-consent-field' => '',
        ];
        foreach (['form-name', 'recipient', 'subject', 'success-message'] as $key) {
            if (! is_string($settings[$key]) || strlen($settings[$key]) > 1000) {
                throw new ConfigurationException('Invalid form setting: ' . $key);
            }
        }
        if (! is_bool($settings['allow-tests'])) {
            throw new ConfigurationException('Invalid test setting.');
        }
        $actions = $settings['actions-after-submit'];
        if (! is_array($actions) || ! array_is_list($actions) || $actions === [] || count($actions) > 2) {
            throw new ConfigurationException('Select at least one submission action.');
        }
        foreach ($actions as $action) {
            if (! in_array($action, ['email', 'mailpoet'], true)) {
                throw new ConfigurationException('Unknown submission action.');
            }
        }
        if (count(array_unique($actions)) !== count($actions)) {
            throw new ConfigurationException('Duplicate submission action.');
        }
        if (in_array('mailpoet', $actions, true)) {
            $lists = $settings['mailpoet-lists'];
            if (! is_array($lists) || ! array_is_list($lists) || $lists === [] || count($lists) > 20) {
                throw new ConfigurationException('Select between 1 and 20 MailPoet lists.');
            }
            foreach ($lists as $list) {
                if (! is_string($list) || ! preg_match('/\A[1-9][0-9]{0,10}\z/', $list)) {
                    throw new ConfigurationException('Invalid MailPoet list ID.');
                }
            }
            $settings['mailpoet-lists'] = array_values(array_unique($lists));
        }

        $nodes = [];
        self::flatten($element['elements'] ?? [], $nodes);
        $labels = [];
        foreach ($nodes as $node) {
            if (($node['widgetType'] ?? '') === 'e-form-label') {
                $props = self::settings($node['settings'] ?? []);
                $text = $props['text'] ?? '';
                $labels[(string) ($props['input-id'] ?? '')] = trim(strip_tags(
                    is_array($text) ? (string) ($text['content'] ?? '') : (string) $text
                ));
            }
        }

        $fields = [];
        $domIds = [];
        foreach ($nodes as $node) {
            $widget = $node['widgetType'] ?? '';
            if (! str_starts_with($widget, 'e-form-') || in_array($widget, ['e-form-label', 'e-form-submit-button'], true)) {
                continue;
            }
            $type = match ($widget) {
                'e-form-input' => 'text',
                'e-form-textarea' => 'textarea',
                'e-form-checkbox' => 'checkbox',
                'e-form-select' => 'select',
                'e-form-radio-button' => 'radio',
                default => throw new ConfigurationException('Unsupported field: ' . $widget),
            };
            $props = self::settings($node['settings'] ?? []);
            if ($widget === 'e-form-input') {
                $type = $props['type'] ?? 'text';
                if (! in_array($type, ['text', 'email', 'tel', 'url', 'number'], true)) {
                    throw new ConfigurationException('Unsupported input type.');
                }
            }
            $id = $node['id'] ?? '';
            $domId = $props['_cssid'] ?? '';
            if (! is_string($id) || ! preg_match('/\A[A-Za-z0-9_-]{1,128}\z/', $id) || isset($fields[$id])) {
                throw new ConfigurationException('Invalid or duplicate field ID.');
            }
            if (! is_string($domId) || $domId === '' || isset($domIds[$domId])) {
                throw new ConfigurationException('Fields need unique CSS IDs.');
            }
            if (empty($labels[$domId])) {
                throw new ConfigurationException('Each field needs an associated label.');
            }
            $domIds[$domId] = true;
            $options = [];
            foreach (($props['options'] ?? []) as $option) {
                if (! is_array($option) || ! isset($option['value']) || ! is_string($option['value'])) {
                    throw new ConfigurationException('Invalid select option.');
                }
                $options[] = $option['value'] === '' ? (string) ($option['key'] ?? '') : $option['value'];
            }
            $attributes = [];
            foreach (($props['attributes'] ?? []) as $attribute) {
                if (is_array($attribute) && isset($attribute['key'], $attribute['value'])) {
                    $attributes[strtolower((string) $attribute['key'])] = $attribute['value'];
                }
            }
            // HTML overrides must not silently change the server-side contract.
            foreach (['name', 'type', 'value', 'required', 'readonly', 'disabled', 'multiple', 'form', 'id', 'pattern'] as $key) {
                if (array_key_exists($key, $attributes)) {
                    throw new ConfigurationException('Unsupported field attribute: ' . $key);
                }
            }
            $fields[$id] = [
                'id' => $id,
                'domId' => $domId,
                'name' => (string) (($props['name'] ?? '') ?: $domId),
                'label' => $labels[$domId],
                'type' => $type,
                'required' => ($props['required'] ?? false) === true,
                'readonly' => ($props['readonly'] ?? false) === true,
                'value' => (string) ($props['value'] ?? ''),
                'multiple' => ($props['multiple'] ?? false) === true,
                'options' => $options,
                'minLength' => max(0, (int) ($props['length']['min'] ?? $props['minlength'] ?? $attributes['minlength'] ?? 0)),
                'maxLength' => min(10000, max(1, (int) ($props['length']['max'] ?? $props['maxlength'] ?? $attributes['maxlength'] ?? 10000))),
                'min' => $attributes['min'] ?? null,
                'max' => $attributes['max'] ?? null,
                'step' => $attributes['step'] ?? null,
            ];
        }
        if ($fields === [] || count($fields) > self::MAX_FIELDS) {
            throw new ConfigurationException('A form must contain between 1 and 50 supported fields.');
        }
        $form = new self($settings, $fields);
        if (in_array('mailpoet', $actions, true)) {
            $form->mailPoetMapping();
        }
        return $form;
    }

    /** Resolve the saved CSS IDs, not the prefixed IDs emitted in browser markup. */
    public function mailPoetMapping(): array
    {
        $mapping = [];
        foreach (['email' => 'email', 'first_name' => 'first-name', 'last_name' => 'last-name', 'consent' => 'consent'] as $remote => $key) {
            $cssId = $this->settings['mailpoet-' . $key . '-field'] ?? '';
            if (! is_string($cssId) || strlen($cssId) > 128 || ($remote === 'email' && $cssId === '')) {
                throw new ConfigurationException('Invalid MailPoet field mapping.');
            }
            if ($cssId === '') {
                continue;
            }
            foreach ($this->fields as $id => $field) {
                if ($field['domId'] !== $cssId) {
                    continue;
                }
                $type = match ($remote) {
                    'email' => 'email', 'consent' => 'checkbox', default => 'text'
                };
                if ($field['type'] !== $type || ($remote === 'consent' && $field['readonly'])) {
                    throw new ConfigurationException('Incompatible MailPoet field type.');
                }
                $mapping[$remote] = $id;
            }
            if (! isset($mapping[$remote])) {
                throw new ConfigurationException('Mapped MailPoet field not found: ' . $cssId);
            }
        }
        if (count(array_unique($mapping)) !== count($mapping)) {
            throw new ConfigurationException('MailPoet fields must have distinct mappings.');
        }
        return $mapping;
    }

    public function publicFields(): array
    {
        return array_values(array_map(static fn(array $field): array => array_intersect_key(
            $field,
            array_flip(['id', 'domId', 'name', 'label', 'type', 'required', 'multiple'])
        ), $this->fields));
    }

    public static function settings(array $settings): array
    {
        // Layout props may contain global/dynamic styles and are irrelevant here.
        $result = [];
        $keys = ['form-name', 'recipient', 'subject', 'success-message', 'allow-tests', 'actions-after-submit',
            'mailpoet-lists', 'mailpoet-email-field', 'mailpoet-first-name-field', 'mailpoet-last-name-field', 'mailpoet-consent-field',
            '_cssid', 'input-id', 'text', 'type', 'name', 'value', 'required', 'readonly',
            'multiple', 'options', 'length', 'minlength', 'maxlength', 'attributes'];
        foreach ($keys as $key) {
            if (array_key_exists($key, $settings)) {
                $result[$key] = self::unwrap($settings[$key]);
            }
        }
        return $result;
    }

    private static function unwrap(mixed $value, int $depth = 0): mixed
    {
        if ($depth > 12) {
            throw new ConfigurationException('Property nesting too deep.');
        }
        if (! is_array($value)) {
            return $value;
        }
        if (isset($value['$$type'])) {
            if (! in_array($value['$$type'], ['string', 'string-array', 'boolean', 'number', 'html-v3', 'escaped-html', 'key-value', 'options', 'attributes', 'number-range'], true)) {
                throw new ConfigurationException('Dynamic form rules are not supported.');
            }
            return self::unwrap($value['value'] ?? null, $depth + 1);
        }
        return array_map(static fn($item) => self::unwrap($item, $depth + 1), $value);
    }

    private static function flatten(array $children, array &$nodes, int $depth = 0): void
    {
        if ($depth > 20) {
            throw new ConfigurationException('Form nesting too deep.');
        }
        foreach ($children as $child) {
            if (! is_array($child) || count($nodes) >= 500) {
                throw new ConfigurationException('Invalid form structure.');
            }
            if (in_array($child['elType'] ?? '', [self::TYPE, 'e-form'], true)) {
                throw new ConfigurationException('Nested forms are not supported.');
            }
            $nodes[] = $child;
            self::flatten($child['elements'] ?? [], $nodes, $depth + 1);
        }
    }
}
