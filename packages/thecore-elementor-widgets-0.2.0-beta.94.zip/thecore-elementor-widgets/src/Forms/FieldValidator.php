<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms;

final class FieldValidator
{
    public function validate(FormDefinition $definition, array $submitted): array
    {
        $errors = [];
        $values = [];
        if (array_diff_key($submitted, $definition->fields)) {
            return ['values' => [], 'errors' => ['_form' => 'Champs inconnus dans la requete.']];
        }
        $radioGroups = [];
        foreach ($definition->fields as $id => $field) {
            $value = $submitted[$id] ?? '';
            if ($field['readonly']) {
                $value = $field['value'];
            }
            $isMultiple = $field['type'] === 'select' && $field['multiple'];
            if ($isMultiple) {
                if ($value === '') {
                    $value = [];
                }
                if (! is_array($value) || ! array_is_list($value) || count($value) > 100) {
                    $errors[$id] = 'Selection invalide.';
                    continue;
                }
            } elseif (! is_string($value)) {
                $errors[$id] = 'Valeur invalide.';
                continue;
            }
            $items = $isMultiple ? $value : [$value];
            foreach ($items as $item) {
                if (! is_string($item) || strlen($item) > 40000 || str_contains($item, "\0")) {
                    $errors[$id] = 'Valeur invalide.';
                    continue 2;
                }
                $length = function_exists('mb_strlen') ? mb_strlen($item, 'UTF-8') : strlen($item);
                if ($length > $field['maxLength'] || ($item !== '' && $length < $field['minLength'])) {
                    $errors[$id] = 'Longueur du champ invalide.';
                }
                if ($item === '') {
                    continue;
                }
                $valid = match ($field['type']) {
                    'email' => (bool) is_email($item),
                    'url' => filter_var($item, FILTER_VALIDATE_URL) !== false
                        && in_array(strtolower((string) parse_url($item, PHP_URL_SCHEME)), ['https', 'http'], true),
                    'number' => $this->validNumber($item, $field),
                    'checkbox', 'radio' => hash_equals($field['value'] !== '' ? $field['value'] : 'on', $item),
                    'select' => in_array($item, $field['options'], true),
                    default => true,
                };
                if (! $valid) {
                    $errors[$id] = 'Veuillez verifier ce champ.';
                }
            }
            $empty = $isMultiple ? $value === [] : trim($value) === '';
            if ($field['type'] === 'radio') {
                $group = &$radioGroups[$field['name']];
                if (! is_array($group)) {
                    $group = ['required' => false, 'selected' => 0, 'ids' => []];
                }
                $group['required'] = $group['required'] || $field['required'];
                $group['selected'] += $empty ? 0 : 1;
                $group['ids'][] = $id;
                unset($group);
            } elseif ($field['required'] && $empty) {
                $errors[$id] = 'Ce champ est obligatoire.';
            }
            $clean = array_map(static fn(string $item): string => sanitize_textarea_field($item), $items);
            $values[$id] = $isMultiple ? $clean : $clean[0];
        }
        foreach ($radioGroups as $group) {
            if ($group['selected'] > 1 || ($group['required'] && $group['selected'] !== 1)) {
                $errors[$group['ids'][0]] = 'Veuillez selectionner une option.';
            }
        }
        return ['values' => $values, 'errors' => $errors];
    }

    private function validNumber(string $value, array $field): bool
    {
        if (! is_numeric($value) || ! is_finite((float) $value)) {
            return false;
        }
        $number = (float) $value;
        if (
            ($field['min'] !== null && $number < (float) $field['min'])
            || ($field['max'] !== null && $number > (float) $field['max'])
        ) {
            return false;
        }
        if ($field['step'] === 'any') {
            return true;
        }
        $step = $field['step'] === null ? 1.0 : (float) $field['step'];
        if ($step <= 0) {
            return false;
        }
        $offset = ($number - (float) ($field['min'] ?? 0)) / $step;
        return abs($offset - round($offset)) < 0.0000001;
    }
}
