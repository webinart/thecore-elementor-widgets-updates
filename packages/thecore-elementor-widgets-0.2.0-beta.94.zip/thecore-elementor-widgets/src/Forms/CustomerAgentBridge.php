<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms;

use TheCore\ElementorWidgets\FormSecurity\Infrastructure\SecurityStore;

final class CustomerAgentBridge implements FleetMonitor
{
    public function __construct(private readonly SecurityStore $store)
    {
    }

    public function authorize(string $token, int $postId, string $formId): array
    {
        if (
            ! is_callable(['Webinart_WP_Agent_Settings', 'is_paired'])
            || ! \Webinart_WP_Agent_Settings::is_paired()
        ) {
            throw new SubmissionException('test_unavailable', 'Agent de suivi indisponible.', 403);
        }
        $settings = \Webinart_WP_Agent_Settings::all();
        $claims = (new TestToken())->verify(
            $token,
            (string) ($settings['agent_secret'] ?? ''),
            (string) ($settings['agent_id'] ?? ''),
            $postId,
            $formId,
            time()
        );
        if ($claims === null) {
            throw new SubmissionException('test_forbidden', 'Jeton de test invalide ou expire.', 403);
        }
        $status = $this->store->consumeReplay(
            hash('sha256', 'atomic-test|' . $claims['agentId'] . '|' . $claims['nonce']),
            $claims['exp'],
            time()
        );
        if ($status !== 'consumed') {
            throw new SubmissionException('test_replayed', 'Jeton deja utilise ou controle indisponible.', $status === 'replay' ? 409 : 503);
        }
        return $claims;
    }

    public function report(array $claims, string $event, array $details): void
    {
        if (! is_callable(['Webinart_WP_Agent_Form_Monitor', 'retry_test_event'])) {
            return;
        }
        // Reuse the agent's authenticated delivery/retries without sending field values.
        wp_schedule_single_event(time() + 1, 'webinart_wp_agent_retry_form_check_event', [
            $claims['runId'],
            ['eventId' => wp_generate_uuid4(), 'occurredAt' => gmdate('c'), 'eventType' => $event,
                'stage' => 'server_processing',
                'payload' => array_merge($details, ['mode' => 'dry-run', 'mailSent' => false])],
            1,
        ]);
    }
}
