<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Actions;

use TheCore\ElementorWidgets\Forms\ConfigurationException;
use TheCore\ElementorWidgets\Forms\FormDefinition;
use TheCore\ElementorWidgets\Forms\MailPoet\MailPoetClient;

final class ActionPipeline
{
    /** @var array<string, SubmissionAction> */
    private array $actions = [];

    public function __construct(?array $actions = null)
    {
        // Subscribe first: a newsletter failure must not send a contact notification.
        foreach ($actions ?? [new MailPoetAction(new MailPoetClient()), new EmailAction()] as $action) {
            $this->actions[$action->name()] = $action;
        }
    }

    public function prepare(FormDefinition $form, array $values): array
    {
        $selected = $form->settings['actions-after-submit'] ?? ['email'];
        if ($selected === [] || array_diff($selected, array_keys($this->actions))) {
            throw new ConfigurationException('Unknown or missing submission action.');
        }
        $prepared = [];
        foreach ($this->actions as $name => $action) {
            if (in_array($name, $selected, true)) {
                $prepared[$name] = $action->prepare($form, $values);
            }
        }
        return $prepared;
    }

    public function execute(array $prepared): void
    {
        // All actions have been validated before any side effect is allowed.
        foreach ($prepared as $name => $data) {
            $this->actions[$name]->execute($data);
        }
    }
}
