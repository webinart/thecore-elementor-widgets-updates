<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Actions;

use TheCore\ElementorWidgets\Forms\ConfigurationException;
use TheCore\ElementorWidgets\Forms\FormDefinition;
use TheCore\ElementorWidgets\Forms\MailPoet\MailPoetClient;
use TheCore\ElementorWidgets\Forms\MailPoet\MailPoetGateway;
use TheCore\ElementorWidgets\Forms\SubmissionException;

final class MailPoetAction implements SubmissionAction
{
    public function __construct(private readonly MailPoetGateway $mailpoet)
    {
    }

    public function name(): string
    {
        return 'mailpoet';
    }

    public function prepare(FormDefinition $form, array $values): array
    {
        $mapping = $form->mailPoetMapping();
        if (isset($mapping['consent']) && ($values[$mapping['consent']] ?? '') === '') {
            return ['skip' => true];
        }
        $lists = array_map('intval', $form->settings['mailpoet-lists']);
        $available = MailPoetClient::activeLists($this->mailpoet->lists());
        if ($lists === [] || array_diff($lists, array_keys($available))) {
            throw new SubmissionException('mailpoet_list_unavailable', 'Une liste newsletter configuree est indisponible.', 503);
        }
        $required = ['email' => true];
        foreach ($this->mailpoet->fields() as $remote) {
            if (! empty($remote['params']['required']) && ! isset($mapping[$remote['id'] ?? ''])) {
                throw new ConfigurationException('A required MailPoet field is not mapped.');
            }
            if (! empty($remote['params']['required'])) {
                $required[$remote['id']] = true;
            }
        }
        $subscriber = [];
        foreach (['email' => 150, 'first_name' => 255, 'last_name' => 255] as $key => $maximum) {
            if (! isset($mapping[$key])) {
                continue;
            }
            $value = $values[$mapping[$key]] ?? '';
            $length = is_string($value) ? (function_exists('mb_strlen') ? mb_strlen($value, 'UTF-8') : strlen($value)) : PHP_INT_MAX;
            if ($length > $maximum || (isset($required[$key]) && trim($value) === '') || ($key === 'email' && ! is_email($value))) {
                throw new SubmissionException(
                    'validation_failed',
                    'Veuillez corriger les champs indiques.',
                    422,
                    [$mapping[$key] => 'Veuillez verifier ce champ pour l\'inscription newsletter.']
                );
            }
            $subscriber[$key] = $value;
        }
        return ['skip' => false, 'subscriber' => $subscriber, 'lists' => $lists];
    }

    public function execute(array $prepared): void
    {
        if ($prepared['skip']) {
            return;
        }
        $email = $prepared['subscriber']['email'];
        $existing = $this->mailpoet->subscriber($email);
        if ($existing === null) {
            if ($this->mailpoet->add($prepared['subscriber'], $prepared['lists'])) {
                return;
            }
            // Another request may have inserted the address. Re-read its opt-out state.
            $existing = $this->mailpoet->subscriber($email);
        }
        if (
            $existing === null || ! empty($existing['deleted_at'])
            || ! in_array($existing['status'] ?? '', ['subscribed', 'unconfirmed'], true)
            || ! is_array($existing['subscriptions'] ?? null)
        ) {
            $this->refuse();
        }
        $remaining = array_fill_keys($prepared['lists'], true);
        foreach ($existing['subscriptions'] as $subscription) {
            $id = (int) ($subscription['segment_id'] ?? 0);
            if (isset($remaining[$id])) {
                if (($subscription['status'] ?? '') !== 'subscribed') {
                    $this->refuse();
                }
                unset($remaining[$id]);
            }
        }
        if ($remaining !== []) {
            // Existing names are never overwritten; already joined lists receive no new email.
            $this->mailpoet->subscribe($email, array_keys($remaining));
        }
    }

    private function refuse(): never
    {
        // Do not reveal whether an address exists or why it cannot be subscribed.
        throw new SubmissionException('mailpoet_failed', 'L\'inscription newsletter n\'a pas pu etre confirmee. Veuillez contacter le site.', 503);
    }
}
