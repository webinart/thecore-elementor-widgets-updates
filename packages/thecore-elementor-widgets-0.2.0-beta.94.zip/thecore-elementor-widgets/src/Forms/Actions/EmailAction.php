<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Actions;

use TheCore\ElementorWidgets\Forms\ConfigurationException;
use TheCore\ElementorWidgets\Forms\FormDefinition;
use TheCore\ElementorWidgets\Forms\SubmissionException;

final class EmailAction implements SubmissionAction
{
    public function name(): string
    {
        return 'email';
    }

    public function prepare(FormDefinition $form, array $values): array
    {
        $recipient = $form->settings['recipient'] ?: (string) get_option('admin_email');
        if (! is_email($recipient) || preg_match('/[\r\n]/', $recipient)) {
            throw new ConfigurationException('Invalid recipient.');
        }
        $body = $form->settings['form-name'] . "\n\n";
        foreach ($form->fields as $id => $field) {
            $value = $values[$id] ?? '';
            $body .= $field['label'] . ': ' . (is_array($value) ? implode(', ', $value) : $value) . "\n\n";
        }
        return ['recipient' => $recipient, 'body' => $body,
            'subject' => trim(str_replace(["\r", "\n"], ' ', $form->settings['subject']))];
    }

    public function execute(array $prepared): void
    {
        if (! wp_mail($prepared['recipient'], $prepared['subject'], $prepared['body'], ['Content-Type: text/plain; charset=UTF-8'])) {
            throw new SubmissionException('mail_failed', 'Le message n\'a pas pu etre envoye. Veuillez reessayer plus tard.', 503);
        }
    }
}
