<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Actions;

use TheCore\ElementorWidgets\Forms\FormDefinition;

interface SubmissionAction
{
    public function name(): string;

    /** Read-only validation and preparation; also used by signed dry-runs. */
    public function prepare(FormDefinition $form, array $values): array;

    public function execute(array $prepared): void;
}
