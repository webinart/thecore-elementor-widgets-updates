<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms;

interface FleetMonitor
{
    public function authorize(string $token, int $postId, string $formId): array;

    public function report(array $claims, string $event, array $details): void;
}
