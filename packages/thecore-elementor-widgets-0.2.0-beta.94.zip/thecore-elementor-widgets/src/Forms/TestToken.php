<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms;

/** Compatible signing envelope with the Customer Agent; strictly scoped claims. */
final class TestToken
{
    public function verify(string $token, string $secret, string $agentId, int $postId, string $formId, int $now): ?array
    {
        if (strlen($token) > 8192 || $secret === '' || $agentId === '' || substr_count($token, '.') !== 1) {
            return null;
        }
        [$body, $signature] = explode('.', $token, 2);
        $decoded = $this->decode($body);
        $mac = $this->decode($signature);
        if ($decoded === null || $mac === null || ! hash_equals(hash_hmac('sha256', $body, $secret, true), $mac)) {
            return null;
        }
        $claims = json_decode($decoded, true, 8);
        if (
            ! is_array($claims) || ($claims['v'] ?? null) !== 1
            || ($claims['agentId'] ?? null) !== $agentId
            || ($claims['postId'] ?? null) !== $postId
            || ($claims['formIdentifier'] ?? null) !== $formId
            || ($claims['mode'] ?? 'dry-run') !== 'dry-run'
            || ! empty($claims['validationBypassFields'])
        ) {
            return null;
        }
        foreach (['runId', 'nonce'] as $key) {
            if (! isset($claims[$key]) || ! is_string($claims[$key])) {
                return null;
            }
        }
        if (
            ! preg_match('/\A[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\z/i', $claims['runId'])
            || ! preg_match('/\A[A-Za-z0-9_-]{16,128}\z/', $claims['nonce'])
            || ! is_int($claims['monitorId'] ?? null) || $claims['monitorId'] < 1
            || ! is_int($claims['iat'] ?? null) || ! is_int($claims['exp'] ?? null)
            || $claims['iat'] > $now + 60 || $claims['exp'] <= $now
            || $claims['exp'] <= $claims['iat'] || $claims['exp'] - $claims['iat'] > 900
        ) {
            return null;
        }
        return $claims;
    }

    private function decode(string $value): ?string
    {
        if (! preg_match('/\A[A-Za-z0-9_-]+\z/', $value) || strlen($value) % 4 === 1) {
            return null;
        }
        $value = strtr($value, '-_', '+/');
        $decoded = base64_decode($value . str_repeat('=', (4 - strlen($value) % 4) % 4), true);
        return is_string($decoded) ? $decoded : null;
    }
}
