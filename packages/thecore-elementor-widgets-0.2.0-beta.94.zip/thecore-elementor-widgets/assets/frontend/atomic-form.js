( function () {
	'use strict';
	if ( window.theCoreAtomicFormsLoaded ) { return; }
	window.theCoreAtomicFormsLoaded = true;
	const selector = 'form[data-thecore-form="1"]';
	const states = new WeakMap();
	let sequence = 0;
	const unavailable = 'Ce formulaire est momentanement indisponible. Veuillez reessayer plus tard.';

	function sameOrigin( value ) {
		const url = new URL( value, window.location.href );
		if ( url.origin !== window.location.origin || ! [ 'http:', 'https:' ].includes( url.protocol ) ) {
			throw new Error( unavailable );
		}
		return url.href;
	}

	function status( state, message, error = false ) {
		state.status.setAttribute( 'role', error ? 'alert' : 'status' );
		state.status.setAttribute( 'aria-live', error ? 'assertive' : 'polite' );
		state.status.textContent = message;
	}

	function init( form ) {
		if ( states.has( form ) ) { return states.get( form ); }
		if ( form.dataset.thecoreEditorPreview === '1' || document.body.classList.contains( 'elementor-editor-active' ) ) { return null; }
		const output = form.querySelector( '[data-thecore-form-status]' );
		if ( ! output ) { return null; }
		const state = { form, status: output, busy: false, controls: new Map(), errors: [] };
		states.set( form, state );
		try {
			state.config = JSON.parse( form.dataset.thecoreFormConfig );
			state.config.endpoint = sameOrigin( state.config.endpoint );
			state.config.challengeUrl = sameOrigin( state.config.challengeUrl );
			const suffix = '-tc-' + ( ++sequence );
			for ( const field of state.config.fields ) {
				const controls = Array.from( form.querySelectorAll( 'input,textarea,select' ) ).filter( el => el.id === field.domId );
				if ( controls.length !== 1 ) { throw new Error( unavailable ); }
				const control = controls[ 0 ];
				const labels = Array.from( form.querySelectorAll( 'label' ) ).filter( el => el.htmlFor === field.domId );
				control.id = field.domId + suffix;
				labels.forEach( label => { label.htmlFor = control.id; } );
				// Repeated templates must not share radio groups or label targets.
				if ( field.type === 'radio' ) { control.name = field.name + suffix; }
				state.controls.set( field.id, control );
			}
		} catch ( error ) {
			state.config = null;
			if ( ! output.textContent.trim() ) { status( state, unavailable, true ); }
		}
		return state;
	}

	function clearErrors( state ) {
		for ( const entry of state.errors ) {
			entry.node.remove();
			const ids = ( entry.control.getAttribute( 'aria-describedby' ) || '' ).split( /\s+/ ).filter( id => id && id !== entry.node.id );
			if ( ids.length ) { entry.control.setAttribute( 'aria-describedby', ids.join( ' ' ) ); }
			else { entry.control.removeAttribute( 'aria-describedby' ); }
			entry.control.removeAttribute( 'aria-invalid' );
		}
		state.errors = [];
	}

	function showErrors( state, errors ) {
		let first;
		for ( const [ id, message ] of Object.entries( errors || {} ) ) {
			const control = state.controls.get( id );
			if ( ! control || typeof message !== 'string' ) { continue; }
			const node = document.createElement( 'span' );
			node.id = control.id + '-error';
			node.dataset.thecoreFieldError = '1';
			node.textContent = message;
			control.insertAdjacentElement( 'afterend', node );
			control.setAttribute( 'aria-invalid', 'true' );
			control.setAttribute( 'aria-describedby', ( ( control.getAttribute( 'aria-describedby' ) || '' ) + ' ' + node.id ).trim() );
			state.errors.push( { node, control } );
			first ||= control;
		}
		return first;
	}

	function collect( state ) {
		const fields = Object.create( null );
		for ( const [ id, control ] of state.controls ) {
			if ( control.tagName === 'SELECT' && control.multiple ) {
				fields[ id ] = Array.from( control.selectedOptions, option => option.value );
			} else if ( [ 'checkbox', 'radio' ].includes( control.type ) ) {
				fields[ id ] = control.checked ? control.value : '';
			} else { fields[ id ] = control.value; }
		}
		return fields;
	}

	async function proof( state, signal ) {
		if ( ! window.customElements ) { throw new Error( unavailable ); }
		await Promise.race( [
			window.customElements.whenDefined( 'altcha-widget' ),
			new Promise( ( resolve, reject ) => { signal.addEventListener( 'abort', () => reject( new Error( unavailable ) ), { once: true } ); } ),
		] );
		if ( signal.aborted ) { throw new Error( unavailable ); }
		const widget = document.createElement( 'altcha-widget' );
		state.form.appendChild( widget );
		state.widget = widget;
		// The custom element installs its imperative API asynchronously on connection.
		await new Promise( resolve => window.setTimeout( resolve, 0 ) );
		if ( signal.aborted || typeof widget.configure !== 'function' ) { throw new Error( unavailable ); }
		widget.configure( {
			auto: 'off', display: 'invisible', challenge: state.config.challengeUrl,
			name: 'thecore_atomic_proof', hideFooter: true, hideLogo: true, humanInteractionSignature: false,
			minDuration: state.config.minDuration + 1000, timeout: 45000, workers: 1,
			fetch: ( input, options ) => fetch( sameOrigin( typeof input === 'string' ? input : input.url ), {
				...options, cache: 'no-store', credentials: 'same-origin', redirect: 'error', signal,
			} ),
		} );
		return new Promise( ( resolve, reject ) => {
			let settled = false;
			const finish = ( payload ) => {
				if ( settled ) { return; }
				settled = true;
				widget.removeEventListener( 'statechange', onState );
				signal.removeEventListener( 'abort', onAbort );
				if ( payload ) { resolve( payload ); }
				else { reject( new Error( 'Le controle anti-spam a echoue. Veuillez reessayer.' ) ); }
			};
			const onAbort = () => finish( null );
			const onState = ( event ) => {
				if ( event.detail?.state === 'verified' ) {
					window.setTimeout( () => finish( state.form.querySelector( 'input[name="thecore_atomic_proof"]' )?.value ), 0 );
				} else if ( [ 'error', 'expired' ].includes( event.detail?.state ) ) { finish( null ); }
			};
			widget.addEventListener( 'statechange', onState );
			signal.addEventListener( 'abort', onAbort, { once: true } );
			try { Promise.resolve( widget.verify() ).catch( () => finish( null ) ); }
			catch ( error ) { finish( null ); }
		} );
	}

	async function submit( state ) {
		if ( state.busy ) { return; }
		if ( ! state.config ) { status( state, unavailable, true ); return; }
		clearErrors( state );
		if ( ! state.form.reportValidity() ) { return; }
		const fields = collect( state );
		const testInput = state.form.querySelector( '[name="webinart_form_check_token"]' );
		const testToken = testInput ? testInput.value : null;
		const buttons = Array.from( state.form.querySelectorAll( 'button[type="submit"],input[type="submit"]' ) );
		const original = buttons.map( button => button.disabled );
		state.busy = true;
		state.form.setAttribute( 'aria-busy', 'true' );
		buttons.forEach( button => { button.disabled = true; } );
		status( state, 'Verification et envoi en cours...' );
		const abort = new AbortController();
		const timeout = window.setTimeout( () => abort.abort(), 60000 );
		let focusTarget;
		try {
			const payload = {
				context: state.config.context, fields,
				website: state.form.querySelector( '[name="thecore_form_website"]' )?.value || '',
				proof: await proof( state, abort.signal ),
			};
			if ( testToken !== null ) { payload.test_token = testToken; }
			const response = await fetch( state.config.endpoint, {
				method: 'POST', headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify( payload ), credentials: 'same-origin', cache: 'no-store', redirect: 'error', signal: abort.signal,
			} );
			const result = await response.json();
			const ok = response.ok && result.success === true;
			status( state, typeof result.message === 'string' ? result.message : unavailable, ! ok );
			if ( ! ok ) { focusTarget = showErrors( state, result.fields ); }
			else if ( result.mode === 'live' ) { state.form.reset(); }
			state.form.dispatchEvent( new CustomEvent( 'thecore:form-result', { bubbles: true,
				detail: { success: ok, mode: result.mode || null, code: result.code || null, runId: result.runId || null,
					mailSent: result.mailSent ?? null, deliveryTested: result.deliveryTested ?? null,
					actionsValidated: result.actionsValidated || [], actionsSkipped: result.actionsSkipped || [],
					actionsExecuted: result.actionsExecuted ?? null } } ) );
		} catch ( error ) {
			console.error( 'The Core form submission failed.', error );
			status( state, 'Envoi non confirme. Verifiez votre connexion avant de reessayer.', true );
		} finally {
			window.clearTimeout( timeout );
			abort.abort();
			if ( state.widget ) {
				try { state.widget.reset?.(); } catch ( error ) { /* Cleanup must restore the form. */ }
				state.widget.remove(); state.widget = null;
			}
			state.form.querySelectorAll( 'input[name="thecore_atomic_proof"]' ).forEach( input => input.remove() );
			buttons.forEach( ( button, index ) => { button.disabled = original[ index ]; } );
			state.form.removeAttribute( 'aria-busy' );
			state.busy = false;
			( focusTarget || state.status ).focus();
		}
	}

	document.addEventListener( 'submit', ( event ) => {
		if ( ! event.target.matches?.( selector ) ) { return; }
		event.preventDefault();
		const state = init( event.target );
		if ( state ) { void submit( state ); }
	} );

	function scan( root ) {
		if ( root.matches?.( selector ) ) { init( root ); }
		root.querySelectorAll?.( selector ).forEach( init );
	}
	function boot() {
		scan( document );
		new MutationObserver( entries => entries.forEach( entry => entry.addedNodes.forEach( node => {
			if ( node.nodeType === 1 ) { scan( node ); }
		} ) ) ).observe( document.body, { childList: true, subtree: true } );
	}
	if ( document.readyState === 'loading' ) { document.addEventListener( 'DOMContentLoaded', boot, { once: true } ); }
	else { boot(); }
}() );
