# Changelog

## 0.2.0-beta.6

- Correction de l'application des styles de typo du `Fullscreen Menu`
- Ajout de styles de typo distincts pour les liens desktop et les liens d'overlay
- Ajout du mode `Overlay only` pour conserver le hamburger sur tous les écrans

## 0.2.0-beta.5

- Suppression de la dépendance frontend du `Fullscreen Menu` au runtime Atomic d'Elementor

## 0.2.0-beta.4

- Correction du chargement trop tôt du domaine de traduction pour éviter le notice `_load_textdomain_just_in_time`

## 0.2.0-beta.3

- Intégration du wrapper `Fullscreen Menu` en `display: flex`
- Bump de version pour publication du canal beta

## 0.2.0-beta.2

- Bump de version pour test end-to-end de la pipeline d’update GitHub

## 0.2.0-beta.1

- Ajout du `PluginUpdater` GitHub avec manifest public `beta` / `prod`
- Ajout de la workflow GitHub de publication vers `webinart/thecore-elementor-widgets-updates`
- Remplacement du widget `Classic Menu` par le port V4 du widget legacy `Fullscreen Menu`
- Nettoyage de l’ancienne implémentation multi-niveaux et de ses assets hamburger dédiés
- Ajout d’une normalisation testée des réglages d’affichage du `Fullscreen Menu`

## 0.1.0

- Initialisation du plugin `The Core - Elementor Widgets`
- Mise en place de l’admin `The Core` avec pages `Widgets` et `Features`
- Ajout du socle Atomic pour `Classic Menu`
- Mise en place de l’outillage local Composer, PHPUnit et PHPCS
- Ajout du choix d’effet d’animation du hamburger
- Ajout du breakpoint mobile configurable par widget
- Chargement conditionnel des styles d’effet du hamburger par page
