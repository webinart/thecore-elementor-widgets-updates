<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Assets;

use TheCore\ElementorWidgets\Contracts\Bootable;
use TheCore\ElementorWidgets\Options\OptionsRepository;
use TheCore\ElementorWidgets\Registry\FeaturesRegistry;

final class FrontendAssets implements Bootable
{
    public const FULLSCREEN_MENU_SCRIPT = 'thecore-fullscreen-menu';
    public const FULLSCREEN_MENU_STYLE = 'thecore-fullscreen-menu';

    public function __construct(
        private readonly OptionsRepository $optionsRepository,
        private readonly FeaturesRegistry $featuresRegistry
    ) {
    }

    public function register(): void
    {
        add_action('wp_enqueue_scripts', [$this, 'registerStyles']);
        add_action('elementor/atomic-widgets/frontend/loader/scripts/register', [$this, 'registerScripts']);
    }

    public function registerStyles(): void
    {
        wp_register_style(
            self::FULLSCREEN_MENU_STYLE,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/fullscreen-menu.css',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION
        );
    }

    public function registerScripts(object $loader = null): void
    {
        wp_register_script(
            self::FULLSCREEN_MENU_SCRIPT,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/fullscreen-menu.js',
            ['elementor-v2-widgets-frontend'],
            THECORE_ELEMENTOR_WIDGETS_VERSION,
            true
        );

        $featureState = $this->optionsRepository->getFeaturesState($this->featuresRegistry->defaults());

        wp_add_inline_script(
            self::FULLSCREEN_MENU_SCRIPT,
            'window.TheCoreElementorWidgetsConfig = ' . wp_json_encode(
                [
                    'features' => [
                        'overlayScrollLock' => ! empty($featureState['overlay-scroll-lock']),
                    ],
                    'bodyLockClass' => 'thecore-elementor-widgets-lock-scroll',
                ],
                JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
            ) . ';',
            'before'
        );
    }
}
