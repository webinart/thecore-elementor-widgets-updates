<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Registry;

final class WidgetsRegistry
{
    /**
     * @return array<string, RegistryItem>
     */
    public function all(): array
    {
        $item = new RegistryItem(
            'classic-menu',
            __('Fullscreen Menu', 'thecore-elementor-widgets'),
            __(
                'Portage V4 du fullscreen menu legacy avec rendu inline sur desktop, overlay mobile et lecture des items de premier niveau d’un menu WordPress.',
                'thecore-elementor-widgets'
            ),
            true
        );

        return [
            $item->id() => $item,
        ];
    }

    /**
     * @return array<string, int>
     */
    public function defaults(): array
    {
        $defaults = [];

        foreach ($this->all() as $item) {
            $defaults[$item->id()] = $item->enabledByDefault() ? 1 : 0;
        }

        return $defaults;
    }
}
