<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Registry;

final class FeaturesRegistry
{
    /**
     * @return array<string, RegistryItem>
     */
    public function all(): array
    {
        $item = new RegistryItem(
            'overlay-scroll-lock',
            __('Overlay Scroll Lock', 'thecore-elementor-widgets'),
            __(
                'Verrouille le scroll du document lorsque des overlays compatibles, comme le Fullscreen Menu mobile, sont ouverts.',
                'thecore-elementor-widgets'
            ),
            true
        );

        return [
            $item->id() => $item,
        ];
    }

    /**
     * @return array<string, int>
     */
    public function defaults(): array
    {
        $defaults = [];

        foreach ($this->all() as $item) {
            $defaults[$item->id()] = $item->enabledByDefault() ? 1 : 0;
        }

        return $defaults;
    }
}
