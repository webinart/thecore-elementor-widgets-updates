<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets;

use TheCore\ElementorWidgets\Admin\AdminMenu;
use TheCore\ElementorWidgets\Assets\AdminAssets;
use TheCore\ElementorWidgets\Assets\FrontendAssets;
use TheCore\ElementorWidgets\Contracts\Bootable;
use TheCore\ElementorWidgets\Modules\WidgetsModule;
use TheCore\ElementorWidgets\Notice\AdminNoticeManager;
use TheCore\ElementorWidgets\Options\OptionsRepository;
use TheCore\ElementorWidgets\Options\StateSanitizer;
use TheCore\ElementorWidgets\Registry\FeaturesRegistry;
use TheCore\ElementorWidgets\Registry\WidgetsRegistry;
use TheCore\ElementorWidgets\Support\RequirementsChecker;
use TheCore\ElementorWidgets\Update\PluginUpdater;

final class Plugin
{
    private static ?self $instance = null;

    private bool $booted = false;

    private WidgetsRegistry $widgetsRegistry;
    private FeaturesRegistry $featuresRegistry;
    private OptionsRepository $optionsRepository;
    private RequirementsChecker $requirementsChecker;

    /**
     * @var Bootable[]
     */
    private array $services = [];

    private function __construct()
    {
        $this->widgetsRegistry = new WidgetsRegistry();
        $this->featuresRegistry = new FeaturesRegistry();
        $this->optionsRepository = new OptionsRepository(new StateSanitizer());
        $this->requirementsChecker = new RequirementsChecker();
    }

    public static function instance(): self
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public static function activate(): void
    {
        $plugin = self::instance();

        $plugin->optionsRepository->initializeDefaults(
            $plugin->widgetsRegistry->defaults(),
            $plugin->featuresRegistry->defaults()
        );
    }

    public function boot(): void
    {
        if ($this->booted) {
            return;
        }

        load_plugin_textdomain(
            'thecore-elementor-widgets',
            false,
            dirname(THECORE_ELEMENTOR_WIDGETS_BASENAME) . '/languages'
        );

        $this->optionsRepository->initializeDefaults(
            $this->widgetsRegistry->defaults(),
            $this->featuresRegistry->defaults()
        );

        $this->services = [
            new AdminAssets(),
            new PluginUpdater(),
            new FrontendAssets($this->optionsRepository, $this->featuresRegistry),
            new AdminMenu(
                $this->widgetsRegistry,
                $this->featuresRegistry,
                $this->optionsRepository,
                $this->requirementsChecker
            ),
            new AdminNoticeManager($this->requirementsChecker),
            new WidgetsModule(
                $this->widgetsRegistry,
                $this->optionsRepository,
                $this->requirementsChecker
            ),
        ];

        foreach ($this->services as $service) {
            $service->register();
        }

        $this->booted = true;
    }

    public function isFeatureEnabled(string $featureId): bool
    {
        $state = $this->optionsRepository->getFeaturesState($this->featuresRegistry->defaults());

        return ! empty($state[$featureId]);
    }
}
