<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\FullscreenMenu;

final class DisplaySettings
{
    public const DEFAULT_MOBILE_BREAKPOINT = 768;
    public const DEFAULT_TOGGLE_COLOR = '#FF5252';
    public const DEFAULT_TOGGLE_OPEN_COLOR = '#FFFFFF';
    public const DEFAULT_OVERLAY_COLOR = '#777777';
    public const DEFAULT_OVERLAY_OPACITY = 90;
    public const DEFAULT_MENU_COLOR = '#FFFFFF';
    public const DEFAULT_TOGGLE_POSITION_TOP = 5;
    public const DEFAULT_TOGGLE_POSITION_RIGHT = 2;

    /**
     * @param array<string, mixed> $settings
     *
     * @return array<string, int|string>
     */
    public function normalize(array $settings): array
    {
        return [
            'menu_id' => $this->toPositiveInt($settings['menu_id'] ?? 0),
            'mobile_breakpoint' => $this->clampInt(
                $settings['mobile_breakpoint'] ?? self::DEFAULT_MOBILE_BREAKPOINT,
                320,
                1920,
                self::DEFAULT_MOBILE_BREAKPOINT
            ),
            'toggle_color' => $this->sanitizeHexColor(
                $settings['toggle_color'] ?? self::DEFAULT_TOGGLE_COLOR,
                self::DEFAULT_TOGGLE_COLOR
            ),
            'toggle_color_open' => $this->sanitizeHexColor(
                $settings['toggle_color_open'] ?? self::DEFAULT_TOGGLE_OPEN_COLOR,
                self::DEFAULT_TOGGLE_OPEN_COLOR
            ),
            'overlay_color' => $this->sanitizeHexColor(
                $settings['overlay_color'] ?? self::DEFAULT_OVERLAY_COLOR,
                self::DEFAULT_OVERLAY_COLOR
            ),
            'overlay_opacity' => $this->clampInt(
                $settings['overlay_opacity'] ?? self::DEFAULT_OVERLAY_OPACITY,
                0,
                100,
                self::DEFAULT_OVERLAY_OPACITY
            ),
            'menu_color' => $this->sanitizeHexColor(
                $settings['menu_color'] ?? self::DEFAULT_MENU_COLOR,
                self::DEFAULT_MENU_COLOR
            ),
            'toggle_position_top' => $this->clampInt(
                $settings['toggle_position_top'] ?? self::DEFAULT_TOGGLE_POSITION_TOP,
                0,
                100,
                self::DEFAULT_TOGGLE_POSITION_TOP
            ),
            'toggle_position_right' => $this->clampInt(
                $settings['toggle_position_right'] ?? self::DEFAULT_TOGGLE_POSITION_RIGHT,
                0,
                100,
                self::DEFAULT_TOGGLE_POSITION_RIGHT
            ),
        ];
    }

    private function clampInt(mixed $value, int $min, int $max, int $default): int
    {
        if (! is_numeric($value)) {
            return $default;
        }

        return max($min, min($max, (int) $value));
    }

    private function toPositiveInt(mixed $value): int
    {
        if (! is_numeric($value)) {
            return 0;
        }

        return max(0, (int) $value);
    }

    private function sanitizeHexColor(mixed $value, string $default): string
    {
        if (! is_string($value)) {
            return $default;
        }

        $color = trim($value);

        if (1 === preg_match('/^#(?:[0-9a-fA-F]{3}){1,2}$/', $color)) {
            return strtoupper($color);
        }

        return $default;
    }
}
