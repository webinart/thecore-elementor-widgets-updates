<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\FullscreenMenu;

use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Number_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Select_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Text_Control;
use Elementor\Modules\AtomicWidgets\Elements\Base\Atomic_Widget_Base;
use Elementor\Modules\AtomicWidgets\PropTypes\Attributes_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Classes_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Number_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\AtomicWidgets\Styles\Style_Definition;
use Elementor\Modules\Components\PropTypes\Overridable_Prop_Type;
use TheCore\ElementorWidgets\Assets\FrontendAssets;
use TheCore\ElementorWidgets\Plugin;

final class FullscreenMenu extends Atomic_Widget_Base
{
    public static $widget_description = 'Fullscreen navigation menu with a mobile overlay and top-level WordPress menu items.';

    public static function get_element_type(): string
    {
        return 'thecore-classic-menu';
    }

    public function get_title(): string
    {
        return esc_html__('Fullscreen Menu', 'thecore-elementor-widgets');
    }

    public function get_icon(): string
    {
        return 'eicon-menu-toggle';
    }

    public function get_keywords(): array
    {
        return ['menu', 'navigation', 'fullscreen', 'overlay', 'hamburger', 'atomic'];
    }

    public function get_style_depends(): array
    {
        return [FrontendAssets::FULLSCREEN_MENU_STYLE];
    }

    public function get_script_depends(): array
    {
        return array_merge(
            parent::get_script_depends(),
            [FrontendAssets::FULLSCREEN_MENU_SCRIPT]
        );
    }

    protected static function define_props_schema(): array
    {
        return [
            'classes' => Classes_Prop_Type::make()->default([]),
            'menu_id' => String_Prop_Type::make()->default(''),
            'mobile_breakpoint' => Number_Prop_Type::make()->default(DisplaySettings::DEFAULT_MOBILE_BREAKPOINT),
            'toggle_color' => String_Prop_Type::make()->default(DisplaySettings::DEFAULT_TOGGLE_COLOR),
            'toggle_color_open' => String_Prop_Type::make()->default(DisplaySettings::DEFAULT_TOGGLE_OPEN_COLOR),
            'overlay_color' => String_Prop_Type::make()->default(DisplaySettings::DEFAULT_OVERLAY_COLOR),
            'overlay_opacity' => Number_Prop_Type::make()->default(DisplaySettings::DEFAULT_OVERLAY_OPACITY),
            'menu_color' => String_Prop_Type::make()->default(DisplaySettings::DEFAULT_MENU_COLOR),
            'toggle_position_top' => Number_Prop_Type::make()->default(DisplaySettings::DEFAULT_TOGGLE_POSITION_TOP),
            'toggle_position_right' => Number_Prop_Type::make()->default(DisplaySettings::DEFAULT_TOGGLE_POSITION_RIGHT),
            'attributes' => Attributes_Prop_Type::make()->meta(Overridable_Prop_Type::ignore()),
        ];
    }

    protected function define_atomic_controls(): array
    {
        $menuOptionsProvider = new MenuOptionsProvider();

        return [
            Section::make()
                ->set_label(__('Content', 'thecore-elementor-widgets'))
                ->set_items([
                    Select_Control::bind_to('menu_id')
                        ->set_label(__('WordPress Menu', 'thecore-elementor-widgets'))
                        ->set_options($menuOptionsProvider->getOptions())
                        ->set_placeholder(__('Select a menu', 'thecore-elementor-widgets'))
                        ->set_description(__('Reads the top-level items of the selected WordPress menu.', 'thecore-elementor-widgets')),
                ]),
            Section::make()
                ->set_label(__('Toggle', 'thecore-elementor-widgets'))
                ->set_items([
                    Text_Control::bind_to('toggle_color')
                        ->set_label(__('Bars color', 'thecore-elementor-widgets'))
                        ->set_placeholder(DisplaySettings::DEFAULT_TOGGLE_COLOR)
                        ->set_description(__('Hex color only, for example #FF5252.', 'thecore-elementor-widgets')),
                    Text_Control::bind_to('toggle_color_open')
                        ->set_label(__('Open bars color', 'thecore-elementor-widgets'))
                        ->set_placeholder(DisplaySettings::DEFAULT_TOGGLE_OPEN_COLOR)
                        ->set_description(__('Hex color only, for example #FFFFFF.', 'thecore-elementor-widgets')),
                    Number_Control::bind_to('toggle_position_top')
                        ->set_label(__('Top offset (%)', 'thecore-elementor-widgets'))
                        ->set_min(0)
                        ->set_max(100)
                        ->set_step(1)
                        ->set_should_force_int(true),
                    Number_Control::bind_to('toggle_position_right')
                        ->set_label(__('Right offset (%)', 'thecore-elementor-widgets'))
                        ->set_min(0)
                        ->set_max(100)
                        ->set_step(1)
                        ->set_should_force_int(true),
                ]),
            Section::make()
                ->set_label(__('Overlay', 'thecore-elementor-widgets'))
                ->set_items([
                    Text_Control::bind_to('overlay_color')
                        ->set_label(__('Background color', 'thecore-elementor-widgets'))
                        ->set_placeholder(DisplaySettings::DEFAULT_OVERLAY_COLOR)
                        ->set_description(__('Hex color only, for example #777777.', 'thecore-elementor-widgets')),
                    Number_Control::bind_to('overlay_opacity')
                        ->set_label(__('Opacity (%)', 'thecore-elementor-widgets'))
                        ->set_min(0)
                        ->set_max(100)
                        ->set_step(1)
                        ->set_should_force_int(true),
                    Text_Control::bind_to('menu_color')
                        ->set_label(__('Links color', 'thecore-elementor-widgets'))
                        ->set_placeholder(DisplaySettings::DEFAULT_MENU_COLOR)
                        ->set_description(__('Hex color only, for example #FFFFFF.', 'thecore-elementor-widgets')),
                ]),
            Section::make()
                ->set_label(__('Responsive', 'thecore-elementor-widgets'))
                ->set_items([
                    Number_Control::bind_to('mobile_breakpoint')
                        ->set_label(__('Mobile breakpoint (px)', 'thecore-elementor-widgets'))
                        ->set_min(320)
                        ->set_max(1920)
                        ->set_step(1)
                        ->set_should_force_int(true),
                ]),
            Section::make()
                ->set_label(__('Settings', 'thecore-elementor-widgets'))
                ->set_id('settings')
                ->set_items([
                    Text_Control::bind_to('_cssid')
                        ->set_label(__('ID', 'thecore-elementor-widgets'))
                        ->set_meta($this->get_css_id_control_meta()),
                ]),
        ];
    }

    protected function define_base_styles(): array
    {
        return [
            'base' => Style_Definition::make(),
        ];
    }

    protected function render()
    {
        $settings = (new DisplaySettings())->normalize($this->get_atomic_settings());
        $renderer = new MenuRenderer();
        $baseStyles = $this->get_base_styles_dictionary();
        $cssId = trim((string) $this->get_atomic_setting('_cssid'));
        $menuMarkup = $renderer->render((int) $settings['menu_id'], $this->get_id());

        if ('' === $menuMarkup) {
            return;
        }

        $attributes = [
            'class' => implode(
                ' ',
                array_filter([
                    'thecore-fullscreen-menu',
                    $baseStyles['base'] ?? '',
                ])
            ),
            'data-thecore-fullscreen-menu' => 'true',
            'data-mobile-breakpoint' => (string) $settings['mobile_breakpoint'],
            'data-scroll-lock' => Plugin::instance()->isFeatureEnabled('overlay-scroll-lock') ? '1' : '0',
            'style' => $this->buildCssVariableString($settings),
        ];

        if ('' !== $cssId) {
            $attributes['id'] = $cssId;
        }

        echo '<div' . $this->buildAttributes($attributes) . '>';
        echo $menuMarkup; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo '</div>';
    }

    /**
     * @param array<string, int|string> $settings
     */
    private function buildCssVariableString(array $settings): string
    {
        return implode(
            ';',
            [
                '--thecore-fsm-toggle-color:' . $settings['toggle_color'],
                '--thecore-fsm-toggle-open-color:' . $settings['toggle_color_open'],
                '--thecore-fsm-overlay-color:' . $settings['overlay_color'],
                '--thecore-fsm-overlay-opacity:' . number_format(((int) $settings['overlay_opacity']) / 100, 2, '.', ''),
                '--thecore-fsm-menu-color:' . $settings['menu_color'],
                '--thecore-fsm-toggle-top:' . (int) $settings['toggle_position_top'],
                '--thecore-fsm-toggle-right:' . (int) $settings['toggle_position_right'],
            ]
        );
    }

    /**
     * @param array<string, string> $attributes
     */
    private function buildAttributes(array $attributes): string
    {
        $markup = '';

        foreach ($attributes as $name => $value) {
            $markup .= sprintf(
                ' %s="%s"',
                esc_attr($name),
                esc_attr($value)
            );
        }

        return $markup;
    }
}
