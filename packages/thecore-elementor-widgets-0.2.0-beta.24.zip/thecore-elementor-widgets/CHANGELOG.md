# Changelog

## 0.2.0-beta.24

- Correction du `Header Menu (Legacy)` : la media query inline du breakpoint mobile est maintenant rendue correctement, ce qui permet enfin le passage en mode burger

## 0.2.0-beta.23

- Import des widgets legacy `Header Menu` et `Search Modal` depuis Bellevue avec renommage The Core
- Ajout du handler AJAX de recherche et des tests de normalisation associés
- Correction du `Header Menu (Legacy)` pour que le layout mobile soit rendu nativement via CSS/media queries, sans dépendre du JS pour le premier affichage

## 0.2.0-beta.22

- Fusion des correctifs de chargement d'assets sur la base beta.21
- Chargement normalise des CSS et JS des widgets via leurs dependances WordPress standards
- Retrait du reliquat `inline_asset_injection` sur `Fullscreen Menu`

## 0.2.0-beta.21

- Suppression complete du systeme de delaying embarque dans le plugin
- Retrait des reglages admin et des controles widget associes
- Retour a un chargement normal des assets, pour laisser cette responsabilite au theme

## 0.2.0-beta.20

- Desactivation simple et centrale du systeme embarque de delaying des assets du plugin, pour laisser un chargement immediat des widgets

## 0.2.0-beta.19

- Renforcement de la robustesse visuelle du `Marquee Banner (Legacy)` sur mobile et vieux navigateurs
- Suppression du double lazy loading et démarrage de l'animation après chargement et mesure réels des images
- Calcul de la distance de défilement en pixels avec recalcul au chargement, resize et changement d'orientation

## 0.2.0-beta.18

- Ajout du widget Elementor classique `Marquee Banner (Legacy)` en parallele du widget V4
- Ajout du support du delaying CSS et JS global/widget sur ce marquee legacy
- Separation claire entre l'enregistrement des widgets classiques Elementor et des widgets Atomic

## 0.2.0-beta.17

- Correction du chargement CSS et JS des widgets dans le preview Elementor en traitant correctement les contextes `editor` et `preview`
- Enregistrement des handles d'assets aussi sur les hooks d'editor Elementor pour fiabiliser le rendu du canvas

## 0.2.0-beta.16

- Ajout d'un vrai switch widget `Enable delaying` separe pour le CSS et le JS
- Possibilite de desactiver explicitement le delaying au niveau d'un widget sans toucher aux triggers

## 0.2.0-beta.15

- Ajout du trigger `Fallback only` dans le socle de delaying CSS/JS global et widget
- Forcage automatique du fallback quand ce trigger est selectionne

## 0.2.0-beta.14

- Ajout d'un socle unifie de delaying CSS et JS pour les widgets, avec resolution globale vs widget
- Ajout d'une section globale `Asset Delivery` dans la page `Features`
- Ajout de reglages `CSS Delivery` et `JS Delivery` dans `Fullscreen Menu` et `Marquee Carousel`
- Delivery frontend unifie avec triggers `viewport` ou `interaction`, fallback temporise, et runtime commun

## 0.2.0-beta.13

- Revert du montage externe de l'overlay du `Fullscreen Menu` pour revenir a un rendu entierement contenu dans le header/widget
- Suppression du reglages `Overlay mount target` et du toggle porte associe

## 0.2.0-beta.12

- Ajout d'un toggle de fermeture porté au-dessus de l'overlay du `Fullscreen Menu`
- Correction du cas où le bouton d'ouverture passait sous l'overlay et ne permettait plus de refermer le menu
- Synchronisation de l'état visuel du toggle entre le bouton source et le bouton porté

## 0.2.0-beta.11

- Ajout d'un réglage `Overlay mount target` dans le `Fullscreen Menu`
- Support des cibles `Closest header`, `Body` et `Custom selector` pour choisir où monter l'overlay
- Propagation du sélecteur custom jusqu'au runtime frontend avec fallback silencieux sur `body`

## 0.2.0-beta.10

- Déplacement de l'overlay du `Fullscreen Menu` hors du container du widget pour éviter qu'un ancêtre transformé ne bloque son `position: fixed`
- Montage automatique de l'overlay sous le `header` ancêtre le plus proche, ou sous `body` à défaut
- Synchronisation des variables CSS du widget vers l'overlay déplacé afin de conserver les styles configurés

## 0.2.0-beta.9

- Décision du mode responsive du `Fullscreen Menu` côté serveur pour éviter le basculement de layout au premier paint
- Suppression du pilotage du layout initial par JS afin de réduire le risque de CLS, notamment en `overlay only`
- Ajout d'un switch `Inline asset injection` dans le widget pour choisir entre assets inline et fichiers externes côté frontoffice
- Alignement du preview Elementor et du rendu frontend sur les nouvelles règles de layout du menu

## 0.2.0-beta.8

- Restauration de la cible `base` du `Fullscreen Menu` pour réactiver les réglages de spacing du wrapper dans l’onglet `Style`
- Réintégration des classes Atomic du widget dans le rendu preview/front pour que les styles V4 appliqués au wrapper aient de nouveau un effet

## 0.2.0-beta.7

- Stabilisation des contrôles custom du `Fullscreen Menu` dans l’éditeur Atomic V4
- Correction de la validation des champs `letter spacing` au save
- Ajout de vrais contrôles `font-family` avec presets et valeur custom conditionnelle
- Ajout d’un sanitiseur de document Elementor pour fiabiliser les payloads du widget

## 0.2.0-beta.6

- Correction de l'application des styles de typo du `Fullscreen Menu`
- Ajout de styles de typo distincts pour les liens desktop et les liens d'overlay
- Ajout du mode `Overlay only` pour conserver le hamburger sur tous les écrans

## 0.2.0-beta.5

- Suppression de la dépendance frontend du `Fullscreen Menu` au runtime Atomic d'Elementor

## 0.2.0-beta.4

- Correction du chargement trop tôt du domaine de traduction pour éviter le notice `_load_textdomain_just_in_time`

## 0.2.0-beta.3

- Intégration du wrapper `Fullscreen Menu` en `display: flex`
- Bump de version pour publication du canal beta

## 0.2.0-beta.2

- Bump de version pour test end-to-end de la pipeline d’update GitHub

## 0.2.0-beta.1

- Ajout du `PluginUpdater` GitHub avec manifest public `beta` / `prod`
- Ajout de la workflow GitHub de publication vers `webinart/thecore-elementor-widgets-updates`
- Remplacement du widget `Classic Menu` par le port V4 du widget legacy `Fullscreen Menu`
- Nettoyage de l’ancienne implémentation multi-niveaux et de ses assets hamburger dédiés
- Ajout d’une normalisation testée des réglages d’affichage du `Fullscreen Menu`

## 0.1.0

- Initialisation du plugin `The Core - Elementor Widgets`
- Mise en place de l’admin `The Core` avec pages `Widgets` et `Features`
- Ajout du socle Atomic pour `Classic Menu`
- Mise en place de l’outillage local Composer, PHPUnit et PHPCS
- Ajout du choix d’effet d’animation du hamburger
- Ajout du breakpoint mobile configurable par widget
- Chargement conditionnel des styles d’effet du hamburger par page
