<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Legacy\Widgets\HeaderMenu;

final class DisplaySettings
{
    public const DEFAULT_MODEL = 'home-inspired';
    public const DEFAULT_BREAKPOINT = '1024';
    public const DEFAULT_TOGGLE_LABEL = 'Menu';

    /**
     * @param array<string, mixed> $settings
     *
     * @return array{
     *     menu_id: int,
     *     menu_model: string,
     *     mobile_breakpoint: string,
     *     mobile_toggle_label: string
     * }
     */
    public function normalize(array $settings): array
    {
        return [
            'menu_id' => isset($settings['menu_id']) ? absint($settings['menu_id']) : 0,
            'menu_model' => $this->sanitizeModel($settings['menu_model'] ?? self::DEFAULT_MODEL),
            'mobile_breakpoint' => $this->sanitizeBreakpoint($settings['mobile_breakpoint'] ?? self::DEFAULT_BREAKPOINT),
            'mobile_toggle_label' => $this->sanitizeText(
                $settings['mobile_toggle_label'] ?? self::DEFAULT_TOGGLE_LABEL,
                self::DEFAULT_TOGGLE_LABEL
            ),
        ];
    }

    private function sanitizeModel(mixed $value): string
    {
        if (! is_string($value)) {
            return self::DEFAULT_MODEL;
        }

        return in_array($value, ['home-inspired', 'minimal-light'], true)
            ? $value
            : self::DEFAULT_MODEL;
    }

    private function sanitizeBreakpoint(mixed $value): string
    {
        if (! is_scalar($value)) {
            return self::DEFAULT_BREAKPOINT;
        }

        $value = (string) $value;

        return in_array($value, ['768', '1024'], true)
            ? $value
            : self::DEFAULT_BREAKPOINT;
    }

    private function sanitizeText(mixed $value, string $default): string
    {
        if (! is_scalar($value)) {
            return $default;
        }

        $sanitized = sanitize_text_field((string) $value);

        return '' !== $sanitized ? $sanitized : $default;
    }
}
