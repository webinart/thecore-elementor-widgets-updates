<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\MarqueeCarousel;

final class DisplaySettings
{
    public const DEFAULT_MARQUEE_SPEED = 18;
    public const DEFAULT_IMAGE_HEIGHT = 80;
    public const DEFAULT_IMAGE_OPACITY = 100;
    public const DEFAULT_IMAGE_GAP = 0;
    public const DEFAULT_BACKGROUND_COLOR = '#FFFBE9';
    public const DEFAULT_LAZY_LOAD = true;
    public const DEFAULT_LAZY_METHOD = 'scroll';
    public const DEFAULT_LAZY_DELAY = 1000;
    public const DEFAULT_SHOW_PAUSE_BUTTON = true;

    /**
     * @param array<string, mixed> $settings
     *
     * @return array{
     *     items: array<int, array{
     *         image_id: int,
     *         image_url: string,
     *         alt: string,
     *         link_url: string,
     *         link_external: bool,
     *         link_nofollow: bool,
     *         item_scale: float,
     *         item_padding_left: int,
     *         item_padding_right: int
     *     }>,
     *     marquee_speed: int,
     *     image_height: int,
     *     image_opacity: int,
     *     image_gap: int,
     *     background_color: string,
     *     lazy_load: bool,
     *     lazy_method: string,
     *     lazy_delay: int,
     *     show_pause_button: bool
     * }
     */
    public function normalize(array $settings): array
    {
        $lazyLoad = $this->toBool($settings['lazy_load'] ?? self::DEFAULT_LAZY_LOAD);

        return [
            'items' => $this->sanitizeItems($settings['items'] ?? []),
            'marquee_speed' => $this->clampInt(
                $settings['marquee_speed'] ?? self::DEFAULT_MARQUEE_SPEED,
                5,
                60,
                self::DEFAULT_MARQUEE_SPEED
            ),
            'image_height' => $this->clampInt(
                $settings['image_height'] ?? self::DEFAULT_IMAGE_HEIGHT,
                24,
                180,
                self::DEFAULT_IMAGE_HEIGHT
            ),
            'image_opacity' => $this->clampInt(
                $settings['image_opacity'] ?? self::DEFAULT_IMAGE_OPACITY,
                0,
                100,
                self::DEFAULT_IMAGE_OPACITY
            ),
            'image_gap' => $this->clampInt(
                $settings['image_gap'] ?? self::DEFAULT_IMAGE_GAP,
                0,
                100,
                self::DEFAULT_IMAGE_GAP
            ),
            'background_color' => $this->sanitizeColor(
                $settings['background_color'] ?? self::DEFAULT_BACKGROUND_COLOR,
                self::DEFAULT_BACKGROUND_COLOR
            ),
            'lazy_load' => $lazyLoad,
            'lazy_method' => $lazyLoad
                ? $this->sanitizeEnum(
                    $settings['lazy_method'] ?? self::DEFAULT_LAZY_METHOD,
                    ['scroll', 'delay'],
                    self::DEFAULT_LAZY_METHOD
                )
                : self::DEFAULT_LAZY_METHOD,
            'lazy_delay' => $lazyLoad
                ? $this->clampInt(
                    $settings['lazy_delay'] ?? self::DEFAULT_LAZY_DELAY,
                    100,
                    5000,
                    self::DEFAULT_LAZY_DELAY
                )
                : self::DEFAULT_LAZY_DELAY,
            'show_pause_button' => $this->toBool(
                $settings['show_pause_button'] ?? self::DEFAULT_SHOW_PAUSE_BUTTON
            ),
        ];
    }

    /**
     * @param mixed $items
     *
     * @return array<int, array{
     *     image_id: int,
     *     image_url: string,
     *     alt: string,
     *     link_url: string,
     *     link_external: bool,
     *     link_nofollow: bool,
     *     item_scale: float,
     *     item_padding_left: int,
     *     item_padding_right: int
     * }>
     */
    private function sanitizeItems(mixed $items): array
    {
        if (! is_array($items)) {
            return [];
        }

        $normalized = [];

        foreach (array_slice($items, 0, 100) as $item) {
            if (! is_array($item)) {
                continue;
            }

            $imageId = $this->toPositiveInt($item['image_id'] ?? 0);
            $imageUrl = $this->sanitizeUrl($item['image_url'] ?? '');

            if ('' === $imageUrl && $imageId > 0) {
                $imageUrl = $this->resolveAttachmentUrl($imageId);
            }

            if ('' === $imageUrl) {
                continue;
            }

            $alt = $this->sanitizeText((string) ($item['alt'] ?? ''));

            if ('' === $alt && $imageId > 0 && function_exists('get_post_meta')) {
                $alt = trim((string) get_post_meta($imageId, '_wp_attachment_image_alt', true));
            }

            $normalized[] = [
                'image_id' => $imageId,
                'image_url' => $imageUrl,
                'alt' => $alt,
                'link_url' => $this->sanitizeUrl($item['link_url'] ?? ''),
                'link_external' => $this->toBool($item['link_external'] ?? false),
                'link_nofollow' => $this->toBool($item['link_nofollow'] ?? false),
                'item_scale' => $this->clampFloat($item['item_scale'] ?? 1, 0.1, 5.0, 1.0),
                'item_padding_left' => $this->clampInt($item['item_padding_left'] ?? 0, 0, 40, 0),
                'item_padding_right' => $this->clampInt($item['item_padding_right'] ?? 0, 0, 40, 0),
            ];
        }

        return $normalized;
    }

    private function clampInt(mixed $value, int $min, int $max, int $default): int
    {
        if (! is_numeric($value)) {
            return $default;
        }

        return max($min, min($max, (int) $value));
    }

    private function clampFloat(mixed $value, float $min, float $max, float $default): float
    {
        if (! is_numeric($value)) {
            return $default;
        }

        return max($min, min($max, (float) $value));
    }

    private function toPositiveInt(mixed $value): int
    {
        if (! is_numeric($value)) {
            return 0;
        }

        return max(0, (int) $value);
    }

    private function toBool(mixed $value): bool
    {
        if (is_bool($value)) {
            return $value;
        }

        if (is_numeric($value)) {
            return 1 === (int) $value;
        }

        if (! is_string($value)) {
            return false;
        }

        return in_array(
            strtolower(trim($value)),
            ['1', 'true', 'yes', 'on'],
            true
        );
    }

    private function sanitizeEnum(mixed $value, array $allowedValues, string $default): string
    {
        if (! is_string($value)) {
            return $default;
        }

        return in_array($value, $allowedValues, true) ? $value : $default;
    }

    private function sanitizeColor(mixed $value, string $default): string
    {
        if (! is_string($value)) {
            return $default;
        }

        $normalized = trim($value);

        if ('' === $normalized) {
            return $default;
        }

        if (1 === preg_match('/^#(?:[0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/', $normalized)) {
            return $normalized;
        }

        if (1 === preg_match('/^(?:rgb|rgba|hsl|hsla)\([0-9.,%\s\/-]+\)$/i', $normalized)) {
            return $normalized;
        }

        if (1 === preg_match('/^var\(--[a-zA-Z0-9_-]+\)$/', $normalized)) {
            return $normalized;
        }

        if (in_array(strtolower($normalized), ['transparent', 'currentcolor', 'inherit'], true)) {
            return $normalized;
        }

        return $default;
    }

    private function sanitizeText(string $value): string
    {
        if (function_exists('sanitize_text_field')) {
            return sanitize_text_field($value);
        }

        return trim(strip_tags($value));
    }

    private function sanitizeUrl(mixed $value): string
    {
        if (! is_string($value)) {
            return '';
        }

        $normalized = trim($value);

        if ('' === $normalized) {
            return '';
        }

        if (function_exists('esc_url_raw')) {
            $sanitized = trim(esc_url_raw($normalized));

            return '' === $sanitized ? '' : $sanitized;
        }

        $validated = filter_var($normalized, FILTER_VALIDATE_URL);

        if (! is_string($validated) || '' === $validated) {
            return '';
        }

        $scheme = parse_url($validated, PHP_URL_SCHEME);

        return in_array(strtolower((string) $scheme), ['http', 'https'], true) ? $validated : '';
    }

    private function resolveAttachmentUrl(int $imageId): string
    {
        if (! function_exists('wp_get_attachment_image_url')) {
            return '';
        }

        $url = wp_get_attachment_image_url($imageId, 'full');

        return is_string($url) ? $url : '';
    }
}
