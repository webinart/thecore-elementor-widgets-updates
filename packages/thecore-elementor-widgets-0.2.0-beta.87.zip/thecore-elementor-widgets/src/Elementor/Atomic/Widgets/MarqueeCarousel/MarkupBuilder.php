<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\MarqueeCarousel;

final class MarkupBuilder
{
    private const PLACEHOLDER_IMAGE = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==';

    /**
     * @param array<int, array{
     *     image_id: int,
     *     image_url: string,
     *     alt: string,
     *     link_url: string,
     *     link_external: bool,
     *     link_nofollow: bool,
     *     item_scale: float,
     *     item_padding_left: int,
     *     item_padding_right: int
     * }> $items
     */
    public function build(
        array $items,
        string $widgetId,
        bool $lazyLoad,
        string $lazyMethod,
        int $lazyDelay,
        bool $showPauseButton = true
    ): string {
        if ([] === $items) {
            return $this->renderEmptyState(
                __('Add at least one image item to render the Marquee Carousel widget.', 'thecore-elementor-widgets')
            );
        }

        $trackId = 'thecore-marquee-track-' . sanitize_html_class($widgetId);
        $markup = '';
        $markup .= '<div';
        $markup .= ' id="' . esc_attr($trackId) . '"';
        $markup .= ' class="thecore-marquee-carousel__track"';
        $markup .= ' data-thecore-marquee-track="true"';
        $markup .= ' data-lazy="' . ($lazyLoad ? '1' : '0') . '"';
        $markup .= ' data-lazy-method="' . esc_attr($lazyMethod) . '"';
        $markup .= ' data-lazy-delay="' . esc_attr((string) $lazyDelay) . '"';
        $markup .= ' aria-live="off"';
        $markup .= '>';

        for ($loopIndex = 0; $loopIndex < 2; $loopIndex++) {
            $isClone = 1 === $loopIndex;

            foreach ($items as $index => $item) {
                $markup .= $this->renderItem($item, $index, $lazyLoad, $isClone);
            }
        }

        $markup .= '</div>';

        if ($showPauseButton) {
            $markup .= $this->renderPauseButton();
        }

        return $markup;
    }

    /**
     * @param array{
     *     image_id: int,
     *     image_url: string,
     *     alt: string,
     *     link_url: string,
     *     link_external: bool,
     *     link_nofollow: bool,
     *     item_scale: float,
     *     item_padding_left: int,
     *     item_padding_right: int
     * } $item
     */
    private function renderItem(array $item, int $index, bool $lazyLoad, bool $isClone): string
    {
        $attributes = [
            'class' => 'thecore-marquee-carousel__item',
            'data-thecore-marquee-item-index' => (string) $index,
        ];

        if ($isClone) {
            $attributes['aria-hidden'] = 'true';
        }

        $markup = '<div' . $this->buildAttributes($attributes) . '>';
        $hasLink = '' !== $item['link_url'];

        if ($hasLink) {
            $markup .= '<a' . $this->buildAttributes($this->buildLinkAttributes($item, $isClone)) . '>';
        }

        $markup .= $this->renderImage($item, $lazyLoad, $isClone);

        if ($hasLink) {
            $markup .= '</a>';
        }

        $markup .= '</div>';

        return $markup;
    }

    /**
     * @param array{image_id: int, image_url: string, alt: string} $item
     */
    private function renderImage(array $item, bool $lazyLoad, bool $isClone): string
    {
        $source = $this->resolveImageSource($item);
        $attributes = [
            'class' => 'thecore-marquee-carousel__image' . ($lazyLoad ? ' is-lazy' : ''),
            'alt' => $isClone ? '' : $item['alt'],
            'loading' => $lazyLoad ? 'lazy' : 'eager',
            'decoding' => 'async',
        ];

        if ($source['width'] > 0 && $source['height'] > 0) {
            $attributes['width'] = (string) $source['width'];
            $attributes['height'] = (string) $source['height'];
        }

        if ($lazyLoad) {
            $attributes['src'] = self::PLACEHOLDER_IMAGE;
            $attributes['data-thecore-marquee-src'] = $source['url'];

            if ('' !== $source['srcset']) {
                $attributes['data-thecore-marquee-srcset'] = $source['srcset'];
            }

            if ('' !== $source['sizes']) {
                $attributes['data-thecore-marquee-sizes'] = $source['sizes'];
            }
        } else {
            $attributes['src'] = $source['url'];

            if ('' !== $source['srcset']) {
                $attributes['srcset'] = $source['srcset'];
            }

            if ('' !== $source['sizes']) {
                $attributes['sizes'] = $source['sizes'];
            }
        }

        return '<img' . $this->buildAttributes($attributes) . ' />';
    }

    /**
     * @param array{image_id: int, image_url: string} $item
     * @return array{url: string, width: int, height: int, srcset: string, sizes: string}
     */
    private function resolveImageSource(array $item): array
    {
        $source = [
            'url' => $item['image_url'],
            'width' => 0,
            'height' => 0,
            'srcset' => '',
            'sizes' => '',
        ];

        if ($item['image_id'] <= 0) {
            return $source;
        }

        $attachment = wp_get_attachment_image_src($item['image_id'], 'full');

        if (is_array($attachment)) {
            $source['url'] = (string) ($attachment[0] ?? $source['url']);
            $source['width'] = max(0, (int) ($attachment[1] ?? 0));
            $source['height'] = max(0, (int) ($attachment[2] ?? 0));
        }

        $srcset = wp_get_attachment_image_srcset($item['image_id'], 'full');
        $source['srcset'] = is_string($srcset) ? $srcset : '';

        $sizes = wp_get_attachment_image_sizes($item['image_id'], 'full');
        $source['sizes'] = is_string($sizes) ? $sizes : '';

        return $source;
    }

    private function renderPauseButton(): string
    {
        return '<button' . $this->buildAttributes([
            'class' => 'thecore-marquee-carousel__toggle',
            'type' => 'button',
            'data-thecore-marquee-toggle' => 'true',
            'data-pause-label' => __('Mettre le carrousel de logos en pause', 'thecore-elementor-widgets'),
            'data-play-label' => __('Relancer le carrousel de logos', 'thecore-elementor-widgets'),
            'aria-label' => __('Mettre le carrousel de logos en pause', 'thecore-elementor-widgets'),
            'aria-pressed' => 'false',
        ]) . '><span aria-hidden="true"></span></button>';
    }

    /**
     * @param array{
     *     image_id: int,
     *     image_url: string,
     *     alt: string,
     *     link_url: string,
     *     link_external: bool,
     *     link_nofollow: bool,
     *     item_scale: float,
     *     item_padding_left: int,
     *     item_padding_right: int
     * } $item
     *
     * @return array<string, string>
     */
    private function buildLinkAttributes(array $item, bool $isClone): array
    {
        $attributes = [
            'class' => 'thecore-marquee-carousel__link',
            'href' => $item['link_url'],
        ];

        if ($item['link_external']) {
            $attributes['target'] = '_blank';
        }

        $rel = [];

        if ($item['link_nofollow']) {
            $rel[] = 'nofollow';
        }

        if ($item['link_external']) {
            $rel[] = 'noopener';
            $rel[] = 'noreferrer';
        }

        if ([] !== $rel) {
            $attributes['rel'] = implode(' ', array_unique($rel));
        }

        if ($isClone) {
            $attributes['tabindex'] = '-1';
            $attributes['aria-hidden'] = 'true';
        }

        return $attributes;
    }

    private function renderEmptyState(string $message): string
    {
        if (! $this->isElementorEditingContext()) {
            return '';
        }

        return sprintf(
            '<div class="thecore-marquee-carousel__empty">%s</div>',
            esc_html($message)
        );
    }

    /**
     * @param array<string, string> $attributes
     */
    private function buildAttributes(array $attributes): string
    {
        $markup = '';

        foreach ($attributes as $name => $value) {
            $escapedValue = in_array($name, ['href', 'data-thecore-marquee-src'], true)
                ? esc_url($value)
                : esc_attr($value);

            $markup .= sprintf(
                ' %s="%s"',
                esc_attr($name),
                $escapedValue
            );
        }

        return $markup;
    }

    private function isElementorEditingContext(): bool
    {
        if (! class_exists('\Elementor\Plugin')) {
            return false;
        }

        return \Elementor\Plugin::$instance->editor->is_edit_mode()
            || \Elementor\Plugin::$instance->preview->is_preview_mode();
    }
}
