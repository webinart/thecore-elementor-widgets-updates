# The Core - Elementor Widgets

Plugin WordPress dédié aux widgets Elementor et fonctionnalités partagées de
The Core, notamment les Forms legacy Elementor Pro.

Version courante: `0.2.0-beta.109`
Statut de maturité: beta

## Périmètre actuel

- Interface admin top-level `The Core - Widgets`
- Page `Widgets` avec activation/désactivation par widget
- Page `Features` avec activation/désactivation des fonctionnalités globales
- Visionneuse d'images générique opt-in pour les galeries V4 natives, sans
  jQuery ni runtime Elementor : [configuration et tests](docs/image-lightbox.md)
- Sommaires repliables et vidéos au clic opt-in pour les éléments V4 natifs :
  [contrats de balisage et activation](docs/native-content-interactions.md)
- Module opt-in `Elementor Form Security` pour les Forms legacy Elementor Pro :
  ALTCHA auto-hébergé, anti-rejeu, quotas atomiques, déduplication et
  minimisation des métadonnées, avec journal temporaire des rejets
- Widgets Atomic actuels: `Fullscreen Menu`, `Marquee Carousel`, `Text List`, `Texte animé (V4)`, `Diaporama de fond (V4)`, `Breadcrumb`, `Icon Text`, `Counter (V4)`, `Formulaire The Core`
- Texte animé V4 autonome avec phrases éditables, affichage fixe alternatif et
  pause locale ou globale : [configuration et tests](docs/animated-text.md)
- Diaporama de fond V4 autonome avec images ordonnables, fondu, zoom Ken Burns,
  recadrage mobile et pause locale ou globale : [configuration et tests](docs/background-slideshow.md)
- Compteur V4 autonome avec animation au scroll, format numérique et valeur
  finale accessible sans JavaScript : [configuration et tests](docs/atomic-counter.md)
- Formulaire V4 avec champs natifs Elementor Pro, actions Email et MailPoet,
  anti-spam obligatoire et tests signes sans email ni inscription newsletter :
  [documentation et contrat de suivi de flotte](docs/atomic-forms.md)
- Action **Envoyer à une API** partagée entre formulaires Atomic et Elementor Pro,
  connexions serveur, mapping JSON et reprises identifiées :
  [configuration du connecteur](docs/forms-api-connector.md)
- Moteur frontend natif sans jQuery pour les formulaires Elementor classiques,
  activable explicitement par instance, avec étapes et traitement PHP existant :
  [contrat et intégration](docs/native-classic-forms.md)
- Système d’update distant GitHub via manifest public `beta` / `prod`
- Outillage local: Composer, PHPUnit, PHPCS

## Versioning

- Format beta: `x.x.x-beta.n`
- Format production: `x.x.x`
- Canaux visés: beta et production

## Updates

- Repo source privé: `webinart/thecore-elementor-widgets`
- Repo public de distribution: `webinart/thecore-elementor-widgets-updates`
- Branche de publication des manifests et archives: `plugin-updates`
- Secret GitHub Actions attendu dans le repo privé: `UPDATES_REPO_SSH_KEY`

## Commandes locales

```bash
composer install
composer test
composer test:js
composer cs:check
```

## Elementor Form Security

1. Activer `Elementor Form Security` dans `The Core - Widgets > Features`.
2. Ajouter une seule fois le champ
   `The Core — Protection anti-spam` dans le repeater du widget Form legacy.
3. Conserver la mention RGPD dans un champ HTML Elementor ordinaire afin que
   son texte et son lien restent propres au responsable de traitement.

La protection est entièrement locale : aucune clé SaaS et aucun appel à un
service anti-spam externe. Un formulaire qui contient le champ de protection
échoue fermé si la feature ou son schéma SQL est indisponible. Les formulaires
qui ne contiennent pas ce champ restent inchangés.

La feature est désactivée par défaut. Le plugin doit rester actif tant qu’un
formulaire publié contient ce champ ; toute désactivation nécessite un
rollback coordonné du formulaire.

Le schéma est installé à l’activation du plugin et mis à niveau depuis
l’administration. Il peut être contrôlé avec :

```bash
wp thecore form-security schema verify
wp thecore form-security status
```

Le module protège et minimise uniquement les **nouvelles** soumissions des
formulaires opt-in. Pour certains motifs de rejet utiles au diagnostic, il peut
conserver au plus 200 détails par site et par fenêtre de 24 heures. Ils sont
consultables dans `The Core - Widgets > Soumissions bloquées` : la liste présente
notamment le nom, l’e-mail et le message lorsqu’ils existent, puis la vue
détaillée les autres champs métier autorisés. Le journal exclut IP brute,
User-Agent, preuves techniques, mots de passe et pièces jointes, et s’intègre
aux outils WordPress d’export/effacement des données personnelles. Il n’envoie
aucune notification par e-mail.

Chaque entrée est éligible à l’effacement après 30 jours par défaut, puis
supprimée par le prochain nettoyage WP-Cron. Une désactivation explicite du
plugin depuis WordPress supprime immédiatement la table du journal ; une mise à
jour standard ou la désactivation de la seule feature ne la purge pas.

Le module ne définit ni les destinataires, ni les actions Elementor, ni le
texte RGPD, ni la durée de conservation des demandes acceptées et des e-mails.
Ces choix restent propres à chaque site.

La documentation technique et la procédure d’intégration sont détaillées dans
[`docs/form-security.md`](docs/form-security.md).
