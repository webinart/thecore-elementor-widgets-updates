<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\NativeInteractions;

use Elementor\Modules\AtomicWidgets\PropsResolver\Props_Resolver_Context;
use Elementor\Modules\AtomicWidgets\PropsResolver\Transformer_Base;

final class InteractionAttributesTransformer extends Transformer_Base
{
    private const DISCLOSURE = [
        'data-thecore-disclosure',
        'data-thecore-disclosure-toggle',
        'data-thecore-disclosure-panel',
        'data-thecore-disclosure-breakpoint',
    ];
    private const VIDEO = [
        'data-thecore-video',
        'data-thecore-video-provider',
        'data-thecore-video-id',
        'data-thecore-video-title',
    ];

    public function __construct(
        private readonly Transformer_Base $delegate,
        private readonly bool $disclosure,
        private readonly bool $video
    ) {
    }

    public function transform($value, Props_Resolver_Context $context)
    {
        if (! is_array($value)) {
            return $this->delegate->transform($value, $context);
        }
        $allowed = array_merge($this->disclosure ? self::DISCLOSURE : [], $this->video ? self::VIDEO : []);
        $remaining = [];
        $owned = [];
        foreach ($value as $index => $item) {
            $key = is_array($item) ? ($item['key'] ?? null) : null;
            if (! in_array($key, $allowed, true)) {
                $remaining[$index] = $item;
                continue;
            }
            $valid = $this->validate($key, $item['value'] ?? null);
            if (null !== $valid) {
                $owned[$key] = $valid;
            }
        }
        // All unrelated attributes retain the site's existing free/Pro/security policy.
        $rendered = $this->delegate->transform($remaining, $context);
        if ([] === $owned) {
            return $rendered;
        }
        $attributes = [];
        foreach ($owned as $key => $attributeValue) {
            $attributes[] = $key . '="' . esc_attr($attributeValue) . '"';
        }

        return (is_string($rendered) ? $rendered : '')
            . ([] !== $attributes && is_string($rendered) && '' !== $rendered ? ' ' : '')
            . implode(' ', $attributes);
    }

    private function validate(string $key, mixed $value): ?string
    {
        if (! is_string($value) || '' === trim($value) || preg_match('/[\x00-\x1F\x7F]/', $value)) {
            return null;
        }
        $value = trim($value);
        if ('data-thecore-disclosure-breakpoint' === $key) {
            return ctype_digit($value) && (int) $value >= 320 && (int) $value <= 1599 ? $value : null;
        }
        if ('data-thecore-video-provider' === $key) {
            return in_array($value, ['youtube', 'vimeo'], true) ? $value : null;
        }
        if ('data-thecore-video-title' === $key) {
            return strlen($value) <= 2000 ? $value : null;
        }

        return strlen($value) <= 160 && preg_match('/^[A-Za-z0-9][A-Za-z0-9_-]*$/D', $value) ? $value : null;
    }
}
