<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\NativeInteractions;

final class AttributeDetector
{
    public function inGraph(mixed $data, string $attribute, int $depth = 0): bool
    {
        if (is_string($data)) {
            $data = json_decode($data, true);
        }
        if (! is_array($data) || $depth > 100) {
            return false;
        }
        if (
            $attribute === $this->stringValue($data['key'] ?? null)
            && '' !== trim($this->stringValue($data['value'] ?? null))
        ) {
            return true;
        }
        foreach ($data as $key => $value) {
            if ($attribute === $key && '' !== trim($this->stringValue($value))) {
                return true;
            }
            if (is_array($value) && $this->inGraph($value, $attribute, $depth + 1)) {
                return true;
            }
        }

        return false;
    }

    public function inHtml(string $html, string $attribute): bool
    {
        if (! str_contains($html, $attribute)) {
            return false;
        }
        if (class_exists('\WP_HTML_Tag_Processor')) {
            $tags = new \WP_HTML_Tag_Processor($html);
            while ($tags->next_tag()) {
                $value = $tags->get_attribute($attribute);
                if (is_string($value) && '' !== trim($value)) {
                    return true;
                }
            }

            return false;
        }
        if (! class_exists('\DOMDocument')) {
            return false;
        }
        $document = new \DOMDocument();
        $previous = libxml_use_internal_errors(true);
        try {
            $document->loadHTML($html);
            foreach ($document->getElementsByTagName('*') as $element) {
                if ('' !== trim($element->getAttribute($attribute))) {
                    return true;
                }
            }
        } finally {
            libxml_clear_errors();
            libxml_use_internal_errors($previous);
        }

        return false;
    }

    private function stringValue(mixed $value): string
    {
        if (is_array($value)) {
            $value = $value['value'] ?? null;
        }

        return is_string($value) ? $value : '';
    }
}
