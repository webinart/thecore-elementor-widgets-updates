<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\NativeInteractions;

use Elementor\Modules\AtomicWidgets\PropsResolver\Transformer_Base;
use TheCore\ElementorWidgets\Contracts\Bootable;

final class NativeInteractionsModule implements Bootable
{
    private array $enqueued = [];

    public function __construct(
        private readonly bool $disclosure,
        private readonly bool $video,
        private readonly AttributeDetector $detector = new AttributeDetector()
    ) {
    }

    public function register(): void
    {
        add_action('wp_enqueue_scripts', [$this, 'enqueueForCurrentDocument'], 20);
        add_action('elementor/frontend/before_render', [$this, 'enqueueForElement']);
        add_action(
            'elementor/atomic-widgets/settings/transformers/register',
            [$this, 'registerAttributesTransformer'],
            PHP_INT_MAX
        );
        add_filter('elementor/frontend/the_content', [$this, 'filterRenderedContent'], 20);
        add_filter('the_content', [$this, 'filterRenderedContent'], 99);
    }

    public function registerAttributesTransformer(mixed $registry): void
    {
        if (
            ! is_object($registry)
            || ! method_exists($registry, 'get')
            || ! method_exists($registry, 'register')
            || ! class_exists(Transformer_Base::class)
        ) {
            return;
        }
        $delegate = $registry->get('attributes');
        if ($delegate instanceof Transformer_Base && ! $delegate instanceof InteractionAttributesTransformer) {
            $registry->register('attributes', new InteractionAttributesTransformer($delegate, $this->disclosure, $this->video));
        }
    }

    public function enqueueForCurrentDocument(): void
    {
        $id = (int) get_queried_object_id();
        if ($id > 0) {
            $this->enqueueForGraph(get_post_meta($id, '_elementor_data', true));
        }
    }

    public function enqueueForElement(mixed $element): void
    {
        if (is_object($element) && method_exists($element, 'get_data')) {
            $this->enqueueForGraph($element->get_data());
        }
    }

    public function filterRenderedContent(string $content): string
    {
        foreach ($this->enabledModules() as $name => $attribute) {
            if ($this->detector->inHtml($content, $attribute)) {
                $this->enqueueAssets($name);
            }
        }
        foreach (array_keys($this->enqueued) as $handle) {
            if (did_action('wp_head') && ! wp_style_is($handle, 'done')) {
                ob_start();
                wp_print_styles([$handle]);
                $content = (string) ob_get_clean() . $content;
            }
        }

        return $content;
    }

    private function enqueueForGraph(mixed $graph): void
    {
        foreach ($this->enabledModules() as $name => $attribute) {
            if ($this->detector->inGraph($graph, $attribute)) {
                $this->enqueueAssets($name);
            }
        }
    }

    private function enabledModules(): array
    {
        return array_filter([
            'responsive-disclosure' => $this->disclosure ? 'data-thecore-disclosure' : null,
            'click-to-play-video' => $this->video ? 'data-thecore-video' : null,
        ]);
    }

    private function enqueueAssets(string $name): void
    {
        $handle = 'thecore-' . $name;
        $base = THECORE_ELEMENTOR_WIDGETS_PATH . 'assets/frontend/' . $name;
        if (isset($this->enqueued[$handle]) || ! is_readable($base . '.css') || ! is_readable($base . '.js')) {
            return;
        }
        wp_register_style($handle, false, [], THECORE_ELEMENTOR_WIDGETS_VERSION);
        wp_add_inline_style($handle, (string) file_get_contents($base . '.css'));
        wp_enqueue_style($handle);
        wp_register_script($handle, false, [], THECORE_ELEMENTOR_WIDGETS_VERSION, true);
        if ('click-to-play-video' === $name) {
            wp_add_inline_script($handle, 'window.TheCoreClickToPlayLabels=' . wp_json_encode([
                'frame' => __('Lecteur vidéo', 'thecore-elementor-widgets'),
                'loading' => __('Chargement de la vidéo…', 'thecore-elementor-widgets'),
                'fallback' => __('Ouvrir la vidéo sur son site d’origine', 'thecore-elementor-widgets'),
                'close' => __('Fermer la vidéo', 'thecore-elementor-widgets'),
                'error' => __('Le lecteur ne répond pas. Vous pouvez ouvrir la vidéo sur son site d’origine.', 'thecore-elementor-widgets'),
            ], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) . ';', 'before');
        }
        wp_add_inline_script($handle, (string) file_get_contents($base . '.js'));
        wp_enqueue_script($handle);
        $this->enqueued[$handle] = true;
    }
}
