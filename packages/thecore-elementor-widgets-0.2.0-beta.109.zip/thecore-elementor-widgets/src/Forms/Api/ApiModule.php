<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Api;

use TheCore\ElementorWidgets\Contracts\Bootable;

/** Connects the shared API client to native WordPress and Elementor controls. */
final class ApiModule implements Bootable
{
    public const SCRIPT = 'thecore-form-api';
    public const LEGACY_SCRIPT = 'thecore-form-api-legacy';

    public function register(): void
    {
        (new AdminPage(new Connections()))->register();
        add_action('elementor_pro/forms/actions/register', [$this, 'registerLegacyAction']);
        add_action('wp_enqueue_scripts', [$this, 'registerAssets'], 5);
        add_action('elementor/frontend/widget/before_render', [$this, 'enqueueLegacyWidget']);
    }

    public function registerLegacyAction(object $registrar): void
    {
        if (class_exists('\\ElementorPro\\Modules\\Forms\\Classes\\Action_Base') && method_exists($registrar, 'register')) {
            $registrar->register(new LegacyAction());
        }
    }

    public function registerAssets(): void
    {
        wp_register_script(self::SCRIPT, THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/form-api.js', [], THECORE_ELEMENTOR_WIDGETS_VERSION, true);
        wp_register_script(self::LEGACY_SCRIPT, THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/form-api-legacy.js', ['jquery', self::SCRIPT], THECORE_ELEMENTOR_WIDGETS_VERSION, true);
    }

    public function enqueueLegacyWidget(object $widget): void
    {
        if (! method_exists($widget, 'get_name') || $widget->get_name() !== 'form') {
            return;
        }
        $actions = $widget->get_settings_for_display('submit_actions');
        if (is_array($actions) && in_array('thecore_api', $actions, true)) {
            $widget->add_render_attribute('_wrapper', 'data-thecore-api', '1');
            wp_enqueue_script(\TheCore\ElementorWidgets\Forms\Classic\NativeModule::isEnabled($widget)
                ? \TheCore\ElementorWidgets\Forms\Classic\NativeModule::SCRIPT : self::LEGACY_SCRIPT);
        }
    }

    /** Generic editor example, containing field identifiers only. */
    public static function mappingExample(): string
    {
        return '{"version":1,"fields":[{"target":"email","source":"email","type":"string","required":true},{"target":"name","source":"name","type":"string","required":true}]}';
    }

    /** Labels are available only to editors; destinations and secrets stay server-side. */
    public static function connectionOptions(): array
    {
        if (! current_user_can('edit_posts') && ! current_user_can('edit_pages')) {
            return [];
        }
        return (new Connections())->publicOptions();
    }
}
