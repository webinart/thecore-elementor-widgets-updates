<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Classic;

use TheCore\ElementorWidgets\Contracts\Bootable;

/** Opt-in frontend adapter. Elementor remains the sole server-side form processor. */
final class NativeModule implements Bootable
{
    public const SCRIPT = 'thecore-native-classic-form';
    public const FILTER = 'thecore_elementor_widgets/forms/native_classic';

    public function register(): void
    {
        add_action('wp_enqueue_scripts', [$this, 'registerAssets'], 5);
        add_action('elementor/widgets/register', [$this, 'registerWidget'], 1000);
        add_action('elementor/frontend/widget/before_render', [$this, 'prepareWidget'], -10);
    }

    public function registerAssets(): void
    {
        wp_register_script(
            self::SCRIPT,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/native-classic-form.js',
            ['thecore-form-api'],
            THECORE_ELEMENTOR_WIDGETS_VERSION,
            true
        );
        wp_register_style(
            self::SCRIPT,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/native-classic-form.css',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION
        );
    }

    public function registerWidget(object $manager): void
    {
        if (class_exists('\\ElementorPro\\Modules\\Forms\\Widgets\\Form') && method_exists($manager, 'register')) {
            $manager->register(new NativeWidget());
        }
    }

    public static function isEnabled(object $widget): bool
    {
        if (! method_exists($widget, 'get_name') || $widget->get_name() !== 'form') {
            return false;
        }
        if (class_exists('\\Elementor\\Plugin') && \Elementor\Plugin::$instance->editor->is_edit_mode()) {
            return false;
        }
        return apply_filters(self::FILTER, false, $widget) === true;
    }

    public function prepareWidget(object $widget): void
    {
        if (! self::isEnabled($widget)) {
            return;
        }
        $settings = (array) $widget->get_settings_for_display();
        $config = [
            'version' => 1,
            'endpoint' => admin_url('admin-ajax.php'),
            'nextLabel' => (string) ($settings['step_next_label'] ?? 'Continuer'),
            'previousLabel' => (string) ($settings['step_previous_label'] ?? 'Retour'),
            'stepType' => (string) ($settings['step_type'] ?? 'number_text'),
            'stepShape' => (string) ($settings['step_icon_shape'] ?? 'circle'),
            'buttonWidth' => (string) ($settings['button_width'] ?? '100'),
        ];
        $widget->add_render_attribute('_wrapper', 'data-thecore-native-form', '1', true);
        $widget->add_render_attribute('_wrapper', 'data-thecore-native-config', wp_json_encode($config), true);
        wp_enqueue_script(self::SCRIPT);
        wp_enqueue_style(self::SCRIPT);
    }
}
