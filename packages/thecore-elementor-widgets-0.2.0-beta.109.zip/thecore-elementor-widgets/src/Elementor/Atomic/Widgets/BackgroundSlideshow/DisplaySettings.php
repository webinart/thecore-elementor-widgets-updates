<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\BackgroundSlideshow;

final class DisplaySettings
{
    public const DEFAULT_DURATION = 5000;
    public const DEFAULT_TRANSITION = 500;
    public const DEFAULT_ZOOM_AMOUNT = 6;
    public const MAX_IMAGES = 20;

    /**
     * @param array<string, mixed> $settings Resolved native Atomic settings.
     * @return array<string, mixed>
     */
    public function normalize(array $settings): array
    {
        $settings['images'] = $this->normalizeImages($settings['images'] ?? []);
        $settings['mobile_image_size'] = is_string($settings['mobile_image_size'] ?? null)
            ? sanitize_key($settings['mobile_image_size'])
            : '';
        $settings['duration'] = $this->number($settings['duration'] ?? null, 1000, 60000, self::DEFAULT_DURATION);
        $settings['transition'] = $this->number($settings['transition'] ?? null, 0, 3000, self::DEFAULT_TRANSITION);
        $settings['transition'] = min($settings['transition'], (int) floor($settings['duration'] / 2));
        $settings['zoom'] = in_array($settings['zoom'] ?? null, ['in', 'out', 'none'], true) ? $settings['zoom'] : 'in';
        $settings['zoom_amount'] = $this->number($settings['zoom_amount'] ?? null, 0, 20, self::DEFAULT_ZOOM_AMOUNT);
        $settings['show_pause_button'] = $this->boolean($settings['show_pause_button'] ?? true, true);
        $settings['first_image_priority'] = $this->boolean($settings['first_image_priority'] ?? true, true);
        $settings['_pause_label'] = __('Mettre le diaporama en pause', 'thecore-elementor-widgets');
        $settings['_resume_label'] = __('Reprendre le diaporama', 'thecore-elementor-widgets');

        return $settings;
    }

    /** @return list<array<string, int|string>> */
    private function normalizeImages(mixed $images): array
    {
        if (! is_array($images)) {
            return [];
        }

        $normalized = [];

        foreach ($images as $image) {
            if (! is_array($image) || ! is_string($image['src'] ?? null)) {
                continue;
            }

            $source = esc_url_raw($image['src'], ['http', 'https']);

            if ('' === $source) {
                continue;
            }

            $normalized[] = [
                'id' => $this->number($image['id'] ?? 0, 0, PHP_INT_MAX, 0),
                'src' => $source,
                'width' => $this->number($image['width'] ?? 0, 0, 100000, 0),
                'height' => $this->number($image['height'] ?? 0, 0, 100000, 0),
                'srcset' => is_string($image['srcset'] ?? null) ? $image['srcset'] : '',
            ];

            if (count($normalized) >= self::MAX_IMAGES) {
                break;
            }
        }

        return $normalized;
    }

    private function number(mixed $value, int $minimum, int $maximum, int $default): int
    {
        if (! is_numeric($value) || ! is_finite((float) $value)) {
            return $default;
        }

        return (int) max($minimum, min($maximum, round((float) $value)));
    }

    private function boolean(mixed $value, bool $default): bool
    {
        if (is_bool($value)) {
            return $value;
        }

        if (in_array($value, [1, '1', 'true', 'yes'], true)) {
            return true;
        }

        if (in_array($value, [0, '0', 'false', 'no', ''], true)) {
            return false;
        }

        return $default;
    }
}
