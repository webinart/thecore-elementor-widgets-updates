<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\BackgroundSlideshow;

final class ImageMarkupBuilder
{
    /** @param array<string, int|string> $image */
    public function build(array $image, bool $first, bool $priority, string $mobileSize = ''): string
    {
        $attributes = [
            'class' => 'thecore-background-slideshow__image',
            'data-thecore-background-slideshow-image' => '',
            'data-thecore-lazy-exclude' => '1',
            'src' => $image['src'],
            'alt' => '',
            'decoding' => 'async',
            'loading' => $first && $priority ? 'eager' : 'lazy',
            'fetchpriority' => $first && $priority ? 'high' : ($first ? 'auto' : 'low'),
        ];

        foreach (['width', 'height', 'srcset'] as $name) {
            if (! empty($image[$name])) {
                $attributes[$name] = $image[$name];
            }
        }

        if (! empty($image['srcset'])) {
            $attributes['sizes'] = '100vw';
        }

        if (! empty($image['id'])) {
            $size = ! empty($image['width']) && ! empty($image['height'])
                ? [(int) $image['width'], (int) $image['height']]
                : 'full';
            $markup = wp_get_attachment_image((int) $image['id'], $size, false, $attributes);

            if ('' !== $markup) {
                // Restore the loading contract after theme-level image filters.
                if (class_exists(\WP_HTML_Tag_Processor::class)) {
                    $processor = new \WP_HTML_Tag_Processor($markup);

                    if ($processor->next_tag('IMG')) {
                        foreach (['alt', 'loading', 'fetchpriority', 'data-thecore-lazy-exclude'] as $name) {
                            $processor->set_attribute($name, $attributes[$name]);
                        }

                        $markup = $processor->get_updated_html();
                    }
                }

                return $this->wrapMobileSource($image, $markup, $mobileSize);
            }
        }

        $markup = '<img';

        foreach ($attributes as $name => $value) {
            $markup .= sprintf(' %s="%s"', $name, esc_attr((string) $value));
        }

        return $this->wrapMobileSource($image, $markup . '>', $mobileSize);
    }

    /** @param array<string, int|string> $image */
    private function wrapMobileSource(array $image, string $markup, string $mobileSize): string
    {
        if ('' === $mobileSize || empty($image['id'])) {
            return $markup;
        }

        $attachmentId = (int) $image['id'];
        $mobile = wp_get_attachment_image_src($attachmentId, $mobileSize);

        // WordPress returns the original when a requested crop is missing.
        if (! $mobile || empty($mobile[1]) || empty($mobile[2]) || ('full' !== $mobileSize && empty($mobile[3]))) {
            return $markup;
        }

        $srcset = wp_get_attachment_image_srcset($attachmentId, $mobileSize);

        if (! is_string($srcset) || '' === $srcset) {
            $srcset = $mobile[0] . ' ' . (int) $mobile[1] . 'w';
        }

        return sprintf(
            '<picture class="thecore-background-slideshow__picture"><source media="(max-width: 767px)" srcset="%s" sizes="100vw" width="%d" height="%d">%s</picture>',
            esc_attr($srcset),
            (int) $mobile[1],
            (int) $mobile[2],
            $markup
        );
    }
}
