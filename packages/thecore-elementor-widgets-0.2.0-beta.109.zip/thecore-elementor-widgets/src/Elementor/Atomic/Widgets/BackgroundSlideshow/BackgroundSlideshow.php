<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\BackgroundSlideshow;

use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Image_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Number_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Repeatable_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Select_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Switch_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Text_Control;
use Elementor\Modules\AtomicWidgets\DynamicTags\Dynamic_Prop_Type;
use Elementor\Modules\AtomicWidgets\Elements\Base\Atomic_Widget_Base;
use Elementor\Modules\AtomicWidgets\Elements\Base\Has_Template;
use Elementor\Modules\AtomicWidgets\Elements\TemplateRenderer\Template_Renderer;
use Elementor\Modules\AtomicWidgets\PropTypes\Attributes_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Classes_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Image_Src_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Boolean_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Number_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Size_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Url_Prop_Type;
use Elementor\Modules\AtomicWidgets\Styles\Style_Definition;
use Elementor\Modules\AtomicWidgets\Styles\Style_Variant;
use Elementor\Modules\AtomicWidgets\Utils\Image\Placeholder_Image;
use Elementor\Modules\AtomicWidgets\Utils\Image\Image_Sizes;
use Elementor\Modules\Components\PropTypes\Overridable_Prop_Type;
use TheCore\ElementorWidgets\Assets\FrontendAssets;
use TheCore\ElementorWidgets\Elementor\Atomic\PropTypes\SlideshowImagesPropType;

final class BackgroundSlideshow extends Atomic_Widget_Base
{
    use Has_Template;

    public static $widget_description = 'Decorative responsive background slideshow with native image controls and independent accessible motion.';

    public static function get_element_type(): string
    {
        return 'thecore-background-slideshow';
    }

    public function get_title(): string
    {
        return esc_html__('Diaporama de fond (V4)', 'thecore-elementor-widgets');
    }

    public function get_icon(): string
    {
        return 'eicon-slideshow';
    }

    public function get_keywords(): array
    {
        return ['diaporama', 'slideshow', 'background', 'image', 'atomic'];
    }

    public function get_script_depends(): array
    {
        return [FrontendAssets::BACKGROUND_SLIDESHOW_SCRIPT];
    }

    public function get_style_depends(): array
    {
        return [FrontendAssets::BACKGROUND_SLIDESHOW_STYLE];
    }

    protected static function define_props_schema(): array
    {
        return [
            'classes' => Classes_Prop_Type::make()->default([]),
            'images' => SlideshowImagesPropType::make()->default([])
                ->meta(Dynamic_Prop_Type::ignore())->meta(Overridable_Prop_Type::ignore()),
            'duration' => Number_Prop_Type::make()->default(DisplaySettings::DEFAULT_DURATION),
            'transition' => Number_Prop_Type::make()->default(DisplaySettings::DEFAULT_TRANSITION),
            'zoom' => String_Prop_Type::make()->enum(['in', 'out', 'none'])->default('in'),
            'zoom_amount' => Number_Prop_Type::make()->default(DisplaySettings::DEFAULT_ZOOM_AMOUNT),
            'show_pause_button' => Boolean_Prop_Type::make()->default(true),
            'first_image_priority' => Boolean_Prop_Type::make()->default(true),
            'mobile_image_size' => String_Prop_Type::make()->enum(array_merge([''], Image_Sizes::get_keys()))->default(''),
            'attributes' => Attributes_Prop_Type::make()->meta(Overridable_Prop_Type::ignore()),
        ];
    }

    protected function define_base_styles(): array
    {
        return [
            'base' => Style_Definition::make()->add_variant(
                Style_Variant::make()
                    ->add_prop('min-height', Size_Prop_Type::generate(['size' => 320, 'unit' => 'px']))
            ),
        ];
    }

    protected function define_atomic_controls(): array
    {
        return [
            Section::make()->set_label(__('Images', 'thecore-elementor-widgets'))->set_id('content')->set_items([
                Repeatable_Control::bind_to('images')
                    ->set_label(__('Images du diaporama', 'thecore-elementor-widgets'))
                    ->set_child_control_type('image')
                    ->set_child_control_props(Image_Control::bind_to('images')->get_props())
                    ->set_prop_key(SlideshowImagesPropType::get_key())
                    ->set_repeaterLabel(__('Images', 'thecore-elementor-widgets'))
                    ->set_patternLabel(__('Image ${value.src.value.id.value}', 'thecore-elementor-widgets'))
                    ->set_placeholder(__('Aucune image', 'thecore-elementor-widgets'))
                    ->set_is_sortable(true)
                    ->set_initialValues([
                        'src' => Image_Src_Prop_Type::generate([
                            'id' => null,
                            'url' => Url_Prop_Type::generate(Placeholder_Image::get_placeholder_image()),
                        ]),
                        'size' => String_Prop_Type::generate('full'),
                    ])
                    ->set_description(__('Jusqu\'a 20 images, dans l\'ordre de lecture.', 'thecore-elementor-widgets')),
                Switch_Control::bind_to('first_image_priority')
                    ->set_label(__('Premiere image prioritaire', 'thecore-elementor-widgets'))
                    ->set_description(__('Chargement immediat et priorite haute pour un fond visible au premier ecran.', 'thecore-elementor-widgets')),
                Select_Control::bind_to('mobile_image_size')
                    ->set_label(__('Taille d\'image mobile', 'thecore-elementor-widgets'))
                    ->set_options(array_merge([
                        ['label' => __('Identique au bureau', 'thecore-elementor-widgets'), 'value' => ''],
                    ], Image_Sizes::get_all()))
                    ->set_description(__('Utilise le recadrage genere de cette taille jusqu\'a 767 px. Sinon, conserve l\'image de bureau.', 'thecore-elementor-widgets')),
            ]),
            Section::make()->set_label(__('Animation', 'thecore-elementor-widgets'))->set_id('animation')->set_items([
                self::numberControl('duration', __('Duree par image (ms)', 'thecore-elementor-widgets'), 1000, 60000),
                self::numberControl('transition', __('Duree du fondu (ms)', 'thecore-elementor-widgets'), 0, 3000),
                Select_Control::bind_to('zoom')->set_label(__('Zoom', 'thecore-elementor-widgets'))->set_options([
                    ['label' => __('Avant', 'thecore-elementor-widgets'), 'value' => 'in'],
                    ['label' => __('Arriere', 'thecore-elementor-widgets'), 'value' => 'out'],
                    ['label' => __('Aucun', 'thecore-elementor-widgets'), 'value' => 'none'],
                ]),
                self::numberControl('zoom_amount', __('Amplitude du zoom (%)', 'thecore-elementor-widgets'), 0, 20),
                Switch_Control::bind_to('show_pause_button')
                    ->set_label(__('Commande de pause', 'thecore-elementor-widgets'))
                    ->set_description(__('Sans commande locale, un controle d\'arret global utilisable est necessaire pour animer le fond.', 'thecore-elementor-widgets')),
            ]),
            Section::make()->set_label(__('Reglages', 'thecore-elementor-widgets'))->set_id('settings')->set_items([
                Text_Control::bind_to('_cssid')->set_label(__('ID', 'thecore-elementor-widgets'))
                    ->set_meta($this->get_css_id_control_meta()),
            ]),
        ];
    }

    protected function get_templates(): array
    {
        return ['thecore/elements/background-slideshow' => __DIR__ . '/background-slideshow.html.twig'];
    }

    protected function render()
    {
        $settings = (new DisplaySettings())->normalize($this->get_atomic_settings());

        if ([] === $settings['images']) {
            return;
        }

        $builder = new ImageMarkupBuilder();

        foreach ($settings['images'] as $index => &$image) {
            $image['_html'] = $builder->build(
                $image,
                0 === $index,
                $settings['first_image_priority'],
                $settings['mobile_image_size']
            );
        }
        unset($image);

        // Themes may remove Elementor's loader; these assets are independent.
        wp_enqueue_style(FrontendAssets::BACKGROUND_SLIDESHOW_STYLE);
        wp_enqueue_script(FrontendAssets::BACKGROUND_SLIDESHOW_SCRIPT);
        $renderer = Template_Renderer::instance();

        foreach (array_merge($this->get_shared_templates(), $this->get_templates()) as $name => $path) {
            if (! $renderer->is_registered($name)) {
                $renderer->register($name, $path);
            }
        }

        echo $renderer->render($this->get_main_template(), [ // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            'id' => $this->get_id(),
            'interaction_id' => $this->get_interaction_id(),
            'type' => $this->get_name(),
            'settings' => $settings,
            'base_styles' => $this->get_base_styles_dictionary(),
        ]);
    }

    private static function numberControl(string $name, string $label, int $minimum, int $maximum): Number_Control
    {
        return Number_Control::bind_to($name)->set_label($label)->set_min($minimum)
            ->set_max($maximum)->set_step(1)->set_should_force_int(true);
    }
}
