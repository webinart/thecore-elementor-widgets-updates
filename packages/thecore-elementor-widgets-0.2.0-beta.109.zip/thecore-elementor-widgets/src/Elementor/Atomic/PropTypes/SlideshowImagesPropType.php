<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\PropTypes;

use Elementor\Modules\AtomicWidgets\PropTypes\Base\Array_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Contracts\Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Image_Prop_Type;

final class SlideshowImagesPropType extends Array_Prop_Type
{
    public static function get_key(): string
    {
        return 'thecore-slideshow-images';
    }

    protected function define_item_type(): Prop_Type
    {
        return Image_Prop_Type::make()->default_size('full');
    }
}
