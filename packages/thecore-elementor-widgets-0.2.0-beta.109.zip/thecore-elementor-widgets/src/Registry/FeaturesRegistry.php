<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Registry;

final class FeaturesRegistry
{
    /**
     * @return array<string, array{title: string, description: string, enabled_by_default: bool}>
     */
    private function definitions(): array
    {
        return [
            'responsive-disclosure' => [
                'title' => __('Sommaires repliables', 'thecore-elementor-widgets'),
                'description' => __('Repli accessible sur mobile des sommaires natifs marqués. Contenu disponible sans JavaScript.', 'thecore-elementor-widgets'),
                'enabled_by_default' => false,
            ],
            'click-to-play-video' => [
                'title' => __('Vidéos au clic', 'thecore-elementor-widgets'),
                'description' => __('Lecteurs YouTube et Vimeo créés uniquement après activation explicite, sans requête tierce préalable.', 'thecore-elementor-widgets'),
                'enabled_by_default' => false,
            ],
            'image-lightbox' => [
                'title' => __('Visionneuse d’images', 'thecore-elementor-widgets'),
                'description' => __(
                    'Visionneuse PhotoSwipe indépendante pour les galeries marquées, sans jQuery ni runtime Elementor. Chargée uniquement sur les pages concernées.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => false,
            ],
            'overlay-scroll-lock' => [
                'title' => __('Overlay Scroll Lock', 'thecore-elementor-widgets'),
                'description' => __(
                    'Verrouille le scroll du document lorsque des overlays compatibles, comme le Fullscreen Menu mobile, sont ouverts.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => true,
            ],
            'form-security' => [
                'title' => __('Elementor Form Security', 'thecore-elementor-widgets'),
                'description' => __(
                    'Ajoute au formulaire legacy Elementor Pro un champ de protection opt-in avec ALTCHA auto-hébergé, anti-rejeu, limitation, déduplication et minimisation des métadonnées.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => false,
            ],
        ];
    }

    /**
     * @return array<string, RegistryItem>
     */
    public function all(): array
    {
        $items = [];

        foreach ($this->definitions() as $id => $definition) {
            $item = new RegistryItem(
                $id,
                $definition['title'],
                $definition['description'],
                $definition['enabled_by_default']
            );

            $items[$item->id()] = $item;
        }

        return $items;
    }

    /**
     * @return array<string, int>
     */
    public function defaults(): array
    {
        return [
            'responsive-disclosure' => 0,
            'click-to-play-video' => 0,
            'image-lightbox' => 0,
            'overlay-scroll-lock' => 1,
            'form-security' => 0,
        ];
    }
}
