<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Registry;

final class WidgetsRegistry
{
    /**
     * @return array<string, array{title: string, description: string, enabled_by_default: bool}>
     */
    private function definitions(): array
    {
        return [
            'form' => [
                'title' => __('Formulaire The Core (V4)', 'thecore-elementor-widgets'),
                'description' => __('Formulaire atomique avec champs Elementor Pro, traitement independant, protection anti-spam et tests de flotte signes.', 'thecore-elementor-widgets'),
                'enabled_by_default' => true,
            ],
            'classic-menu' => [
                'title' => __('Fullscreen Menu', 'thecore-elementor-widgets'),
                'description' => __(
                    'Portage V4 du fullscreen menu legacy avec rendu inline sur desktop, overlay mobile et lecture des items de premier niveau d’un menu WordPress.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => true,
            ],
            'marquee-carousel' => [
                'title' => __('Marquee Carousel', 'thecore-elementor-widgets'),
                'description' => __(
                    'Portage V4 du marquee banner legacy avec défilement infini, items dupliqués pour la boucle continue, réglages par image et lazy loading.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => true,
            ],
            'text-list' => [
                'title' => __('Text List', 'thecore-elementor-widgets'),
                'description' => __(
                    'Portage V4 de la liste de textes legacy, avec sémantique verrouillée, items saisis ligne par ligne et styles inline sans asset dédié.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => true,
            ],
            'animated-text' => [
                'title' => __('Texte animé (V4)', 'thecore-elementor-widgets'),
                'description' => __(
                    'Texte Atomic V4 avec écriture progressive, phrases éditables, pause accessible et alternative statique.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => false,
            ],
            'background-slideshow' => [
                'title' => __('Diaporama de fond (V4)', 'thecore-elementor-widgets'),
                'description' => __('Fond decoratif Atomic V4 avec images responsives, fondu, zoom et pause accessible, sans dependance au runtime Elementor.', 'thecore-elementor-widgets'),
                'enabled_by_default' => false,
            ],
            'breadcrumb' => [
                'title' => __('Breadcrumb', 'thecore-elementor-widgets'),
                'description' => __(
                    'Fil d’ariane V4 accessible, avec génération dynamique du parcours WordPress, landmark `nav`, liste ordonnée et item courant annoncé proprement.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => true,
            ],
            'icon-text' => [
                'title' => __('Icon Text', 'thecore-elementor-widgets'),
                'description' => __(
                    'Élément Atomic simple et accessible pour afficher une icône décorative accompagnée d’un texte éditable, avec styles inline dédiés.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => true,
            ],
            'counter' => [
                'title' => __('Counter (V4)', 'thecore-elementor-widgets'),
                'description' => __('Compteur atomique animé sans jQuery ni JS Elementor, avec valeur finale accessible, temporisation et format numérique configurables.', 'thecore-elementor-widgets'),
                'enabled_by_default' => true,
            ],
            'marquee-banner-legacy' => [
                'title' => __('Marquee Banner (Legacy)', 'thecore-elementor-widgets'),
                'description' => __(
                    'Version Elementor classique du marquee banner historique, avec repeater natif complet pour réordonner et éditer les items plus confortablement.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => true,
            ],
            'header-menu-legacy' => [
                'title' => __('Header Menu (Legacy)', 'thecore-elementor-widgets'),
                'description' => __(
                    'Portage legacy du menu Bellevue avec dropdown desktop, accordéons mobile et lecture directe d’un menu WordPress.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => true,
            ],
            'search-modal-legacy' => [
                'title' => __('Search Modal (Legacy)', 'thecore-elementor-widgets'),
                'description' => __(
                    'Portage legacy de la recherche modale Bellevue avec AJAX, raccourci clavier, recherches populaires et accès rapides.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => true,
            ],
            'accessibility-module-legacy' => [
                'title' => __('Accessibility Module (Legacy)', 'thecore-elementor-widgets'),
                'description' => __(
                    'Portage legacy du panneau d’accessibilité The Core avec cartes d’actions, mask de lecture, contrastes et skip link configurable.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => true,
            ],
            'accessibility-trigger-legacy' => [
                'title' => __('Accessibility Trigger (Legacy)', 'thecore-elementor-widgets'),
                'description' => __(
                    'Portage legacy du bouton de déclenchement du module d’accessibilité The Core.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => true,
            ],
            'cookie-consent' => [
                'title' => __('Cookie Consent Module', 'thecore-elementor-widgets'),
                'description' => __(
                    'Widgets Elementor V4/Atomic et V3 du module complet de consentement cookies The Core, avec bandeau, logging, embeds bloqués, shortcodes et injection conditionnelle de code.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => true,
            ],
            'tchat' => [
                'title' => __('TChat Module', 'thecore-elementor-widgets'),
                'description' => __(
                    'Module TChat avec modale stylable, transport polling/SSE, et trigger par défaut optionnel.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => true,
            ],
            'tchat-trigger' => [
                'title' => __('TChat Trigger', 'thecore-elementor-widgets'),
                'description' => __(
                    'Bouton de déclenchement séparé du TChat, avec les mêmes contrôles que le trigger du panneau d’accessibilité.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => true,
            ],
        ];
    }

    /**
     * @return array<string, RegistryItem>
     */
    public function all(): array
    {
        $items = [];

        foreach ($this->definitions() as $id => $definition) {
            $item = new RegistryItem(
                $id,
                $definition['title'],
                $definition['description'],
                $definition['enabled_by_default']
            );

            $items[$item->id()] = $item;
        }

        return $items;
    }

    /**
     * @return array<string, int>
     */
    public function defaults(): array
    {
        return [
            'form' => 1,
            'classic-menu' => 1,
            'marquee-carousel' => 1,
            'text-list' => 1,
            'animated-text' => 0,
            'background-slideshow' => 0,
            'breadcrumb' => 1,
            'icon-text' => 1,
            'counter' => 1,
            'marquee-banner-legacy' => 1,
            'header-menu-legacy' => 1,
            'search-modal-legacy' => 1,
            'accessibility-module-legacy' => 1,
            'accessibility-trigger-legacy' => 1,
            'cookie-consent' => 1,
            'tchat' => 1,
            'tchat-trigger' => 1,
        ];
    }
}
