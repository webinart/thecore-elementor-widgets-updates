<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\ImageLightbox;

use Elementor\Modules\AtomicWidgets\PropsResolver\Transformer_Base;
use TheCore\ElementorWidgets\Contracts\Bootable;

final class ImageLightboxModule implements Bootable
{
    public const SCRIPT = 'thecore-image-lightbox';
    public const STYLE = 'thecore-image-lightbox';
    public const LIBRARY_VERSION = '5.4.4';

    private bool $enqueued = false;

    public function __construct(private readonly GalleryDetector $detector = new GalleryDetector())
    {
    }

    public function register(): void
    {
        add_action('wp_enqueue_scripts', [$this, 'enqueueForCurrentDocument'], 20);
        add_action('elementor/frontend/before_render', [$this, 'enqueueForElement']);
        add_action(
            'elementor/atomic-widgets/settings/transformers/register',
            [$this, 'registerAttributesTransformer'],
            PHP_INT_MAX
        );
        add_filter('elementor/frontend/the_content', [$this, 'filterRenderedContent'], 20);
        add_filter('the_content', [$this, 'filterRenderedContent'], 99);
    }

    public function registerAttributesTransformer(mixed $registry): void
    {
        if (
            ! is_object($registry)
            || ! method_exists($registry, 'get')
            || ! method_exists($registry, 'register')
            || ! class_exists(Transformer_Base::class)
        ) {
            return;
        }

        $delegate = $registry->get('attributes');
        if ($delegate instanceof Transformer_Base && ! $delegate instanceof GalleryAttributesTransformer) {
            $registry->register('attributes', new GalleryAttributesTransformer($delegate));
        }
    }

    public function enqueueForCurrentDocument(): void
    {
        $postId = (int) get_queried_object_id();
        if ($postId > 0 && $this->detector->hasGalleryInGraph(get_post_meta($postId, '_elementor_data', true))) {
            $this->enqueueAssets();
        }
    }

    public function enqueueForElement(mixed $element): void
    {
        if (
            is_object($element)
            && method_exists($element, 'get_data')
            && $this->detector->hasGalleryInGraph($element->get_data())
        ) {
            $this->enqueueAssets();
        }
    }

    public function filterRenderedContent(string $content): string
    {
        if (! $this->detector->hasGalleryInHtml($content)) {
            return $content;
        }

        $this->enqueueAssets();

        // Cached templates can bypass element hooks and be discovered after wp_head.
        if ($this->enqueued && did_action('wp_head') && ! wp_style_is(self::STYLE, 'done')) {
            ob_start();
            wp_print_styles([self::STYLE]);
            $content = (string) ob_get_clean() . $content;
        }

        return $content;
    }

    private function enqueueAssets(): void
    {
        if ($this->enqueued) {
            return;
        }

        $vendorDirectory = THECORE_ELEMENTOR_WIDGETS_PATH . 'assets/vendor/photoswipe/';
        $cssFile = $vendorDirectory . 'photoswipe.css';
        $moduleCssFile = THECORE_ELEMENTOR_WIDGETS_PATH . 'assets/frontend/image-lightbox.css';
        if (
            ! is_readable($cssFile)
            || ! is_readable($moduleCssFile)
            || ! is_readable(THECORE_ELEMENTOR_WIDGETS_PATH . 'assets/frontend/image-lightbox.js')
            || ! is_readable($vendorDirectory . 'photoswipe.esm.min.js')
            || ! is_readable($vendorDirectory . 'photoswipe-lightbox.esm.min.js')
        ) {
            return;
        }

        wp_register_style(self::STYLE, false, [], THECORE_ELEMENTOR_WIDGETS_VERSION);
        wp_add_inline_style(self::STYLE, file_get_contents($cssFile) . "\n" . file_get_contents($moduleCssFile));
        wp_enqueue_style(self::STYLE);

        wp_register_script(
            self::SCRIPT,
            false,
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION,
            true
        );
        wp_add_inline_script(
            self::SCRIPT,
            'window.TheCoreImageLightboxConfig=' . wp_json_encode(
                [
                    'lightboxUrl' => add_query_arg(
                        'ver',
                        self::LIBRARY_VERSION,
                        THECORE_ELEMENTOR_WIDGETS_URL . 'assets/vendor/photoswipe/photoswipe-lightbox.esm.min.js'
                    ),
                    'coreUrl' => add_query_arg(
                        'ver',
                        self::LIBRARY_VERSION,
                        THECORE_ELEMENTOR_WIDGETS_URL . 'assets/vendor/photoswipe/photoswipe.esm.min.js'
                    ),
                    'labels' => [
                        'dialog' => __('Galerie de photos', 'thecore-elementor-widgets'),
                        'close' => __('Fermer la galerie', 'thecore-elementor-widgets'),
                        'previous' => __('Photo précédente', 'thecore-elementor-widgets'),
                        'next' => __('Photo suivante', 'thecore-elementor-widgets'),
                        'zoom' => __('Agrandir ou réduire la photo', 'thecore-elementor-widgets'),
                        'error' => __('Cette photo ne peut pas être chargée.', 'thecore-elementor-widgets'),
                        'separator' => __(' sur ', 'thecore-elementor-widgets'),
                    ],
                ],
                JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
            ) . ';',
            'before'
        );
        wp_add_inline_script(
            self::SCRIPT,
            (string) file_get_contents(THECORE_ELEMENTOR_WIDGETS_PATH . 'assets/frontend/image-lightbox.js')
        );
        wp_enqueue_script(self::SCRIPT);
        $this->enqueued = true;
    }
}
