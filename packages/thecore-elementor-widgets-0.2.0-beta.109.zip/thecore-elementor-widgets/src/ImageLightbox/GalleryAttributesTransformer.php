<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\ImageLightbox;

use Elementor\Modules\AtomicWidgets\PropsResolver\Props_Resolver_Context;
use Elementor\Modules\AtomicWidgets\PropsResolver\Transformer_Base;

final class GalleryAttributesTransformer extends Transformer_Base
{
    private const OWNED = [
        'data-thecore-gallery',
        'data-pswp-width',
        'data-pswp-height',
        'data-thecore-caption',
    ];

    public function __construct(private readonly Transformer_Base $delegate)
    {
    }

    public function transform($value, Props_Resolver_Context $context)
    {
        if (! is_array($value)) {
            return $this->delegate->transform($value, $context);
        }

        $remaining = [];
        $owned = [];
        foreach ($value as $index => $item) {
            $key = is_array($item) ? ($item['key'] ?? null) : null;
            if (! in_array($key, self::OWNED, true)) {
                $remaining[$index] = $item;
                continue;
            }

            $validated = $this->validateValue($key, $item['value'] ?? null);
            if (null !== $validated) {
                $owned[$key] = $validated;
            }
        }

        // Preserve the existing free, Pro or site policy for every other attribute.
        $rendered = $this->delegate->transform($remaining, $context);
        if ([] === $owned) {
            return $rendered;
        }

        $attributes = [];
        foreach ($owned as $key => $attributeValue) {
            $attributes[] = $key . '="' . esc_attr($attributeValue) . '"';
        }

        return (is_string($rendered) && '' !== $rendered ? $rendered . ' ' : '') . implode(' ', $attributes);
    }

    private function validateValue(string $key, mixed $value): ?string
    {
        if (in_array($key, ['data-pswp-width', 'data-pswp-height'], true)) {
            if (! is_numeric($value)) {
                return null;
            }
            $number = (float) $value;
            if (! is_finite($number) || $number <= 0 || $number >= PHP_INT_MAX || floor($number) !== $number) {
                return null;
            }

            return (string) (int) $number;
        }

        if (! is_string($value)) {
            return null;
        }
        $value = trim($value);
        $limit = 'data-thecore-gallery' === $key ? 160 : 2000;
        if ('' === $value || strlen($value) > $limit || preg_match('/[\x00-\x1F\x7F]/', $value)) {
            return null;
        }

        return $value;
    }
}
