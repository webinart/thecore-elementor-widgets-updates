<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\ImageLightbox;

final class GalleryDetector
{
    public const ATTRIBUTE = 'data-thecore-gallery';

    public function hasGalleryInGraph(mixed $data): bool
    {
        if (is_string($data)) {
            $data = json_decode($data, true);
        }

        return is_array($data) && $this->containsAttribute($data);
    }

    public function hasGalleryInHtml(string $html): bool
    {
        if (! str_contains($html, self::ATTRIBUTE)) {
            return false;
        }

        if (class_exists('\WP_HTML_Tag_Processor')) {
            $tags = new \WP_HTML_Tag_Processor($html);
            while ($tags->next_tag()) {
                $value = $tags->get_attribute(self::ATTRIBUTE);
                if (is_string($value) && '' !== trim($value)) {
                    return true;
                }
            }

            return false;
        }

        // The standalone test runner does not boot the WordPress HTML API.
        if (! class_exists('\DOMDocument')) {
            return false;
        }

        $document = new \DOMDocument();
        $previous = libxml_use_internal_errors(true);
        try {
            $document->loadHTML($html);
            foreach ($document->getElementsByTagName('*') as $element) {
                if ('' !== trim($element->getAttribute(self::ATTRIBUTE))) {
                    return true;
                }
            }
        } finally {
            libxml_clear_errors();
            libxml_use_internal_errors($previous);
        }

        return false;
    }

    private function containsAttribute(array $node, int $depth = 0): bool
    {
        if ($depth > 100) {
            return false;
        }

        if (
            self::ATTRIBUTE === $this->stringValue($node['key'] ?? null)
            && '' !== trim($this->stringValue($node['value'] ?? null))
        ) {
            return true;
        }

        foreach ($node as $key => $value) {
            if (self::ATTRIBUTE === $key && '' !== trim($this->stringValue($value))) {
                return true;
            }
            if (is_array($value) && $this->containsAttribute($value, $depth + 1)) {
                return true;
            }
        }

        return false;
    }

    private function stringValue(mixed $value): string
    {
        if (is_array($value)) {
            $value = $value['value'] ?? null;
        }

        return is_string($value) ? $value : '';
    }
}
