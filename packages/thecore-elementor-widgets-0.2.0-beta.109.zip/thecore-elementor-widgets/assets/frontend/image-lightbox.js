(() => {
    'use strict';

    if (window.TheCoreImageLightbox) return;
    const config = window.TheCoreImageLightboxConfig;
    if (!config || !config.coreUrl || !config.lightboxUrl) return;

    const selector = 'a[href][data-pswp-width][data-pswp-height]';
    const labels = config.labels || {};
    const modules = new Map();
    let requestId = 0;

    function imageLinks(gallery) {
        return [...gallery.querySelectorAll(selector)].filter(link => {
            if (link.closest('[data-thecore-gallery]') !== gallery || link.closest('[hidden]')) return false;
            if (!link.querySelector('img') || !link.getClientRects().length) return false;
            const width = Number(link.dataset.pswpWidth);
            const height = Number(link.dataset.pswpHeight);
            try {
                const url = new URL(link.href, document.baseURI);
                return /^https?:$/.test(url.protocol) && width > 0 && height > 0
                    && Number.isFinite(width) && Number.isFinite(height);
            } catch (_) {
                return false;
            }
        });
    }

    function loadModule(url) {
        if (modules.has(url)) return modules.get(url);
        let timeout;
        const deadline = new Promise((_, reject) => {
            timeout = window.setTimeout(() => reject(new Error('PhotoSwipe unavailable')), 10000);
        });
        const promise = Promise.race([import(url), deadline])
            .then(module => {
                if (typeof module.default !== 'function') throw new Error('PhotoSwipe unavailable');
                return module.default;
            })
            .catch(error => {
                modules.delete(url);
                throw error;
            })
            .finally(() => window.clearTimeout(timeout));
        modules.set(url, promise);
        return promise;
    }

    function loadLibrary() {
        return Promise.all([
            loadModule(config.lightboxUrl),
            loadModule(config.coreUrl)
        ]);
    }

    function openGallery(gallery, links, index, trigger, point, Lightbox, PhotoSwipe) {
        const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        const lightbox = new Lightbox({
            gallery,
            children: links,
            pswpModule: PhotoSwipe,
            mainClass: 'thecore-image-lightbox',
            closeTitle: labels.close,
            arrowPrevTitle: labels.previous,
            arrowNextTitle: labels.next,
            zoomTitle: labels.zoom,
            errorMsg: labels.error,
            indexIndicatorSep: labels.separator,
            bgOpacity: 0.96,
            trapFocus: true,
            returnFocus: true,
            escKey: true,
            arrowKeys: true,
            showHideAnimationType: reduced ? 'none' : 'fade',
            showAnimationDuration: reduced ? 0 : 220,
            hideAnimationDuration: reduced ? 0 : 180,
            zoomAnimationDuration: reduced ? 0 : 220,
            padding: { top: 52, bottom: 64, left: 20, right: 20 }
        });

        lightbox.on('uiRegister', () => {
            lightbox.pswp.ui.registerElement({
                name: 'thecore-caption',
                order: 9,
                isButton: false,
                appendTo: 'root',
                onInit(element, pswp) {
                    const update = () => {
                        const item = pswp.currSlide?.data?.element;
                        const alt = item?.querySelector('img')?.alt || '';
                        const caption = item?.dataset.thecoreCaption || alt;
                        element.textContent = caption;
                        element.setAttribute('aria-hidden', String(caption === alt));
                    };
                    pswp.on('change', update);
                    update();
                }
            });
        });
        lightbox.on('afterInit', () => {
            lightbox.pswp.element.setAttribute('aria-label', labels.dialog || 'Galerie de photos');
            lightbox.pswp.element.setAttribute('aria-modal', 'true');
            const counter = lightbox.pswp.element.querySelector('.pswp__counter');
            if (counter) {
                counter.setAttribute('aria-hidden', 'false');
                counter.setAttribute('role', 'status');
                counter.setAttribute('aria-live', 'polite');
                counter.setAttribute('aria-atomic', 'true');
            }
        });
        lightbox.on('keydown', event => {
            const original = event.originalEvent;
            if (original.key !== 'Tab' || original.ctrlKey || original.metaKey || original.altKey) return;
            const root = lightbox.pswp.element;
            const controls = [...root.querySelectorAll('button, a[href], [tabindex]')].filter(control => (
                control.tabIndex >= 0
                && !control.disabled
                && control.getAttribute('aria-disabled') !== 'true'
                && !control.closest('[hidden], [inert], [aria-hidden="true"]')
                && control.getClientRects().length > 0
                && !['hidden', 'collapse'].includes(window.getComputedStyle(control).visibility)
            ));
            const first = controls[0];
            const last = controls[controls.length - 1];
            const active = document.activeElement;
            const target = original.shiftKey && (active === first || active === root)
                ? last
                : !original.shiftKey && active === last ? first : null;
            if (!target) return;
            original.preventDefault();
            event.preventDefault();
            target.focus({ preventScroll: true });
        });
        lightbox.on('destroy', () => {
            window.requestAnimationFrame(() => {
                if (trigger.isConnected) trigger.focus({ preventScroll: true });
                lightbox.destroy();
            });
        });
        lightbox.loadAndOpen(index, { gallery }, point);
    }

    function onClick(event) {
        if (event.defaultPrevented || event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
        const trigger = event.target instanceof Element ? event.target.closest(selector) : null;
        const gallery = trigger?.closest('[data-thecore-gallery]');
        if (!gallery || !gallery.dataset.thecoreGallery || window.pswp) return;
        if (trigger.hasAttribute('download') || (trigger.target && trigger.target !== '_self')) return;
        const links = imageLinks(gallery);
        const index = links.indexOf(trigger);
        if (index < 0) return;

        event.preventDefault();
        const currentRequest = ++requestId;
        trigger.setAttribute('aria-busy', 'true');
        const point = event.clientX || event.clientY ? { x: event.clientX, y: event.clientY } : null;
        loadLibrary().then(([Lightbox, PhotoSwipe]) => {
            if (currentRequest === requestId && trigger.isConnected && !window.pswp) {
                openGallery(gallery, links, index, trigger, point, Lightbox, PhotoSwipe);
            }
        }).catch(() => {
            if (currentRequest === requestId && trigger.isConnected) window.location.assign(trigger.href);
        }).finally(() => trigger.removeAttribute('aria-busy'));
    }

    document.addEventListener('click', onClick);
    window.TheCoreImageLightbox = Object.freeze({ version: '1' });
})();
