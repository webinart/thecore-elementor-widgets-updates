(function () {
    'use strict';
    if (window.TheCoreResponsiveDisclosure) return;
    var states = new Map();
    function hashTarget() {
        if (!window.location.hash) return null;
        try { return document.getElementById(decodeURIComponent(window.location.hash.slice(1))); }
        catch (error) { return null; }
    }
    function render(state) {
        var narrow = state.media.matches;
        var open = !narrow || state.open;
        state.button.hidden = !narrow;
        state.panel.hidden = !open;
        state.button.setAttribute('aria-expanded', String(open));
        state.root.setAttribute('data-thecore-disclosure-state', open ? 'open' : 'closed');
    }
    function revealTarget(target) {
        if (!target) return;
        states.forEach(function (state) {
            if (state.panel.contains(target)) {
                state.open = true;
                render(state);
            }
        });
    }
    function scan() {
        document.querySelectorAll('[data-thecore-disclosure]').forEach(function (root) {
            if (states.has(root)) return;
            var button = root.querySelector('[data-thecore-disclosure-toggle]');
            if (!button || button.tagName !== 'BUTTON') return;
            var name = button.getAttribute('data-thecore-disclosure-toggle');
            var panel = Array.from(root.querySelectorAll('[data-thecore-disclosure-panel]')).find(function (item) {
                return item.getAttribute('data-thecore-disclosure-panel') === name;
            });
            if (!panel || !/^[A-Za-z][A-Za-z0-9_-]{0,159}$/.test(name || '')) return;
            if (panel.id && panel.id !== name) return;
            var existing = document.getElementById(name);
            if (existing && existing !== panel) return;
            panel.id = name;
            button.type = 'button';
            button.setAttribute('aria-controls', name);
            var limit = Number(root.getAttribute('data-thecore-disclosure-breakpoint') || 767);
            if (!Number.isInteger(limit) || limit < 320 || limit > 1599) limit = 767;
            var state = { root: root, button: button, panel: panel, media: window.matchMedia('(max-width: ' + limit + 'px)'), open: false };
            var target = hashTarget();
            state.open = panel.contains(document.activeElement) || Boolean(target && panel.contains(target)) || Boolean(panel.querySelector('[autofocus]'));
            states.set(root, state);
            root.setAttribute('data-thecore-disclosure-ready', 'true');
            button.addEventListener('click', function () {
                if (!state.media.matches) return;
                state.open = !state.open;
                render(state);
            });
            root.addEventListener('keydown', function (event) {
                if (event.key !== 'Escape' || !state.media.matches || !state.open) return;
                event.preventDefault();
                state.open = false;
                render(state);
                button.focus();
            });
            panel.addEventListener('click', function (event) {
                var link = event.target.closest && event.target.closest('a[href]');
                if (!link || !state.media.matches || event.defaultPrevented || event.button !== 0 || event.ctrlKey || event.metaKey || event.altKey || event.shiftKey) return;
                state.open = false;
                render(state);
                if (panel.contains(document.activeElement)) button.focus({ preventScroll: true });
            });
            var change = function () {
                // Never hide keyboard focus when crossing a responsive breakpoint.
                if (state.media.matches && panel.contains(document.activeElement)) state.open = true;
                render(state);
            };
            if (state.media.addEventListener) state.media.addEventListener('change', change);
            else state.media.addListener(change);
            render(state);
        });
    }
    window.addEventListener('hashchange', function () { revealTarget(hashTarget()); });
    document.addEventListener('focusin', function (event) { revealTarget(event.target); });
    window.TheCoreResponsiveDisclosure = { scan: scan };
    scan();
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', scan, { once: true });
}());
