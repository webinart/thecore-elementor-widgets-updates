(function () {
    'use strict';
    if (window.TheCoreClickToPlayVideo) return;
    var labels = window.TheCoreClickToPlayLabels || {};
    var pending = new WeakSet();
    function source(link) {
        var provider = link.getAttribute('data-thecore-video-provider');
        var id = link.getAttribute('data-thecore-video-id') || '';
        var url;
        try { url = new URL(link.href, document.baseURI); }
        catch (error) { return null; }
        if (url.protocol !== 'https:' || url.username || url.password || url.port) return null;
        var host = url.hostname.toLowerCase();
        if (provider === 'youtube' && /^[A-Za-z0-9_-]{11}$/.test(id)) {
            var match = host === 'youtu.be' ? url.pathname.slice(1) :
                ['youtube.com', 'www.youtube.com', 'm.youtube.com'].includes(host) && url.pathname === '/watch' ? url.searchParams.get('v') :
                ['youtube.com', 'www.youtube.com', 'www.youtube-nocookie.com'].includes(host) && url.pathname.indexOf('/embed/') === 0 ? url.pathname.slice(7) : null;
            if (match !== id) return null;
            return 'https://www.youtube-nocookie.com/embed/' + encodeURIComponent(id) + '?autoplay=1&rel=0';
        }
        if (provider === 'vimeo' && /^[0-9]{5,12}$/.test(id)) {
            var path = host === 'player.vimeo.com' ? '/video/' + id : '/' + id;
            if (!['vimeo.com', 'www.vimeo.com', 'player.vimeo.com'].includes(host) || url.pathname !== path) return null;
            return 'https://player.vimeo.com/video/' + encodeURIComponent(id) + '?autoplay=1&dnt=1';
        }
        return null;
    }
    function onClick(event) {
        var link = event.target.closest && event.target.closest('a[data-thecore-video-provider][data-thecore-video-id]');
        if (!link || event.defaultPrevented || event.button !== 0 || event.ctrlKey || event.metaKey || event.altKey || event.shiftKey || link.hasAttribute('download') || (link.target && link.target !== '_self')) return;
        var root = link.closest('[data-thecore-video]');
        var embed = source(link);
        if (!root || !embed || pending.has(root)) return;
        // This deliberate activation authorizes this provider for this one player only.
        event.preventDefault();
        pending.add(root);
        var player = document.createElement('div');
        player.className = 'thecore-video-player';
        var frame = document.createElement('iframe');
        frame.title = link.getAttribute('data-thecore-video-title') || link.textContent.trim() || labels.frame || 'Lecteur vidéo';
        frame.allow = 'autoplay; encrypted-media; picture-in-picture; fullscreen';
        frame.allowFullscreen = true;
        frame.referrerPolicy = 'strict-origin-when-cross-origin';
        frame.tabIndex = 0;
        var fallback = document.createElement('a');
        fallback.href = link.href;
        fallback.target = '_blank';
        fallback.rel = 'noopener noreferrer';
        fallback.textContent = labels.fallback || 'Ouvrir la vidéo sur son site d’origine';
        var close = document.createElement('button');
        close.type = 'button';
        close.textContent = labels.close || 'Fermer la vidéo';
        var status = document.createElement('p');
        status.className = 'thecore-video-status';
        status.setAttribute('role', 'status');
        status.setAttribute('aria-live', 'polite');
        status.textContent = labels.loading || 'Chargement de la vidéo…';
        player.appendChild(frame);
        player.appendChild(status);
        player.appendChild(fallback);
        player.appendChild(close);
        var previous = Array.from(root.children).map(function (child) {
            var entry = { element: child, hidden: child.hidden };
            child.hidden = true;
            return entry;
        });
        var active = true;
        root.setAttribute('data-thecore-video-state', 'loading');
        var timer = window.setTimeout(function () {
            if (!active) return;
            status.textContent = labels.error || 'Le lecteur ne répond pas. Ouvrez la vidéo sur son site d’origine.';
            root.setAttribute('data-thecore-video-state', 'error');
        }, 12000);
        close.addEventListener('click', function () {
            active = false;
            window.clearTimeout(timer);
            player.remove();
            previous.forEach(function (entry) { entry.element.hidden = entry.hidden; });
            root.removeAttribute('data-thecore-video-state');
            pending.delete(root);
            if (link.isConnected) link.focus();
        });
        frame.addEventListener('load', function () {
            if (!active) return;
            window.clearTimeout(timer);
            status.textContent = '';
            root.setAttribute('data-thecore-video-state', 'loaded');
        }, { once: true });
        frame.addEventListener('error', function () {
            if (!active) return;
            window.clearTimeout(timer);
            status.textContent = labels.error || 'Le lecteur ne répond pas. Ouvrez la vidéo sur son site d’origine.';
            root.setAttribute('data-thecore-video-state', 'error');
        }, { once: true });
        frame.src = embed;
        root.appendChild(player);
        frame.focus();
    }
    document.addEventListener('click', onClick);
    window.TheCoreClickToPlayVideo = { source: source };
}());
