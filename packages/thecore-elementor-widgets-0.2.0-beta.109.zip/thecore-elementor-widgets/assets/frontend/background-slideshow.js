(() => {
    'use strict';

    if (window.thecoreBackgroundSlideshowInitialized) {
        return;
    }

    window.thecoreBackgroundSlideshowInitialized = true;

    const selector = '[data-thecore-background-slideshow]';
    const stageSelector = '[data-thecore-background-slideshow-stage]';
    const templateSelector = '[data-thecore-background-slideshow-slides]';
    const toggleSelector = '[data-thecore-background-slideshow-toggle]';
    const moduleSelector = '[data-thecore-accessibility-module]';
    const triggerSelector = '[data-thecore-accessibility-trigger], .thecore-accessibility-trigger-legacy, .thecore-accessibility-trigger, a[href="#thecore-accessibility-open"], a[href="#thecore-accessibility-toggle"]';
    const actionSelector = '[data-action="pause-animations"]';
    const accessibilitySelector = `${moduleSelector}, ${triggerSelector}, ${actionSelector}`;
    const instances = new Map();
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
    const editorPreview = /(?:^|[?&])elementor-preview=/.test(window.location.search);
    let globalPaused = false;
    let globalControllerReady = false;
    let globalControllerPending = false;
    let accessibilityModule = null;
    let accessibilityTriggers = [];
    let pageSuspended = false;

    const number = (value, fallback, minimum, maximum) => {
        const parsed = Number(value);
        return Number.isFinite(parsed) ? Math.min(Math.max(parsed, minimum), maximum) : fallback;
    };

    const imageFor = (layer) => layer.matches('img') ? layer : layer.querySelector('img');
    const layersFor = (container) => Array.from(container.children)
        .filter((layer) => layer.matches('img, picture') && imageFor(layer));

    // Keep the same readiness contract as Animated Text and the accessibility module.
    const usableTrigger = (trigger) => {
        if (trigger.getAttribute('data-thecore-accessibility-trigger-bound') !== '1'
            || trigger.disabled || trigger.getAttribute('aria-disabled') === 'true'
            || trigger.tabIndex < 0 || trigger.closest('[hidden], [inert], [aria-hidden="true"]')
            || !trigger.matches('button, a[href], [role="button"]')
            || !trigger.getClientRects().length) {
            return false;
        }

        const style = window.getComputedStyle(trigger);
        return style.display !== 'none' && style.visibility !== 'hidden';
    };

    const refreshGlobalState = () => {
        const paused = document.body.classList.contains('thecore-accessibility-pause-animations');
        const modules = document.querySelectorAll(moduleSelector);
        accessibilityModule = modules.length ? modules[modules.length - 1] : null;
        accessibilityTriggers = Array.from(document.querySelectorAll(triggerSelector));
        const action = accessibilityModule?.querySelector(actionSelector);
        const ready = !!(accessibilityModule
            && accessibilityModule.getAttribute('data-thecore-accessibility-bound') === '1'
            && action && action.matches('button') && !action.disabled && !action.hidden
            && action.getAttribute('aria-disabled') !== 'true'
            && accessibilityTriggers.some((trigger) => !accessibilityModule.contains(trigger) && usableTrigger(trigger)));
        const pending = !!accessibilityModule && !ready && (
            accessibilityModule.getAttribute('data-thecore-accessibility-bound') !== '1'
            || accessibilityTriggers.some((trigger) => trigger.getAttribute('data-thecore-accessibility-trigger-bound') !== '1')
        );
        const changed = paused !== globalPaused || ready !== globalControllerReady || pending !== globalControllerPending;
        globalPaused = paused;
        globalControllerReady = ready;
        globalControllerPending = pending;

        if (changed) {
            instances.forEach((instance) => instance.sync());
        }
    };

    const containsAccessibility = (node) => node instanceof Element
        && (node.matches(accessibilitySelector) || node.querySelector(accessibilitySelector));

    const affectsAccessibility = (node) => containsAccessibility(node)
        || accessibilityModule?.contains(node)
        || accessibilityTriggers.some((trigger) => node === trigger || node.contains(trigger));

    class BackgroundSlideshow {
        constructor(root, config) {
            this.root = root;
            this.stage = root.querySelector(stageSelector);
            this.template = root.querySelector(templateSelector);
            this.toggle = root.querySelector(toggleSelector);
            this.current = layersFor(this.stage)[0];
            this.sources = [this.current, ...layersFor(this.template.content)];
            this.duration = number(config.duration, 5000, 1000, 120000);
            this.transition = number(config.transition, 500, 0, Math.min(10000, this.duration));
            this.zoom = ['in', 'out'].includes(config.zoom) ? config.zoom : 'none';
            this.zoomAmount = number(config.zoomAmount, 0.06, 0, 0.3);
            this.pauseLabel = config.pauseLabel || 'Mettre le diaporama en pause';
            this.resumeLabel = config.resumeLabel || 'Reprendre le diaporama';
            this.animations = new Set();
            this.zooms = new Map();
            this.waiters = new Set();
            this.failed = new Set();
            this.currentIndex = 0;
            this.next = null;
            this.nextIndex = null;
            this.nextReady = false;
            this.firstReady = false;
            this.firstWaiting = false;
            this.started = false;
            this.advanceDue = false;
            this.transitioning = false;
            this.inViewport = !('IntersectionObserver' in window);
            this.userPaused = false;
            this.destroyed = false;
            this.timer = null;
            this.pending = null;
            this.idle = null;
            this.onToggle = () => {
                this.userPaused = !this.userPaused;
                this.sync();
            };
            this.onMotionChange = () => {
                if (reducedMotion.matches) {
                    this.restoreFirst();
                }

                this.sync();
            };

            this.toggle?.addEventListener('click', this.onToggle);
            reducedMotion.addEventListener('change', this.onMotionChange);

            if ('IntersectionObserver' in window) {
                this.observer = new IntersectionObserver((entries) => {
                    this.inViewport = entries[0].isIntersecting;
                    this.sync();
                }, { threshold: 0.01 });
                this.observer.observe(root);
            }

            this.root.classList.add('is-ready');
            this.sync();
        }

        staticMode() {
            return editorPreview || reducedMotion.matches || this.sources.length < 2
                || typeof this.current.animate !== 'function'
                || (!this.toggle && !globalControllerReady && !globalControllerPending);
        }

        active() {
            return !this.destroyed && !this.staticMode() && (this.toggle || globalControllerReady)
                && !globalPaused && !this.userPaused && this.inViewport && !document.hidden
                && !pageSuspended && !this.exhausted;
        }

        stopTimer() {
            if (this.timer !== null) {
                window.clearTimeout(this.timer);
                this.timer = null;

                if (this.pending) {
                    this.pending.remaining = Math.max(0, this.pending.due - performance.now());
                }
            }
        }

        resumeTimer() {
            if (!this.active() || !this.pending || this.timer !== null) {
                return;
            }

            this.pending.due = performance.now() + this.pending.remaining;
            this.timer = window.setTimeout(() => {
                this.timer = null;
                const callback = this.pending.callback;
                this.pending = null;

                if (this.active()) {
                    callback();
                } else {
                    this.pending = { remaining: 0, callback };
                    this.sync();
                }
            }, this.pending.remaining);
        }

        schedule(delay, callback) {
            this.stopTimer();
            this.pending = { remaining: delay, callback };
            this.resumeTimer();
        }

        cancelIdle() {
            if (this.idle !== null) {
                if ('cancelIdleCallback' in window) {
                    window.cancelIdleCallback(this.idle);
                } else {
                    window.clearTimeout(this.idle);
                }

                this.idle = null;
            }
        }

        waitForImage(image, callback) {
            let settled = false;
            const cancel = () => {
                settled = true;
                image.removeEventListener('load', load);
                image.removeEventListener('error', error);
                this.waiters.delete(cancel);
            };
            const finish = (success) => {
                if (!settled) {
                    cancel();

                    if (!this.destroyed) {
                        callback(success);
                    }
                }
            };
            const error = () => finish(false);
            const load = () => {
                if (!image.naturalWidth) {
                    finish(false);
                    return;
                }

                if (typeof image.decode === 'function') {
                    image.decode().then(() => finish(true), () => finish(image.naturalWidth > 0));
                } else {
                    finish(true);
                }
            };
            this.waiters.add(cancel);
            image.addEventListener('load', load);
            image.addEventListener('error', error);

            if (image.complete) {
                load();
            }
        }

        animate(image, keyframes, duration) {
            const animation = image.animate(keyframes, { duration, easing: 'linear', fill: 'forwards' });
            this.animations.add(animation);
            return animation;
        }

        startZoom(image) {
            if (this.zoom === 'none' || !this.zoomAmount) {
                return;
            }

            const large = `scale(${1 + this.zoomAmount})`;
            const keyframes = this.zoom === 'out'
                ? [{ transform: large }, { transform: 'scale(1)' }]
                : [{ transform: 'scale(1)' }, { transform: large }];
            this.zooms.set(image, this.animate(image, keyframes, this.duration + this.transition));
        }

        cancelZoom(image) {
            const zoom = this.zooms.get(image);

            if (zoom) {
                zoom.cancel();
                this.animations.delete(zoom);
                this.zooms.delete(image);
            }
        }

        preload() {
            if (!this.active() || !this.firstReady || this.next || this.idle !== null || this.transitioning) {
                return;
            }

            const load = () => {
                this.idle = null;

                if (!this.active()) {
                    return;
                }

                let index = (this.currentIndex + 1) % this.sources.length;

                while (index !== this.currentIndex && this.failed.has(index)) {
                    index = (index + 1) % this.sources.length;
                }

                if (index === this.currentIndex) {
                    this.exhausted = true;
                    this.sync();
                    return;
                }

                // The template stays inert: only this one responsive image becomes live.
                const layer = this.sources[index].cloneNode(true);
                const image = imageFor(layer);
                layer.style.opacity = '0';
                layer.style.transform = '';
                layer.removeAttribute('id');
                image.removeAttribute('id');
                image.setAttribute('loading', 'eager');
                image.setAttribute('decoding', 'async');
                image.setAttribute('fetchpriority', 'low');
                image.setAttribute('aria-hidden', 'true');
                image.setAttribute('alt', '');
                image.setAttribute('data-thecore-background-slideshow-image', '');
                this.next = layer;
                this.nextIndex = index;
                this.nextReady = false;
                this.stage.appendChild(layer);
                this.waitForImage(image, (success) => {
                    if (this.next !== layer) {
                        return;
                    }

                    if (!success) {
                        layer.remove();
                        this.failed.add(index);
                        this.next = null;
                        this.nextIndex = null;
                    } else {
                        this.nextReady = true;
                    }

                    this.sync();
                });
            };
            this.idle = 'requestIdleCallback' in window
                ? window.requestIdleCallback(load, { timeout: 1500 })
                : window.setTimeout(load, 0);
        }

        advance() {
            this.advanceDue = true;

            if (!this.active() || !this.nextReady || !this.next) {
                this.sync();
                return;
            }

            this.advanceDue = false;
            this.transitioning = true;
            this.startZoom(this.next);
            const incoming = this.next;
            const fade = this.animate(incoming, [{ opacity: 0 }, { opacity: 1 }], this.transition);
            this.schedule(this.transition, () => {
                // Keep the outgoing layer opaque until the incoming layer covers it fully.
                incoming.style.opacity = '1';
                fade.cancel();
                this.animations.delete(fade);
                this.cancelZoom(this.current);
                this.current.remove();
                this.current = incoming;
                this.currentIndex = this.nextIndex;
                this.next = null;
                this.nextIndex = null;
                this.nextReady = false;
                this.transitioning = false;
                this.schedule(this.duration - this.transition, () => this.advance());
                this.sync();
            });
            this.sync();
        }

        sync() {
            if (this.destroyed) {
                return;
            }

            const active = this.active();
            const fixed = this.staticMode();
            const waiting = !this.toggle && !globalControllerReady && globalControllerPending;
            const state = fixed ? 'static' : waiting ? 'pending-controller' : !active ? 'paused'
                : !this.firstReady ? 'loading' : this.transitioning ? 'transition' : 'playing';
            this.root.setAttribute('data-thecore-background-slideshow-state', state);
            this.root.classList.toggle('is-running', !!active);
            this.root.classList.toggle('is-paused', !fixed && !active);

            if (this.toggle) {
                const label = this.userPaused ? this.resumeLabel : this.pauseLabel;
                this.toggle.hidden = fixed || !!this.exhausted;
                this.toggle.setAttribute('aria-pressed', this.userPaused ? 'true' : 'false');
                this.toggle.setAttribute('aria-label', label);
                this.toggle.setAttribute('title', label);
                this.toggle.classList.toggle('is-paused', this.userPaused);
            }

            this.animations.forEach((animation) => {
                if (active && animation.playState === 'paused') {
                    animation.play();
                } else if (!active && animation.playState === 'running') {
                    animation.pause();
                }
            });

            if (!active) {
                this.stopTimer();
                this.cancelIdle();
                return;
            }

            if (!this.firstReady) {
                if (!this.firstWaiting) {
                    this.firstWaiting = true;
                    this.waitForImage(imageFor(this.current), () => {
                        this.firstReady = true;
                        this.firstWaiting = false;
                        this.sync();
                    });
                }

                return;
            }

            if (!this.started) {
                this.started = true;
                this.startZoom(this.current);
                this.schedule(this.duration, () => this.advance());
            } else {
                this.resumeTimer();
            }

            if (this.advanceDue && this.nextReady) {
                this.advance();
            }

            this.preload();
        }

        restoreFirst() {
            this.stopTimer();
            this.pending = null;
            this.cancelIdle();
            this.waiters.forEach((cancel) => cancel());
            this.animations.forEach((animation) => animation.cancel());
            this.animations.clear();
            this.zooms.clear();
            this.next?.remove();
            this.next = null;
            this.nextIndex = null;
            this.nextReady = false;

            if (this.currentIndex !== 0) {
                const first = this.sources[0].cloneNode(true);
                this.current.replaceWith(first);
                this.current = first;
            }

            this.current.style.opacity = '1';
            this.current.style.transform = '';
            this.currentIndex = 0;
            this.started = false;
            this.advanceDue = false;
            this.transitioning = false;
            this.exhausted = false;
            this.firstWaiting = false;
            this.firstReady = false;
        }

        sourcesValid() {
            return this.stage === this.root.querySelector(stageSelector)
                && this.template === this.root.querySelector(templateSelector)
                && this.stage.contains(this.current)
                && (!this.next || this.stage.contains(this.next));
        }

        referencesValid() {
            return this.sourcesValid() && this.toggle === this.root.querySelector(toggleSelector);
        }

        destroy(restore = this.sourcesValid()) {
            if (restore) {
                this.restoreFirst();
            }

            this.destroyed = true;
            this.stopTimer();
            this.pending = null;
            this.cancelIdle();
            this.waiters.forEach((cancel) => cancel());
            this.animations.forEach((animation) => animation.cancel());
            this.animations.clear();
            this.zooms.clear();
            this.next?.remove();
            this.next = null;
            this.observer?.disconnect();
            this.toggle?.removeEventListener('click', this.onToggle);
            reducedMotion.removeEventListener('change', this.onMotionChange);
            instances.delete(this.root);
        }
    }

    const initialize = (root, force = false) => {
        if (!root.isConnected || pageSuspended) {
            return;
        }

        const existing = instances.get(root);

        if (existing && !force && existing.referencesValid()) {
            return;
        }

        existing?.destroy(existing.sourcesValid());
        let config;

        try {
            config = JSON.parse(root.getAttribute('data-thecore-background-slideshow'));
        } catch {
            return;
        }

        if (!config || typeof config !== 'object' || Array.isArray(config)
            || !root.querySelector(stageSelector)
            || !layersFor(root.querySelector(stageSelector)).length
            || !root.querySelector(templateSelector)?.content) {
            return;
        }

        instances.set(root, new BackgroundSlideshow(root, config));
    };

    const scan = (node) => {
        if (!(node instanceof Element)) {
            return;
        }

        if (node.matches(selector)) {
            initialize(node);
        } else {
            const root = node.closest(selector);

            if (root) {
                initialize(root);
            }
        }

        node.querySelectorAll(selector).forEach((root) => initialize(root));
    };

    const start = () => {
        refreshGlobalState();
        document.querySelectorAll(selector).forEach((root) => initialize(root));
        document.addEventListener('visibilitychange', () => instances.forEach((instance) => instance.sync()));
        window.addEventListener('resize', refreshGlobalState, { passive: true });
        window.addEventListener('pagehide', (event) => {
            pageSuspended = true;
            instances.forEach((instance) => event.persisted ? instance.sync() : instance.destroy());
        });
        window.addEventListener('pageshow', () => {
            pageSuspended = false;
            refreshGlobalState();
            document.querySelectorAll(selector).forEach((root) => initialize(root));
            instances.forEach((instance) => instance.sync());
        });

        if (!('MutationObserver' in window)) {
            return;
        }

        const observer = new MutationObserver((records) => {
            let accessibilityChanged = false;

            records.forEach((record) => {
                if (record.type === 'attributes') {
                    if (record.attributeName === 'data-thecore-background-slideshow') {
                        initialize(record.target, true);
                    } else if (record.target === document.body || affectsAccessibility(record.target)) {
                        accessibilityChanged = true;
                    }

                    return;
                }

                record.addedNodes.forEach((node) => {
                    scan(node);
                    accessibilityChanged = accessibilityChanged || containsAccessibility(node);
                });
                record.removedNodes.forEach((node) => {
                    if (node instanceof Element) {
                        accessibilityChanged = accessibilityChanged || containsAccessibility(node);
                        instances.forEach((instance, root) => {
                            if (!root.isConnected && (root === node || node.contains(root))) {
                                instance.destroy();
                            }
                        });
                    }
                });

                if (record.removedNodes.length && record.target instanceof Element) {
                    const root = record.target.closest(selector);
                    const instance = instances.get(root);

                    if (root?.isConnected && instance && !instance.referencesValid()) {
                        initialize(root);
                    }
                }
            });

            if (accessibilityChanged) {
                refreshGlobalState();
            }
        });
        observer.observe(document.body, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: [
                'data-thecore-background-slideshow', 'data-thecore-accessibility-module',
                'data-thecore-accessibility-trigger', 'data-thecore-accessibility-bound',
                'data-thecore-accessibility-trigger-bound', 'data-action', 'disabled',
                'aria-disabled', 'hidden', 'inert', 'aria-hidden', 'tabindex', 'class', 'style',
            ],
        });
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', start, { once: true });
    } else {
        start();
    }
})();
