(function (window, document) {
    'use strict';

    if (window.TheCoreCookieConsentCodes) {
        return;
    }

    var cookieName = 'cookie_consent';
    var records = new Map();
    var queue = Promise.resolve();
    var pausedUntilReload = false;
    var previousCategories = null;

    function readConsent() {
        var prefix = cookieName + '=';
        var raw = document.cookie.split(';').map(function (part) { return part.trim(); })
            .filter(function (part) { return part.indexOf(prefix) === 0; })[0];
        if (!raw) { return null; }
        try {
            var value = JSON.parse(raw.slice(prefix.length));
            return value && typeof value === 'object' && !Array.isArray(value)
                && Array.isArray(value.cookie_categories)
                && value.cookie_categories.every(function (category) { return typeof category === 'string'; })
                ? value : null;
        } catch (error) { return null; }
    }

    function categories() {
        var consent = readConsent();
        if (!consent) { return null; }
        return ['category_essential'].concat(consent.cookie_categories.filter(function (category) {
            return category !== 'category_essential';
        }));
    }

    function accepted(category) {
        var allowed = categories();
        return allowed !== null && allowed.indexOf(category) !== -1;
    }

    function emit(name, detail) {
        window.dispatchEvent(new window.CustomEvent(name, { detail: detail }));
    }

    function reportError(record, source, reason) {
        emit('thecore:cookie-consent-code-error', {
            category: record.category, id: record.id, src: source || '', reason: reason
        });
    }

    function appendScript(source, target, anchor, record) {
        var script = document.createElement('script');
        Array.prototype.forEach.call(source.attributes, function (attribute) {
            script.setAttribute(attribute.name, attribute.value);
        });
        if (source.nonce) { script.nonce = source.nonce; }
        script.textContent = source.textContent;
        var type = (source.getAttribute('type') || '').trim().toLowerCase().split(';')[0].trim();
        var executable = !type || type === 'module'
            || /^(?:(?:text|application)\/(?:x-)?(?:java|ecma)script|text\/(?:javascript1\.[0-5]|jscript|livescript))$/.test(type);
        var asynchronous = source.hasAttribute('async');
        // Dynamically inserted classic scripts otherwise default to async=true.
        script.async = asynchronous;
        var skippedModule = script.noModule && 'noModule' in document.createElement('script');
        // Inline modules retain native deferred scheduling and their exact source (including CSP hashes).
        var wait = executable && !asynchronous && !skippedModule && source.hasAttribute('src');
        return new Promise(function (resolve, reject) {
            if (wait) {
                script.onload = function () { resolve(); };
                script.onerror = function () { reject(new Error('script_load_failed')); };
            } else if (executable && source.hasAttribute('src')) {
                script.addEventListener('error', function () {
                    reportError(record, source.getAttribute('src'), 'script_load_failed');
                });
            }
            target.insertBefore(script, anchor);
            if (!wait) { resolve(); }
        });
    }

    function prepare(record) {
        var template = document.createElement('template');
        template.innerHTML = record.html;
        record.jobs = [];
        record.clones = new Map();
        function visit(node, parent) {
            record.jobs.push({ node: node, parent: parent });
            // A template's content and noscript payload must stay inert.
            if (node.nodeType === 1 && !/^(SCRIPT|TEMPLATE|NOSCRIPT)$/.test(node.tagName)) {
                Array.prototype.forEach.call(node.childNodes, function (child) { visit(child, node); });
            }
        }
        Array.prototype.forEach.call(template.content.childNodes, function (node) { visit(node, null); });
    }

    async function execute(record) {
        if (!record.jobs) { prepare(record); }
        while (record.index < record.jobs.length) {
            if (pausedUntilReload || !accepted(record.category)) { return; }
            var job = record.jobs[record.index];
            var target = job.parent ? record.clones.get(job.parent) : record.anchor.parentNode;
            var anchor = job.parent ? null : record.anchor;
            if (!target) { return; }
            if (job.node.nodeType === 1 && job.node.tagName === 'SCRIPT') {
                await appendScript(job.node, target, anchor, record);
            } else {
                var inert = job.node.nodeType === 1 && /^(TEMPLATE|NOSCRIPT)$/.test(job.node.tagName);
                var clone = job.node.cloneNode(inert);
                target.insertBefore(clone, anchor);
                record.clones.set(job.node, clone);
            }
            record.index += 1;
        }
        record.done = true;
    }

    function flush() {
        if (pausedUntilReload) { return; }
        records.forEach(function (record) {
            if (record.queued || record.done || record.failed || !accepted(record.category)) { return; }
            record.queued = true;
            queue = queue.then(function () { return execute(record); }).catch(function (error) {
                record.failed = true;
                reportError(record, '', error.message || 'execution_failed');
            }).then(function () { record.queued = false; });
        });
    }

    function register(element) {
        if (!element || element.getAttribute('data-thecore-cc-code') !== '1') { return; }
        var data;
        try { data = JSON.parse(element.textContent); } catch (error) { return; }
        if (!data || data.version !== 1 || data.cookieName !== cookieName || !Array.isArray(data.entries)) { return; }
        data.entries.forEach(function (entry) {
            if (!entry || typeof entry.id !== 'string' || !/^[a-f0-9]{64}$/.test(entry.id)
                || typeof entry.category !== 'string' || !/^category_[a-z0-9_-]+$/.test(entry.category)
                || typeof entry.html !== 'string' || records.has(entry.id)) { return; }
            records.set(entry.id, {
                id: entry.id, category: entry.category, html: entry.html, anchor: element,
                index: 0, queued: false, done: false, failed: false
            });
        });
        flush();
    }

    function scan() {
        document.querySelectorAll('script[data-thecore-cc-code="1"]').forEach(register);
    }

    function refresh(options) {
        options = options || {};
        // Keep the native reload contract without starting trackers twice around navigation.
        pausedUntilReload = options.execute === false;
        var current = categories();
        var changed = JSON.stringify(current) !== JSON.stringify(previousCategories);
        if (changed || options.source === 'choice' || options.source === 'revoke') {
            emit('thecore:cookie-consent-changed', {
                consentSet: current !== null,
                categories: current || [],
                previousCategories: previousCategories || [],
                source: options.source || 'refresh',
                reloadPending: pausedUntilReload
            });
        }
        previousCategories = current;
        if (!pausedUntilReload) { scan(); flush(); }
    }

    window.TheCoreCookieConsentCodes = {
        register: register, scan: scan, refresh: refresh,
        hasConsent: function () { return readConsent() !== null; },
        isAccepted: accepted,
        whenIdle: function () { return queue; }
    };
    previousCategories = categories();
}(window, document));
