/* The Core native runtime for explicitly opted-in Elementor classic markup. */
(() => {
  'use strict';
  if (window.theCoreNativeForms) return;
  const selector = '[data-thecore-native-form="1"]';
  const states = new WeakMap();
  let sequence = 0;
  const unavailable = 'Le formulaire ne peut pas être envoyé. Réessayez dans un instant.';
  const emit = (form, name, detail = {}, cancelable = false) => form.dispatchEvent(new CustomEvent('thecore:form-' + name, {bubbles: true, cancelable, detail: {form, ...detail}}));
  const node = (tag, className, text) => {
    const result = document.createElement(tag);
    if (className) result.className = className;
    if (text !== undefined) result.textContent = text;
    return result;
  };
  function endpoint(value) {
    const url = new URL(value, window.location.href);
    if (url.origin !== window.location.origin || !['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.hash) throw new Error(unavailable);
    return url.href;
  }
  function status(state, text, error = false) {
    state.output.className = 'thecore-form-status elementor-message ' + (error ? 'elementor-message-danger' : 'elementor-message-success');
    state.output.setAttribute('role', error ? 'alert' : 'status');
    state.output.setAttribute('aria-live', error ? 'assertive' : 'polite');
    state.output.textContent = text;
  }
  function goTo(form, index, focus = true) {
    const state = states.get(form);
    if (!state || state.busy || !Number.isInteger(index) || index < 0 || index >= state.steps.length) return false;
    state.index = index;
    state.steps.forEach((step, position) => {
      const active = position === index;
      step.classList.toggle('elementor-hidden', !active);
      step.setAttribute('aria-hidden', String(!active));
      step.inert = !active;
    });
    state.indicators.forEach((indicator, position) => {
      ['inactive', 'active', 'completed'].forEach(value => indicator.classList.remove('e-form__indicators__indicator--state-' + value));
      indicator.classList.add('e-form__indicators__indicator--state-' + (position < index ? 'completed' : position === index ? 'active' : 'inactive'));
      if (position === index) indicator.setAttribute('aria-current', 'step');
      else indicator.removeAttribute('aria-current');
    });
    if (state.progress) {
      const value = Math.round((index + 1) / state.steps.length * 100);
      state.progress.style.width = value + '%';
      state.progress.textContent = value + '%';
      state.progress.parentElement.setAttribute('aria-valuenow', String(value));
    }
    emit(form, 'step', {index});
    if (focus) state.steps[index].querySelector('input:not([type="hidden"]):not([disabled]),select:not([disabled]),textarea:not([disabled]),button')?.focus({preventScroll: true});
    return true;
  }
  function eligibleControls(root) {
    return [...root.querySelectorAll('input,select,textarea')].filter(control => !control.disabled && control.type !== 'hidden'
      && !control.closest('[data-thecore-form-security]') && !control.closest('[hidden]'));
  }
  function validate(state, root) {
    const invalid = eligibleControls(root).find(control => !control.checkValidity());
    if (!invalid) return true;
    const index = state.steps.findIndex(step => step.contains(invalid));
    if (index >= 0) goTo(state.form, index, false);
    invalid.reportValidity(); invalid.focus({preventScroll: true});
    return false;
  }
  function buildSteps(state) {
    const wrapper = state.form.querySelector('.elementor-form-fields-wrapper');
    if (!wrapper) throw new Error(unavailable);
    const markers = [...wrapper.children].filter(child => child.classList.contains('elementor-field-type-step'));
    if (!markers.length) return;
    const submitGroup = [...wrapper.children].find(child => child.classList.contains('elementor-field-type-submit'));
    const submitButton = submitGroup?.querySelector('[type="submit"]');
    if (!submitButton) throw new Error(unavailable);
    const responsive = [...submitGroup.classList].filter(value => /^elementor-(?:sm|md)-\d+$/.test(value));
    const width = /^\d{1,3}$/.test(state.config.buttonWidth) ? state.config.buttonWidth : '100';
    markers.forEach((step, index) => {
      const marker = step.querySelector('.e-field-step');
      const nextMarker = markers[index + 1];
      let sibling = step.nextElementSibling;
      while (sibling && sibling !== nextMarker) {
        const following = sibling.nextElementSibling;
        if (sibling !== submitGroup) step.append(sibling);
        sibling = following;
      }
      step.classList.add('e-form__step'); step.classList.remove('elementor-field-group', 'elementor-column');
      const buttons = node('div', ['e-form__buttons', 'elementor-column', 'elementor-col-' + width, ...responsive].join(' '));
      function navigation(direction) {
        const control = node('button', 'elementor-button e-form__buttons__wrapper__button e-form__buttons__wrapper__button-' + direction,
          marker?.getAttribute('data-' + direction + 'button') || (direction === 'next' ? state.config.nextLabel : state.config.previousLabel));
        control.type = 'button'; control.dataset.direction = direction;
        const size = [...submitButton.classList].filter(value => value.startsWith('elementor-size-'));
        size.forEach(value => control.classList.add(value));
        const group = node('div', 'elementor-field-group e-form__buttons__wrapper elementor-field-type-' + direction);
        group.append(control); buttons.append(group);
        control.addEventListener('click', () => {
          if (state.busy || (direction === 'next' && !validate(state, step))) return;
          goTo(state.form, state.index + (direction === 'next' ? 1 : -1));
        });
      }
      if (index > 0) navigation('previous');
      if (index < markers.length - 1) navigation('next');
      else {
        [...submitGroup.classList].filter(value => /^elementor-(?:col|sm|md)-/.test(value)).forEach(value => submitGroup.classList.remove(value));
        submitGroup.classList.remove('elementor-column', 'e-form__buttons');
        submitGroup.classList.add('e-form__buttons__wrapper');
        submitButton.classList.add('e-form__buttons__wrapper__button');
        buttons.append(submitGroup);
      }
      step.append(buttons);
    });
    state.steps = markers;
    if (state.config.stepType !== 'none') {
      const type = ['number', 'text', 'number_text', 'progress_bar'].includes(state.config.stepType) ? state.config.stepType : 'number_text';
      const indicators = node('div', 'e-form__indicators e-form__indicators--type-' + type);
      indicators.setAttribute('aria-label', 'Étapes du formulaire');
      if (type === 'progress_bar') {
        const progress = node('div', 'e-form__indicators__indicator__progress');
        progress.setAttribute('role', 'progressbar'); progress.setAttribute('aria-valuemin', '0'); progress.setAttribute('aria-valuemax', '100');
        state.progress = node('div', 'e-form__indicators__indicator__progress__meter');
        progress.append(state.progress); indicators.append(progress);
      } else {
        markers.forEach((step, index) => {
          const indicator = node('div', 'e-form__indicators__indicator');
          const shape = ['circle', 'square', 'rounded', 'none'].includes(state.config.stepShape) ? state.config.stepShape : 'circle';
          if (type !== 'text') indicator.append(node('div', 'e-form__indicators__indicator__number e-form__indicators__indicator--shape-' + shape, String(index + 1)));
          if (type !== 'number') indicator.append(node('div', 'e-form__indicators__indicator__label', step.querySelector('.e-field-step')?.getAttribute('data-label') || 'Étape ' + (index + 1)));
          indicators.append(indicator); state.indicators.push(indicator);
          if (index < markers.length - 1) indicators.append(node('div', 'e-form__indicators__indicator__separator'));
        });
      }
      wrapper.before(indicators);
    }
    goTo(state.form, 0, false);
    state.form.addEventListener('keydown', event => {
      if (event.key === 'Enter' && event.target.tagName !== 'TEXTAREA' && state.index < state.steps.length - 1) {
        event.preventDefault();
        if (!state.busy && validate(state, state.steps[state.index])) goTo(state.form, state.index + 1);
      }
    });
  }
  function clearErrors(state) {
    state.form.querySelectorAll('[data-thecore-native-error]').forEach(error => error.remove());
    state.errors.forEach(({control, describedBy}) => {
      control.removeAttribute('aria-invalid');
      if (describedBy === null) control.removeAttribute('aria-describedby'); else control.setAttribute('aria-describedby', describedBy);
    });
    state.errors = [];
  }
  function showErrors(state, errors) {
    let first;
    Object.entries(errors || {}).forEach(([id, message]) => {
      if (typeof message !== 'string') return;
      const controls = [...state.form.querySelectorAll('input,select,textarea')].filter(control => control.name === 'form_fields[' + id + ']' || control.name === 'form_fields[' + id + '][]');
      if (!controls.length) return;
      const error = node('span', 'elementor-message elementor-message-danger elementor-help-inline elementor-form-help-inline', message);
      error.id = 'thecore-native-error-' + (++sequence); error.dataset.thecoreNativeError = '1';
      (controls[0].closest('.elementor-field-group') || controls[0].parentElement).append(error);
      controls.forEach(control => {
        const describedBy = control.getAttribute('aria-describedby');
        state.errors.push({control, describedBy});
        control.setAttribute('aria-invalid', 'true'); control.setAttribute('aria-describedby', [describedBy, error.id].filter(Boolean).join(' '));
      });
      first ||= controls[0];
    });
    if (first) {
      const index = state.steps.findIndex(step => step.contains(first));
      if (index >= 0) goTo(state.form, index, false);
    }
    return first;
  }
  async function send(state, event) {
    if (event.defaultPrevented) return;
    event.preventDefault(); event.stopImmediatePropagation();
    if (state.busy) return;
    if (state.steps.length && state.index < state.steps.length - 1) {
      if (validate(state, state.steps[state.index])) goTo(state.form, state.index + 1);
      return;
    }
    clearErrors(state);
    if (!validate(state, state.form)) return;
    const data = new FormData(state.form);
    data.set('action', 'elementor_pro_forms_send_form');
    data.set('referrer', window.location.href);
    const request = {data, endpoint: state.endpoint};
    if (!emit(state.form, 'before-send', request, true)) return;
    const buttons = [...state.form.querySelectorAll('button,input[type="submit"]')];
    const disabled = buttons.map(button => button.disabled);
    const abort = new AbortController();
    const timeout = window.setTimeout(() => abort.abort(), 60000);
    let response = null, statusCode = 0, transportError = false, success = false, started = false;
    let focusTarget;
    state.busy = true; state.form.setAttribute('aria-busy', 'true');
    buttons.forEach(button => { button.disabled = true; });
    status(state, 'Envoi en cours…');
    try {
      // This immutable endpoint comes from the server configuration, never an event listener.
      emit(state.form, 'request', request); started = true;
      const http = await fetch(state.endpoint, {method: 'POST', body: data, credentials: 'same-origin', cache: 'no-store', redirect: 'error', signal: abort.signal});
      statusCode = http.status;
      response = await http.json();
      if (!response || typeof response !== 'object' || Array.isArray(response) || typeof response.success !== 'boolean') throw new Error(unavailable);
      success = http.ok && response.success === true;
      state.busy = false;
      const payload = response.data && typeof response.data === 'object' ? response.data : {};
      const message = typeof payload.message === 'string' && payload.message.trim() ? payload.message : success ? 'Votre demande a bien été reçue.' : 'Votre envoi n’a pas pu être confirmé. Vérifiez les champs puis réessayez.';
      status(state, message, !success);
      if (!success) focusTarget = showErrors(state, payload.errors);
      else {
        if (state.wrapper.dataset.thecoreApi === '1') void window.theCoreFormApiSubmission.clear(apiScope(state.form)).catch(() => {});
        state.form.reset();
        if (state.steps.length) goTo(state.form, 0, false);
      }
    } catch (_) {
      transportError = true;
      status(state, 'La confirmation n’a pas pu être reçue. Vos réponses sont conservées ; réessayez le même envoi.', true);
    } finally {
      window.clearTimeout(timeout); state.busy = false; state.form.removeAttribute('aria-busy');
      buttons.forEach((button, index) => { button.disabled = disabled[index]; });
      if (started) emit(state.form, 'result', {data, endpoint: state.endpoint, response, status: statusCode, transportError, success, uncertain: transportError || (!success && !Object.keys(response?.data?.errors || {}).length)});
      (focusTarget || state.output).focus({preventScroll: true});
    }
  }
  function init(form) {
    if (states.has(form)) return states.get(form);
    const wrapper = form.closest(selector);
    if (!wrapper || form.closest('.elementor-editor-active')) return null;
    let config;
    try { config = JSON.parse(wrapper.dataset.thecoreNativeConfig); config.endpoint = endpoint(config.endpoint); }
    catch (_) { return null; }
    const output = node('div', 'thecore-form-status'); output.tabIndex = -1; output.setAttribute('aria-live', 'polite'); form.append(output);
    const state = {form, wrapper, config, endpoint: config.endpoint, output, busy: false, apiPending: false, apiReady: false, index: 0, steps: [], indicators: [], errors: []};
    states.set(form, state); form.noValidate = true;
    try { buildSteps(state); } catch (_) { states.delete(form); status(state, unavailable, true); return null; }
    form.addEventListener('submit', event => { void send(state, event); });
    form.dataset.thecoreNativeReady = '1'; emit(form, 'ready');
    return state;
  }
  function scan(root = document) {
    const forms = [];
    if (root.matches?.('form.elementor-form') && root.closest(selector)) forms.push(root);
    root.querySelectorAll?.('form.elementor-form').forEach(form => { if (form.closest(selector)) forms.push(form); });
    return forms.filter(form => init(form) && form.dataset.thecoreNativeReady === '1');
  }
  function apiScope(form) {
    return 'legacy:' + window.location.pathname + ':' + (form.querySelector('[name="post_id"]')?.value || '') + ':' + (form.querySelector('[name="form_id"]')?.value || '');
  }
  function apiValues(form) {
    const values = {};
    for (const [key, value] of new FormData(form).entries()) {
      if (!key.startsWith('form_fields[') || value instanceof File || /thecore_form_security|thecore_atomic_proof/.test(key)) continue;
      (values[key] ||= []).push(value);
    }
    return values;
  }
  // API identity must be available before site-specific capture listeners bind videos or drafts.
  document.addEventListener('submit', async event => {
    const form = event.target;
    if (event.defaultPrevented || !form.matches?.('form.elementor-form') || !form.closest(selector)) return;
    const state = init(form);
    if (!state || state.wrapper.dataset.thecoreApi !== '1') return;
    if (state.apiReady) { state.apiReady = false; return; }
    event.preventDefault(); event.stopImmediatePropagation();
    if (state.apiPending || state.busy) return;
    state.apiPending = true;
    try {
      const id = await window.theCoreFormApiSubmission.prepare(apiScope(form), apiValues(form));
      let input = form.querySelector('[name="thecore_api_submission_id"]');
      if (!input) { input = node('input'); input.type = 'hidden'; input.name = 'thecore_api_submission_id'; form.append(input); }
      input.value = id;
      await new Promise(resolve => window.setTimeout(resolve, 0));
      state.apiReady = true;
      if (event.submitter?.form === form) form.requestSubmit(event.submitter); else form.requestSubmit();
      state.apiReady = false;
    } catch (_) { status(state, unavailable, true); }
    finally { state.apiPending = false; }
  }, true);
  window.theCoreNativeForms = {scan, goTo, ready: form => states.has(form) && form.dataset.thecoreNativeReady === '1'};
  function boot() {
    scan();
    new MutationObserver(entries => entries.forEach(entry => entry.addedNodes.forEach(added => { if (added.nodeType === 1) scan(added); }))).observe(document.body, {childList: true, subtree: true});
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, {once: true}); else boot();
})();
