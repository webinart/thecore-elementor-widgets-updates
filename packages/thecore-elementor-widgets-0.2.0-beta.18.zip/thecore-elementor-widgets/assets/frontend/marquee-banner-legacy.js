(function () {
    var TRACK_SELECTOR = '[data-thecore-marquee-banner-legacy-track="true"]';

    function loadTrackImages(track) {
        var lazyImages = track.querySelectorAll('img.is-lazy[data-thecore-marquee-src]');

        if (!lazyImages.length) {
            return;
        }

        lazyImages.forEach(function (image) {
            image.src = image.getAttribute('data-thecore-marquee-src');
            image.classList.remove('is-lazy');
        });
    }

    function observeTrack(track) {
        if ('IntersectionObserver' in window) {
            var observer = new IntersectionObserver(function (entries, instance) {
                entries.forEach(function (entry) {
                    if (!entry.isIntersecting) {
                        return;
                    }

                    loadTrackImages(track);
                    instance.unobserve(entry.target);
                });
            }, { rootMargin: '200px' });

            observer.observe(track);

            return;
        }

        loadTrackImages(track);
    }

    function initTrack(track) {
        if (!track || track.dataset.thecoreMarqueeLegacyInitialized === '1') {
            return;
        }

        track.dataset.thecoreMarqueeLegacyInitialized = '1';

        if (track.dataset.lazy !== '1') {
            return;
        }

        if (track.dataset.lazyMethod === 'delay') {
            window.setTimeout(function () {
                loadTrackImages(track);
            }, parseInt(track.dataset.lazyDelay || '1000', 10));

            return;
        }

        observeTrack(track);
    }

    function boot(context) {
        if (!context || !context.querySelectorAll) {
            return;
        }

        context.querySelectorAll(TRACK_SELECTOR).forEach(initTrack);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () {
            boot(document);
        });
    } else {
        boot(document);
    }

    if (window.elementorFrontend && window.elementorFrontend.hooks) {
        window.elementorFrontend.hooks.addAction(
            'frontend/element_ready/thecore-marquee-banner-legacy.default',
            function ($scope) {
                if ($scope && $scope[0]) {
                    boot($scope[0]);
                }
            }
        );
    }
})();
