(function () {
    'use strict';

    var config = window.TheCoreElementorWidgetsAccessibilityConfig || {};
    var TOOLBAR_ID = 'thecore-accessibility-toolbar';
    var PANEL_ID = 'thecore-accessibility-toolbar-panel';
    var MASK_ID = 'thecore-accessibility-reading-mask';
    var OPEN_HASH = config.openHash || '#thecore-accessibility-open';
    var TOGGLE_HASH = config.toggleHash || '#thecore-accessibility-toggle';
    var STORAGE_KEY = config.storageKey || 'thecore-elementor-widgets-accessibility';
    var READING_MASK_HEIGHT = 112;
    var ACTION_CLASS_MAP = {
        'bigger-text': 'thecore-accessibility-resize-font-120',
        'bigger-line-height': 'thecore-accessibility-bigger-line-height',
        'text-align': 'thecore-accessibility-text-align',
        'readable-font': 'thecore-accessibility-readable-font',
        'grayscale': 'thecore-accessibility-grayscale',
        'contrast': 'thecore-accessibility-high-contrast',
        'page-structure': 'thecore-accessibility-page-structure',
        'reading-mask': 'thecore-accessibility-reading-mask-enabled',
        'hide-images': 'thecore-accessibility-hide-images',
        'pause-animations': 'thecore-accessibility-pause-animations',
        'highlight-links': 'thecore-accessibility-links-underline',
        'focus-outline': 'thecore-accessibility-focusable'
    };

    var state = {
        actions: createDefaultState(),
        expires: null
    };

    var dom = {
        body: document.body,
        toolbar: null,
        panel: null,
        toggleButton: null,
        closeButton: null,
        controls: [],
        actionControls: [],
        skipNav: null,
        skipLink: null,
        mask: null,
        maskTop: null,
        maskFocus: null,
        maskBottom: null
    };
    var lastTrigger = null;
    var observer = null;
    var mutationFrame = null;

    function createDefaultState() {
        return {
            'bigger-text': false,
            'bigger-line-height': false,
            'text-align': false,
            'readable-font': false,
            'grayscale': false,
            'contrast': false,
            'page-structure': false,
            'reading-mask': false,
            'hide-images': false,
            'pause-animations': false,
            'highlight-links': false,
            'focus-outline': !!config.alwaysFocusable
        };
    }

    function cacheElements() {
        dom.toolbar = document.getElementById(TOOLBAR_ID);
        dom.panel = document.getElementById(PANEL_ID);
        dom.skipNav = document.querySelector('[data-thecore-accessibility-skip-nav]');
        dom.skipLink = dom.skipNav ? dom.skipNav.querySelector('.thecore-accessibility-skip-link') : null;
        dom.mask = document.getElementById(MASK_ID);
        dom.maskTop = dom.mask ? dom.mask.querySelector('.thecore-accessibility-reading-mask-top') : null;
        dom.maskFocus = dom.mask ? dom.mask.querySelector('.thecore-accessibility-reading-mask-focus') : null;
        dom.maskBottom = dom.mask ? dom.mask.querySelector('.thecore-accessibility-reading-mask-bottom') : null;

        if (!dom.toolbar) {
            return;
        }

        dom.toggleButton = dom.toolbar.querySelector('.thecore-accessibility-toolbar-toggle-link');
        dom.closeButton = dom.toolbar.querySelector('.thecore-accessibility-toolbar-close');
        dom.controls = Array.prototype.slice.call(
            dom.toolbar.querySelectorAll('.thecore-accessibility-toolbar-control, .thecore-accessibility-toolbar-close')
        );
        dom.actionControls = Array.prototype.slice.call(
            dom.toolbar.querySelectorAll('[data-action]')
        );
    }

    function prependNode(target, node) {
        if (!target || !node) {
            return;
        }

        if (node.parentNode === target && target.firstElementChild === node) {
            return;
        }

        target.insertBefore(node, target.firstChild);
    }

    function insertAfterNode(target, node, referenceNode) {
        if (!target || !node || !referenceNode || referenceNode.parentNode !== target) {
            return;
        }

        if (node.parentNode === target && node.previousElementSibling === referenceNode) {
            return;
        }

        if (referenceNode.nextSibling) {
            target.insertBefore(node, referenceNode.nextSibling);
            return;
        }

        target.appendChild(node);
    }

    function resolveSelector(selector) {
        if (!selector) {
            return null;
        }

        try {
            return document.querySelector(selector);
        } catch (error) {
            return null;
        }
    }

    function syncSkipLinkTarget() {
        var targetSelector;
        var target;

        if (!dom.skipNav || !dom.skipLink) {
            return;
        }

        targetSelector = dom.skipNav.getAttribute('data-target-selector') || 'main, #content, [role="main"]';
        target = resolveSelector(targetSelector);

        if (!target) {
            return;
        }

        if (!target.id) {
            target.id = 'thecore-accessibility-target';
        }

        dom.skipLink.setAttribute('href', '#' + target.id);
    }

    function mountRuntimeElements() {
        var mountSelector;
        var mountTarget;

        if (!dom.body) {
            return;
        }

        if (dom.skipNav) {
            mountSelector = dom.skipNav.getAttribute('data-mount-selector') || 'body';
            mountTarget = resolveSelector(mountSelector) || dom.body;

            if (mountTarget === dom.body) {
                prependNode(dom.body, dom.skipNav);
            } else {
                prependNode(mountTarget, dom.skipNav);
            }

            syncSkipLinkTarget();
        }

        if (dom.mask) {
            if (dom.skipNav && dom.skipNav.parentNode === dom.body) {
                insertAfterNode(dom.body, dom.mask, dom.skipNav);
                return;
            }

            prependNode(dom.body, dom.mask);
        }
    }

    function bindToolbarEvents() {
        if (!dom.toolbar || dom.toolbar.getAttribute('data-thecore-accessibility-bound') === '1') {
            return;
        }

        dom.toolbar.setAttribute('data-thecore-accessibility-bound', '1');
        dom.toolbar.addEventListener('click', handleToolbarClick);
    }

    function isToolbarOpen() {
        return !!(dom.toolbar && dom.toolbar.classList.contains('thecore-accessibility-toolbar-open'));
    }

    function syncToolbarAccessibility() {
        var open = isToolbarOpen();

        if (dom.toggleButton) {
            dom.toggleButton.setAttribute('aria-expanded', open ? 'true' : 'false');
        }

        if (dom.panel) {
            dom.panel.setAttribute('aria-hidden', open ? 'false' : 'true');
        }

        dom.controls.forEach(function (control) {
            if (control === dom.toggleButton) {
                return;
            }

            control.setAttribute('tabindex', open ? '0' : '-1');
        });
    }

    function openToolbar() {
        if (!dom.toolbar) {
            return false;
        }

        syncAdminBarOffset();
        dom.toolbar.classList.add('thecore-accessibility-toolbar-open');
        syncToolbarAccessibility();

        return true;
    }

    function closeToolbar() {
        if (!dom.toolbar) {
            return false;
        }

        dom.toolbar.classList.remove('thecore-accessibility-toolbar-open');
        syncToolbarAccessibility();

        return true;
    }

    function toggleToolbar() {
        return isToolbarOpen() ? closeToolbar() : openToolbar();
    }

    function restoreTriggerFocus() {
        if (lastTrigger && document.contains(lastTrigger) && typeof lastTrigger.focus === 'function') {
            lastTrigger.focus();
            return;
        }

        if (dom.toggleButton) {
            dom.toggleButton.focus();
        }
    }

    function focusFirstToolbarControl() {
        if (!dom.actionControls.length) {
            return;
        }

        dom.actionControls[0].focus();
    }

    function updateButtonState(action, active) {
        dom.actionControls.forEach(function (control) {
            if (control.getAttribute('data-action') !== action) {
                return;
            }

            control.classList.toggle('is-active', active);

            if (control.tagName === 'BUTTON') {
                control.setAttribute('aria-pressed', active ? 'true' : 'false');
            }
        });
    }

    function removeBodyClasses() {
        Object.keys(ACTION_CLASS_MAP).forEach(function (action) {
            dom.body.classList.remove(ACTION_CLASS_MAP[action]);
        });
    }

    function applyState() {
        removeBodyClasses();

        Object.keys(ACTION_CLASS_MAP).forEach(function (action) {
            var active = !!state.actions[action];

            updateButtonState(action, active);

            if (active) {
                dom.body.classList.add(ACTION_CLASS_MAP[action]);
            }
        });

        syncReadingMask();
        window.dispatchEvent(new Event('resize'));
    }

    function resetState() {
        state.actions = createDefaultState();
        state.expires = null;
        clearSavedState();
        applyState();
    }

    function toggleAction(action) {
        if (action === 'reset') {
            resetState();
            return;
        }

        if (!Object.prototype.hasOwnProperty.call(state.actions, action)) {
            return;
        }

        state.actions[action] = !state.actions[action];
        applyState();
        saveState();
    }

    function saveState() {
        if (!config.enableSave) {
            return;
        }

        state.expires = Date.now() + (Number(config.saveExpirationHours || 12) * 60 * 60 * 1000);

        try {
            window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
        } catch (error) {
            return;
        }
    }

    function clearSavedState() {
        try {
            window.localStorage.removeItem(STORAGE_KEY);
        } catch (error) {
            return;
        }
    }

    function loadState() {
        var payload;
        var defaultState;

        if (!config.enableSave) {
            return;
        }

        try {
            payload = window.localStorage.getItem(STORAGE_KEY);
        } catch (error) {
            return;
        }

        if (!payload) {
            return;
        }

        try {
            payload = JSON.parse(payload);
        } catch (error) {
            clearSavedState();
            return;
        }

        if (!payload || typeof payload !== 'object' || !payload.actions || typeof payload.actions !== 'object') {
            clearSavedState();
            return;
        }

        if (!payload.expires || payload.expires < Date.now()) {
            clearSavedState();
            return;
        }

        defaultState = createDefaultState();

        Object.keys(defaultState).forEach(function (action) {
            if (typeof payload.actions[action] === 'boolean') {
                defaultState[action] = payload.actions[action];
            }
        });

        if (config.alwaysFocusable) {
            defaultState['focus-outline'] = true;
        }

        state.actions = defaultState;
        state.expires = payload.expires;
    }

    function syncReadingMask() {
        if (!dom.mask) {
            return;
        }

        dom.mask.classList.toggle('is-active', !!state.actions['reading-mask']);

        if (state.actions['reading-mask']) {
            updateReadingMask((window.innerHeight || 0) / 2);
        } else {
            dom.maskTop.style.height = '';
            dom.maskFocus.style.top = '';
            dom.maskBottom.style.top = '';
            dom.maskBottom.style.height = '';
        }
    }

    function updateReadingMask(clientY) {
        var viewportHeight;
        var halfMask;
        var safeY;

        if (!dom.mask || !dom.maskTop || !dom.maskFocus || !dom.maskBottom || !state.actions['reading-mask']) {
            return;
        }

        viewportHeight = Math.max(window.innerHeight || 0, document.documentElement.clientHeight || 0);
        halfMask = READING_MASK_HEIGHT / 2;
        safeY = Math.max(halfMask + 20, Math.min(viewportHeight - halfMask - 20, clientY || viewportHeight / 2));

        dom.maskTop.style.height = Math.max(safeY - halfMask, 0) + 'px';
        dom.maskFocus.style.top = Math.max(safeY - halfMask, 0) + 'px';
        dom.maskBottom.style.top = Math.min(safeY + halfMask, viewportHeight) + 'px';
        dom.maskBottom.style.height = Math.max(viewportHeight - (safeY + halfMask), 0) + 'px';
    }

    function syncAdminBarOffset() {
        var adminBar = document.getElementById('wpadminbar');
        var offset = 0;

        if (adminBar) {
            offset = Math.max(adminBar.getBoundingClientRect().height || 0, adminBar.offsetHeight || 0);
        }

        document.documentElement.style.setProperty('--thecore-accessibility-admin-bar-offset', offset + 'px');
    }

    function handleToolbarClick(event) {
        var toggleTarget;
        var closeTarget;
        var actionTarget;

        if (!dom.toolbar) {
            return;
        }

        toggleTarget = event.target.closest('.thecore-accessibility-toolbar-toggle-link');

        if (toggleTarget && dom.toolbar.contains(toggleTarget)) {
            event.preventDefault();
            if (toggleToolbar()) {
                if (isToolbarOpen()) {
                    focusFirstToolbarControl();
                }
            }
            return;
        }

        closeTarget = event.target.closest('[data-thecore-accessibility-close]');

        if (closeTarget && dom.toolbar.contains(closeTarget)) {
            event.preventDefault();
            closeToolbar();
            restoreTriggerFocus();
            return;
        }

        actionTarget = event.target.closest('[data-action]');

        if (!actionTarget || !dom.toolbar.contains(actionTarget)) {
            return;
        }

        event.preventDefault();
        toggleAction(actionTarget.getAttribute('data-action'));
    }

    function handleDocumentClick(event) {
        var externalTrigger = event.target.closest(
            '[data-thecore-accessibility-trigger], .thecore-accessibility-trigger, a[href="' + OPEN_HASH + '"], a[href="' + TOGGLE_HASH + '"]'
        );
        var triggerMode;

        if (externalTrigger && (!dom.toolbar || !dom.toolbar.contains(externalTrigger))) {
            lastTrigger = externalTrigger;
            triggerMode = externalTrigger.getAttribute('data-thecore-accessibility-trigger');

            if (triggerMode !== 'toggle' && externalTrigger.getAttribute('href') === TOGGLE_HASH) {
                triggerMode = 'toggle';
            }

            event.preventDefault();

            if (triggerMode === 'toggle') {
                toggleToolbar();
                return;
            }

            if (openToolbar()) {
                focusFirstToolbarControl();
            }
            return;
        }

        if (isToolbarOpen() && dom.toolbar && !dom.toolbar.contains(event.target)) {
            closeToolbar();
        }
    }

    function handleKeyboardInteractions(event) {
        if (event.key === 'Escape' && isToolbarOpen()) {
            closeToolbar();
            restoreTriggerFocus();
        }
    }

    function handleDocumentKeyup(event) {
        if (event.key !== 'Tab' || !dom.toggleButton || document.activeElement !== dom.toggleButton) {
            return;
        }

        openToolbar();
    }

    function handleMouseMove(event) {
        updateReadingMask(event.clientY);
    }

    function applyGlobalOptions() {
        if (config.removeLinkTarget) {
            Array.prototype.forEach.call(document.querySelectorAll('a[target="_blank"]'), function (link) {
                link.setAttribute('target', '');
            });
        }

        if (config.addRoleLinks) {
            Array.prototype.forEach.call(document.querySelectorAll('a'), function (link) {
                if (!link.hasAttribute('role')) {
                    link.setAttribute('role', 'link');
                }
            });
        }
    }

    function clearHash() {
        if (!window.location.hash || !window.history || typeof window.history.replaceState !== 'function') {
            return;
        }

        window.history.replaceState(null, document.title, window.location.pathname + window.location.search);
    }

    function handleHashAction() {
        if (window.location.hash === OPEN_HASH) {
            if (openToolbar()) {
                focusFirstToolbarControl();
            }

            clearHash();
            return;
        }

        if (window.location.hash === TOGGLE_HASH) {
            toggleToolbar();
            clearHash();
            return;
        }

        focusHashTarget(window.location.hash);
    }

    function focusHashTarget(hash) {
        var id;
        var element;

        if (!hash || hash === OPEN_HASH || hash === TOGGLE_HASH) {
            return;
        }

        id = hash.replace(/^#/, '');

        if (!/^[A-z0-9_-]+$/.test(id)) {
            return;
        }

        element = document.getElementById(id);

        if (!element) {
            return;
        }

        if (!/^(?:a|select|input|button|textarea)$/i.test(element.tagName)) {
            element.setAttribute('tabindex', '-1');
        }

        element.focus();
    }

    function initToolbar() {
        if (
            window.thecoreElementorWidgetsAccessibility
            && typeof window.thecoreElementorWidgetsAccessibility.refresh === 'function'
        ) {
            window.thecoreElementorWidgetsAccessibility.refresh();
            return;
        }

        cacheElements();
        mountRuntimeElements();
        syncToolbarAccessibility();
        applyGlobalOptions();
        loadState();
        applyState();
        syncAdminBarOffset();
        handleHashAction();
        bindToolbarEvents();

        document.addEventListener('keyup', handleDocumentKeyup);
        document.addEventListener('keydown', handleKeyboardInteractions);
        document.addEventListener('click', handleDocumentClick);
        document.addEventListener('mousemove', handleMouseMove);
        window.addEventListener('load', syncAdminBarOffset);
        window.addEventListener('resize', syncReadingMask);
        window.addEventListener('resize', syncAdminBarOffset);
        window.addEventListener('hashchange', handleHashAction);

        if (window.MutationObserver && document.body) {
            observer = new MutationObserver(function () {
                if (mutationFrame !== null || !document.body) {
                    return;
                }

                mutationFrame = window.requestAnimationFrame(function () {
                    mutationFrame = null;
                    cacheElements();
                    mountRuntimeElements();
                    syncToolbarAccessibility();
                    bindToolbarEvents();
                });
            });

            observer.observe(document.body, { childList: true, subtree: true });
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initToolbar);
    } else {
        initToolbar();
    }

    window.thecoreElementorWidgetsAccessibility = {
        __initialized: true,
        openToolbar: openToolbar,
        closeToolbar: closeToolbar,
        toggleToolbar: toggleToolbar,
        refresh: function () {
            cacheElements();
            mountRuntimeElements();
            syncToolbarAccessibility();
            bindToolbarEvents();
        }
    };
})();
