<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\TChat;

use TheCore\ElementorWidgets\Assets\FrontendAssets;
use TheCore\ElementorWidgets\Contracts\Bootable;
use TheCore\ElementorWidgets\TChat\Admin\AdminPage;
use TheCore\ElementorWidgets\TChat\Http\AdminController;
use TheCore\ElementorWidgets\TChat\Http\ConversationController;
use TheCore\ElementorWidgets\TChat\Http\MessageController;
use TheCore\ElementorWidgets\TChat\Http\PersistController;

final class TChatModule implements Bootable
{
    public const DEFAULT_TITLE = 'TChat';
    public const DEFAULT_SUBTITLE = '';
    public const DEFAULT_PLACEHOLDER = 'Votre message...';
    public const DEFAULT_TRIGGER_LABEL = 'TChat';

    public function register(): void
    {
        add_action('init', [$this, 'registerShortcode']);
        add_action('wp_enqueue_scripts', [$this, 'enqueueFrontendAssets']);
        add_action('rest_api_init', [$this, 'registerRoutes']);
        add_action('wp_ajax_tchat_poll', [$this, 'ajaxPoll']);
        add_action('wp_ajax_nopriv_tchat_poll', [$this, 'ajaxPoll']);

        AdminPage::register();
    }

    public function registerShortcode(): void
    {
        add_shortcode('tchat', [$this, 'renderShortcode']);
    }

    /**
     * @param array<string, mixed> $atts
     */
    public function renderShortcode(array $atts = []): string
    {
        return self::renderModule(
            [
                'id' => 'tchat-root',
            ],
            self::renderDefaultTriggerMarkup()
        );
    }

    public function enqueueFrontendAssets(): void
    {
        wp_enqueue_script(FrontendAssets::TCHAT_WIDGET_SCRIPT);
        wp_enqueue_style(FrontendAssets::TCHAT_WIDGET_STYLE);
    }

    /**
     * @param array<string, mixed> $config
     */
    public static function renderModule(array $config = [], string $triggerMarkup = ''): string
    {
        wp_enqueue_script(FrontendAssets::TCHAT_WIDGET_SCRIPT);
        wp_enqueue_style(FrontendAssets::TCHAT_WIDGET_STYLE);

        $config = array_merge(
            [
                'id' => '',
                'title' => self::DEFAULT_TITLE,
                'subtitle' => self::DEFAULT_SUBTITLE,
                'placeholder' => self::DEFAULT_PLACEHOLDER,
                'horizontal_position' => 'right',
                'vertical_position' => 'bottom',
                'force_open' => false,
                'editor_preview' => false,
                'root_classes' => [],
            ],
            $config
        );

        $horizontalPosition = $config['horizontal_position'] === 'left' ? 'left' : 'right';
        $verticalPosition = in_array($config['vertical_position'], ['top', 'center', 'bottom'], true)
            ? (string) $config['vertical_position']
            : 'bottom';
        $rootClasses = [
            'thecore-tchat-module',
            'thecore-tchat-module--align-' . $horizontalPosition,
            'thecore-tchat-module--position-' . $verticalPosition,
        ];

        if (is_array($config['root_classes'])) {
            foreach ($config['root_classes'] as $rootClass) {
                if (is_string($rootClass) && $rootClass !== '') {
                    $rootClasses[] = $rootClass;
                }
            }
        }

        if ($triggerMarkup !== '') {
            $rootClasses[] = 'thecore-tchat-module--with-trigger';
        }

        $forceOpen = !empty($config['force_open']);
        $editorPreview = !empty($config['editor_preview']);
        if ($forceOpen) {
            $rootClasses[] = 'is-open';
        }
        if ($editorPreview) {
            $rootClasses[] = 'thecore-tchat-module--editor-preview';
        }

        $rootId = is_string($config['id']) ? $config['id'] : '';
        $title = is_string($config['title']) && $config['title'] !== '' ? $config['title'] : self::DEFAULT_TITLE;
        $subtitle = is_string($config['subtitle']) ? $config['subtitle'] : self::DEFAULT_SUBTITLE;
        $placeholder = is_string($config['placeholder']) && $config['placeholder'] !== ''
            ? $config['placeholder']
            : self::DEFAULT_PLACEHOLDER;

        ob_start();
        ?>
        <div
            <?php if ($rootId !== '') : ?>
                id="<?php echo esc_attr($rootId); ?>"
            <?php endif; ?>
            class="<?php echo esc_attr(implode(' ', array_unique($rootClasses))); ?>"
            data-tchat-root="1"
            data-thecore-tchat-module="1"
            data-thecore-editor-preview="<?php echo $editorPreview ? '1' : '0'; ?>"
        >
            <?php echo $triggerMarkup; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
            <div class="thecore-tchat-module__backdrop" data-thecore-tchat-close="1" aria-hidden="<?php echo $forceOpen ? 'false' : 'true'; ?>"></div>
            <div
                id="thecore-tchat-dialog"
                class="thecore-tchat-module__dialog"
                role="dialog"
                aria-modal="false"
                aria-hidden="<?php echo $forceOpen ? 'false' : 'true'; ?>"
                aria-labelledby="thecore-tchat-title"
            >
                <header class="thecore-tchat-module__header">
                    <div class="thecore-tchat-module__header-copy">
                        <p id="thecore-tchat-title" class="thecore-tchat-module__title"><?php echo esc_html($title); ?></p>
                        <?php if ($subtitle !== '') : ?>
                            <p class="thecore-tchat-module__subtitle"><?php echo esc_html($subtitle); ?></p>
                        <?php endif; ?>
                    </div>
                    <button
                        type="button"
                        class="thecore-tchat-module__close"
                        data-thecore-tchat-close="1"
                        aria-label="<?php echo esc_attr__('Close chat', 'thecore-elementor-widgets'); ?>"
                    >
                        <?php echo self::getCloseIconSvg(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                    </button>
                </header>
                <section class="thecore-tchat-module__log" aria-live="polite"></section>
                <footer class="thecore-tchat-module__footer">
                    <input
                        class="thecore-tchat-module__input"
                        placeholder="<?php echo esc_attr($placeholder); ?>"
                        autocomplete="off"
                    />
                </footer>
            </div>
        </div>
        <?php

        return (string) ob_get_clean();
    }

    private static function renderDefaultTriggerMarkup(): string
    {
        return sprintf(
            '<div class="elementor-button-wrapper thecore-tchat-trigger__wrapper thecore-tchat-module__trigger-wrap"><a class="elementor-button-link elementor-button elementor-size-sm thecore-tchat-trigger" href="#thecore-tchat-open" role="button" aria-controls="thecore-tchat-dialog" aria-expanded="false" aria-label="%1$s" data-thecore-tchat-trigger="open"><span class="elementor-button-content-wrapper"><span class="elementor-button-icon" aria-hidden="true">%2$s</span><span class="elementor-button-text">%3$s</span></span></a></div>',
            esc_attr__('Open chat', 'thecore-elementor-widgets'),
            self::getDefaultTriggerIconSvg(),
            esc_html(self::DEFAULT_TRIGGER_LABEL)
        );
    }

    private static function getDefaultTriggerIconSvg(): string
    {
        return '<svg viewBox="0 0 24 24" focusable="false" xmlns="http://www.w3.org/2000/svg"><path d="M6 4.75C4.48122 4.75 3.25 5.98122 3.25 7.5V13C3.25 14.5188 4.48122 15.75 6 15.75H7.77028C8.07431 15.75 8.36646 15.8663 8.58731 16.0751L11.7424 19.0587C12.2265 19.5163 13.0312 19.1732 13.0312 18.507V16.5C13.0312 16.0858 13.367 15.75 13.7812 15.75H18C19.5188 15.75 20.75 14.5188 20.75 13V7.5C20.75 5.98122 19.5188 4.75 18 4.75H6ZM4.75 7.5C4.75 6.80964 5.30964 6.25 6 6.25H18C18.6904 6.25 19.25 6.80964 19.25 7.5V13C19.25 13.6904 18.6904 14.25 18 14.25H13.7812C12.5386 14.25 11.5312 15.2574 11.5312 16.5V16.7686L9.61747 14.9593C9.11967 14.4888 8.46146 14.25 7.77028 14.25H6C5.30964 14.25 4.75 13.6904 4.75 13V7.5Z" fill="currentColor"/></svg>';
    }

    private static function getCloseIconSvg(): string
    {
        return '<svg viewBox="0 0 24 24" focusable="false" xmlns="http://www.w3.org/2000/svg"><path d="M6.53 5.47a.75.75 0 0 0-1.06 1.06L10.94 12l-5.47 5.47a.75.75 0 1 0 1.06 1.06L12 13.06l5.47 5.47a.75.75 0 0 0 1.06-1.06L13.06 12l5.47-5.47a.75.75 0 0 0-1.06-1.06L12 10.94 6.53 5.47Z" fill="currentColor"/></svg>';
    }

    public function registerRoutes(): void
    {
        ConversationController::register();
        PersistController::register();
        AdminController::register();
        MessageController::register();
    }

    public function ajaxPoll(): void
    {
        check_ajax_referer('tchat_nonce', 'nonce');

        global $wpdb;

        $conversation_id = isset($_POST['conversation_id']) ? (int) $_POST['conversation_id'] : 0;
        $visitor_uuid = isset($_POST['visitor_uuid']) ? sanitize_text_field(wp_unslash((string) $_POST['visitor_uuid'])) : '';
        if (! $conversation_id) {
            wp_send_json_error('conversation_id missing', 400);
        }

        if ($visitor_uuid === '' || ! PersistController::visitorOwnsConversation($visitor_uuid, $conversation_id)) {
            wp_send_json_error('invalid conversation', 403);
        }

        if (isset($_POST['write']) && $_POST['write'] === '1') {
            $content = wp_kses_post(wp_unslash((string) ($_POST['content'] ?? '')));
            $created_at = current_time('mysql', true);

            $wpdb->insert(
                $wpdb->prefix . 'tchat_messages',
                [
                    'conversation_id' => $conversation_id,
                    'sender_type' => 'visitor',
                    'sender_id' => null,
                    'visitor_uuid' => $visitor_uuid,
                    'content' => $content,
                    'created_at' => $created_at,
                ],
                ['%d', '%s', '%d', '%s', '%s', '%s']
            );

            $wpdb->query(
                $wpdb->prepare(
                    "UPDATE {$wpdb->prefix}tchat_conversations
                     SET unread_count = unread_count + 1,
                         updated_at = %s
                     WHERE id = %d",
                    $created_at,
                    $conversation_id
                )
            );

            wp_send_json_success();
        }

        $since = sanitize_text_field((string) ($_POST['since'] ?? '1970-01-01 00:00:00'));

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, sender_type, sender_id, visitor_uuid, content, created_at
                 FROM {$wpdb->prefix}tchat_messages
                 WHERE conversation_id = %d AND created_at > %s
                 ORDER BY created_at ASC",
                $conversation_id,
                $since
            ),
            ARRAY_A
        );

        wp_send_json_success($rows);
    }
}
