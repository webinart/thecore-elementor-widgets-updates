<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms;

use TheCore\ElementorWidgets\FormSecurity\Support\ContextToken;
use TheCore\ElementorWidgets\Forms\Actions\ActionPipeline;
use TheCore\ElementorWidgets\Forms\Submissions\SubmissionArchive;
use Throwable;

final class SubmissionService
{
    private readonly ActionPipeline $actions;

    public function __construct(
        private readonly FormProvider $forms,
        private readonly SubmissionProtection $security,
        private readonly FleetMonitor $fleet,
        private readonly ContextToken $tokens,
        ?ActionPipeline $actions = null,
        private readonly ?SubmissionArchive $archive = null,
        private readonly ?BlockedSubmissionMonitor $blocked = null
    ) {
        $this->actions = $actions ?? new ActionPipeline();
    }

    public function submit(array $request): array
    {
        if (array_diff(array_keys($request), ['context', 'fields', 'proof', 'website', 'test_token'])) {
            throw new SubmissionException('invalid_request', 'Parametres inconnus.');
        }
        $context = is_string($request['context'] ?? null) ? $this->tokens->decode($request['context']) : null;
        if (! $context || $context->fieldId() !== FormDefinition::SECURITY_FIELD) {
            throw new SubmissionException('invalid_context', 'Formulaire invalide.');
        }
        $definition = $this->forms->find($context->postId(), $context->widgetId());
        $claims = null;
        // A requested test must never fall back to a real submission.
        if (array_key_exists('test_token', $request)) {
            if (! $definition->settings['allow-tests'] || ! is_string($request['test_token']) || $request['test_token'] === '') {
                throw new SubmissionException('test_forbidden', 'Les tests sont desactives ou le jeton est invalide.', 403);
            }
            $claims = $this->fleet->authorize($request['test_token'], $context->postId(), $context->widgetId());
        }
        try {
            $this->security->check($context, $request);
            $fields = $request['fields'] ?? null;
            if (! is_array($fields) || count($fields) > FormDefinition::MAX_FIELDS) {
                throw new SubmissionException('invalid_fields', 'Champs invalides.');
            }
            $validation = (new FieldValidator())->validate($definition, $fields);
            if ($validation['errors'] !== []) {
                throw new SubmissionException('validation_failed', 'Veuillez corriger les champs indiques.', 422, $validation['errors']);
            }
            $prepared = $this->actions->prepare($definition, $validation['values']);
            $archivePrepared = null;
            if (($definition->settings['store-submissions'] ?? false) === true) {
                if ($this->archive === null) {
                    throw new SubmissionException('storage_unavailable', 'La conservation des demandes est momentanement indisponible.', 503);
                }
                $archivePrepared = $this->archive->prepare($context, $definition, $validation['values']);
            }
            $this->security->reserve($context, $validation['values'], $claims['runId'] ?? null);
            if ($claims !== null) {
                $skipped = array_keys(array_filter($prepared, static fn(array $action): bool => ($action['skip'] ?? false) === true));
                $validated = array_values(array_diff(array_keys($prepared), $skipped));
                $this->report($claims, 'submission_succeeded', ['formIdentifier' => $context->widgetId(), 'postId' => $context->postId(),
                    'actionsValidated' => $validated, 'actionsSkipped' => $skipped, 'actionsExecuted' => false,
                    'storageValidated' => $archivePrepared !== null, 'storageWritten' => false]);
                return ['success' => true, 'mode' => 'dry-run', 'runId' => $claims['runId'],
                    'mailSent' => false, 'deliveryTested' => false,
                    'storageValidated' => $archivePrepared !== null, 'storageWritten' => false,
                    'actionsValidated' => $validated, 'actionsSkipped' => $skipped, 'actionsExecuted' => false,
                    'message' => 'Test reussi : validation effectuee, aucune action executee.'];
            }
            $archiveId = $archivePrepared !== null ? $this->persistArchive($archivePrepared) : null;
            $outcomes = [];
            try {
                $this->actions->execute($prepared, $outcomes);
            } catch (Throwable $error) {
                if ($archiveId !== null) {
                    try {
                        $this->archive->recordOutcome($archiveId, $outcomes);
                    } catch (Throwable) {
                        // Preserve the original action failure, especially after a partial delivery.
                    }
                }
                throw $error;
            }
            if ($archiveId !== null) {
                try {
                    $this->archive->recordOutcome($archiveId, $outcomes);
                } catch (Throwable) {
                    throw new SubmissionException('storage_unavailable', 'Le suivi de votre demande est indisponible. Contactez-nous pour confirmation.', 503);
                }
            }
            return ['success' => true, 'mode' => 'live', 'message' => $definition->settings['success-message']];
        } catch (Throwable $error) {
            if ($claims !== null) {
                $this->report($claims, 'validation_failed', [
                    'formIdentifier' => $context->widgetId(),
                    'errorCode' => $error instanceof SubmissionException ? $error->errorCode : 'configuration_error',
                    'fieldIds' => $error instanceof SubmissionException ? array_keys($error->fields) : [],
                ]);
            } elseif (
                ! array_key_exists('test_token', $request) && ($definition->settings['log-blocked-submissions'] ?? false) === true
                && $error instanceof SubmissionException && $this->blocked !== null
            ) {
                try {
                    $this->blocked->log($context, $definition, is_array($request['fields'] ?? null) ? $request['fields'] : [], $error);
                } catch (Throwable) {
                    // An optional blocked-submission journal must never change the public result.
                }
            }
            throw $error;
        }
    }

    private function persistArchive(array $prepared): int
    {
        try {
            $id = $this->archive->persist($prepared);
            if ($id > 0) {
                return $id;
            }
        } catch (Throwable) {
            // No delivery is attempted when the explicitly requested archive is unavailable.
        }
        throw new SubmissionException('storage_unavailable', 'La demande n\'a pas pu etre enregistree. Veuillez reessayer plus tard.', 503);
    }

    private function report(array $claims, string $event, array $details): void
    {
        try {
            $this->fleet->report($claims, $event, $details);
        } catch (Throwable) {
            // Monitoring delivery must not change the submission result.
        }
    }
}
