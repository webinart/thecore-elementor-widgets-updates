<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Actions;

use TheCore\ElementorWidgets\Forms\ConfigurationException;
use TheCore\ElementorWidgets\Forms\FormDefinition;
use TheCore\ElementorWidgets\Forms\MailPoet\MailPoetClient;
use Throwable;

final class ActionPipeline
{
    /** @var array<string, SubmissionAction> */
    private array $actions = [];

    public function __construct(?array $actions = null)
    {
        // Subscribe first: a newsletter failure must not send a contact notification.
        foreach ($actions ?? [new MailPoetAction(new MailPoetClient()), new EmailAction(), new AutoresponderAction()] as $action) {
            $this->actions[$action->name()] = $action;
        }
    }

    public function prepare(FormDefinition $form, array $values): array
    {
        $selected = $form->settings['actions-after-submit'] ?? ['email'];
        if ($selected === [] || array_diff($selected, array_keys($this->actions))) {
            throw new ConfigurationException('Unknown or missing submission action.');
        }
        $prepared = [];
        foreach ($this->actions as $name => $action) {
            if (in_array($name, $selected, true)) {
                $prepared[$name] = $action->prepare($form, $values);
            }
        }
        return $prepared;
    }

    public function execute(array $prepared, ?array &$outcomes = null): void
    {
        // All actions have been validated before any side effect is allowed.
        $outcomes = array_fill_keys(array_keys($prepared), 'not_attempted');
        foreach ($prepared as $name => $data) {
            if (($data['skip'] ?? false) === true) {
                $outcomes[$name] = 'skipped';
                continue;
            }
            try {
                $this->actions[$name]->execute($data);
                $outcomes[$name] = 'succeeded';
            } catch (Throwable $error) {
                $outcomes[$name] = 'failed';
                throw $error;
            }
        }
    }
}
