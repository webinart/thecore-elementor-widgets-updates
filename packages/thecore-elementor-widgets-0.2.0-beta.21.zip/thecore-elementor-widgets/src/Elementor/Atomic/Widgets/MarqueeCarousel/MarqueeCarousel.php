<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\MarqueeCarousel;

use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Number_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Select_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Switch_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Text_Control;
use Elementor\Modules\AtomicWidgets\DynamicTags\Dynamic_Prop_Type;
use Elementor\Modules\AtomicWidgets\Elements\Base\Atomic_Widget_Base;
use Elementor\Modules\AtomicWidgets\Elements\Base\Has_Template;
use Elementor\Modules\AtomicWidgets\PropTypes\Attributes_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Classes_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Color_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Dimensions_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Boolean_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Number_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\Components\PropTypes\Overridable_Prop_Type;
use TheCore\ElementorWidgets\Assets\FrontendAssets;
use TheCore\ElementorWidgets\Elementor\Atomic\Controls\Types\ColorControl;
use TheCore\ElementorWidgets\Elementor\Atomic\Controls\Types\MarqueeItemsControl;
use TheCore\ElementorWidgets\Elementor\Atomic\PropTypes\MarqueeItemsPropType;

final class MarqueeCarousel extends Atomic_Widget_Base
{
    use Has_Template;

    public static $widget_description = 'Infinite marquee carousel ported from the legacy widget, with per-item sizing, optional links, and lazy loading.';

    public static function get_element_type(): string
    {
        return 'thecore-marquee-carousel';
    }

    public function get_title(): string
    {
        return esc_html__('Marquee Carousel', 'thecore-elementor-widgets');
    }

    public function get_icon(): string
    {
        return 'eicon-slider-push';
    }

    public function get_keywords(): array
    {
        return ['marquee', 'carousel', 'logos', 'ticker', 'slider', 'atomic'];
    }

    public function get_style_depends(): array
    {
        return $this->isElementorEditingContext() ? [FrontendAssets::MARQUEE_CAROUSEL_STYLE] : [];
    }

    public function get_script_depends(): array
    {
        return $this->isElementorEditingContext() ? [FrontendAssets::MARQUEE_CAROUSEL_SCRIPT] : [];
    }

    protected static function define_props_schema(): array
    {
        return [
            'classes' => Classes_Prop_Type::make()->default([]),
            'items' => MarqueeItemsPropType::make()
                ->default([])
                ->meta(Dynamic_Prop_Type::ignore())
                ->meta(Overridable_Prop_Type::ignore()),
            'marquee_speed' => Number_Prop_Type::make()->default(DisplaySettings::DEFAULT_MARQUEE_SPEED),
            'image_height' => Number_Prop_Type::make()->default(DisplaySettings::DEFAULT_IMAGE_HEIGHT),
            'image_opacity' => Number_Prop_Type::make()->default(DisplaySettings::DEFAULT_IMAGE_OPACITY),
            'image_gap' => Number_Prop_Type::make()->default(DisplaySettings::DEFAULT_IMAGE_GAP),
            'background_color' => Color_Prop_Type::make()->default(DisplaySettings::DEFAULT_BACKGROUND_COLOR),
            'lazy_load' => Boolean_Prop_Type::make()->default(DisplaySettings::DEFAULT_LAZY_LOAD),
            'lazy_method' => String_Prop_Type::make()
                ->enum(['scroll', 'delay'])
                ->default(DisplaySettings::DEFAULT_LAZY_METHOD)
                ->meta(Dynamic_Prop_Type::ignore())
                ->meta(Overridable_Prop_Type::ignore()),
            'lazy_delay' => Number_Prop_Type::make()->default(DisplaySettings::DEFAULT_LAZY_DELAY),
            'attributes' => Attributes_Prop_Type::make()->meta(Overridable_Prop_Type::ignore()),
        ];
    }

    protected function define_base_styles(): array
    {
        $zeroSize = \Elementor\Modules\AtomicWidgets\PropTypes\Size_Prop_Type::generate([
            'size' => 0,
            'unit' => 'px',
        ]);

        $spacingValue = Dimensions_Prop_Type::generate([
            'block-start' => $zeroSize,
            'inline-end' => $zeroSize,
            'block-end' => $zeroSize,
            'inline-start' => $zeroSize,
        ]);

        return [
            'base' => \Elementor\Modules\AtomicWidgets\Styles\Style_Definition::make()
                ->add_variant(
                    \Elementor\Modules\AtomicWidgets\Styles\Style_Variant::make()
                        ->add_prop('padding', $spacingValue)
                        ->add_prop('margin', $spacingValue)
                ),
        ];
    }

    protected function define_atomic_controls(): array
    {
        return [
            Section::make()
                ->set_label(__('Items', 'thecore-elementor-widgets'))
                ->set_items([
                    MarqueeItemsControl::bind_to('items')
                        ->set_label(__('Images', 'thecore-elementor-widgets'))
                        ->set_description(__('Add the images, optional links, and per-item spacing used in the marquee.', 'thecore-elementor-widgets')),
                ]),
            Section::make()
                ->set_label(__('Carousel', 'thecore-elementor-widgets'))
                ->set_items([
                    Number_Control::bind_to('marquee_speed')
                        ->set_label(__('Scroll speed (seconds)', 'thecore-elementor-widgets'))
                        ->set_min(5)
                        ->set_max(60)
                        ->set_step(1)
                        ->set_should_force_int(true),
                    Number_Control::bind_to('image_height')
                        ->set_label(__('Image height (px)', 'thecore-elementor-widgets'))
                        ->set_min(24)
                        ->set_max(180)
                        ->set_step(1)
                        ->set_should_force_int(true),
                    Number_Control::bind_to('image_opacity')
                        ->set_label(__('Image opacity (%)', 'thecore-elementor-widgets'))
                        ->set_min(0)
                        ->set_max(100)
                        ->set_step(1)
                        ->set_should_force_int(true),
                    Number_Control::bind_to('image_gap')
                        ->set_label(__('Gap (px)', 'thecore-elementor-widgets'))
                        ->set_min(0)
                        ->set_max(100)
                        ->set_step(1)
                        ->set_should_force_int(true),
                    ColorControl::bind_to('background_color')
                        ->set_label(__('Background color', 'thecore-elementor-widgets')),
                ]),
            Section::make()
                ->set_label(__('Lazy Loading', 'thecore-elementor-widgets'))
                ->set_items([
                    Switch_Control::bind_to('lazy_load')
                        ->set_label(__('Enable lazy loading', 'thecore-elementor-widgets')),
                    Select_Control::bind_to('lazy_method')
                        ->set_label(__('Loading method', 'thecore-elementor-widgets'))
                        ->set_options([
                            [
                                'label' => __('On scroll (Intersection Observer)', 'thecore-elementor-widgets'),
                                'value' => 'scroll',
                            ],
                            [
                                'label' => __('After delay', 'thecore-elementor-widgets'),
                                'value' => 'delay',
                            ],
                        ]),
                    Number_Control::bind_to('lazy_delay')
                        ->set_label(__('Delay (ms)', 'thecore-elementor-widgets'))
                        ->set_min(100)
                        ->set_max(5000)
                        ->set_step(100)
                        ->set_should_force_int(true),
                ]),
            Section::make()
                ->set_label(__('Settings', 'thecore-elementor-widgets'))
                ->set_id('settings')
                ->set_items([
                    Text_Control::bind_to('_cssid')
                        ->set_label(__('ID', 'thecore-elementor-widgets'))
                        ->set_meta($this->get_css_id_control_meta()),
                ]),
        ];
    }

    protected function get_templates(): array
    {
        return [
            'thecore/elements/marquee-carousel' => __DIR__ . '/marquee-carousel.html.twig',
        ];
    }

    protected function render()
    {
        $atomicSettings = $this->get_atomic_settings();
        $settings = (new DisplaySettings())->normalize($atomicSettings);
        $markup = (new MarkupBuilder())->build(
            $settings['items'],
            $this->get_id(),
            $settings['lazy_load'],
            $settings['lazy_method'],
            $settings['lazy_delay']
        );

        if ('' === $markup) {
            return;
        }

        $cssId = trim((string) $this->get_atomic_setting('_cssid'));
        $scope = $this->buildScopeValue();
        $scopeSelector = '[data-thecore-marquee-carousel-scope="' . $scope . '"]';
        $styleMarkup = (new InlineStylesBuilder())->build($scopeSelector, $settings);
        $classes = array_filter(array_merge(
            ['thecore-marquee-carousel', $this->get_base_styles_dictionary()['base'] ?? ''],
            is_array($atomicSettings['classes'] ?? null) ? $atomicSettings['classes'] : []
        ));

        $attributes = [
            'class' => implode(' ', array_unique($classes)),
            'data-thecore-marquee-carousel' => 'true',
            'data-thecore-marquee-carousel-scope' => $scope,
        ];

        if ('' !== $cssId) {
            $attributes['id'] = $cssId;
        }

        if (! $this->isElementorEditingContext()) {
            echo FrontendAssets::prepareWidgetAssets('marquee-carousel'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }

        echo '<style>' . $styleMarkup . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo '<div' . $this->buildAttributes($attributes) . '>';
        echo $markup; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo '</div>';
    }

    private function isElementorEditingContext(): bool
    {
        if (! class_exists('\Elementor\Plugin')) {
            return false;
        }

        return \Elementor\Plugin::$instance->editor->is_edit_mode()
            || \Elementor\Plugin::$instance->preview->is_preview_mode();
    }

    private function buildScopeValue(): string
    {
        return 'thecore-marquee-' . sanitize_html_class($this->get_id());
    }

    /**
     * @param array<string, string> $attributes
     */
    private function buildAttributes(array $attributes): string
    {
        $markup = '';

        foreach ($attributes as $name => $value) {
            $markup .= sprintf(
                ' %s="%s"',
                esc_attr($name),
                esc_attr($value)
            );
        }

        return $markup;
    }
}
