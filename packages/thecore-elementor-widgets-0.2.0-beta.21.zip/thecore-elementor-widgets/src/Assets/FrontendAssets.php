<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Assets;

use TheCore\ElementorWidgets\Contracts\Bootable;
use TheCore\ElementorWidgets\Options\OptionsRepository;
use TheCore\ElementorWidgets\Registry\FeaturesRegistry;

final class FrontendAssets implements Bootable
{
    public const FULLSCREEN_MENU_SCRIPT = 'thecore-fullscreen-menu';
    public const FULLSCREEN_MENU_STYLE = 'thecore-fullscreen-menu';
    public const MARQUEE_CAROUSEL_SCRIPT = 'thecore-marquee-carousel';
    public const MARQUEE_CAROUSEL_STYLE = 'thecore-marquee-carousel';
    public const MARQUEE_BANNER_LEGACY_SCRIPT = 'thecore-marquee-banner-legacy';
    public const MARQUEE_BANNER_LEGACY_STYLE = 'thecore-marquee-banner-legacy';

    private static ?self $instance = null;

    /**
     * @var array<string, array<string, string>>
     */
    private static array $renderedStyles = [];

    /**
     * @var array<string, array<string, string>>
     */
    private static array $queuedImmediateScripts = [];

    private static bool $requiresFullscreenConfig = false;
    private bool $stylesRegistered = false;
    private bool $scriptsRegistered = false;

    public function __construct(
        private readonly OptionsRepository $optionsRepository,
        private readonly FeaturesRegistry $featuresRegistry
    ) {
        self::$instance = $this;
    }

    public function register(): void
    {
        add_action('wp_enqueue_scripts', [$this, 'registerStyles']);
        add_action('wp_enqueue_scripts', [$this, 'registerScripts']);
        add_action('elementor/editor/before_enqueue_styles', [$this, 'registerStyles']);
        add_action('elementor/editor/before_enqueue_scripts', [$this, 'registerScripts']);
        add_action('elementor/atomic-widgets/frontend/loader/scripts/register', [$this, 'registerScripts']);
        add_action('wp_footer', [$this, 'renderFooterAssets'], 100);
    }

    public function registerStyles(): void
    {
        if ($this->stylesRegistered) {
            return;
        }

        wp_register_style(
            self::FULLSCREEN_MENU_STYLE,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/fullscreen-menu.css',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION
        );

        wp_register_style(
            self::MARQUEE_CAROUSEL_STYLE,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/marquee-carousel.css',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION
        );

        wp_register_style(
            self::MARQUEE_BANNER_LEGACY_STYLE,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/marquee-banner-legacy.css',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION
        );

        $this->stylesRegistered = true;
    }

    public function registerScripts(mixed $loader = null): void
    {
        if ($this->scriptsRegistered) {
            return;
        }

        $fullscreenMenuConfig = $this->buildFullscreenMenuConfigScript();

        wp_register_script(
            self::FULLSCREEN_MENU_SCRIPT,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/fullscreen-menu.js',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION,
            true
        );

        wp_add_inline_script(
            self::FULLSCREEN_MENU_SCRIPT,
            $fullscreenMenuConfig,
            'before'
        );

        wp_register_script(
            self::MARQUEE_CAROUSEL_SCRIPT,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/marquee-carousel.js',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION,
            true
        );

        wp_register_script(
            self::MARQUEE_BANNER_LEGACY_SCRIPT,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/marquee-banner-legacy.js',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION,
            true
        );

        $this->scriptsRegistered = true;
    }

    public static function prepareWidgetAssets(
        string $widgetKey,
        bool $inlineCss = false,
        bool $inlineJs = false
    ): string {
        if (! self::$instance instanceof self) {
            return '';
        }

        return self::$instance->prepareWidgetAssetsInstance(
            $widgetKey,
            $inlineCss,
            $inlineJs
        );
    }

    public function renderFooterAssets(): void
    {
        if ([] === self::$queuedImmediateScripts) {
            return;
        }

        if (self::$requiresFullscreenConfig) {
            echo '<script id="thecore-elementor-widgets-config">' . $this->buildFullscreenMenuConfigScript() . '</script>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }

        foreach (self::$queuedImmediateScripts as $descriptor) {
            echo $this->renderScriptTag($descriptor); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }
    }

    private function prepareWidgetAssetsInstance(
        string $widgetKey,
        bool $inlineCss,
        bool $inlineJs
    ): string {
        $cssDescriptor = $this->buildDescriptor($widgetKey, 'css', $inlineCss);
        $jsDescriptor = $this->buildDescriptor($widgetKey, 'js', $inlineJs);

        if ('fullscreen-menu' === $widgetKey) {
            self::$requiresFullscreenConfig = true;
        }

        self::$queuedImmediateScripts[$jsDescriptor['load_key']] = $jsDescriptor;

        return $this->renderStyleTag($cssDescriptor);
    }

    /**
     * @param array<string, string> $descriptor
     */
    private function renderStyleTag(array $descriptor): string
    {
        if (isset(self::$renderedStyles[$descriptor['load_key']])) {
            return '';
        }

        self::$renderedStyles[$descriptor['load_key']] = $descriptor;

        if ('inline' === $descriptor['mode']) {
            if (empty($descriptor['content'])) {
                return '';
            }

            return sprintf(
                "<style id='%s'>\n%s\n</style>\n",
                esc_attr($descriptor['domId']),
                $descriptor['content']
            );
        }

        return sprintf(
            "<link rel='stylesheet' id='%s' href='%s' media='all' />\n",
            esc_attr($descriptor['domId']),
            esc_url($descriptor['url'])
        );
    }

    /**
     * @param array<string, string> $descriptor
     */
    private function renderScriptTag(array $descriptor): string
    {
        if ('inline' === $descriptor['mode']) {
            if (empty($descriptor['content'])) {
                return '';
            }

            return sprintf(
                "<script id='%s'>\n%s\n</script>\n",
                esc_attr($descriptor['domId']),
                $descriptor['content']
            );
        }

        return sprintf(
            "<script id='%s' src='%s'></script>\n",
            esc_attr($descriptor['domId']),
            esc_url($descriptor['url'])
        );
    }

    /**
     * @param array<string, string> $descriptor
     *
     * @return array<string, string>
     */
    private function buildDescriptor(string $widgetKey, string $type, bool $inline): array
    {
        $definitions = $this->assetDefinitions();
        $definition = $definitions[$widgetKey][$type];
        $handle = $definition['handle'];

        $descriptor = [
            'handle' => $handle,
            'load_key' => $type . ':' . $handle,
            'domId' => $handle . '-' . $type,
            'mode' => $inline ? 'inline' : 'external',
        ];

        if ($inline) {
            $descriptor['content'] = self::getStaticAssetContents($definition['path']);

            return $descriptor;
        }

        $descriptor['url'] = THECORE_ELEMENTOR_WIDGETS_URL
            . $definition['path']
            . '?ver='
            . rawurlencode((string) THECORE_ELEMENTOR_WIDGETS_VERSION);

        return $descriptor;
    }

    /**
     * @return array<string, array<string, array{handle: string, path: string}>>
     */
    private function assetDefinitions(): array
    {
        return [
            'fullscreen-menu' => [
                'css' => [
                    'handle' => self::FULLSCREEN_MENU_STYLE,
                    'path' => 'assets/frontend/fullscreen-menu.css',
                ],
                'js' => [
                    'handle' => self::FULLSCREEN_MENU_SCRIPT,
                    'path' => 'assets/frontend/fullscreen-menu.js',
                ],
            ],
            'marquee-carousel' => [
                'css' => [
                    'handle' => self::MARQUEE_CAROUSEL_STYLE,
                    'path' => 'assets/frontend/marquee-carousel.css',
                ],
                'js' => [
                    'handle' => self::MARQUEE_CAROUSEL_SCRIPT,
                    'path' => 'assets/frontend/marquee-carousel.js',
                ],
            ],
            'marquee-banner-legacy' => [
                'css' => [
                    'handle' => self::MARQUEE_BANNER_LEGACY_STYLE,
                    'path' => 'assets/frontend/marquee-banner-legacy.css',
                ],
                'js' => [
                    'handle' => self::MARQUEE_BANNER_LEGACY_SCRIPT,
                    'path' => 'assets/frontend/marquee-banner-legacy.js',
                ],
            ],
        ];
    }

    private function buildFullscreenMenuConfigScript(): string
    {
        $featureState = $this->optionsRepository->getFeaturesState($this->featuresRegistry->defaults());

        return 'window.TheCoreElementorWidgetsConfig = ' . wp_json_encode(
            [
                'features' => [
                    'overlayScrollLock' => ! empty($featureState['overlay-scroll-lock']),
                ],
                'bodyLockClass' => 'thecore-elementor-widgets-lock-scroll',
            ]
        ) . ';';
    }

    private static function getStaticAssetContents(string $relativePath): string
    {
        $path = THECORE_ELEMENTOR_WIDGETS_PATH . ltrim($relativePath, '/');

        if (! is_readable($path)) {
            return '';
        }

        $contents = file_get_contents($path);

        if (false === $contents) {
            return '';
        }

        return trim($contents);
    }
}
