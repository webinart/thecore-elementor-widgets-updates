<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Registry;

final class WidgetsRegistry
{
    /**
     * @return array<string, array{title: string, description: string, enabled_by_default: bool}>
     */
    private function definitions(): array
    {
        return [
            'classic-menu' => [
                'title' => __('Fullscreen Menu', 'thecore-elementor-widgets'),
                'description' => __(
                    'Portage V4 du fullscreen menu legacy avec rendu inline sur desktop, overlay mobile et lecture des items de premier niveau d’un menu WordPress.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => true,
            ],
            'marquee-carousel' => [
                'title' => __('Marquee Carousel', 'thecore-elementor-widgets'),
                'description' => __(
                    'Portage V4 du marquee banner legacy avec défilement infini, items dupliqués pour la boucle continue, réglages par image et lazy loading.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => true,
            ],
            'marquee-banner-legacy' => [
                'title' => __('Marquee Banner (Legacy)', 'thecore-elementor-widgets'),
                'description' => __(
                    'Version Elementor classique du marquee banner historique, avec repeater natif complet pour réordonner et éditer les items plus confortablement.',
                    'thecore-elementor-widgets'
                ),
                'enabled_by_default' => true,
            ],
        ];
    }

    /**
     * @return array<string, RegistryItem>
     */
    public function all(): array
    {
        $items = [];

        foreach ($this->definitions() as $id => $definition) {
            $item = new RegistryItem(
                $id,
                $definition['title'],
                $definition['description'],
                $definition['enabled_by_default']
            );

            $items[$item->id()] = $item;
        }

        return $items;
    }

    /**
     * @return array<string, int>
     */
    public function defaults(): array
    {
        return [
            'classic-menu' => 1,
            'marquee-carousel' => 1,
            'marquee-banner-legacy' => 1,
        ];
    }
}
