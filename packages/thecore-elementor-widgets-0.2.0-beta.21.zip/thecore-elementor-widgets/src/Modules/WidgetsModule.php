<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Modules;

use TheCore\ElementorWidgets\Contracts\Bootable;
use TheCore\ElementorWidgets\Elementor\Atomic\Widgets\FullscreenMenu\FullscreenMenu;
use TheCore\ElementorWidgets\Elementor\Atomic\Widgets\MarqueeCarousel\MarqueeCarousel;
use TheCore\ElementorWidgets\Elementor\Legacy\Widgets\MarqueeBanner\MarqueeBanner;
use TheCore\ElementorWidgets\Options\OptionsRepository;
use TheCore\ElementorWidgets\Registry\WidgetsRegistry;
use TheCore\ElementorWidgets\Support\RequirementsChecker;

final class WidgetsModule implements Bootable
{
    public function __construct(
        private readonly WidgetsRegistry $widgetsRegistry,
        private readonly OptionsRepository $optionsRepository,
        private readonly RequirementsChecker $requirementsChecker
    ) {
    }

    public function register(): void
    {
        add_action('elementor/widgets/register', [$this, 'registerWidgets']);
    }

    public function registerWidgets(object $widgetsManager): void
    {
        if (! $this->requirementsChecker->canRegisterClassicWidgets()) {
            return;
        }

        $state = $this->optionsRepository->getWidgetsState($this->widgetsRegistry->defaults());

        if (method_exists($widgetsManager, 'register')) {
            if (! empty($state['classic-menu']) && $this->requirementsChecker->canRegisterAtomicWidgets()) {
                $widgetsManager->register(new FullscreenMenu());
            }

            if (! empty($state['marquee-carousel']) && $this->requirementsChecker->canRegisterAtomicWidgets()) {
                $widgetsManager->register(new MarqueeCarousel());
            }

            if (! empty($state['marquee-banner-legacy'])) {
                $widgetsManager->register(new MarqueeBanner());
            }
        }
    }
}
