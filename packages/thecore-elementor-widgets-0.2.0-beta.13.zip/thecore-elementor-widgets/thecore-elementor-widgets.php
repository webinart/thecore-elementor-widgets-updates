<?php
declare(strict_types=1);

/**
 * Plugin Name: The Core - Elementor Widgets
 * Plugin URI: https://thecoreelementor.webinart.fr
 * Description: Atomic Elementor widgets and shared frontend features for The Core.
 * Update URI: https://github.com/webinart/thecore-elementor-widgets
 * Version: 0.2.0-beta.13
 * Requires at least: 6.6
 * Requires PHP: 8.1
 * Author: The Core
 * Text Domain: thecore-elementor-widgets
 * Domain Path: /languages
 */

if (! defined('ABSPATH')) {
    exit;
}

define('THECORE_ELEMENTOR_WIDGETS_VERSION', '0.2.0-beta.13');
define('THECORE_ELEMENTOR_WIDGETS_FILE', __FILE__);
define('THECORE_ELEMENTOR_WIDGETS_BASENAME', plugin_basename(__FILE__));
define('THECORE_ELEMENTOR_WIDGETS_PATH', plugin_dir_path(__FILE__));
define('THECORE_ELEMENTOR_WIDGETS_URL', plugin_dir_url(__FILE__));

$vendor_autoload = THECORE_ELEMENTOR_WIDGETS_PATH . 'vendor/autoload.php';

if (file_exists($vendor_autoload)) {
    require_once $vendor_autoload;
}

require_once THECORE_ELEMENTOR_WIDGETS_PATH . 'src/Infrastructure/Autoloader.php';

(new \TheCore\ElementorWidgets\Infrastructure\Autoloader())->register();

register_activation_hook(
    THECORE_ELEMENTOR_WIDGETS_FILE,
    static function (): void {
        \TheCore\ElementorWidgets\Plugin::activate();
    }
);

add_action(
    'plugins_loaded',
    static function (): void {
        \TheCore\ElementorWidgets\Plugin::instance()->boot();
    }
);
