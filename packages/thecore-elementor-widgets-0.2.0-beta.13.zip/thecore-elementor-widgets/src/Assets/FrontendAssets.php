<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Assets;

use TheCore\ElementorWidgets\Contracts\Bootable;
use TheCore\ElementorWidgets\Options\OptionsRepository;
use TheCore\ElementorWidgets\Registry\FeaturesRegistry;

final class FrontendAssets implements Bootable
{
    public const FULLSCREEN_MENU_SCRIPT = 'thecore-fullscreen-menu';
    public const FULLSCREEN_MENU_STYLE = 'thecore-fullscreen-menu';
    public const FULLSCREEN_MENU_SCRIPT_INLINE = 'thecore-fullscreen-menu-inline';
    public const MARQUEE_CAROUSEL_SCRIPT = 'thecore-marquee-carousel';
    public const MARQUEE_CAROUSEL_STYLE = 'thecore-marquee-carousel';

    private static bool $fullscreenMenuInlineStyleRendered = false;
    private static bool $fullscreenMenuFileStyleRendered = false;
    private static bool $fullscreenMenuInlineScriptQueued = false;
    private static bool $fullscreenMenuFileScriptQueued = false;
    private bool $stylesRegistered = false;
    private bool $scriptsRegistered = false;

    public function __construct(
        private readonly OptionsRepository $optionsRepository,
        private readonly FeaturesRegistry $featuresRegistry
    ) {
    }

    public function register(): void
    {
        add_action('wp_enqueue_scripts', [$this, 'registerStyles']);
        add_action('wp_enqueue_scripts', [$this, 'registerScripts']);
        add_action('elementor/atomic-widgets/frontend/loader/scripts/register', [$this, 'registerScripts']);
    }

    public function registerStyles(): void
    {
        if ($this->stylesRegistered) {
            return;
        }

        wp_register_style(
            self::FULLSCREEN_MENU_STYLE,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/fullscreen-menu.css',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION
        );

        wp_register_style(
            self::MARQUEE_CAROUSEL_STYLE,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/marquee-carousel.css',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION
        );

        $this->stylesRegistered = true;
    }

    public function registerScripts(mixed $loader = null): void
    {
        if ($this->scriptsRegistered) {
            return;
        }

        $featureState = $this->optionsRepository->getFeaturesState($this->featuresRegistry->defaults());
        $fullscreenMenuConfig = $this->buildFullscreenMenuConfigScript($featureState);

        wp_register_script(
            self::FULLSCREEN_MENU_SCRIPT,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/fullscreen-menu.js',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION,
            true
        );

        wp_add_inline_script(
            self::FULLSCREEN_MENU_SCRIPT,
            $fullscreenMenuConfig,
            'before'
        );

        wp_register_script(
            self::FULLSCREEN_MENU_SCRIPT_INLINE,
            false,
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION,
            true
        );

        wp_add_inline_script(
            self::FULLSCREEN_MENU_SCRIPT_INLINE,
            $fullscreenMenuConfig,
            'before'
        );

        $fullscreenMenuScript = $this->getAssetContents('assets/frontend/fullscreen-menu.js');

        if ('' !== $fullscreenMenuScript) {
            wp_add_inline_script(self::FULLSCREEN_MENU_SCRIPT_INLINE, $fullscreenMenuScript);
        }

        wp_register_script(
            self::MARQUEE_CAROUSEL_SCRIPT,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/marquee-carousel.js',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION,
            true
        );

        $this->scriptsRegistered = true;
    }

    public static function renderFullscreenMenuStyleTag(bool $inline): string
    {
        if ($inline) {
            if (self::$fullscreenMenuInlineStyleRendered) {
                return '';
            }

            self::$fullscreenMenuInlineStyleRendered = true;
            $css = self::getStaticAssetContents('assets/frontend/fullscreen-menu.css');

            if ('' === $css) {
                return '';
            }

            return sprintf(
                "<style id='%s-inline-css'>\n%s\n</style>\n",
                esc_attr(self::FULLSCREEN_MENU_STYLE),
                $css
            );
        }

        if (self::$fullscreenMenuFileStyleRendered) {
            return '';
        }

        self::$fullscreenMenuFileStyleRendered = true;

        return sprintf(
            "<link rel='stylesheet' id='%s-css' href='%s' media='all' />\n",
            esc_attr(self::FULLSCREEN_MENU_STYLE),
            esc_url(THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/fullscreen-menu.css?ver=' . rawurlencode((string) THECORE_ELEMENTOR_WIDGETS_VERSION))
        );
    }

    public static function enqueueFullscreenMenuScript(bool $inline): void
    {
        if ($inline) {
            if (self::$fullscreenMenuInlineScriptQueued) {
                return;
            }

            self::$fullscreenMenuInlineScriptQueued = true;
            wp_enqueue_script(self::FULLSCREEN_MENU_SCRIPT_INLINE);

            return;
        }

        if (self::$fullscreenMenuFileScriptQueued) {
            return;
        }

        self::$fullscreenMenuFileScriptQueued = true;
        wp_enqueue_script(self::FULLSCREEN_MENU_SCRIPT);
    }

    /**
     * @param array<string, int> $featureState
     */
    private function buildFullscreenMenuConfigScript(array $featureState): string
    {
        return 'window.TheCoreElementorWidgetsConfig = ' . wp_json_encode(
            [
                'features' => [
                    'overlayScrollLock' => ! empty($featureState['overlay-scroll-lock']),
                ],
                'bodyLockClass' => 'thecore-elementor-widgets-lock-scroll',
            ],
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
        ) . ';';
    }

    private function getAssetContents(string $relativePath): string
    {
        return self::getStaticAssetContents($relativePath);
    }

    private static function getStaticAssetContents(string $relativePath): string
    {
        $path = THECORE_ELEMENTOR_WIDGETS_PATH . ltrim($relativePath, '/');

        if (! is_readable($path)) {
            return '';
        }

        $contents = file_get_contents($path);

        if (false === $contents) {
            return '';
        }

        return trim($contents);
    }
}
