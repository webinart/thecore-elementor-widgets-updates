# Changelog

## 0.2.0-beta.11

- Ajout d'un réglage `Overlay mount target` dans le `Fullscreen Menu`
- Support des cibles `Closest header`, `Body` et `Custom selector` pour choisir où monter l'overlay
- Propagation du sélecteur custom jusqu'au runtime frontend avec fallback silencieux sur `body`

## 0.2.0-beta.10

- Déplacement de l'overlay du `Fullscreen Menu` hors du container du widget pour éviter qu'un ancêtre transformé ne bloque son `position: fixed`
- Montage automatique de l'overlay sous le `header` ancêtre le plus proche, ou sous `body` à défaut
- Synchronisation des variables CSS du widget vers l'overlay déplacé afin de conserver les styles configurés

## 0.2.0-beta.9

- Décision du mode responsive du `Fullscreen Menu` côté serveur pour éviter le basculement de layout au premier paint
- Suppression du pilotage du layout initial par JS afin de réduire le risque de CLS, notamment en `overlay only`
- Ajout d'un switch `Inline asset injection` dans le widget pour choisir entre assets inline et fichiers externes côté frontoffice
- Alignement du preview Elementor et du rendu frontend sur les nouvelles règles de layout du menu

## 0.2.0-beta.8

- Restauration de la cible `base` du `Fullscreen Menu` pour réactiver les réglages de spacing du wrapper dans l’onglet `Style`
- Réintégration des classes Atomic du widget dans le rendu preview/front pour que les styles V4 appliqués au wrapper aient de nouveau un effet

## 0.2.0-beta.7

- Stabilisation des contrôles custom du `Fullscreen Menu` dans l’éditeur Atomic V4
- Correction de la validation des champs `letter spacing` au save
- Ajout de vrais contrôles `font-family` avec presets et valeur custom conditionnelle
- Ajout d’un sanitiseur de document Elementor pour fiabiliser les payloads du widget

## 0.2.0-beta.6

- Correction de l'application des styles de typo du `Fullscreen Menu`
- Ajout de styles de typo distincts pour les liens desktop et les liens d'overlay
- Ajout du mode `Overlay only` pour conserver le hamburger sur tous les écrans

## 0.2.0-beta.5

- Suppression de la dépendance frontend du `Fullscreen Menu` au runtime Atomic d'Elementor

## 0.2.0-beta.4

- Correction du chargement trop tôt du domaine de traduction pour éviter le notice `_load_textdomain_just_in_time`

## 0.2.0-beta.3

- Intégration du wrapper `Fullscreen Menu` en `display: flex`
- Bump de version pour publication du canal beta

## 0.2.0-beta.2

- Bump de version pour test end-to-end de la pipeline d’update GitHub

## 0.2.0-beta.1

- Ajout du `PluginUpdater` GitHub avec manifest public `beta` / `prod`
- Ajout de la workflow GitHub de publication vers `webinart/thecore-elementor-widgets-updates`
- Remplacement du widget `Classic Menu` par le port V4 du widget legacy `Fullscreen Menu`
- Nettoyage de l’ancienne implémentation multi-niveaux et de ses assets hamburger dédiés
- Ajout d’une normalisation testée des réglages d’affichage du `Fullscreen Menu`

## 0.1.0

- Initialisation du plugin `The Core - Elementor Widgets`
- Mise en place de l’admin `The Core` avec pages `Widgets` et `Features`
- Ajout du socle Atomic pour `Classic Menu`
- Mise en place de l’outillage local Composer, PHPUnit et PHPCS
- Ajout du choix d’effet d’animation du hamburger
- Ajout du breakpoint mobile configurable par widget
- Chargement conditionnel des styles d’effet du hamburger par page
