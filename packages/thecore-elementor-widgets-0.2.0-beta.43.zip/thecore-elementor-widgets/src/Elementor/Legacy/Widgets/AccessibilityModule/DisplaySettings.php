<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Legacy\Widgets\AccessibilityModule;

final class DisplaySettings
{
    public const DEFAULT_HEADER_EYEBROW = 'Accessibility';
    public const DEFAULT_HEADER_TITLE = '';
    public const DEFAULT_HEADER_SUBTITLE = '';
    public const DEFAULT_MODULE_VERTICAL_POSITION = 'bottom';
    public const DEFAULT_MODULE_HORIZONTAL_POSITION = 'right';
    public const DEFAULT_SKIP_LINK_LABEL = 'Skip to content';
    public const DEFAULT_SKIP_LINK_TARGET_SELECTOR = 'main, #content, [role="main"]';
    public const DEFAULT_SKIP_LINK_MOUNT_SELECTOR = 'body';
    public const DEFAULT_HELP_LABEL = 'Help';
    public const DEFAULT_FEEDBACK_LABEL = 'Feedback';
    public const DEFAULT_FEATURE_LABELS = [
        'feature_bigger_text_label' => 'Bigger text',
        'feature_bigger_line_height_label' => 'Bigger line height',
        'feature_text_align_label' => 'Text align',
        'feature_readable_font_label' => 'Readable font',
        'feature_grayscale_label' => 'Greyscale',
        'feature_contrast_label' => 'Contrast',
        'feature_page_structure_label' => 'Page structure',
        'feature_reading_mask_label' => 'Reading mask',
        'feature_hide_images_label' => 'Hide images',
        'feature_pause_animations_label' => 'Pause animations',
        'feature_highlight_links_label' => 'Highlight links',
        'feature_focus_outline_label' => 'Outline focus',
    ];

    /**
     * @param array<string, mixed> $settings
     *
     * @return array<string, bool|string>
     */
    public function normalize(array $settings): array
    {
        return [
            'header_eyebrow_text' => $this->sanitizeText(
                $settings['header_eyebrow_text'] ?? self::DEFAULT_HEADER_EYEBROW,
                self::DEFAULT_HEADER_EYEBROW
            ),
            'header_title_text' => $this->sanitizeOptionalText(
                $settings['header_title_text'] ?? self::DEFAULT_HEADER_TITLE
            ),
            'header_subtitle_text' => $this->sanitizeOptionalTextarea(
                $settings['header_subtitle_text'] ?? self::DEFAULT_HEADER_SUBTITLE
            ),
            'module_vertical_position' => $this->sanitizeEnum(
                $settings['module_vertical_position'] ?? self::DEFAULT_MODULE_VERTICAL_POSITION,
                ['top', 'center', 'bottom'],
                self::DEFAULT_MODULE_VERTICAL_POSITION
            ),
            'module_horizontal_position' => $this->sanitizeEnum(
                $settings['module_horizontal_position'] ?? self::DEFAULT_MODULE_HORIZONTAL_POSITION,
                ['left', 'right'],
                self::DEFAULT_MODULE_HORIZONTAL_POSITION
            ),
            'feature_bigger_text' => $this->toBool($settings['feature_bigger_text'] ?? true),
            'feature_bigger_text_label' => $this->sanitizeText(
                $settings['feature_bigger_text_label'] ?? self::DEFAULT_FEATURE_LABELS['feature_bigger_text_label'],
                self::DEFAULT_FEATURE_LABELS['feature_bigger_text_label']
            ),
            'feature_bigger_line_height' => $this->toBool($settings['feature_bigger_line_height'] ?? true),
            'feature_bigger_line_height_label' => $this->sanitizeText(
                $settings['feature_bigger_line_height_label'] ?? self::DEFAULT_FEATURE_LABELS['feature_bigger_line_height_label'],
                self::DEFAULT_FEATURE_LABELS['feature_bigger_line_height_label']
            ),
            'feature_text_align' => $this->toBool($settings['feature_text_align'] ?? true),
            'feature_text_align_label' => $this->sanitizeText(
                $settings['feature_text_align_label'] ?? self::DEFAULT_FEATURE_LABELS['feature_text_align_label'],
                self::DEFAULT_FEATURE_LABELS['feature_text_align_label']
            ),
            'feature_readable_font' => $this->toBool($settings['feature_readable_font'] ?? true),
            'feature_readable_font_label' => $this->sanitizeText(
                $settings['feature_readable_font_label'] ?? self::DEFAULT_FEATURE_LABELS['feature_readable_font_label'],
                self::DEFAULT_FEATURE_LABELS['feature_readable_font_label']
            ),
            'feature_grayscale' => $this->toBool($settings['feature_grayscale'] ?? true),
            'feature_grayscale_label' => $this->sanitizeText(
                $settings['feature_grayscale_label'] ?? self::DEFAULT_FEATURE_LABELS['feature_grayscale_label'],
                self::DEFAULT_FEATURE_LABELS['feature_grayscale_label']
            ),
            'feature_contrast' => $this->toBool($settings['feature_contrast'] ?? true),
            'feature_contrast_label' => $this->sanitizeText(
                $settings['feature_contrast_label'] ?? self::DEFAULT_FEATURE_LABELS['feature_contrast_label'],
                self::DEFAULT_FEATURE_LABELS['feature_contrast_label']
            ),
            'feature_page_structure' => $this->toBool($settings['feature_page_structure'] ?? true),
            'feature_page_structure_label' => $this->sanitizeText(
                $settings['feature_page_structure_label'] ?? self::DEFAULT_FEATURE_LABELS['feature_page_structure_label'],
                self::DEFAULT_FEATURE_LABELS['feature_page_structure_label']
            ),
            'feature_reading_mask' => $this->toBool($settings['feature_reading_mask'] ?? true),
            'feature_reading_mask_label' => $this->sanitizeText(
                $settings['feature_reading_mask_label'] ?? self::DEFAULT_FEATURE_LABELS['feature_reading_mask_label'],
                self::DEFAULT_FEATURE_LABELS['feature_reading_mask_label']
            ),
            'feature_hide_images' => $this->toBool($settings['feature_hide_images'] ?? true),
            'feature_hide_images_label' => $this->sanitizeText(
                $settings['feature_hide_images_label'] ?? self::DEFAULT_FEATURE_LABELS['feature_hide_images_label'],
                self::DEFAULT_FEATURE_LABELS['feature_hide_images_label']
            ),
            'feature_pause_animations' => $this->toBool($settings['feature_pause_animations'] ?? true),
            'feature_pause_animations_label' => $this->sanitizeText(
                $settings['feature_pause_animations_label'] ?? self::DEFAULT_FEATURE_LABELS['feature_pause_animations_label'],
                self::DEFAULT_FEATURE_LABELS['feature_pause_animations_label']
            ),
            'feature_highlight_links' => $this->toBool($settings['feature_highlight_links'] ?? true),
            'feature_highlight_links_label' => $this->sanitizeText(
                $settings['feature_highlight_links_label'] ?? self::DEFAULT_FEATURE_LABELS['feature_highlight_links_label'],
                self::DEFAULT_FEATURE_LABELS['feature_highlight_links_label']
            ),
            'feature_focus_outline' => $this->toBool($settings['feature_focus_outline'] ?? true),
            'feature_focus_outline_label' => $this->sanitizeText(
                $settings['feature_focus_outline_label'] ?? self::DEFAULT_FEATURE_LABELS['feature_focus_outline_label'],
                self::DEFAULT_FEATURE_LABELS['feature_focus_outline_label']
            ),
            'help_label' => $this->sanitizeText($settings['help_label'] ?? self::DEFAULT_HELP_LABEL, self::DEFAULT_HELP_LABEL),
            'help_url' => $this->sanitizeUrl($settings['help_url'] ?? ''),
            'feedback_label' => $this->sanitizeText(
                $settings['feedback_label'] ?? self::DEFAULT_FEEDBACK_LABEL,
                self::DEFAULT_FEEDBACK_LABEL
            ),
            'feedback_url' => $this->sanitizeUrl($settings['feedback_url'] ?? ''),
            'skip_link_enabled' => $this->toBool($settings['skip_link_enabled'] ?? false),
            'skip_link_label' => $this->sanitizeText(
                $settings['skip_link_label'] ?? self::DEFAULT_SKIP_LINK_LABEL,
                self::DEFAULT_SKIP_LINK_LABEL
            ),
            'skip_link_hidden' => $this->toBool($settings['skip_link_hidden'] ?? false),
            'skip_link_target_selector' => $this->sanitizeSelector(
                $settings['skip_link_target_selector'] ?? self::DEFAULT_SKIP_LINK_TARGET_SELECTOR,
                self::DEFAULT_SKIP_LINK_TARGET_SELECTOR
            ),
            'skip_link_mount_selector' => $this->sanitizeSelector(
                $settings['skip_link_mount_selector'] ?? self::DEFAULT_SKIP_LINK_MOUNT_SELECTOR,
                self::DEFAULT_SKIP_LINK_MOUNT_SELECTOR
            ),
        ];
    }

    private function sanitizeText(mixed $value, string $default): string
    {
        if (! is_scalar($value)) {
            return $default;
        }

        $sanitized = sanitize_text_field((string) $value);

        return '' !== $sanitized ? $sanitized : $default;
    }

    private function sanitizeTextarea(mixed $value, string $default): string
    {
        if (! is_scalar($value)) {
            return $default;
        }

        $sanitized = sanitize_textarea_field((string) $value);

        return '' !== $sanitized ? $sanitized : $default;
    }

    private function sanitizeOptionalText(mixed $value): string
    {
        if (! is_scalar($value)) {
            return '';
        }

        return sanitize_text_field((string) $value);
    }

    private function sanitizeOptionalTextarea(mixed $value): string
    {
        if (! is_scalar($value)) {
            return '';
        }

        return sanitize_textarea_field((string) $value);
    }

    private function sanitizeSelector(mixed $value, string $default): string
    {
        if (! is_scalar($value)) {
            return $default;
        }

        $normalized = trim(wp_strip_all_tags((string) $value));

        return '' !== $normalized ? $normalized : $default;
    }

    private function sanitizeUrl(mixed $value): string
    {
        if (is_array($value)) {
            $value = $value['url'] ?? '';
        }

        if (! is_scalar($value)) {
            return '';
        }

        return esc_url_raw((string) $value);
    }

    /**
     * @param array<int, string> $allowed
     */
    private function sanitizeEnum(mixed $value, array $allowed, string $default): string
    {
        if (! is_string($value)) {
            return $default;
        }

        return in_array($value, $allowed, true) ? $value : $default;
    }

    private function toBool(mixed $value): bool
    {
        if (is_bool($value)) {
            return $value;
        }

        if (is_numeric($value)) {
            return 1 === (int) $value;
        }

        return is_string($value) && in_array(strtolower($value), ['yes', 'true', 'on'], true);
    }
}
