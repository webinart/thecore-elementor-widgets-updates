# The Core - Elementor Widgets

Plugin WordPress dédié aux widgets custom Elementor Atomics de The Core.

Version courante: `0.2.0-beta.80`
Statut de maturité: beta

## Périmètre actuel

- Interface admin top-level `The Core - Widgets`
- Page `Widgets` avec activation/désactivation par widget
- Page `Features` avec activation/désactivation des fonctionnalités globales
- Widgets Atomic actuels: `Fullscreen Menu`, `Marquee Carousel`, `Text List`, `Breadcrumb`, `Icon Text`
- Système d’update distant GitHub via manifest public `beta` / `prod`
- Outillage local: Composer, PHPUnit, PHPCS

## Versioning

- Format beta: `x.x.x-beta.n`
- Format production: `x.x.x`
- Canaux visés: beta et production

## Updates

- Repo source privé: `webinart/thecore-elementor-widgets`
- Repo public de distribution: `webinart/thecore-elementor-widgets-updates`
- Branche de publication des manifests et archives: `plugin-updates`
- Secret GitHub Actions attendu dans le repo privé: `UPDATES_REPO_SSH_KEY`

## Commandes locales

```bash
composer install
composer test
composer cs:check
```
