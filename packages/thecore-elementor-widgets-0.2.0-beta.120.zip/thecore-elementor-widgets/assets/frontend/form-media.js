( function () {
	'use strict';
	if ( window.theCoreAtomicFormMedia ) { return; }
	let qrLoading;
	const unavailable = 'Le dépôt de fichiers est momentanément indisponible.';
	const accepts = {
		photos: 'image/jpeg,image/png,image/webp',
		videos: 'video/mp4,video/quicktime,video/webm',
	};

	function sameOrigin( value ) {
		if ( typeof value !== 'string' || ! value.trim() ) { throw new Error( unavailable ); }
		const url = new URL( value, window.location.href );
		if ( url.origin !== window.location.origin || url.username || url.password || ! [ 'http:', 'https:' ].includes( url.protocol ) ) { throw new Error( unavailable ); }
		return url.href;
	}
	function node( tag, text, className ) {
		const el = document.createElement( tag );
		if ( text ) { el.textContent = text; }
		if ( className ) { el.className = className; }
		return el;
	}
	function button( text, action ) {
		const el = node( 'button', text, 'tc-form-media__button' );
		el.type = 'button'; el.addEventListener( 'click', action ); return el;
	}
	function loadQr() {
		if ( typeof window.QRCode === 'function' ) { return Promise.resolve(); }
		if ( qrLoading ) { return qrLoading; }
		qrLoading = new Promise( ( resolve, reject ) => {
			let url;
			try { url = sameOrigin( window.TheCoreAtomicFormMediaAssets?.qrCodeUrl ); }
			catch ( error ) { reject( error ); return; }
			if ( ! window.TheCoreAtomicFormMediaAssets?.qrCodeUrl ) { reject( new Error( unavailable ) ); return; }
			const script = document.createElement( 'script' );
			const timer = window.setTimeout( () => finish( false ), 15000 );
			function finish( ok ) {
				window.clearTimeout( timer ); script.onload = script.onerror = null;
				if ( ok && typeof window.QRCode === 'function' ) { resolve(); }
				else { script.remove(); reject( new Error( 'Le QR code ne peut pas être affiché. Réessayez.' ) ); }
			}
			script.onload = () => finish( true ); script.onerror = () => finish( false );
			script.src = url; document.head.appendChild( script );
		} ).catch( error => { qrLoading = null; throw error; } );
		return qrLoading;
	}

	function init( adapter ) {
		const { form, config, controls } = adapter;
		const fields = new Map();
		const endpoint = sameOrigin( config.mediaEndpoint );
		let submitting = false;
		let deliveryUncertain = false;
		function request( action, payload, multipart = false, signal ) {
			const abort = signal ? null : new AbortController();
			const timer = abort ? window.setTimeout( () => abort.abort(), 30000 ) : null;
			return fetch( sameOrigin( endpoint.replace( /\/$/, '' ) + '/' + action ), {
				method: 'POST', credentials: 'same-origin', cache: 'no-store', redirect: 'error',
				headers: multipart ? {} : { 'Content-Type': 'application/json' },
				body: multipart ? payload : JSON.stringify( payload ), signal: signal || abort.signal,
			} ).then( async response => {
				let result;
				try { result = await response.json(); } catch ( error ) { throw new Error( unavailable ); }
				if ( ! response.ok ) { throw new Error( typeof result.message === 'string' ? result.message : unavailable ); }
				return result;
			} ).finally( () => { if ( timer !== null ) { window.clearTimeout( timer ); abort.abort(); } } );
		}
		function say( field, message, error = false ) {
			field.status.textContent = message; field.status.setAttribute( 'role', error ? 'alert' : 'status' );
			field.status.setAttribute( 'aria-live', error ? 'assertive' : 'polite' );
		}
		function credentials( field ) { return { session: field.session.session, owner: field.session.owner }; }
		function busy( field, value ) {
			field.busy = value;
			field.root.setAttribute( 'aria-busy', value ? 'true' : 'false' );
			field.ui.querySelectorAll( 'button,input' ).forEach( control => { control.disabled = value || submitting; } );
			field.control.disabled = value || submitting;
			if ( field.failedFiles.length ) {
				field.control.disabled = true;
				field.actions.querySelectorAll( 'button,input' ).forEach( control => { control.disabled = true; } );
			}
		}
		function render( field ) {
			field.list.replaceChildren();
			for ( const file of field.files ) {
				const item = node( 'li', '', 'tc-form-media__file' );
				const name = node( 'span', String( file.name || 'Fichier' ) );
				const size = Number( file.size );
				if ( Number.isFinite( size ) ) { name.append( node( 'small', ' — ' + ( size / 1048576 ).toLocaleString( 'fr-FR', { maximumFractionDigits: 1 } ) + ' Mo' ) ); }
				const remove = button( 'Retirer', () => void removeFile( field, file.id ) );
				remove.setAttribute( 'aria-label', 'Retirer ' + String( file.name || 'ce fichier' ) ); remove.disabled = field.busy || submitting;
				item.append( name, remove ); field.list.append( item );
			}
			field.count.textContent = field.files.length + ' / ' + field.policy.max_files + ' fichiers ajoutés';
			field.control.setCustomValidity( '' );
		}
		async function ensureSession( field ) {
			if ( field.session ) { return field.session; }
			if ( field.creating ) { return field.creating; }
			field.creating = ( async () => {
				const abort = new AbortController();
				const timer = window.setTimeout( () => abort.abort(), 60000 );
				try {
					const result = await request( 'session', { context: config.context, field: field.definition.id,
						proof: await adapter.requestProof( abort.signal ), website: adapter.getWebsite() }, false, abort.signal );
					if ( typeof result.session !== 'string' || typeof result.owner !== 'string' ) { throw new Error( unavailable ); }
					field.session = { session: result.session, owner: result.owner };
					if ( result.policy ) { field.policy = result.policy; }
					field.files = Array.isArray( result.files ) ? result.files : [];
					field.expiresAt = result.expires_at; render( field );
					return field.session;
				} finally { window.clearTimeout( timer ); abort.abort(); field.creating = null; }
			} )();
			return field.creating;
		}
		function allowed( field, file ) {
			const type = file.type || '';
			const mode = field.policy.mode;
			if ( mode === 'photos' && ! type.startsWith( 'image/' ) || mode === 'videos' && ! type.startsWith( 'video/' ) || ! /^(image|video)\//.test( type ) ) {
				throw new Error( 'Ce type de fichier n’est pas autorisé pour ce champ.' );
			}
			if ( file.size > field.policy.max_file_size_mb * 1048576 ) { throw new Error( 'Le fichier dépasse la limite de ' + field.policy.max_file_size_mb + ' Mo.' ); }
			if ( file.size < 1 ) { throw new Error( 'Ce fichier est vide.' ); }
		}
		async function upload( field, file ) {
			const abort = new AbortController(); const timer = window.setTimeout( () => abort.abort(), 180000 );
			const body = new FormData(); const auth = credentials( field );
			body.append( 'session', auth.session ); body.append( 'owner', auth.owner ); body.append( 'file', file );
			// Fetch can forbid redirects (XHR cannot), so bearer credentials never follow a redirect.
			// Indeterminate progress remains accurate on browsers without upload-stream support.
			field.progress.removeAttribute( 'value' );
			try { return await request( 'upload', body, true, abort.signal ); }
			finally { window.clearTimeout( timer ); abort.abort(); }
		}
		async function addFiles( field, selected ) {
			const files = Array.from( selected ); field.control.value = '';
			if ( ! files.length || field.busy || submitting ) { return; }
			field.failedFiles = files.slice(); field.retryUi.hidden = true;
			busy( field, true );
			try {
				files.forEach( file => allowed( field, file ) );
				await ensureSession( field );
				if ( field.files.length + files.length > field.policy.max_files ) { throw new Error( 'Vous pouvez ajouter au maximum ' + field.policy.max_files + ' fichiers.' ); }
				for ( const file of files ) {
					allowed( field, file ); say( field, 'Transfert de « ' + file.name + ' »…' );
					field.progress.hidden = false; field.progress.value = 0;
					const result = await upload( field, file );
					if ( ! Array.isArray( result.files ) ) { throw new Error( unavailable ); }
					field.files = result.files; render( field );
					field.failedFiles.shift();
				}
				say( field, 'Fichiers ajoutés. Vous pouvez continuer le formulaire.' );
			} catch ( error ) { say( field, error.message || unavailable, true ); }
			finally { field.retryUi.hidden = ! field.failedFiles.length; field.progress.hidden = true; busy( field, false ); }
		}
		async function removeFile( field, id ) {
			if ( field.busy || submitting ) { return; }
			busy( field, true );
			try {
				const result = await request( 'delete', { ...credentials( field ), id } );
				if ( ! Array.isArray( result.files ) ) { throw new Error( unavailable ); }
				field.files = result.files; render( field ); say( field, 'Fichier retiré.' );
			} catch ( error ) { say( field, error.message || unavailable, true ); }
			finally { busy( field, false ); field.control.focus(); }
		}
		function stopPoll( field ) { window.clearTimeout( field.poll ); field.poll = null; }
		function poll( field ) {
			stopPoll( field );
			if ( ! field.session || ! field.bridgeOpen || ! form.isConnected ) { return; }
			field.poll = window.setTimeout( async () => {
				try {
					const currentSession = field.session;
					const result = await request( 'status', credentials( field ) );
					if ( field.session !== currentSession || ! field.bridgeOpen || ! form.isConnected ) { return; }
					if ( ! field.busy && ! submitting && Array.isArray( result.files ) ) { field.files = result.files; render( field ); }
					const bridge = result.bridge || {};
					field.approve.hidden = bridge.state !== 'pending';
					field.pairCode = bridge.pair_code || '';
					if ( field.soft ) {
						field.expiry.hidden = bridge.state !== 'waiting';
						field.approve.hidden = bridge.state !== 'pending' || ! /^\d{6}$/.test( String( field.pairCode ) );
					}
					if ( bridge.state === 'pending' ) {
						field.pair.textContent = 'Le téléphone affiche le code ' + field.pairCode + '. Vérifiez qu’il s’agit bien du vôtre avant de confirmer.';
					} else if ( bridge.state === 'approved' ) { field.pair.textContent = 'Téléphone connecté. Les fichiers ajoutés apparaîtront ici.'; }
					else if ( bridge.state === 'finished' ) { field.pair.textContent = 'Le transfert depuis le téléphone est terminé.'; return; }
					else if ( [ 'expired', 'revoked' ].includes( bridge.state ) ) {
						field.pair.textContent = 'La connexion au téléphone a expiré. Fermez puis affichez un nouveau QR code.';
						stopPoll( field ); return;
					}
					else if ( bridge.state === 'none' ) { field.pair.textContent = 'La connexion au téléphone est terminée. Les fichiers reçus sont conservés.'; return; }
					else if ( field.soft && bridge.state === 'waiting' ) { field.pair.textContent = 'Scannez ce QR code avec votre téléphone. Vous devrez confirmer la connexion ici.'; }
				} catch ( error ) { field.pair.textContent = error.message || 'Connexion interrompue. Réessayez.'; }
				poll( field );
			}, 2500 );
		}
		async function closeBridge( field ) {
			if ( field.busy || submitting ) { return; }
			busy( field, true );
			try {
				await request( 'finish', credentials( field ) );
				const result = await request( 'status', credentials( field ) );
				if ( Array.isArray( result.files ) ) { field.files = result.files; render( field ); }
				field.bridgeOpen = false; stopPoll( field ); field.panel.hidden = true; field.qr.replaceChildren();
				say( field, 'Connexion au téléphone fermée. Les fichiers déjà ajoutés sont conservés.' );
			} catch ( error ) { say( field, error.message || unavailable, true ); }
			finally { busy( field, false ); if ( ! field.bridgeOpen ) { field.phone.focus(); } }
		}
		async function openBridge( field ) {
			if ( field.busy || submitting ) { return; }
			busy( field, true );
			try {
				await ensureSession( field ); await loadQr();
				const result = await request( 'bridge', credentials( field ) );
				const mobileUrl = sameOrigin( result.mobile_url );
				const parsed = new URL( mobileUrl );
				if ( ! parsed.hash || parsed.searchParams.get( 'thecore-form-media' ) !== 'mobile' ) { throw new Error( unavailable ); }
				field.qr.replaceChildren();
				new window.QRCode( field.qr, { text: mobileUrl, width: 208, height: 208, correctLevel: window.QRCode.CorrectLevel?.M ?? 0 } );
				// Do not leave a clickable bearer URL in the DOM or an image title.
				field.qr.removeAttribute( 'title' ); field.qr.querySelectorAll( '[title]' ).forEach( el => el.removeAttribute( 'title' ) );
				field.panel.hidden = false; field.bridgeOpen = true;
				field.pair.textContent = 'Scannez ce QR code avec votre téléphone. Vous devrez confirmer la connexion ici.';
				if ( field.soft ) { field.expiry.hidden = false; field.pairCode = ''; field.approvalError = ''; }
				field.approve.hidden = true; poll( field );
				say( field, field.soft ? '' : 'QR code prêt. Le lien expire après 15 minutes.' );
			} catch ( error ) { say( field, error.message || unavailable, true ); }
			finally { busy( field, false ); if ( field.bridgeOpen ) { field.close.focus(); } }
		}
		async function approve( field ) {
			if ( field.busy || submitting || ! /^\d{6}$/.test( String( field.pairCode ) ) ) { return; }
			busy( field, true );
			try {
				await request( 'approve', { ...credentials( field ), pair_code: field.pairCode } );
				field.approve.hidden = true; field.pair.textContent = 'Téléphone connecté. Ajoutez vos fichiers depuis le téléphone.';
				if ( field.soft ) {
					field.expiry.hidden = true;
					if ( field.approvalError && field.status.textContent === field.approvalError ) { say( field, '' ); }
					field.approvalError = '';
				}
			} catch ( error ) { say( field, error.message || unavailable, true ); if ( field.soft ) { field.approvalError = field.status.textContent; } }
			finally { busy( field, false ); }
		}
		for ( const definition of config.fields.filter( field => field.type === 'media' ) ) {
			const control = controls.get( definition.id );
			const root = control?.closest( '[data-thecore-form-media]' );
			if ( ! root || root.closest( 'form' ) !== form ) { throw new Error( unavailable ); }
			const settings = definition.media || {};
			const mode = [ 'photos', 'videos', 'both' ].includes( settings.mode ) ? settings.mode : 'both';
			const ui = root.querySelector( '[data-thecore-media-ui]' ) || root.appendChild( node( 'div' ) );
			ui.dataset.thecoreMediaUi = '1'; ui.replaceChildren(); root.classList.add( 'tc-form-media' );
			const output = root.querySelector( '[data-thecore-media-status]' ) || root.appendChild( node( 'p' ) );
			output.dataset.thecoreMediaStatus = '1'; output.tabIndex = -1; output.setAttribute( 'role', 'status' ); output.setAttribute( 'aria-live', 'polite' );
			const field = { definition, control, root, ui, status: output, soft: root.dataset.mediaAppearance === 'soft', files: [], failedFiles: [], busy: false, session: null,
				policy: { mode, max_files: settings.maxFiles || 5, max_file_size_mb: Math.max( 1, ( settings.maxBytes || 26214400 ) / 1048576 ) } };
			control.required = false; control.multiple = true;
			control.accept = mode === 'both' ? accepts.photos + ',' + accepts.videos : accepts[ mode ];
			control.addEventListener( 'change', () => void addFiles( field, control.files ) );
			const actions = node( 'div', '', 'tc-form-media__actions' );
			field.actions = actions;
			const pick = button( mode === 'photos' ? 'Choisir des photos' : mode === 'videos' ? 'Choisir des vidéos' : 'Choisir des photos ou vidéos', () => control.click() );
			control.classList.add( 'tc-form-media__native' ); actions.append( pick );
			for ( const kind of [ 'photos', 'videos' ] ) {
				if ( mode !== 'both' && mode !== kind ) { continue; }
				const capture = node( 'input' ); capture.type = 'file'; capture.accept = accepts[ kind ]; capture.setAttribute( 'capture', 'environment' );
				capture.className = 'tc-form-media__native'; capture.tabIndex = -1;
				capture.setAttribute( 'aria-label', kind === 'photos' ? 'Prendre une photo' : 'Filmer une vidéo' );
				capture.addEventListener( 'change', () => { const files = Array.from( capture.files ); capture.value = ''; void addFiles( field, files ); } );
				const captureButton = button( kind === 'photos' ? 'Prendre une photo' : 'Filmer une vidéo', () => capture.click() );
				captureButton.classList.add( 'tc-form-media__capture' ); actions.append( capture, captureButton );
			}
			field.phone = button( 'Ajouter depuis mon téléphone', () => void openBridge( field ) );
			field.phone.classList.add( 'tc-form-media__phone' );
			if ( settings.mobileTransfer !== false ) { actions.append( field.phone ); }
			field.count = node( 'p', '', 'tc-form-media__count' ); field.list = node( 'ul', '', 'tc-form-media__files' );
			field.list.setAttribute( 'aria-label', 'Fichiers ajoutés' );
			const help = root.querySelector( '.tc-form-media__hint' ) || node( 'p', 'Jusqu’à ' + field.policy.max_files + ' fichiers, ' + field.policy.max_file_size_mb + ' Mo par fichier.' );
			help.classList.add( 'tc-form-media__help' ); help.append( ' Les fichiers sont déposés de façon privée avant l’envoi de votre demande.' );
			help.id = control.id + '-media-help'; control.setAttribute( 'aria-describedby', ( control.getAttribute( 'aria-describedby' ) || '' ) + ' ' + help.id );
			field.progress = node( 'progress' ); field.progress.max = 100; field.progress.hidden = true; field.progress.setAttribute( 'aria-label', 'Progression du transfert' );
			field.panel = node( 'section', '', 'tc-form-media__panel' ); field.panel.hidden = true;
			field.panel.setAttribute( 'aria-label', 'Transfert depuis le téléphone' );
			field.qr = node( 'div', '', 'tc-form-media__qr' ); field.qr.setAttribute( 'role', 'img' ); field.qr.setAttribute( 'aria-label', 'QR code à scanner avec le téléphone' );
			field.pair = node( 'p' ); field.pair.setAttribute( 'aria-live', 'polite' );
			field.approve = button( 'Je reconnais ce code : connecter le téléphone', () => void approve( field ) ); field.approve.hidden = true;
			field.close = button( 'Fermer la connexion au téléphone', () => void closeBridge( field ) );
			if ( field.soft ) {
				const details = node( 'div', '', 'tc-form-media__connection' );
				const panelActions = node( 'div', '', 'tc-form-media__connection-actions' );
				field.pair.className = 'tc-form-media__connection-message';
				field.expiry = node( 'p', 'Lien valable 15 minutes.', 'tc-form-media__connection-expiry' );
				panelActions.append( field.approve, field.close );
				details.append( field.pair, field.expiry, panelActions );
				field.panel.append( field.qr, details );
			} else {
				field.panel.append( node( 'h3', 'Ajouter depuis mon téléphone' ), field.qr, field.pair, field.approve, field.close );
			}
			field.panel.addEventListener( 'keydown', event => { if ( event.key === 'Escape' ) { event.preventDefault(); void closeBridge( field ); } } );
			field.retryUi = node( 'div', '', 'tc-form-media__retry' ); field.retryUi.hidden = true;
			field.retryUi.append( button( 'Réessayer le transfert', () => void addFiles( field, field.failedFiles ) ), button( 'Continuer sans ces fichiers non reçus', () => {
				if ( field.busy || submitting ) { return; }
				field.failedFiles = []; field.retryUi.hidden = true; field.control.setCustomValidity( '' ); busy( field, false );
				say( field, 'Les fichiers non reçus ont été retirés. Les fichiers déjà ajoutés sont conservés.' ); field.control.focus();
			} ) );
			ui.append( help, actions, field.count, field.list, field.progress, field.retryUi, field.panel );
			fields.set( definition.id, field ); render( field );
		}
		function selectedFields( ids ) {
			return Array.from( fields ).filter( ( [ id ] ) => ! ids || ( typeof ids.has === 'function' ? ids.has( id ) : ids.includes( id ) ) );
		}
		return {
			values: ids => Object.fromEntries( selectedFields( ids ).map( ( [ id, field ] ) => [ id, field.files.map( file => file.id ) ] ) ),
			sessions: ids => Object.fromEntries( selectedFields( ids ).filter( ( [ , field ] ) => !! field.session ).map( ( [ id, field ] ) => [ id, credentials( field ) ] ) ),
			isBusy: ids => selectedFields( ids ).some( ( [ , field ] ) => field.busy ),
			validate: ids => {
				if ( deliveryUncertain ) { return; }
				for ( const [ , field ] of selectedFields( ids ) ) {
					field.control.disabled = false;
					field.control.setCustomValidity( field.failedFiles.length ? 'Un fichier n’a pas pu être transféré. Réessayez ou retirez les fichiers non reçus.' : field.definition.required && ! field.files.length ? 'Veuillez ajouter au moins un fichier.' : '' );
				}
			},
			prepare: async ids => {
				if ( deliveryUncertain ) { throw new Error( 'Contactez-nous avant de recommencer cette demande.' ); }
				// Close mobile capabilities and take a final authoritative snapshot before submit.
				for ( const [ , field ] of selectedFields( ids ) ) {
					if ( ! field.session ) { continue; }
					if ( field.bridgeOpen ) {
						stopPoll( field ); await request( 'finish', credentials( field ) );
						field.bridgeOpen = false; field.panel.hidden = true; field.qr.replaceChildren();
					}
					const result = await request( 'status', credentials( field ) );
					if ( ! Array.isArray( result.files ) ) { throw new Error( unavailable ); }
					field.files = result.files; render( field );
				}
			},
			setSubmitting: value => { submitting = value || deliveryUncertain; for ( const field of fields.values() ) { busy( field, field.busy ); } },
			deliveryUncertain: () => {
				// Delivery may already have occurred. Do not mutate sealed files or reuse their owner capability.
				deliveryUncertain = true; submitting = true;
				for ( const field of fields.values() ) {
					stopPoll( field ); field.bridgeOpen = false; field.panel.hidden = true; field.qr.replaceChildren();
					field.session = null; busy( field, false );
					say( field, 'Fichiers conservés de manière sécurisée. Contactez-nous avant de recommencer cette demande.', true );
				}
			},
			confirmedSuccess: ids => {
				for ( const [ , field ] of selectedFields( ids ) ) {
					stopPoll( field ); field.bridgeOpen = false; field.panel.hidden = true; field.qr.replaceChildren();
					// The server has sealed submitted files. Forget their capability locally; it can no longer mutate the session.
					field.session = null; field.files = []; field.failedFiles = []; field.retryUi.hidden = true; field.control.value = ''; render( field ); say( field, '' );
				}
			},
		};
	}
	window.theCoreAtomicFormMedia = { init };
	window.dispatchEvent( new Event( 'thecore:form-media-ready' ) );
}() );
