<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\TextList;

final class DisplaySettings
{
    public const DEFAULT_ITEMS_TEXT = "Premier item\nSecond item";
    public const DEFAULT_LIST_MODE = 'unordered';
    public const DEFAULT_PLAIN_CONTAINER_TAG = 'div';
    public const DEFAULT_PLAIN_ITEM_TAG = 'div';
    public const DEFAULT_TEXT_COLOR = '#222222';
    public const DEFAULT_FONT_FAMILY = 'inherit';
    public const DEFAULT_FONT_SIZE = [
        'size' => 16.0,
        'unit' => 'px',
    ];
    public const DEFAULT_FONT_WEIGHT = '400';
    public const DEFAULT_LINE_HEIGHT = [
        'size' => 1.4,
        'unit' => 'em',
    ];
    public const DEFAULT_LETTER_SPACING = [
        'size' => 0.0,
        'unit' => 'px',
    ];
    public const DEFAULT_FONT_STYLE = 'normal';
    public const DEFAULT_TEXT_DECORATION = 'none';
    public const DEFAULT_TEXT_TRANSFORM = 'none';
    public const DEFAULT_GAP = 12;

    /**
     * @param array<string, mixed> $settings
     *
     * @return array{
     *     items: array<int, string>,
     *     list_mode: string,
     *     container_tag: string,
     *     item_tag: string,
     *     text_color: string,
     *     font_family: string,
     *     font_size: array{size: float, unit: string},
     *     font_weight: string,
     *     line_height: array{size: float, unit: string},
     *     letter_spacing: array{size: float, unit: string},
     *     font_style: string,
     *     text_decoration: string,
     *     text_transform: string,
     *     gap: int
     * }
     */
    public function normalize(array $settings): array
    {
        $listMode = $this->sanitizeEnum(
            $settings['list_mode'] ?? self::DEFAULT_LIST_MODE,
            ['unordered', 'ordered', 'plain'],
            self::DEFAULT_LIST_MODE
        );

        return [
            'items' => $this->sanitizeItems($settings['items_text'] ?? self::DEFAULT_ITEMS_TEXT),
            'list_mode' => $listMode,
            'container_tag' => $this->resolveContainerTag(
                $listMode,
                $settings['plain_container_tag'] ?? self::DEFAULT_PLAIN_CONTAINER_TAG
            ),
            'item_tag' => $this->resolveItemTag(
                $listMode,
                $settings['plain_item_tag'] ?? self::DEFAULT_PLAIN_ITEM_TAG
            ),
            'text_color' => $this->sanitizeColor(
                $settings['text_color'] ?? self::DEFAULT_TEXT_COLOR,
                self::DEFAULT_TEXT_COLOR
            ),
            'font_family' => $this->sanitizeFontFamily(
                $settings['font_family'] ?? self::DEFAULT_FONT_FAMILY,
                self::DEFAULT_FONT_FAMILY
            ),
            'font_size' => $this->sanitizeSize(
                $settings['font_size'] ?? self::DEFAULT_FONT_SIZE,
                self::DEFAULT_FONT_SIZE,
                ['px', 'em', 'rem'],
                8.0,
                120.0
            ),
            'font_weight' => $this->sanitizeEnum(
                $settings['font_weight'] ?? self::DEFAULT_FONT_WEIGHT,
                ['100', '200', '300', '400', '500', '600', '700', '800', '900'],
                self::DEFAULT_FONT_WEIGHT
            ),
            'line_height' => $this->sanitizeSize(
                $settings['line_height'] ?? self::DEFAULT_LINE_HEIGHT,
                self::DEFAULT_LINE_HEIGHT,
                ['px', 'em', 'rem'],
                0.5,
                4.0
            ),
            'letter_spacing' => $this->sanitizeSize(
                $settings['letter_spacing'] ?? self::DEFAULT_LETTER_SPACING,
                self::DEFAULT_LETTER_SPACING,
                ['px', 'em', 'rem'],
                -20.0,
                20.0
            ),
            'font_style' => $this->sanitizeEnum(
                $settings['font_style'] ?? self::DEFAULT_FONT_STYLE,
                ['normal', 'italic', 'oblique'],
                self::DEFAULT_FONT_STYLE
            ),
            'text_decoration' => $this->sanitizeEnum(
                $settings['text_decoration'] ?? self::DEFAULT_TEXT_DECORATION,
                ['none', 'underline', 'line-through', 'overline'],
                self::DEFAULT_TEXT_DECORATION
            ),
            'text_transform' => $this->sanitizeEnum(
                $settings['text_transform'] ?? self::DEFAULT_TEXT_TRANSFORM,
                ['none', 'uppercase', 'lowercase', 'capitalize'],
                self::DEFAULT_TEXT_TRANSFORM
            ),
            'gap' => $this->clampInt(
                $settings['gap'] ?? self::DEFAULT_GAP,
                0,
                100,
                self::DEFAULT_GAP
            ),
        ];
    }

    /**
     * @param mixed $value
     *
     * @return array<int, string>
     */
    private function sanitizeItems(mixed $value): array
    {
        if (! is_string($value)) {
            return [];
        }

        $items = [];
        $lines = preg_split('/\R/u', $value) ?: [];

        foreach (array_slice($lines, 0, 100) as $line) {
            $normalized = sanitize_text_field($line);

            if ('' === $normalized) {
                continue;
            }

            $items[] = $normalized;
        }

        return $items;
    }

    private function resolveContainerTag(string $listMode, mixed $value): string
    {
        if ('unordered' === $listMode) {
            return 'ul';
        }

        if ('ordered' === $listMode) {
            return 'ol';
        }

        return $this->sanitizeEnum(
            $value,
            ['div', 'section', 'nav', 'aside'],
            self::DEFAULT_PLAIN_CONTAINER_TAG
        );
    }

    private function resolveItemTag(string $listMode, mixed $value): string
    {
        if ('plain' !== $listMode) {
            return 'li';
        }

        return $this->sanitizeEnum(
            $value,
            ['div', 'p', 'span'],
            self::DEFAULT_PLAIN_ITEM_TAG
        );
    }

    private function clampInt(mixed $value, int $min, int $max, int $default): int
    {
        if (! is_numeric($value)) {
            return $default;
        }

        return max($min, min($max, (int) $value));
    }

    private function sanitizeColor(mixed $value, string $default): string
    {
        if (! is_string($value)) {
            return $default;
        }

        $normalized = trim($value);

        if ('' === $normalized) {
            return $default;
        }

        if (1 === preg_match('/^#(?:[0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/', $normalized)) {
            return $normalized;
        }

        if (1 === preg_match('/^(?:rgb|rgba|hsl|hsla)\([0-9.,%\s\/-]+\)$/i', $normalized)) {
            return $normalized;
        }

        if (1 === preg_match('/^var\(--[a-zA-Z0-9_-]+\)$/', $normalized)) {
            return $normalized;
        }

        if (in_array(strtolower($normalized), ['transparent', 'currentcolor', 'inherit'], true)) {
            return $normalized;
        }

        return $default;
    }

    private function sanitizeFontFamily(mixed $value, string $default): string
    {
        if (! is_string($value)) {
            return $default;
        }

        $normalized = trim(str_replace([';', '{', '}', '<', '>'], '', $value));

        return '' !== $normalized ? $normalized : $default;
    }

    /**
     * @param array<int, string> $allowed
     */
    private function sanitizeEnum(mixed $value, array $allowed, string $default): string
    {
        if (! is_string($value)) {
            return $default;
        }

        $normalized = trim($value);

        return in_array($normalized, $allowed, true) ? $normalized : $default;
    }

    /**
     * @param array{size: float|int, unit: string} $default
     * @param array<int, string>                   $allowedUnits
     *
     * @return array{size: float, unit: string}
     */
    private function sanitizeSize(mixed $value, array $default, array $allowedUnits, float $min, float $max): array
    {
        if (! is_array($value)) {
            return $default;
        }

        $size = $value['size'] ?? null;
        $unit = $value['unit'] ?? null;

        if (! is_numeric($size) || ! is_string($unit) || ! in_array($unit, $allowedUnits, true)) {
            return $default;
        }

        return [
            'size' => max($min, min($max, (float) $size)),
            'unit' => $unit,
        ];
    }
}
