<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\TextList;

final class InlineStylesBuilder
{
    /**
     * @param array{
     *     text_color: string,
     *     font_family: string,
     *     font_size: array{size: float, unit: string},
     *     font_weight: string,
     *     line_height: array{size: float, unit: string},
     *     letter_spacing: array{size: float, unit: string},
     *     font_style: string,
     *     text_decoration: string,
     *     text_transform: string,
     *     gap: int
     * } $settings
     */
    public function build(string $scopeSelector, array $settings): string
    {
        $rules = [];
        $rules[] = $scopeSelector . '{' . implode(';', [
            '--thecore-text-list-gap:' . (int) $settings['gap'] . 'px',
            '--thecore-text-list-color:' . $settings['text_color'],
            '--thecore-text-list-font-family:' . $settings['font_family'],
            '--thecore-text-list-font-size:' . $this->formatSize($settings['font_size']),
            '--thecore-text-list-font-weight:' . $settings['font_weight'],
            '--thecore-text-list-line-height:' . $this->formatSize($settings['line_height']),
            '--thecore-text-list-letter-spacing:' . $this->formatSize($settings['letter_spacing']),
            '--thecore-text-list-font-style:' . $settings['font_style'],
            '--thecore-text-list-text-decoration:' . $settings['text_decoration'],
            '--thecore-text-list-text-transform:' . $settings['text_transform'],
        ]) . ';}';
        $rules[] = $scopeSelector . ' .thecore-text-list__container{display:grid;gap:var(--thecore-text-list-gap);margin:0;padding:0;list-style:none;}';
        $rules[] = $scopeSelector . ' .thecore-text-list__item{display:block;margin:0;color:var(--thecore-text-list-color);font-family:var(--thecore-text-list-font-family);font-size:var(--thecore-text-list-font-size);font-weight:var(--thecore-text-list-font-weight);line-height:var(--thecore-text-list-line-height);letter-spacing:var(--thecore-text-list-letter-spacing);font-style:var(--thecore-text-list-font-style);text-decoration:var(--thecore-text-list-text-decoration);text-transform:var(--thecore-text-list-text-transform);}';
        $rules[] = $scopeSelector . ' .thecore-text-list__empty{padding:16px;border:1px dashed #C7C7C7;color:#666;font-size:14px;line-height:1.4;}';

        return implode('', $rules);
    }

    /**
     * @param array{size: float, unit: string} $value
     */
    private function formatSize(array $value): string
    {
        $size = (float) $value['size'];

        if ((float) (int) $size === $size) {
            return (string) (int) $size . $value['unit'];
        }

        return rtrim(rtrim(sprintf('%.4F', $size), '0'), '.') . $value['unit'];
    }
}
