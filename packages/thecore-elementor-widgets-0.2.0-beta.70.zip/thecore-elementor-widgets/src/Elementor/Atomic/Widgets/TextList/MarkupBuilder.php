<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\TextList;

final class MarkupBuilder
{
    /**
     * @param array<int, string> $items
     */
    public function build(array $items, string $containerTag, string $itemTag): string
    {
        if ([] === $items) {
            return $this->renderEmptyState(
                __('Add at least one text item to render the Text List widget.', 'thecore-elementor-widgets')
            );
        }

        $attributes = [
            'class' => 'thecore-text-list__container',
        ];

        if ('li' !== $itemTag) {
            $attributes['role'] = 'list';
        }

        $markup = '<' . esc_html($containerTag) . $this->buildAttributes($attributes) . '>';

        foreach ($items as $item) {
            $itemAttributes = [
                'class' => 'thecore-text-list__item',
            ];

            if ('li' !== $itemTag) {
                $itemAttributes['role'] = 'listitem';
            }

            $markup .= '<' . esc_html($itemTag) . $this->buildAttributes($itemAttributes) . '>';
            $markup .= esc_html($item);
            $markup .= '</' . esc_html($itemTag) . '>';
        }

        $markup .= '</' . esc_html($containerTag) . '>';

        return $markup;
    }

    private function renderEmptyState(string $message): string
    {
        if (! $this->isElementorEditingContext()) {
            return '';
        }

        return sprintf(
            '<div class="thecore-text-list__empty">%s</div>',
            esc_html($message)
        );
    }

    /**
     * @param array<string, string> $attributes
     */
    private function buildAttributes(array $attributes): string
    {
        $markup = '';

        foreach ($attributes as $name => $value) {
            $markup .= sprintf(
                ' %s="%s"',
                esc_attr($name),
                esc_attr($value)
            );
        }

        return $markup;
    }

    private function isElementorEditingContext(): bool
    {
        if (! class_exists('\Elementor\Plugin')) {
            return false;
        }

        return \Elementor\Plugin::$instance->editor->is_edit_mode()
            || \Elementor\Plugin::$instance->preview->is_preview_mode();
    }
}
