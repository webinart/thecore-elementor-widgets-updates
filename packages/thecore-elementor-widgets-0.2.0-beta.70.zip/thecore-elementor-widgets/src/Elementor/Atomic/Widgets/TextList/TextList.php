<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\TextList;

use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Number_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Select_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Size_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Text_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Textarea_Control;
use Elementor\Modules\AtomicWidgets\DynamicTags\Dynamic_Prop_Type;
use Elementor\Modules\AtomicWidgets\Elements\Base\Atomic_Widget_Base;
use Elementor\Modules\AtomicWidgets\Elements\Base\Has_Template;
use Elementor\Modules\AtomicWidgets\PropTypes\Attributes_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Classes_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Color_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Dimensions_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Number_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Size_Prop_Type;
use Elementor\Modules\AtomicWidgets\Styles\Style_Definition;
use Elementor\Modules\AtomicWidgets\Styles\Style_Variant;
use Elementor\Modules\Components\PropTypes\Overridable_Prop_Type;
use TheCore\ElementorWidgets\Elementor\Atomic\Controls\Types\ColorControl;
use TheCore\ElementorWidgets\Elementor\Atomic\Controls\Types\FontFamilyControl;
use TheCore\ElementorWidgets\Elementor\Atomic\Controls\Types\ZeroDefaultSizeControl;
use TheCore\ElementorWidgets\Elementor\Atomic\PropTypes\ZeroableSizePropType;

final class TextList extends Atomic_Widget_Base
{
    use Has_Template;

    public static $widget_description = 'Simple text list ported from the legacy widget with cleaner semantics and inline typography styling.';

    public static function get_element_type(): string
    {
        return 'thecore-text-list';
    }

    public function get_title(): string
    {
        return esc_html__('Text List', 'thecore-elementor-widgets');
    }

    public function get_icon(): string
    {
        return 'eicon-editor-list-ul';
    }

    public function get_keywords(): array
    {
        return ['text', 'list', 'items', 'copy', 'atomic'];
    }

    protected static function define_props_schema(): array
    {
        return [
            'classes' => Classes_Prop_Type::make()->default([]),
            'items_text' => String_Prop_Type::make()
                ->default(DisplaySettings::DEFAULT_ITEMS_TEXT)
                ->meta(Dynamic_Prop_Type::ignore())
                ->meta(Overridable_Prop_Type::ignore()),
            'list_mode' => String_Prop_Type::make()
                ->enum(['unordered', 'ordered', 'plain'])
                ->default(DisplaySettings::DEFAULT_LIST_MODE)
                ->meta(Dynamic_Prop_Type::ignore())
                ->meta(Overridable_Prop_Type::ignore()),
            'plain_container_tag' => String_Prop_Type::make()
                ->enum(['div', 'section', 'nav', 'aside'])
                ->default(DisplaySettings::DEFAULT_PLAIN_CONTAINER_TAG)
                ->meta(Dynamic_Prop_Type::ignore())
                ->meta(Overridable_Prop_Type::ignore()),
            'plain_item_tag' => String_Prop_Type::make()
                ->enum(['div', 'p', 'span'])
                ->default(DisplaySettings::DEFAULT_PLAIN_ITEM_TAG)
                ->meta(Dynamic_Prop_Type::ignore())
                ->meta(Overridable_Prop_Type::ignore()),
            'text_color' => Color_Prop_Type::make()->default(DisplaySettings::DEFAULT_TEXT_COLOR),
            'font_family' => String_Prop_Type::make()->default(DisplaySettings::DEFAULT_FONT_FAMILY),
            'font_size' => Size_Prop_Type::make()
                ->units(['px', 'em', 'rem'])
                ->default_unit('px')
                ->default(DisplaySettings::DEFAULT_FONT_SIZE),
            'font_weight' => String_Prop_Type::make()->enum(self::fontWeightValues())->default(DisplaySettings::DEFAULT_FONT_WEIGHT),
            'line_height' => Size_Prop_Type::make()
                ->units(['em', 'px', 'rem'])
                ->default_unit('em')
                ->default(DisplaySettings::DEFAULT_LINE_HEIGHT),
            'letter_spacing' => ZeroableSizePropType::make()
                ->units(['px', 'em', 'rem'])
                ->default_unit('px')
                ->meta(Dynamic_Prop_Type::ignore())
                ->meta(Overridable_Prop_Type::ignore())
                ->initial_value(DisplaySettings::DEFAULT_LETTER_SPACING)
                ->default(DisplaySettings::DEFAULT_LETTER_SPACING),
            'font_style' => String_Prop_Type::make()->enum(self::fontStyleValues())->default(DisplaySettings::DEFAULT_FONT_STYLE),
            'text_decoration' => String_Prop_Type::make()->enum(self::textDecorationValues())->default(DisplaySettings::DEFAULT_TEXT_DECORATION),
            'text_transform' => String_Prop_Type::make()->enum(self::textTransformValues())->default(DisplaySettings::DEFAULT_TEXT_TRANSFORM),
            'gap' => Number_Prop_Type::make()->default(DisplaySettings::DEFAULT_GAP),
            'attributes' => Attributes_Prop_Type::make()->meta(Overridable_Prop_Type::ignore()),
        ];
    }

    protected function define_base_styles(): array
    {
        $zeroSize = Size_Prop_Type::generate([
            'size' => 0,
            'unit' => 'px',
        ]);

        $spacingValue = Dimensions_Prop_Type::generate([
            'block-start' => $zeroSize,
            'inline-end' => $zeroSize,
            'block-end' => $zeroSize,
            'inline-start' => $zeroSize,
        ]);

        return [
            'base' => Style_Definition::make()
                ->add_variant(
                    Style_Variant::make()
                        ->add_prop('padding', $spacingValue)
                        ->add_prop('margin', $spacingValue)
                ),
        ];
    }

    protected function define_atomic_controls(): array
    {
        return [
            Section::make()
                ->set_label(__('Content', 'thecore-elementor-widgets'))
                ->set_items([
                    Textarea_Control::bind_to('items_text')
                        ->set_label(__('Items', 'thecore-elementor-widgets'))
                        ->set_placeholder(__("Premier item\nSecond item", 'thecore-elementor-widgets'))
                        ->set_description(__('Enter one item per line.', 'thecore-elementor-widgets')),
                    Select_Control::bind_to('list_mode')
                        ->set_label(__('List type', 'thecore-elementor-widgets'))
                        ->set_options([
                            [
                                'label' => __('Unordered list', 'thecore-elementor-widgets'),
                                'value' => 'unordered',
                            ],
                            [
                                'label' => __('Ordered list', 'thecore-elementor-widgets'),
                                'value' => 'ordered',
                            ],
                            [
                                'label' => __('Plain stack', 'thecore-elementor-widgets'),
                                'value' => 'plain',
                            ],
                        ]),
                    Select_Control::bind_to('plain_container_tag')
                        ->set_label(__('Plain container tag', 'thecore-elementor-widgets'))
                        ->set_options([
                            ['label' => 'div', 'value' => 'div'],
                            ['label' => 'section', 'value' => 'section'],
                            ['label' => 'nav', 'value' => 'nav'],
                            ['label' => 'aside', 'value' => 'aside'],
                        ])
                        ->set_description(__('Used only when List type is Plain stack.', 'thecore-elementor-widgets')),
                    Select_Control::bind_to('plain_item_tag')
                        ->set_label(__('Plain item tag', 'thecore-elementor-widgets'))
                        ->set_options([
                            ['label' => 'div', 'value' => 'div'],
                            ['label' => 'p', 'value' => 'p'],
                            ['label' => 'span', 'value' => 'span'],
                        ])
                        ->set_description(__('Used only when List type is Plain stack.', 'thecore-elementor-widgets')),
                ]),
            Section::make()
                ->set_label(__('Style', 'thecore-elementor-widgets'))
                ->set_items([
                    ColorControl::bind_to('text_color')
                        ->set_label(__('Text color', 'thecore-elementor-widgets')),
                    FontFamilyControl::bind_to('font_family')
                        ->set_label(__('Font family', 'thecore-elementor-widgets')),
                    Size_Control::bind_to('font_size')
                        ->set_label(__('Font size', 'thecore-elementor-widgets'))
                        ->set_units(['px', 'em', 'rem'])
                        ->set_default_unit('px')
                        ->set_disable_custom(true),
                    Select_Control::bind_to('font_weight')
                        ->set_label(__('Font weight', 'thecore-elementor-widgets'))
                        ->set_options(self::fontWeightOptions()),
                    Size_Control::bind_to('line_height')
                        ->set_label(__('Line height', 'thecore-elementor-widgets'))
                        ->set_units(['em', 'px', 'rem'])
                        ->set_default_unit('em')
                        ->set_disable_custom(true),
                    ZeroDefaultSizeControl::bind_to('letter_spacing')
                        ->set_label(__('Letter spacing', 'thecore-elementor-widgets'))
                        ->set_units(['px', 'em', 'rem'])
                        ->set_default_unit('px')
                        ->set_disable_custom(true),
                    Select_Control::bind_to('font_style')
                        ->set_label(__('Font style', 'thecore-elementor-widgets'))
                        ->set_options(self::fontStyleOptions()),
                    Select_Control::bind_to('text_decoration')
                        ->set_label(__('Text decoration', 'thecore-elementor-widgets'))
                        ->set_options(self::textDecorationOptions()),
                    Select_Control::bind_to('text_transform')
                        ->set_label(__('Text transform', 'thecore-elementor-widgets'))
                        ->set_options(self::textTransformOptions()),
                    Number_Control::bind_to('gap')
                        ->set_label(__('Gap (px)', 'thecore-elementor-widgets'))
                        ->set_min(0)
                        ->set_max(100)
                        ->set_step(1)
                        ->set_should_force_int(true),
                ]),
            Section::make()
                ->set_label(__('Settings', 'thecore-elementor-widgets'))
                ->set_id('settings')
                ->set_items([
                    Text_Control::bind_to('_cssid')
                        ->set_label(__('ID', 'thecore-elementor-widgets'))
                        ->set_meta($this->get_css_id_control_meta()),
                ]),
        ];
    }

    protected function get_templates(): array
    {
        return [
            'thecore/elements/text-list' => __DIR__ . '/text-list.html.twig',
        ];
    }

    protected function render()
    {
        $atomicSettings = $this->get_atomic_settings();
        $settings = (new DisplaySettings())->normalize($atomicSettings);
        $markup = (new MarkupBuilder())->build(
            $settings['items'],
            $settings['container_tag'],
            $settings['item_tag']
        );

        if ('' === $markup) {
            return;
        }

        $cssId = trim((string) $this->get_atomic_setting('_cssid'));
        $scope = $this->buildScopeValue();
        $scopeSelector = '[data-thecore-text-list-scope="' . $scope . '"]';
        $styleMarkup = (new InlineStylesBuilder())->build($scopeSelector, $settings);
        $classes = array_filter(array_merge(
            ['thecore-text-list', $this->get_base_styles_dictionary()['base'] ?? ''],
            is_array($atomicSettings['classes'] ?? null) ? $atomicSettings['classes'] : []
        ));
        $attributes = [
            'class' => implode(' ', array_unique($classes)),
            'data-thecore-text-list' => 'true',
            'data-thecore-text-list-scope' => $scope,
        ];

        if ('' !== $cssId) {
            $attributes['id'] = $cssId;
        }

        echo '<style>' . $styleMarkup . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo '<div' . $this->buildAttributes($attributes) . '>';
        echo $markup; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo '</div>';
    }

    /**
     * @return array<int, array{label: string, value: string}>
     */
    private static function fontWeightOptions(): array
    {
        return array_map(
            static fn (string $value): array => [
                'label' => $value,
                'value' => $value,
            ],
            self::fontWeightValues()
        );
    }

    /**
     * @return array<int, string>
     */
    private static function fontWeightValues(): array
    {
        return ['100', '200', '300', '400', '500', '600', '700', '800', '900'];
    }

    /**
     * @return array<int, array{label: string, value: string}>
     */
    private static function fontStyleOptions(): array
    {
        return [
            [
                'label' => __('Normal', 'thecore-elementor-widgets'),
                'value' => 'normal',
            ],
            [
                'label' => __('Italic', 'thecore-elementor-widgets'),
                'value' => 'italic',
            ],
            [
                'label' => __('Oblique', 'thecore-elementor-widgets'),
                'value' => 'oblique',
            ],
        ];
    }

    /**
     * @return array<int, string>
     */
    private static function fontStyleValues(): array
    {
        return ['normal', 'italic', 'oblique'];
    }

    /**
     * @return array<int, array{label: string, value: string}>
     */
    private static function textDecorationOptions(): array
    {
        return [
            [
                'label' => __('None', 'thecore-elementor-widgets'),
                'value' => 'none',
            ],
            [
                'label' => __('Underline', 'thecore-elementor-widgets'),
                'value' => 'underline',
            ],
            [
                'label' => __('Line Through', 'thecore-elementor-widgets'),
                'value' => 'line-through',
            ],
            [
                'label' => __('Overline', 'thecore-elementor-widgets'),
                'value' => 'overline',
            ],
        ];
    }

    /**
     * @return array<int, string>
     */
    private static function textDecorationValues(): array
    {
        return ['none', 'underline', 'line-through', 'overline'];
    }

    /**
     * @return array<int, array{label: string, value: string}>
     */
    private static function textTransformOptions(): array
    {
        return [
            [
                'label' => __('None', 'thecore-elementor-widgets'),
                'value' => 'none',
            ],
            [
                'label' => __('Uppercase', 'thecore-elementor-widgets'),
                'value' => 'uppercase',
            ],
            [
                'label' => __('Lowercase', 'thecore-elementor-widgets'),
                'value' => 'lowercase',
            ],
            [
                'label' => __('Capitalize', 'thecore-elementor-widgets'),
                'value' => 'capitalize',
            ],
        ];
    }

    /**
     * @return array<int, string>
     */
    private static function textTransformValues(): array
    {
        return ['none', 'uppercase', 'lowercase', 'capitalize'];
    }

    private function buildScopeValue(): string
    {
        return 'thecore-text-list-' . sanitize_html_class($this->get_id());
    }

    /**
     * @param array<string, string> $attributes
     */
    private function buildAttributes(array $attributes): string
    {
        $markup = '';

        foreach ($attributes as $name => $value) {
            $markup .= sprintf(
                ' %s="%s"',
                esc_attr($name),
                esc_attr($value)
            );
        }

        return $markup;
    }
}
