<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Admin;

use TheCore\ElementorWidgets\Contracts\Bootable;
use TheCore\ElementorWidgets\Options\OptionsRepository;
use TheCore\ElementorWidgets\Registry\FeaturesRegistry;
use TheCore\ElementorWidgets\Registry\RegistryItem;
use TheCore\ElementorWidgets\Registry\WidgetsRegistry;
use TheCore\ElementorWidgets\Support\RequirementsChecker;

final class AdminMenu implements Bootable
{
    private const WIDGETS_PAGE = 'thecore-elementor-widgets';
    private const FEATURES_PAGE = 'thecore-elementor-features';

    public function __construct(
        private readonly WidgetsRegistry $widgetsRegistry,
        private readonly FeaturesRegistry $featuresRegistry,
        private readonly OptionsRepository $optionsRepository,
        private readonly RequirementsChecker $requirementsChecker
    ) {
    }

    public function register(): void
    {
        add_action('admin_menu', [$this, 'registerMenu']);
        add_action('admin_post_thecore_elementor_widgets_save_widgets', [$this, 'handleWidgetsSave']);
        add_action('admin_post_thecore_elementor_widgets_save_features', [$this, 'handleFeaturesSave']);
    }

    public function registerMenu(): void
    {
        add_menu_page(
            __('The Core - Widgets', 'thecore-elementor-widgets'),
            __('The Core - Widgets', 'thecore-elementor-widgets'),
            'manage_options',
            self::WIDGETS_PAGE,
            [$this, 'renderWidgetsPage'],
            'dashicons-screenoptions',
            58
        );

        add_submenu_page(
            self::WIDGETS_PAGE,
            __('Widgets', 'thecore-elementor-widgets'),
            __('Widgets', 'thecore-elementor-widgets'),
            'manage_options',
            self::WIDGETS_PAGE,
            [$this, 'renderWidgetsPage']
        );

        add_submenu_page(
            self::WIDGETS_PAGE,
            __('Features', 'thecore-elementor-widgets'),
            __('Features', 'thecore-elementor-widgets'),
            'manage_options',
            self::FEATURES_PAGE,
            [$this, 'renderFeaturesPage']
        );
    }

    public function renderWidgetsPage(): void
    {
        $state = $this->optionsRepository->getWidgetsState($this->widgetsRegistry->defaults());

        $this->renderPage(
            self::WIDGETS_PAGE,
            __('Widgets', 'thecore-elementor-widgets'),
            __('Active ou désactive les widgets disponibles dans The Core - Elementor Widgets.', 'thecore-elementor-widgets'),
            $this->widgetsRegistry->all(),
            $state,
            'thecore_elementor_widgets_save_widgets',
            'thecore_elementor_widgets_save_widgets'
        );
    }

    public function renderFeaturesPage(): void
    {
        $state = $this->optionsRepository->getFeaturesState($this->featuresRegistry->defaults());

        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('You are not allowed to access this page.', 'thecore-elementor-widgets'));
        }

        ?>
        <div class="wrap thecore-admin">
            <h1><?php echo esc_html__('Features', 'thecore-elementor-widgets'); ?></h1>
            <p class="thecore-admin__intro">
                <?php esc_html_e('Active ou désactive les fonctionnalités globales qui peuvent enrichir plusieurs widgets.', 'thecore-elementor-widgets'); ?>
            </p>
            <?php $this->renderTabs(self::FEATURES_PAGE); ?>
            <?php $this->renderUpdatedNotice(self::FEATURES_PAGE); ?>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="thecore-admin__form">
                <input type="hidden" name="action" value="thecore_elementor_widgets_save_features">
                <?php wp_nonce_field('thecore_elementor_widgets_save_features'); ?>

                <div class="thecore-admin__cards">
                    <?php foreach ($this->featuresRegistry->all() as $item) : ?>
                        <?php $this->renderItemCard($item, $state); ?>
                    <?php endforeach; ?>
                </div>

                <p class="submit">
                    <button type="submit" class="button button-primary">
                        <?php esc_html_e('Save changes', 'thecore-elementor-widgets'); ?>
                    </button>
                </p>
            </form>
        </div>
        <?php
    }

    public function handleWidgetsSave(): void
    {
        $this->guardRequest('thecore_elementor_widgets_save_widgets');

        $submittedState = isset($_POST['state']) && is_array($_POST['state']) ? wp_unslash($_POST['state']) : [];

        $this->optionsRepository->saveWidgetsState($submittedState, $this->widgetsRegistry->defaults());

        $this->redirect(self::WIDGETS_PAGE);
    }

    public function handleFeaturesSave(): void
    {
        $this->guardRequest('thecore_elementor_widgets_save_features');

        $submittedState = isset($_POST['state']) && is_array($_POST['state']) ? wp_unslash($_POST['state']) : [];

        $this->optionsRepository->saveFeaturesState($submittedState, $this->featuresRegistry->defaults());

        $this->redirect(self::FEATURES_PAGE);
    }

    /**
     * @param array<string, RegistryItem> $items
     * @param array<string, int>          $state
     */
    private function renderPage(
        string $currentPage,
        string $title,
        string $description,
        array $items,
        array $state,
        string $nonceAction,
        string $formAction
    ): void {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('You are not allowed to access this page.', 'thecore-elementor-widgets'));
        }

        ?>
        <div class="wrap thecore-admin">
            <h1><?php echo esc_html($title); ?></h1>
            <p class="thecore-admin__intro"><?php echo esc_html($description); ?></p>
            <?php $this->renderTabs($currentPage); ?>
            <?php $this->renderUpdatedNotice($currentPage); ?>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="thecore-admin__form">
                <input type="hidden" name="action" value="<?php echo esc_attr($formAction); ?>">
                <?php wp_nonce_field($nonceAction); ?>

                <div class="thecore-admin__cards">
                    <?php foreach ($items as $item) : ?>
                        <?php $this->renderItemCard($item, $state); ?>
                    <?php endforeach; ?>
                </div>

                <p class="submit">
                    <button type="submit" class="button button-primary">
                        <?php esc_html_e('Save changes', 'thecore-elementor-widgets'); ?>
                    </button>
                </p>
            </form>
        </div>
        <?php
    }

    private function renderTabs(string $currentPage): void
    {
        $tabs = [
            self::WIDGETS_PAGE => __('Widgets', 'thecore-elementor-widgets'),
            self::FEATURES_PAGE => __('Features', 'thecore-elementor-widgets'),
        ];

        echo '<nav class="nav-tab-wrapper">';

        foreach ($tabs as $page => $label) {
            $activeClass = $currentPage === $page ? ' nav-tab-active' : '';

            printf(
                '<a href="%1$s" class="nav-tab%2$s">%3$s</a>',
                esc_url(admin_url('admin.php?page=' . $page)),
                esc_attr($activeClass),
                esc_html($label)
            );
        }

        echo '</nav>';
    }

    /**
     * @param array<string, int> $state
     */
    private function renderItemCard(RegistryItem $item, array $state): void
    {
        $itemId = $item->id();
        $isEnabled = ! empty($state[$itemId]);
        $requiresAtomicWarning = in_array($itemId, ['classic-menu', 'marquee-carousel', 'text-list'], true)
            && ! $this->requirementsChecker->canRegisterAtomicWidgets();
        ?>
        <section class="thecore-admin__card">
            <div class="thecore-admin__card-content">
                <h2><?php echo esc_html($item->title()); ?></h2>
                <p><?php echo esc_html($item->description()); ?></p>
                <?php if ($requiresAtomicWarning) : ?>
                    <p class="thecore-admin__warning">
                        <?php
                        echo esc_html(
                            sprintf(
                                /* translators: %s: Elementor experiment key. */
                                __('Requires Elementor Atomic experiment `%s` to be active before registration.', 'thecore-elementor-widgets'),
                                $this->requirementsChecker->atomicExperimentName()
                            )
                        );
                        ?>
                    </p>
                <?php endif; ?>
            </div>

            <label class="thecore-admin__switch">
                <input type="hidden" name="state[<?php echo esc_attr($itemId); ?>]" value="0">
                <input
                    type="checkbox"
                    name="state[<?php echo esc_attr($itemId); ?>]"
                    value="1"
                    <?php checked($isEnabled); ?>
                >
                <span class="thecore-admin__slider" aria-hidden="true"></span>
                <span class="screen-reader-text">
                    <?php
                    printf(
                        /* translators: %s: item title. */
                        esc_html__('Toggle %s', 'thecore-elementor-widgets'),
                        esc_html($item->title())
                    );
                    ?>
                </span>
            </label>
        </section>
        <?php
    }

    private function renderUpdatedNotice(string $page): void
    {
        $updated = isset($_GET['updated']) ? sanitize_key((string) $_GET['updated']) : '';
        $currentPage = isset($_GET['page']) ? sanitize_key((string) $_GET['page']) : '';

        if ('1' !== $updated || $currentPage !== $page) {
            return;
        }

        printf(
            '<div class="notice notice-success"><p>%s</p></div>',
            esc_html__('Settings saved.', 'thecore-elementor-widgets')
        );
    }

    private function guardRequest(string $nonceAction): void
    {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('You are not allowed to perform this action.', 'thecore-elementor-widgets'));
        }

        check_admin_referer($nonceAction);
    }

    private function redirect(string $page): void
    {
        wp_safe_redirect(
            add_query_arg(
                [
                    'page' => $page,
                    'updated' => '1',
                ],
                admin_url('admin.php')
            )
        );

        exit;
    }
}
