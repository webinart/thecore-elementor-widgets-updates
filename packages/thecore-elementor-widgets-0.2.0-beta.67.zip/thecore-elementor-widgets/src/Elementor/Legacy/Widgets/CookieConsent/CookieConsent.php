<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Legacy\Widgets\CookieConsent;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;
use TheCore\ElementorWidgets\Assets\FrontendAssets;
use TheCore\ElementorWidgets\CookieConsent\ConfigRepository;
use TheCore\ElementorWidgets\CookieConsent\CookieConsentModule;

final class CookieConsent extends Widget_Base
{
    public function get_name(): string
    {
        return 'thecore-cookie-consent';
    }

    public function get_title(): string
    {
        return __('Cookie Consent Module', 'thecore-elementor-widgets');
    }

    public function get_icon(): string
    {
        return 'eicon-lock-user';
    }

    public function get_categories(): array
    {
        return ['general'];
    }

    public function get_keywords(): array
    {
        return ['cookie', 'consent', 'gdpr', 'privacy', 'banner', 'the core'];
    }

    public function get_style_depends(): array
    {
        return [FrontendAssets::COOKIE_CONSENT_STYLE];
    }

    public function get_script_depends(): array
    {
        return [FrontendAssets::COOKIE_CONSENT_SCRIPT];
    }

    protected function register_controls(): void
    {
        $this->start_controls_section(
            'section_module',
            [
                'label' => __('Module', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'module_notice',
            [
                'type' => Controls_Manager::RAW_HTML,
                'raw' => esc_html__(
                    'This widget renders the consent banner directly. Disable the global theme cookie module on the same site to avoid duplicate banners.',
                    'thecore-elementor-widgets'
                ),
                'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
            ]
        );

        $this->add_control(
            'theme_preset',
            [
                'label' => __('Preset', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SELECT,
                'default' => CookieConsentModule::DEFAULT_THEME_PRESET,
                'options' => [
                    'default' => __('Default', 'thecore-elementor-widgets'),
                    'labs' => __('Labs', 'thecore-elementor-widgets'),
                    'sidecar' => __('Sidecar', 'thecore-elementor-widgets'),
                    'lowkey' => __('Low-key', 'thecore-elementor-widgets'),
                ],
            ]
        );

        $this->add_control(
            'preview_notice',
            [
                'label' => __('Preview', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::RAW_HTML,
                'raw' => esc_html__(
                    'These controls are preview-only. The real cookie categories and module behavior stay in Cookies > Config.',
                    'thecore-elementor-widgets'
                ),
                'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
            ]
        );

        $this->add_control(
            'preview_show_category_descriptions',
            [
                'label' => __('Show category descriptions in preview', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'thecore-elementor-widgets'),
                'label_off' => __('No', 'thecore-elementor-widgets'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        foreach (DisplaySettings::DEFAULT_CATEGORY_SETTINGS as $slug => $definition) {
            $this->add_control(
                'preview_' . $slug,
                [
                    'label' => sprintf(
                        __('Show %s in preview', 'thecore-elementor-widgets'),
                        (string) $definition['label']
                    ),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => __('Yes', 'thecore-elementor-widgets'),
                    'label_off' => __('No', 'thecore-elementor-widgets'),
                    'return_value' => 'yes',
                    'default' => 'yes',
                ]
            );
        }

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_panel',
            [
                'label' => __('Panel', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'panel_width',
            [
                'label' => __('Panel Width', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'vw'],
                'range' => [
                    'px' => [
                        'min' => 280,
                        'max' => 720,
                    ],
                    'vw' => [
                        'min' => 30,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc' => '--thecore-cc-panel-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'overlay_background',
            [
                'label' => __('Overlay Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc' => '--thecore-cc-overlay: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'accent_color',
            [
                'label' => __('Accent Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc' => '--thecore-cc-accent: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'panel_background',
                'selector' => '{{WRAPPER}} .thecore-cc__container',
            ]
        );

        $this->add_control(
            'panel_text_color',
            [
                'label' => __('Text Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc__container' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'panel_border',
                'selector' => '{{WRAPPER}} .thecore-cc__container',
            ]
        );

        $this->add_responsive_control(
            'panel_border_radius',
            [
                'label' => __('Border Radius', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc__container' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'panel_shadow',
                'selector' => '{{WRAPPER}} .thecore-cc__container',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_notice',
            [
                'label' => __('Notice Text', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'notice_text_color',
            [
                'label' => __('Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc__text' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'notice_typography',
                'selector' => '{{WRAPPER}} .thecore-cc__text',
            ]
        );

        $this->add_responsive_control(
            'notice_alignment',
            [
                'label' => __('Alignment', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc__text' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_categories',
            [
                'label' => __('Categories', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'category_label_color',
            [
                'label' => __('Label Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc__category label' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'category_label_typography',
                'selector' => '{{WRAPPER}} .thecore-cc__category label',
            ]
        );

        $this->add_control(
            'category_description_color',
            [
                'label' => __('Description Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc__category-description' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'category_description_typography',
                'selector' => '{{WRAPPER}} .thecore-cc__category-description',
            ]
        );

        $this->add_responsive_control(
            'categories_text_alignment',
            [
                'label' => __('Content Alignment', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc__category' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'categories_inline_alignment',
            [
                'label' => __('Inline Row Alignment', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => __('Left', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'flex-end' => [
                        'title' => __('Right', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc__categories--inline' => 'justify-content: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'category_background',
            [
                'label' => __('Card Background', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc' => '--thecore-cc-category-background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'category_border_color',
            [
                'label' => __('Card Border', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc' => '--thecore-cc-category-border: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_buttons',
            [
                'label' => __('Buttons', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'selector' => '{{WRAPPER}} .thecore-cc__button',
            ]
        );

        $this->add_responsive_control(
            'buttons_alignment',
            [
                'label' => __('Alignment', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => __('Left', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'flex-end' => [
                        'title' => __('Right', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc__buttons' => 'justify-content: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_background_color',
            [
                'label' => __('Background', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc' => '--thecore-cc-button-background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_text_color',
            [
                'label' => __('Text Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc' => '--thecore-cc-button-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_border_color',
            [
                'label' => __('Border Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc' => '--thecore-cc-button-border: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_border_radius',
            [
                'label' => __('Border Radius', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc__button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'primary_button_heading',
            [
                'label' => __('Primary Button', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'primary_button_background_color',
            [
                'label' => __('Background', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc' => '--thecore-cc-primary-background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'primary_button_text_color',
            [
                'label' => __('Text Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc' => '--thecore-cc-primary-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'primary_button_border_color',
            [
                'label' => __('Border Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc' => '--thecore-cc-primary-border: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render(): void
    {
        $settings = $this->get_settings_for_display();
        $displaySettings = new DisplaySettings();
        $presentationSettings = $displaySettings->normalizePresentation($settings);
        $configRepository = new ConfigRepository();
        $moduleConfig = $configRepository->active();
        $editorPreview = $this->shouldForceModuleVisible();
        $initiallyVisible = $editorPreview || ! CookieConsentModule::hasConsentCookie();

        $moduleConfig['theme_preset'] = $presentationSettings['theme_preset'];

        if ($editorPreview) {
            $moduleConfig['show_category_descriptions'] = $presentationSettings['preview_show_category_descriptions'];
            $moduleConfig['categories'] = $this->applyPreviewCategoryVisibility(
                is_array($moduleConfig['categories'] ?? null) ? $moduleConfig['categories'] : [],
                $presentationSettings['preview_categories']
            );
        }

        $rootId = 'thecore-cc-' . $this->get_id();

        if ($initiallyVisible) {
            echo $this->renderInitialVisibilityGuardStyle($this->get_id());
        }

        echo $this->renderPresetDefaultsStyle($rootId, $presentationSettings['theme_preset']);

        echo CookieConsentModule::renderModule(
            array_merge(
                $moduleConfig,
                [
                    'id' => $rootId,
                    'editor_preview' => $editorPreview,
                ]
            )
        );
    }

    private function renderInitialVisibilityGuardStyle(string $widgetId): string
    {
        $widgetSelector = sprintf(
            'html.thecore-anim-engine [data-id="%1$s"]',
            esc_attr($widgetId)
        );

        $css = $widgetSelector
            . '.thecore-entrance-anim--pending[data-thecore-anim-trigger="load"]{'
            . 'opacity:1!important;'
            . 'transform:none!important;'
            . '-webkit-transform:none!important;'
            . 'animation:none!important;'
            . '-webkit-animation:none!important;'
            . 'will-change:auto!important;'
            . '}';

        return sprintf("<style>%s</style>\n", $css);
    }

    private function renderPresetDefaultsStyle(string $rootId, string $themePreset): string
    {
        $selector = ':where(#' . sanitize_html_class($rootId) . ')';
        $presetSelector = $selector . '.thecore-cc--theme-' . $themePreset;
        $css = [];

        $css[] = $selector . '{'
            . '--thecore-cc-overlay:rgba(0,0,0,0.36);'
            . '--thecore-cc-panel-width:440px;'
            . '--thecore-cc-panel-background:#ffffff;'
            . '--thecore-cc-panel-color:#111111;'
            . '--thecore-cc-panel-radius:20px;'
            . '--thecore-cc-panel-padding:24px;'
            . '--thecore-cc-panel-shadow:0 24px 80px rgba(0,0,0,0.18);'
            . '--thecore-cc-accent:#47c17c;'
            . '--thecore-cc-category-background:rgba(255,255,255,0.04);'
            . '--thecore-cc-category-border:rgba(17,17,17,0.12);'
            . '--thecore-cc-button-background:#f5f5f5;'
            . '--thecore-cc-button-color:#202020;'
            . '--thecore-cc-button-border:rgba(17,17,17,0.12);'
            . '--thecore-cc-primary-background:var(--thecore-cc-accent);'
            . '--thecore-cc-primary-color:#ffffff;'
            . '--thecore-cc-primary-border:var(--thecore-cc-accent);'
            . '--thecore-cc-category-label-weight:700;'
            . '--thecore-cc-button-radius:999px;'
            . '--thecore-cc-accept-button-weight:700;'
            . '}';

        switch ($themePreset) {
            case 'default':
                $css[] = $presetSelector . '{top:auto;right:0;bottom:0;left:0;padding:0;font-size:smaller;}';
                $css[] = $selector . '{'
                    . '--thecore-cc-overlay:transparent;'
                    . '--thecore-cc-viewport-gap:0px;'
                    . '--thecore-cc-panel-background:#23282d;'
                    . '--thecore-cc-panel-color:#ffffff;'
                    . '--thecore-cc-button-background:transparent;'
                    . '--thecore-cc-button-color:currentColor;'
                    . '--thecore-cc-button-border:currentColor;'
                    . '--thecore-cc-primary-background:transparent;'
                    . '--thecore-cc-primary-color:currentColor;'
                    . '--thecore-cc-primary-border:currentColor;'
                    . '--thecore-cc-category-background:transparent;'
                    . '--thecore-cc-category-border:transparent;'
                    . '--thecore-cc-panel-radius:0px;'
                    . '--thecore-cc-panel-shadow:none;'
                    . '--thecore-cc-root-padding:0px;'
                    . '--thecore-cc-container-width:100vw;'
                    . '--thecore-cc-container-max-height:none;'
                    . '--thecore-cc-container-padding:15px 30px;'
                    . '--thecore-cc-category-label-weight:400;'
                    . '--thecore-cc-button-radius:3px;'
                    . '--thecore-cc-text-align:center;'
                    . '--thecore-cc-category-text-align:center;'
                    . '--thecore-cc-categories-inline-justify:center;'
                    . '--thecore-cc-buttons-justify:center;'
                    . '}';
                $css[] = $presetSelector . ' .thecore-cc__text{margin-bottom:10px;}';
                $css[] = $presetSelector . ' .thecore-cc__categories{margin-top:0;}';
                $css[] = $presetSelector . ' .thecore-cc__category{padding:0;}';
                $css[] = $presetSelector . ' .thecore-cc__categories--inline .thecore-cc__category{display:inline-block;margin-right:20px;}';
                $css[] = $presetSelector . ' .thecore-cc__category input{position:static;opacity:1;pointer-events:auto;vertical-align:middle;}';
                $css[] = $presetSelector . ' .thecore-cc__category label{display:inline-block;padding-left:10px;vertical-align:middle;}';
                $css[] = $presetSelector . ' .thecore-cc__category label::before,' . $presetSelector . ' .thecore-cc__category label::after{content:none;display:none;}';
                $css[] = $presetSelector . ' .thecore-cc__category-description{margin:0 0 20px;opacity:.66;}';
                $css[] = $presetSelector . ' .thecore-cc__button{display:inline-block;min-height:0;margin:5px;padding:5px 15px;transform:none;}';
                $css[] = $presetSelector . ' .thecore-cc__button:hover,' . $presetSelector . ' .thecore-cc__button:focus-visible{box-shadow:inset 0 0 0 999px rgba(255,255,255,.1);}';

                break;

            case 'labs':
                $css[] = $selector . '{'
                    . '--thecore-cc-overlay:rgba(0,0,0,0.72);'
                    . '--thecore-cc-panel-width:520px;'
                    . '}';
                $css[] = $presetSelector . '{backdrop-filter:blur(2px);}';

                break;

            case 'sidecar':
                $css[] = $selector . '{'
                    . '--thecore-cc-panel-radius:0px;'
                    . '--thecore-cc-root-justify-content:flex-start;'
                    . '--thecore-cc-root-align-items:stretch;'
                    . '--thecore-cc-root-padding:0px;'
                    . '--thecore-cc-container-height:100vh;'
                    . '--thecore-cc-container-max-height:100vh;'
                    . '--thecore-cc-container-width:100vw;'
                    . '}';
                $css[] = '@media (min-width:768px){' . $selector . '{--thecore-cc-container-width:min(var(--thecore-cc-panel-width),88vw);}}';

                break;

            case 'lowkey':
                $css[] = $selector . '{'
                    . '--thecore-cc-overlay:transparent;'
                    . '--thecore-cc-panel-width:360px;'
                    . '--thecore-cc-root-justify-content:flex-start;'
                    . '--thecore-cc-root-align-items:flex-end;'
                    . '}';

                break;
        }

        return sprintf("<style>%s</style>\n", implode('', $css));
    }

    /**
     * @param array<int, array{slug?: string, active?: bool}> $categories
     * @param array<string, bool> $previewCategories
     *
     * @return array<int, array<string, mixed>>
     */
    private function applyPreviewCategoryVisibility(array $categories, array $previewCategories): array
    {
        $adjusted = [];

        foreach ($categories as $category) {
            if (! is_array($category)) {
                continue;
            }

            $slug = isset($category['slug']) && is_string($category['slug']) ? $category['slug'] : '';

            if ($slug !== '' && array_key_exists($slug, $previewCategories)) {
                $category['active'] = $previewCategories[$slug];
            }

            $adjusted[] = $category;
        }

        return $adjusted;
    }

    private function shouldForceModuleVisible(): bool
    {
        if (! class_exists(\Elementor\Plugin::class) || ! isset(\Elementor\Plugin::$instance)) {
            return false;
        }

        try {
            $plugin = \Elementor\Plugin::$instance;

            if (
                isset($plugin->editor)
                && is_object($plugin->editor)
                && method_exists($plugin->editor, 'is_edit_mode')
                && $plugin->editor->is_edit_mode()
            ) {
                return true;
            }

            if (
                isset($plugin->preview)
                && is_object($plugin->preview)
                && method_exists($plugin->preview, 'is_preview_mode')
            ) {
                return (bool) $plugin->preview->is_preview_mode();
            }
        } catch (\Throwable $exception) {
            return false;
        }

        return false;
    }
}
