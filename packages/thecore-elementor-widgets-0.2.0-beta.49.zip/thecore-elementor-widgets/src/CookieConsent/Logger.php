<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\CookieConsent;

final class Logger
{
    public const POST_TYPE = 'cookie_consent';
    public const PURGER_HOOK = 'thecore_cookie_consent_purger';

    public function __construct(
        private readonly ConfigRepository $configRepository,
        private readonly Helper $helper
    ) {
    }

    public function registerHooks(): void
    {
        add_action('init', [$this, 'registerPostType'], 151);
        add_action('init', [$this, 'setupAutoPurger'], 152);
        add_action(self::PURGER_HOOK, [$this, 'autoPurgeConsents']);

        add_action('wp_ajax_save_cookie_consent', [$this, 'ajaxSaveCookieConsent']);
        add_action('wp_ajax_nopriv_save_cookie_consent', [$this, 'ajaxSaveCookieConsent']);

        add_filter('manage_' . self::POST_TYPE . '_posts_columns', [$this, 'setPostListColumnHeader']);
        add_action('manage_' . self::POST_TYPE . '_posts_custom_column', [$this, 'setPostListColumnContent'], 10, 2);
        add_action('admin_init', [$this, 'manageAdminViews']);
    }

    public function registerPostType(): void
    {
        register_post_type(
            self::POST_TYPE,
            [
                'label' => __('Cookie Consents', 'thecore-elementor-widgets'),
                'labels' => [
                    'edit_item' => __('View Cookie Consent', 'thecore-elementor-widgets'),
                    'search_items' => __('Search Consents', 'thecore-elementor-widgets'),
                    'not_found' => __('No consents found.', 'thecore-elementor-widgets'),
                    'not_found_in_trash' => __('No consents found in Trash.', 'thecore-elementor-widgets'),
                ],
                'public' => false,
                'publicly_queryable' => false,
                'exclude_from_search' => true,
                'show_ui' => true,
                'query_var' => false,
                'menu_position' => 99,
                'show_in_menu' => 'thecore-elementor-widgets',
                'show_in_nav_menus' => false,
                'show_in_admin_bar' => false,
                'rewrite' => false,
                'has_archive' => false,
                'capability_type' => 'post',
                'capabilities' => [
                    'create_posts' => false,
                ],
                'map_meta_cap' => true,
                'show_in_rest' => false,
                'hierarchical' => false,
                'supports' => ['title'],
            ]
        );
    }

    /**
     * @return array<string, string>
     */
    public function setPostListColumnHeader(array $columns): array
    {
        $date = $columns['date'] ?? '';
        unset($columns['date']);

        $columns['title'] = __('UUID', 'thecore-elementor-widgets');
        $columns['cookie_categories'] = __('Cookie Categories', 'thecore-elementor-widgets');

        if ('' !== $date) {
            $columns['date'] = $date;
        }

        return $columns;
    }

    public function setPostListColumnContent(string $column, int $postId): void
    {
        if ('cookie_categories' !== $column) {
            return;
        }

        echo esc_html($this->helper->prettyPrintLoggedCategories($postId));
    }

    public function ajaxSaveCookieConsent(): void
    {
        if (! $this->isLoggingEnabled()) {
            wp_send_json_error(['message' => 'logging_disabled'], 403);
        }

        if (! (defined('WP_CACHE') && WP_CACHE)) {
            check_ajax_referer('thecore_cookie_consent', 'nonce');
        }

        $uuid = isset($_POST['uuid']) ? sanitize_text_field(wp_unslash((string) $_POST['uuid'])) : '';
        $categories = isset($_POST['categories']) ? wp_unslash($_POST['categories']) : [];

        if (! is_array($categories)) {
            $categories = [];
        }

        $allowedCategories = [];

        foreach ($categories as $category) {
            if (! is_scalar($category)) {
                continue;
            }

            $allowedCategories[] = sanitize_key((string) $category);
        }

        $this->addCookieConsentLog(
            $uuid,
            $allowedCategories,
            isset($_SERVER['REMOTE_ADDR']) ? (string) $_SERVER['REMOTE_ADDR'] : '',
            isset($_SERVER['HTTP_USER_AGENT']) ? (string) $_SERVER['HTTP_USER_AGENT'] : ''
        );

        wp_send_json_success(['message' => 'saved']);
    }

    /**
     * @param string[] $categories
     */
    public function addCookieConsentLog(
        string $uuid,
        array $categories,
        string $remoteAddress,
        string $httpUserAgent
    ): void {
        $config = $this->configRepository->active();
        $storedCategories = $this->helper->filterAllowedCookieCategories($categories);

        wp_insert_post(
            [
                'post_type' => self::POST_TYPE,
                'post_status' => 'publish',
                'post_title' => wp_strip_all_tags($uuid),
                'meta_input' => [
                    'uuid' => wp_strip_all_tags($uuid),
                    'categories' => serialize($storedCategories),
                    'remote_addr' => ! empty($config['anonymize_consent_log_ips']) && '' !== $remoteAddress
                        ? wp_privacy_anonymize_ip($remoteAddress)
                        : $remoteAddress,
                    'http_user_agent' => sanitize_text_field($httpUserAgent),
                ],
            ]
        );
    }

    public function manageAdminViews(): void
    {
        $postType = '';

        if (isset($_GET['post']) && ! empty($_GET['post'])) {
            $postType = get_post_type((int) $_GET['post']) ?: '';
        }

        if (isset($_GET['post_type']) && is_string($_GET['post_type'])) {
            $postType = sanitize_key(wp_unslash($_GET['post_type']));
        }

        if (self::POST_TYPE !== $postType) {
            return;
        }

        add_filter('post_row_actions', [$this, 'consentPostRowActions'], 10, 2);
        add_filter('bulk_actions-edit-' . self::POST_TYPE, [$this, 'consentBulkActions']);
        add_action('transition_post_status', [$this, 'consentUntrashStatus'], 10, 3);
        add_action('in_admin_header', [$this, 'consentScreenLayout']);
        add_action('edit_form_after_title', [$this, 'consentTitleJs'], 100);
        add_action('add_meta_boxes', [$this, 'consentMetaBoxes']);
    }

    /**
     * @param array<string, string> $actions
     *
     * @return array<string, string>
     */
    public function consentPostRowActions(array $actions, \WP_Post $post): array
    {
        unset($actions['inline hide-if-no-js'], $actions['edit']);

        if (isset($actions['trash'])) {
            $trashAction = $actions['trash'];
            unset($actions['trash']);
            $actions['view'] = sprintf(
                '<a href="%s" title="%s">%s</a>',
                esc_url((string) get_edit_post_link($post->ID)),
                esc_attr__('View', 'thecore-elementor-widgets'),
                esc_html__('View', 'thecore-elementor-widgets')
            );
            $actions['trash'] = $trashAction;
        }

        return $actions;
    }

    /**
     * @param array<string, string> $actions
     *
     * @return array<string, string>
     */
    public function consentBulkActions(array $actions): array
    {
        unset($actions['edit']);

        return $actions;
    }

    public function consentUntrashStatus(string $newStatus, string $oldStatus, \WP_Post $post): void
    {
        if ('trash' === $oldStatus && 'draft' === $newStatus && self::POST_TYPE === $post->post_type) {
            wp_update_post(
                [
                    'ID' => $post->ID,
                    'post_status' => 'publish',
                ]
            );
        }
    }

    public function consentScreenLayout(): void
    {
        add_screen_option(
            'layout_columns',
            [
                'max' => 1,
                'default' => 1,
            ]
        );
    }

    public function consentTitleJs(): void
    {
        echo '<script>var title=document.getElementById("title");if(title){title.setAttribute("readonly","readonly");}</script>';
    }

    public function consentMetaBoxes(): void
    {
        remove_meta_box('submitdiv', self::POST_TYPE, 'side');
        remove_meta_box('postcustom', self::POST_TYPE, 'normal');

        add_meta_box(
            'thecore-cookie-consent-data',
            __('Consent Data', 'thecore-elementor-widgets'),
            [$this, 'renderConsentAdminView'],
            self::POST_TYPE
        );
    }

    public function renderConsentAdminView(): void
    {
        $postId = get_the_ID();

        if (! is_int($postId)) {
            return;
        }

        ?>
        <table class="cookie-notice-consent__consent-data-table">
            <tr>
                <td><?php esc_html_e('UUID', 'thecore-elementor-widgets'); ?></td>
                <td><?php echo esc_html((string) get_post_meta($postId, 'uuid', true)); ?></td>
            </tr>
            <tr>
                <td><?php esc_html_e('Date/Time', 'thecore-elementor-widgets'); ?></td>
                <td><?php echo esc_html(get_the_date((string) get_option('date_format'), $postId) . ' ' . get_the_time((string) get_option('time_format'), $postId)); ?></td>
            </tr>
            <tr>
                <td><?php esc_html_e('Remote Address', 'thecore-elementor-widgets'); ?></td>
                <td><?php echo esc_html((string) get_post_meta($postId, 'remote_addr', true)); ?></td>
            </tr>
            <tr>
                <td><?php esc_html_e('HTTP User Agent', 'thecore-elementor-widgets'); ?></td>
                <td><?php echo esc_html((string) get_post_meta($postId, 'http_user_agent', true)); ?></td>
            </tr>
            <tr>
                <td><?php esc_html_e('Cookie Categories', 'thecore-elementor-widgets'); ?></td>
                <td><?php echo esc_html($this->helper->prettyPrintLoggedCategories($postId)); ?></td>
            </tr>
        </table>
        <?php
    }

    public function setupAutoPurger(): void
    {
        $config = $this->configRepository->active();
        $shouldPurge = $this->isLoggingEnabled() && ! empty($config['auto_purge_consents']);

        if ($shouldPurge) {
            if (! wp_next_scheduled(self::PURGER_HOOK)) {
                wp_schedule_event(time(), 'twicedaily', self::PURGER_HOOK);
            }

            return;
        }

        if (wp_next_scheduled(self::PURGER_HOOK)) {
            wp_clear_scheduled_hook(self::PURGER_HOOK);
        }
    }

    public function autoPurgeConsents(): void
    {
        $config = $this->configRepository->active();
        $olderThan = is_string($config['auto_purge_consents_interval'] ?? null)
            ? (string) $config['auto_purge_consents_interval']
            : CookieConsentModule::DEFAULT_AUTO_PURGE_INTERVAL;

        $toPurge = get_posts(
            [
                'post_type' => self::POST_TYPE,
                'posts_per_page' => -1,
                'fields' => 'ids',
                'date_query' => [
                    [
                        'before' => $olderThan . ' ago',
                    ],
                ],
            ]
        );

        foreach ($toPurge as $postId) {
            wp_trash_post((int) $postId);
        }
    }

    private function isLoggingEnabled(): bool
    {
        return ! empty($this->configRepository->active()['log_consents']);
    }
}
