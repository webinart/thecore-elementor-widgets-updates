(function (window, document) {
    'use strict';

    var config = window.TheCoreElementorWidgetsCookieConsentConfig || {};
    var cookieName = typeof config.cookieName === 'string' && config.cookieName !== ''
        ? config.cookieName
        : 'cookie_consent';
    var secure = !!config.secure;
    var initializedAttribute = 'data-thecore-cc-ready';
    var observer = null;
    var refreshQueued = false;

    function generateUUIDv4() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (character) {
            var random = Math.random() * 16 | 0;
            var value = character === 'x' ? random : ((random & 0x3) | 0x8);
            return value.toString(16);
        });
    }

    function setBodyClasses(classes) {
        if (!document.body) {
            return;
        }

        document.body.classList.remove('thecore-cc-set');
        document.body.classList.remove('thecore-cc-not-set');

        for (var index = 0; index < classes.length; index += 1) {
            document.body.classList.add(classes[index]);
        }
    }

    function readCookie(name) {
        var nameEq = name + '=';
        var cookies = document.cookie.split(';');

        for (var index = 0; index < cookies.length; index += 1) {
            var cookie = cookies[index];

            while (cookie.charAt(0) === ' ') {
                cookie = cookie.substring(1, cookie.length);
            }

            if (cookie.indexOf(nameEq) === 0) {
                return cookie.substring(nameEq.length, cookie.length);
            }
        }

        return null;
    }

    function hasConsentCookie() {
        return readCookie(cookieName) !== null;
    }

    function setCookie(name, value, days) {
        var expires = '';

        if (days) {
            var date = new Date();
            date.setTime(parseInt(date.getTime(), 10) + (days * 24 * 60 * 60 * 1000));
            expires = '; expires=' + date.toUTCString();
        }

        document.cookie = name
            + '=' + JSON.stringify(value)
            + expires
            + '; path=/; SameSite=Lax; '
            + (secure ? 'Secure;' : '');
    }

    function eraseCookie(name) {
        setCookie(name, '', -1);
    }

    function eraseAllCookies() {
        var cookies = document.cookie.split(';');

        for (var index = 0; index < cookies.length; index += 1) {
            var name = cookies[index].split('=')[0].trim();

            if (name.indexOf('wordpress') === 0 || name.indexOf('wp-settings') === 0) {
                continue;
            }

            eraseCookie(name);
        }
    }

    function showInstance(root) {
        root.classList.remove('thecore-cc--hidden');
        root.classList.add('thecore-cc--visible');
        root.removeAttribute('aria-hidden');
    }

    function releaseFocusWithin(root) {
        var activeElement = document.activeElement;

        if (!activeElement || !root.contains(activeElement)) {
            return;
        }

        if (typeof activeElement.blur === 'function') {
            activeElement.blur();
        }
    }

    function hideInstance(root) {
        releaseFocusWithin(root);
        root.classList.remove('thecore-cc--visible');
        root.classList.add('thecore-cc--hidden');
        root.removeAttribute('aria-hidden');
        root.classList.remove('thecore-cc--loading');
    }

    function getInstances() {
        return document.querySelectorAll('[data-thecore-cc="1"]');
    }

    function hideAllInstances() {
        var instances = getInstances();

        for (var index = 0; index < instances.length; index += 1) {
            hideInstance(instances[index]);
        }
    }

    function syncVisibleState() {
        var instances = getInstances();
        var consentSet = hasConsentCookie();

        for (var index = 0; index < instances.length; index += 1) {
            var root = instances[index];
            var editorPreview = root.getAttribute('data-thecore-editor-preview') === '1';

            if (editorPreview || !consentSet) {
                showInstance(root);
            } else {
                hideInstance(root);
            }
        }

        setBodyClasses([consentSet ? 'thecore-cc-set' : 'thecore-cc-not-set']);
    }

    function collectAcceptedCategories(root, mode) {
        var selector = '.thecore-cc__category input[type="checkbox"]';

        if (mode === 'confirm') {
            selector += ':checked';
        }

        var categoryInputs = root.querySelectorAll(selector);
        var acceptedCategories = [];

        for (var index = 0; index < categoryInputs.length; index += 1) {
            var categorySlug = categoryInputs[index].getAttribute('data-thecore-cc-category');

            if (categorySlug) {
                acceptedCategories.push(categorySlug);
            }
        }

        return acceptedCategories;
    }

    function maybeReload(root, forceReload) {
        if (!forceReload && root.getAttribute('data-thecore-cc-reload') !== '1') {
            return false;
        }

        var instances = getInstances();

        for (var index = 0; index < instances.length; index += 1) {
            instances[index].classList.add('thecore-cc--loading');
        }

        window.setTimeout(function () {
            window.location.reload();
        }, 50);

        return true;
    }

    function persistConsent(uuid, categories, onComplete) {
        if (!config.log || !config.ajaxUrl) {
            onComplete();
            return;
        }

        var formData = new window.FormData();
        formData.append('action', 'save_cookie_consent');
        formData.append('nonce', config.ajaxNonce || '');
        formData.append('uuid', uuid);

        for (var index = 0; index < categories.length; index += 1) {
            formData.append('categories[]', categories[index]);
        }

        window.fetch(config.ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            body: formData
        }).then(function () {
            onComplete();
        }, function () {
            onComplete();
        });
    }

    function bindAction(root, button, action) {
        if (button.getAttribute('data-thecore-cc-bound') === '1') {
            return;
        }

        button.setAttribute('data-thecore-cc-bound', '1');

        button.addEventListener('click', function (event) {
            event.preventDefault();
            event.stopPropagation();

            var acceptedCategories = [];

            if (action === 'accept') {
                acceptedCategories = collectAcceptedCategories(root, 'accept');
            } else if (action === 'confirm') {
                acceptedCategories = collectAcceptedCategories(root, 'confirm');
            }

            var uuid = generateUUIDv4();

            setCookie(
                cookieName,
                {
                    uuid: uuid,
                    cookie_categories: acceptedCategories,
                    timestamp: new Date() / 1000 | 0
                },
                parseInt(root.getAttribute('data-thecore-cc-expiration') || '30', 10)
            );

            setBodyClasses(['thecore-cc-set']);

            if (config.log || root.getAttribute('data-thecore-cc-reload') === '1') {
                root.classList.add('thecore-cc--loading');
            }

            persistConsent(uuid, acceptedCategories, function () {
                if (!maybeReload(root, false)) {
                    hideAllInstances();
                }
            });
        });
    }

    function bindRevokeButton(button) {
        if (button.getAttribute('data-thecore-cc-revoke-bound') === '1') {
            return;
        }

        button.setAttribute('data-thecore-cc-revoke-bound', '1');

        button.addEventListener('click', function (event) {
            event.preventDefault();
            event.stopPropagation();

            if (config.revokeAll) {
                eraseAllCookies();
            } else {
                eraseCookie(cookieName);
            }

            if (config.revokeNotice) {
                window.alert(config.revokeNotice);
            }

            maybeReload({ getAttribute: function () { return '0'; }, classList: { add: function () {} } }, true);
        });
    }

    function decodeHTML(html) {
        var textArea = document.createElement('textarea');
        textArea.innerHTML = html;

        return textArea.value;
    }

    function createElementFromHTML(htmlString) {
        var container = document.createElement('div');
        container.innerHTML = htmlString.trim();

        return container.firstChild;
    }

    function bindEmbedUnblocker(item) {
        if (item.getAttribute('data-thecore-cc-embed-bound') === '1') {
            return;
        }

        item.setAttribute('data-thecore-cc-embed-bound', '1');

        var unblock = function () {
            var embedCode = decodeHTML(item.getAttribute('data-embed-content') || '');
            var embedProvider = item.getAttribute('data-embed-provider') || '';
            var element = createElementFromHTML(embedCode);

            if (!element || !item.parentNode) {
                return;
            }

            item.parentNode.replaceWith(element);

            if (embedProvider === 'twitter.com') {
                var script = document.createElement('script');
                var head = document.head || document.getElementsByTagName('head')[0];
                script.src = '//platform.twitter.com/widgets.js';
                script.async = false;
                head.insertBefore(script, head.firstChild);
            }
        };

        item.addEventListener('click', unblock);
        item.addEventListener('keydown', function (event) {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                unblock();
            }
        });
    }

    function initializeInstance(root) {
        if (!root || root.getAttribute(initializedAttribute) === '1') {
            return;
        }

        root.setAttribute(initializedAttribute, '1');

        if (root.getAttribute('data-thecore-editor-preview') === '1') {
            showInstance(root);
            return;
        }

        var acceptButton = root.querySelector('[data-thecore-cc-action="accept"]');
        var confirmButton = root.querySelector('[data-thecore-cc-action="confirm"]');
        var rejectButton = root.querySelector('[data-thecore-cc-action="reject"]');

        if (acceptButton) {
            bindAction(root, acceptButton, 'accept');
        }

        if (confirmButton) {
            bindAction(root, confirmButton, 'confirm');
        }

        if (rejectButton) {
            bindAction(root, rejectButton, 'reject');
        }
    }

    function refreshGlobalBindings() {
        var revokeButtons = document.querySelectorAll('#thecore-cc__revoke-button');
        var embedButtons = document.querySelectorAll('.thecore-cc__embed-unblock');

        for (var index = 0; index < revokeButtons.length; index += 1) {
            bindRevokeButton(revokeButtons[index]);
        }

        for (var embedIndex = 0; embedIndex < embedButtons.length; embedIndex += 1) {
            bindEmbedUnblocker(embedButtons[embedIndex]);
        }
    }

    function refresh() {
        var instances = getInstances();

        for (var index = 0; index < instances.length; index += 1) {
            initializeInstance(instances[index]);
        }

        refreshGlobalBindings();
        syncVisibleState();
    }

    function queueRefresh() {
        if (refreshQueued) {
            return;
        }

        refreshQueued = true;
        window.requestAnimationFrame(function () {
            refreshQueued = false;
            refresh();
        });
    }

    function bootstrap() {
        refresh();

        if (observer || !document.body || typeof MutationObserver === 'undefined') {
            return;
        }

        observer = new MutationObserver(function () {
            queueRefresh();
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }

    if (document.readyState === 'complete' || document.readyState === 'interactive') {
        bootstrap();
    } else {
        document.addEventListener('DOMContentLoaded', bootstrap, false);
        window.addEventListener('load', bootstrap, false);
    }
}(window, document));
