# Changelog

## 0.2.0-beta.50

- Restauration d’une admin globale `Cookies` avec `Config` et `Cookie Consents`, sans onglet design, le design restant piloté par le widget Elementor

## 0.2.0-beta.49

- Portage complet du module `Cookie Consent` du thème en widget Elementor, avec logging des consentements, shortcode de revoke, statut, blocage des embeds et injection conditionnelle de code par catégorie

## 0.2.0-beta.48

- Correction du garde CSS critique des modales `Accessibility Module` et `TChat Module` pour ne plus bloquer leur ouverture après chargement du CSS principal

## 0.2.0-beta.47

- Ajout d’un CSS critique minimal injecté une seule fois pour garder les modales `Accessibility Module` et `TChat Module` masquées avant chargement du CSS complet

## 0.2.0-beta.46

- Ajout de réglages de couleurs normales et hover pour le bouton d’envoi du widget `TChat Module`

## 0.2.0-beta.45

- Ajout de champs éditables pour renommer les libellés des boutons `Close` et `Restore defaults` du widget `Accessibility Module`

## 0.2.0-beta.44

- Ajout de champs éditables pour renommer les titres des trois sections du widget `Accessibility Module`

## 0.2.0-beta.43

- Ajout d’un champ de label custom sous chaque feature du widget `Accessibility Module`, pour renommer librement les cards activées

## 0.2.0-beta.42

- Renforcement supplémentaire du suivi du `reading mask` avec écoute redondante sur `window`, `document`, le backdrop et le panel du module d’accessibilité

## 0.2.0-beta.41

- Renforcement du suivi du `reading mask` du module d’accessibilité avec écoute `window` en `mousemove`, `pointermove` et `touchmove`

## 0.2.0-beta.40

- Correction du `reading mask` du module d’accessibilité, qui restait actif mais se retrouvait visuellement masqué par le nouveau backdrop de fermeture

## 0.2.0-beta.39

- Alignement du comportement du module d’accessibilité sur le TChat : trigger en vrai toggle et fermeture via backdrop cliquable
- Suppression de la fermeture globale au clic document au profit d’un flux d’interaction plus simple et plus robuste

## 0.2.0-beta.38

- Correction de l’ouverture du module d’accessibilité en frontend via des binds directs sur les triggers externes
- Nettoyage de la logique de clic global du runtime accessibilité pour limiter son rôle à la fermeture au clic extérieur

## 0.2.0-beta.37

- Simplification du runtime du module d’accessibilité pour mieux cibler l’instance active après rerender Elementor
- Suppression du rendu preview spécial du `TChat Module`, tout en gardant la désactivation du bootstrap réseau/polling dans l’éditeur
- Ajout d’un vrai bouton d’envoi mobile dans le TChat

## 0.2.0-beta.36

- Renforcement du runtime du module d’accessibilité pour recacher/rebinder correctement le DOM après rerender Elementor
- Réactivation plus fiable des ouvertures/fermetures du panneau accessibilité sur le front et dans l’éditeur

## 0.2.0-beta.35

- Allègement du mode preview Elementor du `TChat Module` pour éviter de casser le canvas avec une vraie modale fullscreen
- Désactivation du bootstrap réseau/polling TChat dans le preview Elementor, tout en gardant une vue stylable de la modale

## 0.2.0-beta.34

- Correction du comportement des modales `Accessibility` et `TChat` dans l’éditeur Elementor après rerender du canvas
- Rebinding correct du toolbar accessibilité pour réactiver fermeture et interactions après refresh preview
- Runtime TChat rendu résilient aux remounts du DOM, avec module forcé ouvert en mode édition/preview

## 0.2.0-beta.33

- Correction des URLs REST du runtime TChat côté frontend pour supprimer les espaces parasites sur `conversations` et `persist`
- Nettoyage de quelques chaînes cassées du runtime TChat : cookie visiteur, fallback UUID et classe CSS des messages

## 0.2.0-beta.32

- Refactor du TChat en deux widgets Elementor : `TChat Module` et `TChat Trigger`
- Ajout d’un trigger TChat séparé avec la même surface de contrôle que le trigger du panneau d’accessibilité
- Ajout de vrais réglages de style pour la modale TChat : panel, header, messages et input
- Refonte du runtime/frontend TChat pour piloter une structure HTML rendue côté PHP au lieu d’injecter toute la modale en JS

## 0.2.0-beta.31

- Ajout d’un widget Elementor `TChat` minimal qui monte le module frontend existant sans dupliquer la logique métier
- Réutilisation du même mount que le shortcode `[tchat]` pour le widget Elementor
- Enregistrement propre des handles CSS/JS TChat pour qu’ils puissent être déclarés comme dépendances du widget

## 0.2.0-beta.30

- Intégration du module `TChat` directement dans `thecore-elementor-widgets`, avec transport configurable `polling`, `sse` ou `auto`
- Ajout de l’admin `TChat`, du shortcode `[tchat]` et du relay SSE optionnel côté WordPress
- Renommage du menu admin principal en `The Core - Widgets`
- Correction du `Overlay Scroll Lock` pour compenser la largeur de scrollbar et éviter le layout shift à l’ouverture du menu

## 0.2.0-beta.29

- Correction de l’alignement horizontal du `Accessibility Module (Legacy)` pour que le mode gauche/droite positionne réellement le panneau
- `Title` et `Subtitle` du module d’accessibilité peuvent maintenant être laissés vides, sans fallback forcé au rendu

## 0.2.0-beta.28

- Ajout des widgets legacy `Accessibility Module` et `Accessibility Trigger` issus de The Core Accessibility
- Pilotage des fonctions d’accessibilité et du skip link directement depuis les contrôles Elementor du module
- Retrait de l’option `Sitemap` du module d’accessibilité
- Ajout d’un mode `Hide skip link visually` pour rendre le skip link invisible avec une taille `0 x 0`
- Correction d’un freeze dans l’éditeur Elementor causé par le runtime de montage du skip link et du reading mask

## 0.2.0-beta.27

- Bump de version après revert du correctif d'opacité de l'overlay sur `Fullscreen Menu`

## 0.2.0-beta.25

- Suppression du texte visible à côté du burger sur `Header Menu (Legacy)`
- Retrait du contrôle Elementor et du setting associés au label mobile du toggle

## 0.2.0-beta.24

- Correction du `Header Menu (Legacy)` : la media query inline du breakpoint mobile est maintenant rendue correctement, ce qui permet enfin le passage en mode burger

## 0.2.0-beta.23

- Import des widgets legacy `Header Menu` et `Search Modal` depuis Bellevue avec renommage The Core
- Ajout du handler AJAX de recherche et des tests de normalisation associés
- Correction du `Header Menu (Legacy)` pour que le layout mobile soit rendu nativement via CSS/media queries, sans dépendre du JS pour le premier affichage

## 0.2.0-beta.22

- Fusion des correctifs de chargement d'assets sur la base beta.21
- Chargement normalise des CSS et JS des widgets via leurs dependances WordPress standards
- Retrait du reliquat `inline_asset_injection` sur `Fullscreen Menu`

## 0.2.0-beta.21

- Suppression complete du systeme de delaying embarque dans le plugin
- Retrait des reglages admin et des controles widget associes
- Retour a un chargement normal des assets, pour laisser cette responsabilite au theme

## 0.2.0-beta.20

- Desactivation simple et centrale du systeme embarque de delaying des assets du plugin, pour laisser un chargement immediat des widgets

## 0.2.0-beta.19

- Renforcement de la robustesse visuelle du `Marquee Banner (Legacy)` sur mobile et vieux navigateurs
- Suppression du double lazy loading et démarrage de l'animation après chargement et mesure réels des images
- Calcul de la distance de défilement en pixels avec recalcul au chargement, resize et changement d'orientation

## 0.2.0-beta.18

- Ajout du widget Elementor classique `Marquee Banner (Legacy)` en parallele du widget V4
- Ajout du support du delaying CSS et JS global/widget sur ce marquee legacy
- Separation claire entre l'enregistrement des widgets classiques Elementor et des widgets Atomic

## 0.2.0-beta.17

- Correction du chargement CSS et JS des widgets dans le preview Elementor en traitant correctement les contextes `editor` et `preview`
- Enregistrement des handles d'assets aussi sur les hooks d'editor Elementor pour fiabiliser le rendu du canvas

## 0.2.0-beta.16

- Ajout d'un vrai switch widget `Enable delaying` separe pour le CSS et le JS
- Possibilite de desactiver explicitement le delaying au niveau d'un widget sans toucher aux triggers

## 0.2.0-beta.15

- Ajout du trigger `Fallback only` dans le socle de delaying CSS/JS global et widget
- Forcage automatique du fallback quand ce trigger est selectionne

## 0.2.0-beta.14

- Ajout d'un socle unifie de delaying CSS et JS pour les widgets, avec resolution globale vs widget
- Ajout d'une section globale `Asset Delivery` dans la page `Features`
- Ajout de reglages `CSS Delivery` et `JS Delivery` dans `Fullscreen Menu` et `Marquee Carousel`
- Delivery frontend unifie avec triggers `viewport` ou `interaction`, fallback temporise, et runtime commun

## 0.2.0-beta.13

- Revert du montage externe de l'overlay du `Fullscreen Menu` pour revenir a un rendu entierement contenu dans le header/widget
- Suppression du reglages `Overlay mount target` et du toggle porte associe

## 0.2.0-beta.12

- Ajout d'un toggle de fermeture porté au-dessus de l'overlay du `Fullscreen Menu`
- Correction du cas où le bouton d'ouverture passait sous l'overlay et ne permettait plus de refermer le menu
- Synchronisation de l'état visuel du toggle entre le bouton source et le bouton porté

## 0.2.0-beta.11

- Ajout d'un réglage `Overlay mount target` dans le `Fullscreen Menu`
- Support des cibles `Closest header`, `Body` et `Custom selector` pour choisir où monter l'overlay
- Propagation du sélecteur custom jusqu'au runtime frontend avec fallback silencieux sur `body`

## 0.2.0-beta.10

- Déplacement de l'overlay du `Fullscreen Menu` hors du container du widget pour éviter qu'un ancêtre transformé ne bloque son `position: fixed`
- Montage automatique de l'overlay sous le `header` ancêtre le plus proche, ou sous `body` à défaut
- Synchronisation des variables CSS du widget vers l'overlay déplacé afin de conserver les styles configurés

## 0.2.0-beta.9

- Décision du mode responsive du `Fullscreen Menu` côté serveur pour éviter le basculement de layout au premier paint
- Suppression du pilotage du layout initial par JS afin de réduire le risque de CLS, notamment en `overlay only`
- Ajout d'un switch `Inline asset injection` dans le widget pour choisir entre assets inline et fichiers externes côté frontoffice
- Alignement du preview Elementor et du rendu frontend sur les nouvelles règles de layout du menu

## 0.2.0-beta.8

- Restauration de la cible `base` du `Fullscreen Menu` pour réactiver les réglages de spacing du wrapper dans l’onglet `Style`
- Réintégration des classes Atomic du widget dans le rendu preview/front pour que les styles V4 appliqués au wrapper aient de nouveau un effet

## 0.2.0-beta.7

- Stabilisation des contrôles custom du `Fullscreen Menu` dans l’éditeur Atomic V4
- Correction de la validation des champs `letter spacing` au save
- Ajout de vrais contrôles `font-family` avec presets et valeur custom conditionnelle
- Ajout d’un sanitiseur de document Elementor pour fiabiliser les payloads du widget

## 0.2.0-beta.6

- Correction de l'application des styles de typo du `Fullscreen Menu`
- Ajout de styles de typo distincts pour les liens desktop et les liens d'overlay
- Ajout du mode `Overlay only` pour conserver le hamburger sur tous les écrans

## 0.2.0-beta.5

- Suppression de la dépendance frontend du `Fullscreen Menu` au runtime Atomic d'Elementor

## 0.2.0-beta.4

- Correction du chargement trop tôt du domaine de traduction pour éviter le notice `_load_textdomain_just_in_time`

## 0.2.0-beta.3

- Intégration du wrapper `Fullscreen Menu` en `display: flex`
- Bump de version pour publication du canal beta

## 0.2.0-beta.2

- Bump de version pour test end-to-end de la pipeline d’update GitHub

## 0.2.0-beta.1

- Ajout du `PluginUpdater` GitHub avec manifest public `beta` / `prod`
- Ajout de la workflow GitHub de publication vers `webinart/thecore-elementor-widgets-updates`
- Remplacement du widget `Classic Menu` par le port V4 du widget legacy `Fullscreen Menu`
- Nettoyage de l’ancienne implémentation multi-niveaux et de ses assets hamburger dédiés
- Ajout d’une normalisation testée des réglages d’affichage du `Fullscreen Menu`

## 0.1.0

- Initialisation du plugin `The Core - Elementor Widgets`
- Mise en place de l’admin `The Core` avec pages `Widgets` et `Features`
- Ajout du socle Atomic pour `Classic Menu`
- Mise en place de l’outillage local Composer, PHPUnit et PHPCS
- Ajout du choix d’effet d’animation du hamburger
- Ajout du breakpoint mobile configurable par widget
- Chargement conditionnel des styles d’effet du hamburger par page
