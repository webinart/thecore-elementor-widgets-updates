<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\CookieConsent;

use TheCore\ElementorWidgets\Elementor\Legacy\Widgets\CookieConsent\DisplaySettings;

final class AdminPage
{
    private const MENU_SLUG = 'thecore-cookies';
    private const CONSENTS_SUBMENU_SLUG = 'edit.php?post_type=' . Logger::POST_TYPE;
    private const SAVE_ACTION = 'thecore_cookie_consent_save_config';

    public function __construct(
        private readonly ConfigRepository $configRepository
    ) {
    }

    public function registerHooks(): void
    {
        add_action('admin_menu', [$this, 'registerMenu']);
        add_action('admin_post_' . self::SAVE_ACTION, [$this, 'handleSave']);
        add_filter('parent_file', [$this, 'filterParentFile']);
        add_filter('submenu_file', [$this, 'filterSubmenuFile']);
    }

    public function registerMenu(): void
    {
        add_menu_page(
            __('Cookies', 'thecore-elementor-widgets'),
            __('Cookies', 'thecore-elementor-widgets'),
            'manage_options',
            self::MENU_SLUG,
            [$this, 'renderConfigPage'],
            'dashicons-shield-alt',
            59
        );

        add_submenu_page(
            self::MENU_SLUG,
            __('Config', 'thecore-elementor-widgets'),
            __('Config', 'thecore-elementor-widgets'),
            'manage_options',
            self::MENU_SLUG,
            [$this, 'renderConfigPage']
        );

        add_submenu_page(
            self::MENU_SLUG,
            __('Cookie Consents', 'thecore-elementor-widgets'),
            __('Cookie Consents', 'thecore-elementor-widgets'),
            'manage_options',
            self::CONSENTS_SUBMENU_SLUG
        );
    }

    public function renderConfigPage(): void
    {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('You are not allowed to access this page.', 'thecore-elementor-widgets'));
        }

        $config = $this->configRepository->active();
        $activeTab = $this->activeTab();
        ?>
        <div class="wrap thecore-admin">
            <h1><?php echo esc_html__('Cookies', 'thecore-elementor-widgets'); ?></h1>
            <p class="thecore-admin__intro">
                <?php esc_html_e('Configure the functional behavior of the Cookie Consent module. Design and style are now handled directly in the Elementor widget.', 'thecore-elementor-widgets'); ?>
            </p>
            <?php $this->renderTabs($activeTab); ?>
            <?php $this->renderUpdatedNotice(); ?>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="thecore-admin__form">
                <input type="hidden" name="action" value="<?php echo esc_attr(self::SAVE_ACTION); ?>">
                <input type="hidden" name="tab" value="<?php echo esc_attr($activeTab); ?>">
                <?php wp_nonce_field(self::SAVE_ACTION); ?>

                <div class="thecore-admin__cards">
                    <?php
                    if ('categories' === $activeTab) {
                        $this->renderCategoriesTab($config);
                    } elseif ('consent' === $activeTab) {
                        $this->renderConsentTab($config);
                    } else {
                        $this->renderGeneralTab($config);
                    }
                    ?>
                </div>

                <p class="submit">
                    <button type="submit" class="button button-primary">
                        <?php esc_html_e('Save changes', 'thecore-elementor-widgets'); ?>
                    </button>
                </p>
            </form>
        </div>
        <?php
    }

    public function handleSave(): void
    {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('You are not allowed to perform this action.', 'thecore-elementor-widgets'));
        }

        check_admin_referer(self::SAVE_ACTION);

        $tab = $this->sanitizeTab($_POST['tab'] ?? '');
        $submitted = isset($_POST['cookie_consent']) && is_array($_POST['cookie_consent'])
            ? wp_unslash($_POST['cookie_consent'])
            : [];
        $current = $this->configRepository->active();
        $normalized = (new DisplaySettings())->normalize(is_array($submitted) ? $submitted : []);

        $normalized['theme_preset'] = is_string($current['theme_preset'] ?? null)
            ? (string) $current['theme_preset']
            : CookieConsentModule::DEFAULT_THEME_PRESET;
        $normalized['privacy_policy_external'] = ! empty($current['privacy_policy_external']);

        $this->configRepository->saveOverride($normalized);

        wp_safe_redirect(
            add_query_arg(
                [
                    'page' => self::MENU_SLUG,
                    'tab' => $tab,
                    'updated' => '1',
                ],
                admin_url('admin.php')
            )
        );
        exit;
    }

    public function filterParentFile(string $parentFile): string
    {
        if ($this->isCookieConsentScreen()) {
            return self::MENU_SLUG;
        }

        return $parentFile;
    }

    public function filterSubmenuFile(?string $submenuFile): ?string
    {
        if ($this->isCookieConsentScreen()) {
            return self::CONSENTS_SUBMENU_SLUG;
        }

        return $submenuFile;
    }

    /**
     * @param array<string, mixed> $config
     */
    private function renderGeneralTab(array $config): void
    {
        ?>
        <section class="thecore-admin__card">
            <div class="thecore-admin__card-content">
                <h2><?php echo esc_html__('General Settings', 'thecore-elementor-widgets'); ?></h2>
                <p><?php esc_html_e('Notice text, labels and content behavior of the cookie banner.', 'thecore-elementor-widgets'); ?></p>
            </div>

            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><label for="cookie_consent_notice_text"><?php esc_html_e('Notice Text', 'thecore-elementor-widgets'); ?></label></th>
                    <td><textarea class="large-text" rows="5" id="cookie_consent_notice_text" name="cookie_consent[notice_text]"><?php echo esc_textarea((string) ($config['notice_text'] ?? '')); ?></textarea></td>
                </tr>
                <tr>
                    <th scope="row"><label for="cookie_consent_accept_button_label"><?php esc_html_e('Accept Button Text', 'thecore-elementor-widgets'); ?></label></th>
                    <td><input class="regular-text" id="cookie_consent_accept_button_label" name="cookie_consent[accept_button_label]" type="text" value="<?php echo esc_attr((string) (($config['buttons']['accept'] ?? ''))); ?>"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="cookie_consent_confirm_choice_button_label"><?php esc_html_e('Confirm Choice Button Text', 'thecore-elementor-widgets'); ?></label></th>
                    <td><input class="regular-text" id="cookie_consent_confirm_choice_button_label" name="cookie_consent[confirm_choice_button_label]" type="text" value="<?php echo esc_attr((string) (($config['buttons']['confirm'] ?? ''))); ?>"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="cookie_consent_reject_button_label"><?php esc_html_e('Reject Button Text', 'thecore-elementor-widgets'); ?></label></th>
                    <td><input class="regular-text" id="cookie_consent_reject_button_label" name="cookie_consent[reject_button_label]" type="text" value="<?php echo esc_attr((string) (($config['buttons']['reject'] ?? ''))); ?>"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="cookie_consent_privacy_policy_button_label"><?php esc_html_e('Privacy Policy Button Text', 'thecore-elementor-widgets'); ?></label></th>
                    <td><input class="regular-text" id="cookie_consent_privacy_policy_button_label" name="cookie_consent[privacy_policy_button_label]" type="text" value="<?php echo esc_attr((string) (($config['buttons']['privacy'] ?? ''))); ?>"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="cookie_consent_revoke_consent_button_label"><?php esc_html_e('Revoke Consent Button Text', 'thecore-elementor-widgets'); ?></label></th>
                    <td><input class="regular-text" id="cookie_consent_revoke_consent_button_label" name="cookie_consent[revoke_consent_button_label]" type="text" value="<?php echo esc_attr((string) ($config['revoke_consent_button_label'] ?? '')); ?>"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="cookie_consent_privacy_policy_url"><?php esc_html_e('Privacy Policy URL', 'thecore-elementor-widgets'); ?></label></th>
                    <td><input class="regular-text" id="cookie_consent_privacy_policy_url" name="cookie_consent[privacy_policy_url]" type="url" value="<?php echo esc_attr((string) ($config['privacy_policy_url'] ?? '')); ?>"></td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e('Show category descriptions', 'thecore-elementor-widgets'); ?></th>
                    <td><?php $this->renderCheckbox('cookie_consent[show_category_descriptions]', ! empty($config['show_category_descriptions'])); ?></td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e('Reload page after cookie choice has been saved', 'thecore-elementor-widgets'); ?></th>
                    <td><?php $this->renderCheckbox('cookie_consent[reload_on_set]', ! empty($config['reload_on_set'])); ?></td>
                </tr>
                <tr>
                    <th scope="row"><label for="cookie_consent_cookie_expiration_days"><?php esc_html_e('Cookie expiration (days)', 'thecore-elementor-widgets'); ?></label></th>
                    <td><input class="small-text" id="cookie_consent_cookie_expiration_days" name="cookie_consent[cookie_expiration_days]" type="number" min="1" max="365" value="<?php echo esc_attr((string) ($config['cookie_expiration_days'] ?? CookieConsentModule::DEFAULT_COOKIE_EXPIRATION_DAYS)); ?>"></td>
                </tr>
            </table>
        </section>
        <?php
    }

    /**
     * @param array<string, mixed> $config
     */
    private function renderCategoriesTab(array $config): void
    {
        $categories = is_array($config['categories'] ?? null) ? $config['categories'] : [];

        foreach ($categories as $category) {
            if (! is_array($category)) {
                continue;
            }

            $slug = is_string($category['slug'] ?? null) ? (string) $category['slug'] : '';

            if ('' === $slug) {
                continue;
            }
            ?>
            <section class="thecore-admin__card">
                <div class="thecore-admin__card-content">
                    <h2><?php echo esc_html((string) ($category['label'] ?? $slug)); ?></h2>
                    <p><?php echo esc_html((string) ($category['description'] ?? '')); ?></p>
                </div>

                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><?php esc_html_e('Status', 'thecore-elementor-widgets'); ?></th>
                        <td><?php $this->renderCheckbox('cookie_consent[' . $slug . '_active]', ! empty($category['active'])); ?></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="<?php echo esc_attr($slug . '_label'); ?>"><?php esc_html_e('Label', 'thecore-elementor-widgets'); ?></label></th>
                        <td><input class="regular-text" id="<?php echo esc_attr($slug . '_label'); ?>" name="<?php echo esc_attr('cookie_consent[' . $slug . '_label]'); ?>" type="text" value="<?php echo esc_attr((string) ($category['label'] ?? '')); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="<?php echo esc_attr($slug . '_description'); ?>"><?php esc_html_e('Description', 'thecore-elementor-widgets'); ?></label></th>
                        <td><textarea class="large-text" rows="4" id="<?php echo esc_attr($slug . '_description'); ?>" name="<?php echo esc_attr('cookie_consent[' . $slug . '_description]'); ?>"><?php echo esc_textarea((string) ($category['description'] ?? '')); ?></textarea></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="<?php echo esc_attr($slug . '_code'); ?>"><?php esc_html_e('Code', 'thecore-elementor-widgets'); ?></label></th>
                        <td><textarea class="large-text code" rows="8" id="<?php echo esc_attr($slug . '_code'); ?>" name="<?php echo esc_attr('cookie_consent[' . $slug . '_code]'); ?>"><?php echo esc_textarea((string) ($category['code'] ?? '')); ?></textarea></td>
                    </tr>
                </table>
            </section>
            <?php
        }
    }

    /**
     * @param array<string, mixed> $config
     */
    private function renderConsentTab(array $config): void
    {
        ?>
        <section class="thecore-admin__card">
            <div class="thecore-admin__card-content">
                <h2><?php echo esc_html__('Consent Settings', 'thecore-elementor-widgets'); ?></h2>
                <p><?php esc_html_e('Logging, purge policy, embed blocking and revoke behavior.', 'thecore-elementor-widgets'); ?></p>
            </div>

            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><?php esc_html_e('Log consents', 'thecore-elementor-widgets'); ?></th>
                    <td><?php $this->renderCheckbox('cookie_consent[log_consents]', ! empty($config['log_consents'])); ?></td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e('Anonymize consent IPs', 'thecore-elementor-widgets'); ?></th>
                    <td><?php $this->renderCheckbox('cookie_consent[anonymize_consent_log_ips]', ! empty($config['anonymize_consent_log_ips'])); ?></td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e('Auto-purge old consent logs', 'thecore-elementor-widgets'); ?></th>
                    <td><?php $this->renderCheckbox('cookie_consent[auto_purge_consents]', ! empty($config['auto_purge_consents'])); ?></td>
                </tr>
                <tr>
                    <th scope="row"><label for="cookie_consent_auto_purge_consents_interval"><?php esc_html_e('Auto-purge interval', 'thecore-elementor-widgets'); ?></label></th>
                    <td>
                        <select id="cookie_consent_auto_purge_consents_interval" name="cookie_consent[auto_purge_consents_interval]">
                            <?php foreach (['1 month', '3 months', '6 months', '1 year', '2 years', '5 years'] as $interval) : ?>
                                <option value="<?php echo esc_attr($interval); ?>" <?php selected((string) ($config['auto_purge_consents_interval'] ?? ''), $interval); ?>><?php echo esc_html($interval); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e('Delete all cookies on revoke', 'thecore-elementor-widgets'); ?></th>
                    <td><?php $this->renderCheckbox('cookie_consent[revoke_delete_all]', ! empty($config['revoke_delete_all'])); ?></td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e('Block embeds until functional consent', 'thecore-elementor-widgets'); ?></th>
                    <td><?php $this->renderCheckbox('cookie_consent[block_embeds]', ! empty($config['block_embeds'])); ?></td>
                </tr>
            </table>
        </section>
        <?php
    }

    private function renderTabs(string $activeTab): void
    {
        $tabs = [
            'general' => __('Config', 'thecore-elementor-widgets'),
            'categories' => __('Categories', 'thecore-elementor-widgets'),
            'consent' => __('Consent', 'thecore-elementor-widgets'),
        ];

        echo '<nav class="nav-tab-wrapper">';

        foreach ($tabs as $slug => $label) {
            $activeClass = $slug === $activeTab ? ' nav-tab-active' : '';

            printf(
                '<a href="%1$s" class="nav-tab%2$s">%3$s</a>',
                esc_url(
                    add_query_arg(
                        [
                            'page' => self::MENU_SLUG,
                            'tab' => $slug,
                        ],
                        admin_url('admin.php')
                    )
                ),
                esc_attr($activeClass),
                esc_html($label)
            );
        }

        echo '</nav>';
    }

    private function renderUpdatedNotice(): void
    {
        if ((string) ($_GET['updated'] ?? '') !== '1') {
            return;
        }

        echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Cookie settings saved.', 'thecore-elementor-widgets') . '</p></div>';
    }

    private function activeTab(): string
    {
        return $this->sanitizeTab($_GET['tab'] ?? '');
    }

    private function sanitizeTab(mixed $tab): string
    {
        $tab = is_scalar($tab) ? sanitize_key((string) $tab) : '';

        return in_array($tab, ['general', 'categories', 'consent'], true)
            ? $tab
            : 'general';
    }

    private function isCookieConsentScreen(): bool
    {
        $postType = '';

        if (isset($_GET['post_type']) && is_scalar($_GET['post_type'])) {
            $postType = sanitize_key((string) wp_unslash((string) $_GET['post_type']));
        } elseif (isset($_GET['post']) && is_numeric($_GET['post'])) {
            $postType = (string) get_post_type((int) $_GET['post']);
        }

        return Logger::POST_TYPE === $postType;
    }

    private function renderCheckbox(string $name, bool $checked): void
    {
        printf(
            '<input type="hidden" name="%1$s" value="0"><label><input type="checkbox" name="%1$s" value="yes" %2$s> %3$s</label>',
            esc_attr($name),
            checked($checked, true, false),
            esc_html__('Enabled', 'thecore-elementor-widgets')
        );
    }
}
