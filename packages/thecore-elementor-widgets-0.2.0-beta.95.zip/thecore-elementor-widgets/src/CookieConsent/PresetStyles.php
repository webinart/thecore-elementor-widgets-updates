<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\CookieConsent;

final class PresetStyles
{
    public function render(string $rootId, string $themePreset): string
    {
        if (! in_array($themePreset, ['default', 'labs', 'sidecar', 'lowkey'], true)) {
            $themePreset = 'default';
        }
        $selector = ':where(#' . sanitize_html_class($rootId) . ')';
        $presetSelector = $selector . '.thecore-cc--theme-' . $themePreset;
        $css = [];

        $css[] = $selector . '{'
            . '--thecore-cc-overlay:rgba(0,0,0,0.36);'
            . '--thecore-cc-panel-width:440px;'
            . '--thecore-cc-panel-background:#ffffff;'
            . '--thecore-cc-panel-color:#111111;'
            . '--thecore-cc-panel-radius:20px;'
            . '--thecore-cc-panel-padding:24px;'
            . '--thecore-cc-panel-shadow:0 24px 80px rgba(0,0,0,0.18);'
            . '--thecore-cc-accent:#47c17c;'
            . '--thecore-cc-category-background:rgba(255,255,255,0.04);'
            . '--thecore-cc-category-border:rgba(17,17,17,0.12);'
            . '--thecore-cc-button-background:#f5f5f5;'
            . '--thecore-cc-button-color:#202020;'
            . '--thecore-cc-button-border:rgba(17,17,17,0.12);'
            . '--thecore-cc-primary-background:var(--thecore-cc-accent);'
            . '--thecore-cc-primary-color:#ffffff;'
            . '--thecore-cc-primary-border:var(--thecore-cc-accent);'
            . '--thecore-cc-category-label-weight:700;'
            . '--thecore-cc-button-radius:999px;'
            . '--thecore-cc-accept-button-weight:700;'
            . '}';

        switch ($themePreset) {
            case 'default':
                $css[] = $presetSelector . '{top:auto;right:0;bottom:0;left:0;padding:0;font-size:smaller;}';
                $css[] = $selector . '{'
                    . '--thecore-cc-overlay:transparent;'
                    . '--thecore-cc-viewport-gap:0px;'
                    . '--thecore-cc-panel-background:#23282d;'
                    . '--thecore-cc-panel-color:#ffffff;'
                    . '--thecore-cc-button-background:transparent;'
                    . '--thecore-cc-button-color:currentColor;'
                    . '--thecore-cc-button-border:currentColor;'
                    . '--thecore-cc-primary-background:transparent;'
                    . '--thecore-cc-primary-color:currentColor;'
                    . '--thecore-cc-primary-border:currentColor;'
                    . '--thecore-cc-category-background:transparent;'
                    . '--thecore-cc-category-border:transparent;'
                    . '--thecore-cc-panel-radius:0px;'
                    . '--thecore-cc-panel-shadow:none;'
                    . '--thecore-cc-root-padding:0px;'
                    . '--thecore-cc-container-width:100vw;'
                    . '--thecore-cc-container-max-height:none;'
                    . '--thecore-cc-container-padding:15px 30px;'
                    . '--thecore-cc-category-label-weight:400;'
                    . '--thecore-cc-button-radius:3px;'
                    . '--thecore-cc-text-align:center;'
                    . '--thecore-cc-category-text-align:center;'
                    . '--thecore-cc-categories-inline-justify:center;'
                    . '--thecore-cc-buttons-justify:center;'
                    . '}';
                $css[] = $presetSelector . ' .thecore-cc__text{margin-bottom:10px;}';
                $css[] = $presetSelector . ' .thecore-cc__categories{margin-top:0;}';
                $css[] = $presetSelector . ' .thecore-cc__category{padding:0;}';
                $css[] = $presetSelector . ' .thecore-cc__categories--inline .thecore-cc__category{display:inline-block;margin-right:20px;}';
                $css[] = $presetSelector . ' .thecore-cc__category input{position:static;opacity:1;pointer-events:auto;vertical-align:middle;}';
                $css[] = $presetSelector . ' .thecore-cc__category label{display:inline-block;padding-left:10px;vertical-align:middle;}';
                $css[] = $presetSelector . ' .thecore-cc__category label::before,' . $presetSelector . ' .thecore-cc__category label::after{content:none;display:none;}';
                $css[] = $presetSelector . ' .thecore-cc__category-description{margin:0 0 20px;opacity:.66;}';
                $css[] = $presetSelector . ' .thecore-cc__button{display:inline-block;min-height:0;margin:5px;padding:5px 15px;transform:none;}';
                $css[] = $presetSelector . ' .thecore-cc__button:hover,' . $presetSelector . ' .thecore-cc__button:focus-visible{box-shadow:inset 0 0 0 999px rgba(255,255,255,.1);}';

                break;

            case 'labs':
                $css[] = $selector . '{'
                    . '--thecore-cc-overlay:rgba(0,0,0,0.72);'
                    . '--thecore-cc-panel-width:520px;'
                    . '}';
                $css[] = $presetSelector . '{backdrop-filter:blur(2px);}';

                break;

            case 'sidecar':
                $css[] = $selector . '{'
                    . '--thecore-cc-panel-radius:0px;'
                    . '--thecore-cc-root-justify-content:flex-start;'
                    . '--thecore-cc-root-align-items:stretch;'
                    . '--thecore-cc-root-padding:0px;'
                    . '--thecore-cc-container-height:100vh;'
                    . '--thecore-cc-container-max-height:100vh;'
                    . '--thecore-cc-container-width:100vw;'
                    . '}';
                $css[] = '@media (min-width:768px){' . $selector . '{--thecore-cc-container-width:min(var(--thecore-cc-panel-width),88vw);}}';

                break;

            case 'lowkey':
                $css[] = $selector . '{'
                    . '--thecore-cc-overlay:transparent;'
                    . '--thecore-cc-panel-width:360px;'
                    . '--thecore-cc-root-justify-content:flex-start;'
                    . '--thecore-cc-root-align-items:flex-end;'
                    . '}';

                break;
        }

        return sprintf("<style>%s</style>\n", implode('', $css));
    }
}
