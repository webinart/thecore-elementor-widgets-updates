<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\CookieConsent;

use TheCore\ElementorWidgets\Elementor\Legacy\Widgets\CookieConsent\DisplaySettings;

/** Shared presentation only: widget settings never override consent policy. */
final class Presentation
{
    public function config(array $settings, array $config, bool $preview): array
    {
        $presentation = (new DisplaySettings())->normalizePresentation($settings);
        $config['theme_preset'] = $presentation['theme_preset'];
        $config['editor_preview'] = $preview;

        if ($preview) {
            $config['show_category_descriptions'] = $presentation['preview_show_category_descriptions'];
            $config['categories'] = array_values(array_filter(
                is_array($config['categories'] ?? null) ? $config['categories'] : [],
                'is_array'
            ));
            foreach ($config['categories'] as &$category) {
                if (isset($presentation['preview_categories'][$category['slug'] ?? ''])) {
                    $category['active'] = $presentation['preview_categories'][$category['slug']];
                }
            }
            unset($category);
        }

        return $config;
    }

    public function render(array $settings, string $id, bool $preview, array $panelClasses = [], string $panelId = ''): string
    {
        $config = $this->config($settings, (new ConfigRepository())->active(), $preview);
        $config['id'] = $id;
        $config['panel_classes'] = $panelClasses;
        $config['panel_id'] = $panelId;

        return (new PresetStyles())->render($id, $config['theme_preset']) . CookieConsentModule::renderModule($config);
    }

    public static function isEditorPreview(): bool
    {
        if (! class_exists(\Elementor\Plugin::class) || ! isset(\Elementor\Plugin::$instance)) {
            return false;
        }
        try {
            $plugin = \Elementor\Plugin::$instance;
            return (isset($plugin->editor) && $plugin->editor->is_edit_mode())
                || (isset($plugin->preview) && $plugin->preview->is_preview_mode());
        } catch (\Throwable) {
            return false;
        }
    }
}
