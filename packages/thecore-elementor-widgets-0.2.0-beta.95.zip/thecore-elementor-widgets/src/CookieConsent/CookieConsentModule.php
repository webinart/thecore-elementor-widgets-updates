<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\CookieConsent;

use TheCore\ElementorWidgets\Assets\FrontendAssets;
use TheCore\ElementorWidgets\Contracts\Bootable;

final class CookieConsentModule implements Bootable
{
    public const COOKIE_NAME = 'cookie_consent';
    public const DEFAULT_NOTICE_TEXT = 'Nous utilisons des cookies pour mesurer nos actions marketing et améliorer nos services. Veuillez consulter les paramètres des cookies et confirmer votre choix.';
    public const DEFAULT_ACCEPT_BUTTON_LABEL = 'Accepter les cookies';
    public const DEFAULT_CONFIRM_BUTTON_LABEL = 'Confirmer mon choix';
    public const DEFAULT_REJECT_BUTTON_LABEL = 'Refuser les cookies';
    public const DEFAULT_PRIVACY_BUTTON_LABEL = 'Politique de confidentialité';
    public const DEFAULT_REVOKE_BUTTON_LABEL = 'Réinitialiser mes choix de cookies';
    public const DEFAULT_THEME_PRESET = 'default';
    public const DEFAULT_COOKIE_EXPIRATION_DAYS = 30;
    public const DEFAULT_AUTO_PURGE_INTERVAL = '6 months';

    private readonly ConfigRepository $configRepository;
    private readonly Helper $helper;
    private readonly Logger $logger;
    private readonly Embeds $embeds;
    private readonly Shortcodes $shortcodes;
    private readonly AdminPage $adminPage;

    public function __construct()
    {
        $this->configRepository = new ConfigRepository();
        $this->helper = new Helper($this->configRepository);
        $this->logger = new Logger($this->configRepository, $this->helper);
        $this->embeds = new Embeds($this->configRepository, $this->helper);
        $this->shortcodes = new Shortcodes($this->configRepository, $this->helper);
        $this->adminPage = new AdminPage($this->configRepository);
    }

    public function register(): void
    {
        add_action('elementor/document/after_save', [$this, 'syncConfigFromDocument'], 10, 2);
        add_action('deleted_post', [$this, 'removeDeletedDocument']);

        add_filter('body_class', [$this, 'addCookieStatusBodyClasses']);
        add_action('wp_enqueue_scripts', [$this, 'enqueueFrontendAssets'], 20);
        add_action('wp_head', [$this, 'printConsentGuard'], 1);
        add_action('wp_head', [$this, 'printAcceptedCategoryCodeInHead'], 20);
        add_action('wp_footer', [$this, 'printAcceptedCategoryCodeInFooter'], 20);

        $this->logger->registerHooks();
        $this->embeds->registerHooks();
        $this->shortcodes->registerHooks();
        $this->adminPage->registerHooks();
    }

    /**
     * @param mixed                $document
     * @param array<string, mixed> $data
     */
    public function syncConfigFromDocument($document, array $data): void
    {
        $this->configRepository->syncFromDocument($document, $data);
    }

    public function removeDeletedDocument(int $postId): void
    {
        $this->configRepository->removeDocument($postId);
    }

    /**
     * @param string[] $classes
     *
     * @return string[]
     */
    public function addCookieStatusBodyClasses(array $classes): array
    {
        if (is_admin() || ! $this->configRepository->hasSavedConfig()) {
            return $classes;
        }

        $classes[] = $this->helper->isCookieConsentSet()
            ? 'thecore-cc-set'
            : 'thecore-cc-not-set';

        return $classes;
    }

    public function enqueueFrontendAssets(): void
    {
        if (is_admin() || ! $this->configRepository->hasSavedConfig()) {
            return;
        }

        wp_enqueue_script(FrontendAssets::COOKIE_CONSENT_SCRIPT);
        wp_enqueue_style(FrontendAssets::COOKIE_CONSENT_STYLE);

        wp_add_inline_script(
            FrontendAssets::COOKIE_CONSENT_SCRIPT,
            'window.TheCoreElementorWidgetsCookieConsentConfig = Object.assign({}, window.TheCoreElementorWidgetsCookieConsentConfig || {}, ' . wp_json_encode($this->buildFrontendConfig()) . ');',
            'before'
        );
    }

    public function printConsentGuard(): void
    {
        if (is_admin() || ! $this->configRepository->hasSavedConfig()) {
            return;
        }

        ?>
        <script id="thecore-cc-consent-guard">
document.documentElement.classList.add(document.cookie.indexOf('<?php echo esc_js(self::COOKIE_NAME); ?>=') === -1 ? 'thecore-cc-consent-not-set' : 'thecore-cc-consent-set');
        </script>
        <?php
    }

    public function printAcceptedCategoryCodeInHead(): void
    {
        if (is_admin()) {
            return;
        }

        echo $this->renderAcceptedCategoryCode(true); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }

    public function printAcceptedCategoryCodeInFooter(): void
    {
        if (is_admin()) {
            return;
        }

        echo $this->renderAcceptedCategoryCode(false); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }

    /**
     * @param array{
     *     id?: string,
     *     notice_text?: string,
     *     theme_preset?: string,
     *     show_category_descriptions?: bool,
     *     reload_on_set?: bool,
     *     cookie_expiration_days?: int,
     *     privacy_policy_url?: string,
     *     privacy_policy_external?: bool,
     *     buttons?: array{
     *         accept?: string,
     *         confirm?: string,
     *         reject?: string,
     *         privacy?: string
     *     },
     *     categories?: array<int, array{
     *         slug: string,
     *         label: string,
     *         description: string,
     *         active: bool,
     *         required: bool,
     *         code?: string
     *     }>,
     *     editor_preview?: bool
     * } $config
     */
    public static function renderModule(array $config = []): string
    {
        wp_enqueue_script(FrontendAssets::COOKIE_CONSENT_SCRIPT);
        wp_enqueue_style(FrontendAssets::COOKIE_CONSENT_STYLE);

        $editorPreview = ! empty($config['editor_preview']);
        $panelClasses = ['thecore-cc__container'];
        foreach (is_array($config['panel_classes'] ?? null) ? $config['panel_classes'] : [] as $class) {
            if (is_string($class) && preg_match('/\A[a-zA-Z0-9_-]+\z/', $class)) {
                $panelClasses[] = $class;
            }
        }
        $panelId = is_string($config['panel_id'] ?? null) ? $config['panel_id'] : '';
        $consentSet = self::hasConsentCookie();
        $rootId = isset($config['id']) && is_string($config['id']) ? $config['id'] : '';
        $themePreset = self::sanitizeThemePreset($config['theme_preset'] ?? self::DEFAULT_THEME_PRESET);
        $noticeText = isset($config['notice_text']) && is_string($config['notice_text'])
            ? $config['notice_text']
            : self::DEFAULT_NOTICE_TEXT;
        $showCategoryDescriptions = ! empty($config['show_category_descriptions']);
        $reloadOnSet = ! empty($config['reload_on_set']);
        $expirationDays = isset($config['cookie_expiration_days']) && is_int($config['cookie_expiration_days'])
            ? max(1, min(365, $config['cookie_expiration_days']))
            : self::DEFAULT_COOKIE_EXPIRATION_DAYS;
        $privacyUrl = isset($config['privacy_policy_url']) && is_string($config['privacy_policy_url'])
            ? $config['privacy_policy_url']
            : '';
        $privacyExternal = ! empty($config['privacy_policy_external']);
        $buttons = is_array($config['buttons'] ?? null) ? $config['buttons'] : [];
        $acceptLabel = isset($buttons['accept']) && is_string($buttons['accept'])
            ? $buttons['accept']
            : self::DEFAULT_ACCEPT_BUTTON_LABEL;
        $confirmLabel = isset($buttons['confirm']) && is_string($buttons['confirm'])
            ? $buttons['confirm']
            : self::DEFAULT_CONFIRM_BUTTON_LABEL;
        $rejectLabel = isset($buttons['reject']) && is_string($buttons['reject'])
            ? $buttons['reject']
            : self::DEFAULT_REJECT_BUTTON_LABEL;
        $privacyLabel = isset($buttons['privacy']) && is_string($buttons['privacy'])
            ? $buttons['privacy']
            : self::DEFAULT_PRIVACY_BUTTON_LABEL;
        $categories = self::sanitizeCategories($config['categories'] ?? []);
        $activeCategories = array_values(
            array_filter(
                $categories,
                static fn(array $category): bool => $category['active']
            )
        );

        $shouldRenderConfirm = count($activeCategories) > 1
            || (
                1 === count($activeCategories)
                && ($activeCategories[0]['slug'] ?? '') !== 'category_essential'
            );

        $rootClasses = [
            'thecore-cc',
            'thecore-cc--theme-' . $themePreset,
            $editorPreview || ! $consentSet
                ? 'thecore-cc--visible'
                : 'thecore-cc--hidden',
        ];

        if (! $showCategoryDescriptions) {
            $rootClasses[] = 'thecore-cc--inline-categories';
        }

        if ($editorPreview) {
            $rootClasses[] = 'thecore-cc--editor-preview';
        }

        ob_start();
        ?>
        <div
            <?php if ($rootId !== '') : ?>
                id="<?php echo esc_attr($rootId); ?>"
            <?php endif; ?>
            class="<?php echo esc_attr(implode(' ', array_unique($rootClasses))); ?>"
            role="banner"
            aria-label="<?php echo esc_attr__('Gestion du consentement aux cookies', 'thecore-elementor-widgets'); ?>"
            data-thecore-cc="1"
            data-thecore-anim-viewport-proxy="1"
            data-thecore-editor-preview="<?php echo $editorPreview ? '1' : '0'; ?>"
            data-thecore-cc-reload="<?php echo $reloadOnSet ? '1' : '0'; ?>"
            data-thecore-cc-expiration="<?php echo esc_attr((string) $expirationDays); ?>"
        >
            <div class="<?php echo esc_attr(implode(' ', array_unique($panelClasses))); ?>"<?php if ($panelId !== '') :
                ?> id="<?php echo esc_attr($panelId); ?>"<?php
                        endif; ?>>
                <?php if ('' !== trim($noticeText)) : ?>
                    <div class="thecore-cc__text">
                        <?php echo wp_kses_post($noticeText); ?>
                    </div>
                <?php endif; ?>

                <?php if ([] !== $activeCategories) : ?>
                    <div class="thecore-cc__categories<?php echo ! $showCategoryDescriptions ? ' thecore-cc__categories--inline' : ''; ?>">
                        <?php foreach ($activeCategories as $index => $category) : ?>
                            <?php
                            $categoryId = self::buildCategoryInputId($rootId, (string) $category['slug'], $index);
                            $isRequired = ! empty($category['required']);
                            ?>
                            <div class="thecore-cc__category">
                                <input
                                    type="checkbox"
                                    id="<?php echo esc_attr($categoryId); ?>"
                                    data-thecore-cc-category="<?php echo esc_attr((string) $category['slug']); ?>"
                                    <?php checked($isRequired); ?>
                                    <?php disabled($isRequired); ?>
                                />
                                <label for="<?php echo esc_attr($categoryId); ?>">
                                    <?php echo esc_html((string) $category['label']); ?>
                                </label>
                                <?php if ($showCategoryDescriptions && '' !== trim((string) $category['description'])) : ?>
                                    <p class="thecore-cc__category-description">
                                        <?php echo esc_html((string) $category['description']); ?>
                                    </p>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div class="thecore-cc__buttons">
                    <?php if ('' !== trim($acceptLabel)) : ?>
                        <button
                            type="button"
                            class="thecore-cc__button thecore-cc__accept-button"
                            data-thecore-cc-action="accept"
                        >
                            <?php echo esc_html($acceptLabel); ?>
                        </button>
                    <?php endif; ?>

                    <?php if ($shouldRenderConfirm && '' !== trim($confirmLabel)) : ?>
                        <button
                            type="button"
                            class="thecore-cc__button thecore-cc__confirm-button"
                            data-thecore-cc-action="confirm"
                        >
                            <?php echo esc_html($confirmLabel); ?>
                        </button>
                    <?php endif; ?>

                    <?php if ('' !== trim($rejectLabel)) : ?>
                        <button
                            type="button"
                            class="thecore-cc__button thecore-cc__reject-button"
                            data-thecore-cc-action="reject"
                        >
                            <?php echo esc_html($rejectLabel); ?>
                        </button>
                    <?php endif; ?>

                    <?php if ('' !== trim($privacyLabel) && '' !== $privacyUrl) : ?>
                        <a
                            href="<?php echo esc_url($privacyUrl); ?>"
                            class="thecore-cc__button thecore-cc__privacy-button"
                            <?php if ($privacyExternal) : ?>
                                target="_blank" rel="noopener noreferrer"
                            <?php endif; ?>
                        >
                            <?php echo esc_html($privacyLabel); ?>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php

        return (string) ob_get_clean();
    }

    public static function hasConsentCookie(): bool
    {
        return isset($_COOKIE[self::COOKIE_NAME]);
    }

    private function buildFrontendConfig(): array
    {
        $active = $this->configRepository->active();

        return [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'ajaxNonce' => wp_create_nonce('thecore_cookie_consent'),
            'log' => ! empty($active['log_consents']),
            'revokeAll' => ! empty($active['revoke_delete_all']),
            'revokeNotice' => __('Vos préférences de consentement ont été réinitialisées.', 'thecore-elementor-widgets')
                . (! empty($active['revoke_delete_all'])
                    ? ' ' . __('De plus, tous les cookies définis pour ce domaine ont été supprimés.', 'thecore-elementor-widgets')
                    : ''),
        ];
    }

    private function renderAcceptedCategoryCode(bool $inHead): string
    {
        if (! $this->configRepository->hasSavedConfig() || ! $this->helper->isCookieConsentSet()) {
            return '';
        }

        $output = '';

        foreach ($this->configRepository->active()['categories'] ?? [] as $category) {
            if (! is_array($category)) {
                continue;
            }

            $slug = isset($category['slug']) && is_string($category['slug']) ? $category['slug'] : '';
            $active = ! empty($category['active']);
            $code = isset($category['code']) && is_string($category['code']) ? trim($category['code']) : '';

            if ($slug === '' || ! $active || '' === $code || ! $this->helper->isCookieCategoryAccepted($slug)) {
                continue;
            }

            $printInHead = (bool) apply_filters('thecore_cookie_consent_print_' . $slug . '_code_in_head', false);

            if ($printInHead !== $inHead) {
                continue;
            }

            $sanitizedCode = apply_filters(
                'thecore_cookie_consent_' . $slug . '_code',
                html_entity_decode(trim(wp_kses($code, $this->helper->getAllowedHtml())))
            );

            if (is_string($sanitizedCode) && '' !== trim($sanitizedCode)) {
                $output .= $sanitizedCode;
            }
        }

        return $output;
    }

    private static function sanitizeThemePreset(mixed $value): string
    {
        $value = is_string($value) ? $value : '';

        return in_array($value, ['default', 'labs', 'sidecar', 'lowkey'], true)
            ? $value
            : self::DEFAULT_THEME_PRESET;
    }

    /**
     * @param mixed $categories
     *
     * @return array<int, array{
     *     slug: string,
     *     label: string,
     *     description: string,
     *     active: bool,
     *     required: bool,
     *     code: string
     * }>
     */
    private static function sanitizeCategories(mixed $categories): array
    {
        if (! is_array($categories)) {
            return [];
        }

        $normalized = [];

        foreach ($categories as $category) {
            if (! is_array($category)) {
                continue;
            }

            $slug = isset($category['slug']) && is_string($category['slug']) ? $category['slug'] : '';
            $label = isset($category['label']) && is_string($category['label']) ? $category['label'] : '';

            if ($slug === '' || $label === '') {
                continue;
            }

            $normalized[] = [
                'slug' => $slug,
                'label' => $label,
                'description' => isset($category['description']) && is_string($category['description'])
                    ? $category['description']
                    : '',
                'active' => ! empty($category['active']),
                'required' => ! empty($category['required']),
                'code' => isset($category['code']) && is_string($category['code'])
                    ? $category['code']
                    : '',
            ];
        }

        return $normalized;
    }

    private static function buildCategoryInputId(string $rootId, string $slug, int $index): string
    {
        $prefix = '' !== $rootId ? $rootId : 'thecore-cc';

        return sanitize_html_class($prefix . '-' . str_replace('_', '-', $slug) . '-' . $index);
    }
}
