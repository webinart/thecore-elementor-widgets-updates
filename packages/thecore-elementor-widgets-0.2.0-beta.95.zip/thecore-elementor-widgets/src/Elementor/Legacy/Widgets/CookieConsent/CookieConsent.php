<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Legacy\Widgets\CookieConsent;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;
use TheCore\ElementorWidgets\Assets\FrontendAssets;
use TheCore\ElementorWidgets\CookieConsent\CookieConsentModule;

final class CookieConsent extends Widget_Base
{
    public function get_name(): string
    {
        return 'thecore-cookie-consent';
    }

    public function get_title(): string
    {
        return __('Cookie Consent (Legacy)', 'thecore-elementor-widgets');
    }

    public function get_icon(): string
    {
        return 'eicon-lock-user';
    }

    public function get_categories(): array
    {
        return ['general'];
    }

    public function get_keywords(): array
    {
        return ['cookie', 'consent', 'gdpr', 'privacy', 'banner', 'the core'];
    }

    public function get_style_depends(): array
    {
        return [FrontendAssets::COOKIE_CONSENT_STYLE];
    }

    public function get_script_depends(): array
    {
        return [FrontendAssets::COOKIE_CONSENT_SCRIPT];
    }

    protected function register_controls(): void
    {
        $this->start_controls_section(
            'section_module',
            [
                'label' => __('Module', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'module_notice',
            [
                'type' => Controls_Manager::RAW_HTML,
                'raw' => esc_html__(
                    'This widget renders the consent banner directly. Disable the global theme cookie module on the same site to avoid duplicate banners.',
                    'thecore-elementor-widgets'
                ),
                'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
            ]
        );

        $this->add_control(
            'theme_preset',
            [
                'label' => __('Preset', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SELECT,
                'default' => CookieConsentModule::DEFAULT_THEME_PRESET,
                'options' => [
                    'default' => __('Default', 'thecore-elementor-widgets'),
                    'labs' => __('Labs', 'thecore-elementor-widgets'),
                    'sidecar' => __('Sidecar', 'thecore-elementor-widgets'),
                    'lowkey' => __('Low-key', 'thecore-elementor-widgets'),
                ],
            ]
        );

        $this->add_control(
            'preview_notice',
            [
                'label' => __('Preview', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::RAW_HTML,
                'raw' => esc_html__(
                    'These controls are preview-only. The real cookie categories and module behavior stay in Cookies > Config.',
                    'thecore-elementor-widgets'
                ),
                'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
            ]
        );

        $this->add_control(
            'preview_show_category_descriptions',
            [
                'label' => __('Show category descriptions in preview', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'thecore-elementor-widgets'),
                'label_off' => __('No', 'thecore-elementor-widgets'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        foreach (DisplaySettings::DEFAULT_CATEGORY_SETTINGS as $slug => $definition) {
            $this->add_control(
                'preview_' . $slug,
                [
                    'label' => sprintf(
                        __('Show %s in preview', 'thecore-elementor-widgets'),
                        (string) $definition['label']
                    ),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => __('Yes', 'thecore-elementor-widgets'),
                    'label_off' => __('No', 'thecore-elementor-widgets'),
                    'return_value' => 'yes',
                    'default' => 'yes',
                ]
            );
        }

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_panel',
            [
                'label' => __('Panel', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'root_typography',
                'label' => __('Root Typography', 'thecore-elementor-widgets'),
                'selector' => '{{WRAPPER}} .thecore-cc',
            ]
        );

        $this->add_responsive_control(
            'root_padding',
            [
                'label' => __('Viewport Padding', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', 'rem', '%', 'vw'],
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'panel_width',
            [
                'label' => __('Panel Width', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'vw'],
                'range' => [
                    'px' => [
                        'min' => 280,
                        'max' => 720,
                    ],
                    'vw' => [
                        'min' => 30,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc' => '--thecore-cc-panel-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'overlay_background',
            [
                'label' => __('Page Overlay Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'description' => __(
                    'Backdrop behind modal-style presets. Hidden for banner/toast presets that should not cover the page.',
                    'thecore-elementor-widgets'
                ),
                'condition' => [
                    'theme_preset' => ['labs', 'sidecar'],
                ],
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc' => '--thecore-cc-overlay: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'accent_color',
            [
                'label' => __('Accent Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc' => '--thecore-cc-accent: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'panel_background',
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .thecore-cc__container',
            ]
        );

        $this->add_control(
            'panel_text_color',
            [
                'label' => __('Text Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc__container' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'panel_typography',
                'label' => __('Panel Typography', 'thecore-elementor-widgets'),
                'selector' => '{{WRAPPER}} .thecore-cc__container',
            ]
        );

        $this->add_responsive_control(
            'panel_padding',
            [
                'label' => __('Panel Padding', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', 'rem', '%'],
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc__container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'panel_border',
                'selector' => '{{WRAPPER}} .thecore-cc__container',
            ]
        );

        $this->add_responsive_control(
            'panel_border_radius',
            [
                'label' => __('Border Radius', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc__container' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'panel_shadow',
                'selector' => '{{WRAPPER}} .thecore-cc__container',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_notice',
            [
                'label' => __('Notice Text', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'notice_text_color',
            [
                'label' => __('Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc__text' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'notice_typography',
                'selector' => '{{WRAPPER}} .thecore-cc__text',
            ]
        );

        $this->add_responsive_control(
            'notice_alignment',
            [
                'label' => __('Alignment', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc__text' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_categories',
            [
                'label' => __('Categories', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'category_label_color',
            [
                'label' => __('Label Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc__category label' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'category_label_typography',
                'selector' => '{{WRAPPER}} .thecore-cc__category label',
            ]
        );

        $this->add_control(
            'category_description_color',
            [
                'label' => __('Description Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc__category-description' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'category_description_typography',
                'selector' => '{{WRAPPER}} .thecore-cc__category-description',
            ]
        );

        $this->add_responsive_control(
            'categories_text_alignment',
            [
                'label' => __('Content Alignment', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc__category' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'categories_inline_alignment',
            [
                'label' => __('Inline Row Alignment', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => __('Left', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'flex-end' => [
                        'title' => __('Right', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc__categories--inline' => 'justify-content: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'category_background',
            [
                'label' => __('Card Background', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc' => '--thecore-cc-category-background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'category_border_color',
            [
                'label' => __('Card Border', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc' => '--thecore-cc-category-border: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'category_border_radius',
            [
                'label' => __('Card Border Radius', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc__category' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_buttons',
            [
                'label' => __('Buttons', 'thecore-elementor-widgets'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'selector' => '{{WRAPPER}} .thecore-cc__button',
            ]
        );

        $this->add_responsive_control(
            'buttons_alignment',
            [
                'label' => __('Alignment', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => __('Left', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'flex-end' => [
                        'title' => __('Right', 'thecore-elementor-widgets'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc__buttons' => 'justify-content: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'buttons_direction',
            [
                'label' => __('Direction', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'row' => __('Row', 'thecore-elementor-widgets'),
                    'column' => __('Column', 'thecore-elementor-widgets'),
                    'row-reverse' => __('Row Reversed', 'thecore-elementor-widgets'),
                    'column-reverse' => __('Column Reversed', 'thecore-elementor-widgets'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc__buttons' => 'flex-direction: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_width',
            [
                'label' => __('Button Width', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'auto' => __('Automatic', 'thecore-elementor-widgets'),
                    '100%' => __('Full Width', 'thecore-elementor-widgets'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc__button' => 'width: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_flex',
            [
                'label' => __('Button Flex', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '0 1 auto' => __('Natural', 'thecore-elementor-widgets'),
                    '0 0 auto' => __('Fixed', 'thecore-elementor-widgets'),
                    '1 1 auto' => __('Grow', 'thecore-elementor-widgets'),
                    '1 1 0%' => __('Equal Widths', 'thecore-elementor-widgets'),
                    '1 1 100%' => __('Own Row', 'thecore-elementor-widgets'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc__button' => 'flex: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_background_color',
            [
                'label' => __('Background', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc' => '--thecore-cc-button-background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_text_color',
            [
                'label' => __('Text Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc' => '--thecore-cc-button-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_border_color',
            [
                'label' => __('Border Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc' => '--thecore-cc-button-border: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_border_radius',
            [
                'label' => __('Border Radius', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc__button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'primary_button_heading',
            [
                'label' => __('Primary Button', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'primary_button_width',
            [
                'label' => __('Width', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'auto' => __('Automatic', 'thecore-elementor-widgets'),
                    '100%' => __('Full Width', 'thecore-elementor-widgets'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc__accept-button' => 'width: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'primary_button_flex',
            [
                'label' => __('Flex', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '0 1 auto' => __('Natural', 'thecore-elementor-widgets'),
                    '0 0 auto' => __('Fixed', 'thecore-elementor-widgets'),
                    '1 1 auto' => __('Grow', 'thecore-elementor-widgets'),
                    '1 1 0%' => __('Equal Width', 'thecore-elementor-widgets'),
                    '1 1 100%' => __('Own Row', 'thecore-elementor-widgets'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc__accept-button' => 'flex: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'primary_button_background_color',
            [
                'label' => __('Background', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc' => '--thecore-cc-primary-background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'primary_button_text_color',
            [
                'label' => __('Text Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc' => '--thecore-cc-primary-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'primary_button_border_color',
            [
                'label' => __('Border Color', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thecore-cc' => '--thecore-cc-primary-border: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render(): void
    {
        echo (new \TheCore\ElementorWidgets\CookieConsent\Presentation())->render(
            $this->get_settings_for_display(),
            'thecore-cc-' . $this->get_id(),
            \TheCore\ElementorWidgets\CookieConsent\Presentation::isEditorPreview()
        );
    }
}
