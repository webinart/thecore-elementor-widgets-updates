<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\CookieConsent;

use TheCore\ElementorWidgets\CookieConsent\PresetStyles;

/** Only public, sanitized display data is embedded in the editor template. */
final class EditorPreview
{
    public function template(array $config, string $template): string
    {
        $data = [
            'notice' => wp_kses_post((string) ($config['notice_text'] ?? '')),
            'privacy_url' => esc_url((string) ($config['privacy_policy_url'] ?? '')),
            'privacy_external' => ! empty($config['privacy_policy_external']),
            'buttons' => array_map('strval', array_intersect_key($config['buttons'] ?? [], array_flip(['accept', 'confirm', 'reject', 'privacy']))),
            'categories' => [],
        ];
        foreach ($config['categories'] ?? [] as $category) {
            if (! is_array($category)) {
                continue;
            }
            $data['categories'][] = [
                'slug' => sanitize_key((string) ($category['slug'] ?? '')),
                'label' => (string) ($category['label'] ?? ''),
                'description' => (string) ($category['description'] ?? ''),
                'required' => ! empty($category['required']),
            ];
        }
        $prefix = '{% set cc = ' . $this->literal($data) . ' %}';
        $prefix .= '{% set preset = settings.theme_preset|default("default") %}';
        foreach (['default', 'labs', 'sidecar', 'lowkey'] as $preset) {
            $style = (new PresetStyles())->render('THECORE_CC_PREVIEW_ID', $preset);
            $prefix .= '{% if preset == "' . $preset . '" %}'
                . str_replace('THECORE_CC_PREVIEW_ID', 'thecore-cc-v4-{{ id }}', $style) . '{% endif %}';
        }
        return $prefix . '<style>' . (new Appearance())->twig() . '</style>' . $template;
    }

    private function literal(mixed $value): string
    {
        if (is_bool($value)) {
            return $value ? 'true' : 'false';
        }
        if (is_array($value)) {
            if (array_is_list($value)) {
                return '[' . implode(',', array_map($this->literal(...), $value)) . ']';
            }
            $pairs = [];
            foreach ($value as $key => $item) {
                $pairs[] = $this->literal($key) . ':' . $this->literal($item);
            }
            return '{' . implode(',', $pairs) . '}';
        }
        // Single-quoted Twig strings avoid interpolation of administrator-supplied text.
        return "'" . str_replace(["\\", "'", "\r", "\n"], ["\\\\", "\\'", '\\r', '\\n'], (string) $value) . "'";
    }
}
