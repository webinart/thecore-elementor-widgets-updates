<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\CookieConsent;

use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Select_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Size_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Switch_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Text_Control;
use Elementor\Modules\AtomicWidgets\DynamicTags\Dynamic_Prop_Type;
use Elementor\Modules\AtomicWidgets\Elements\Base\Atomic_Widget_Base;
use Elementor\Modules\AtomicWidgets\Elements\Base\Has_Template;
use Elementor\Modules\AtomicWidgets\PropTypes\Classes_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Color_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Boolean_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Size_Prop_Type;
use Elementor\Modules\AtomicWidgets\Styles\Style_Definition;
use Elementor\Modules\AtomicWidgets\Styles\Style_Variant;
use Elementor\Modules\Components\PropTypes\Overridable_Prop_Type;
use TheCore\ElementorWidgets\Assets\FrontendAssets;
use TheCore\ElementorWidgets\CookieConsent\ConfigRepository;
use TheCore\ElementorWidgets\CookieConsent\Presentation;
use TheCore\ElementorWidgets\Elementor\Atomic\Controls\Types\ColorControl;
use TheCore\ElementorWidgets\Elementor\Atomic\Controls\Types\FontFamilyControl;
use TheCore\ElementorWidgets\Elementor\Legacy\Widgets\CookieConsent\DisplaySettings;

final class CookieConsent extends Atomic_Widget_Base
{
    use Has_Template {
        get_templates_contents as private nativeTemplates;
    }

    public static $widget_description = 'Cookie consent banner using the shared The Core consent service. Native V4 styles target the panel.';

    public static function get_element_type(): string
    {
        return 'thecore-cc';
    }

    public static function get_computed_html_tag(array $settings): string
    {
        return 'div';
    }

    public function get_title(): string
    {
        return __('Cookie Consent (V4)', 'thecore-elementor-widgets');
    }

    public function get_icon(): string
    {
        return 'eicon-lock-user';
    }

    public function get_keywords(): array
    {
        return ['cookie', 'consent', 'privacy', 'banner', 'atomic'];
    }

    public function get_script_depends(): array
    {
        return [FrontendAssets::COOKIE_CONSENT_SCRIPT];
    }

    public function get_style_depends(): array
    {
        return [FrontendAssets::COOKIE_CONSENT_STYLE];
    }

    protected static function define_props_schema(): array
    {
        $props = [
            'classes' => Classes_Prop_Type::make()->default([]),
            'theme_preset' => String_Prop_Type::make()->enum(['default', 'labs', 'sidecar', 'lowkey'])->default('default'),
            'preview_show_category_descriptions' => Boolean_Prop_Type::make()->default(true),
        ];
        foreach (DisplaySettings::DEFAULT_CATEGORY_SETTINGS as $slug => $category) {
            $props['preview_' . $slug] = Boolean_Prop_Type::make()->default(true);
        }
        foreach (Appearance::definitions() as $key => $definition) {
            $props[$key] = match ($definition['type']) {
                'color' => Color_Prop_Type::make(),
                'size' => Size_Prop_Type::make()->units(['px', 'em', 'rem', '%', 'vw'])->default_unit('px'),
                'enum' => String_Prop_Type::make()->enum(array_merge([''], $definition['options']))->default(''),
                default => String_Prop_Type::make()->default(''),
            };
        }
        foreach ($props as $key => $prop) {
            if ($key !== 'classes') {
                $prop->meta(Dynamic_Prop_Type::ignore())->meta(Overridable_Prop_Type::ignore());
            }
        }
        return $props;
    }

    protected function define_base_styles(): array
    {
        return ['base' => Style_Definition::make()->add_variant(Style_Variant::make()
            ->add_prop('box-sizing', String_Prop_Type::generate('border-box')))];
    }

    protected function define_atomic_controls(): array
    {
        $preview = [Switch_Control::bind_to('preview_show_category_descriptions')
            ->set_label(__('Show category descriptions', 'thecore-elementor-widgets'))];
        foreach (DisplaySettings::DEFAULT_CATEGORY_SETTINGS as $slug => $category) {
            $preview[] = Switch_Control::bind_to('preview_' . $slug)->set_label($category['label']);
        }
        $sections = [
            Section::make()->set_label(__('Module', 'thecore-elementor-widgets'))
                ->set_description(__('Content and consent settings remain in Cookies > Config. The native Style tab styles the panel, including responsive backgrounds, gradients, typography and spacing. Do not add a second consent banner on the same page.', 'thecore-elementor-widgets'))
                ->set_items([Select_Control::bind_to('theme_preset')->set_label(__('Preset', 'thecore-elementor-widgets'))
                    ->set_options([
                        ['label' => 'Default', 'value' => 'default'], ['label' => 'Labs', 'value' => 'labs'],
                        ['label' => 'Sidecar', 'value' => 'sidecar'], ['label' => 'Low-key', 'value' => 'lowkey'],
                    ])]),
            Section::make()->set_label(__('Editor preview only', 'thecore-elementor-widgets'))
                ->set_description(__('These switches never enable categories or change consent behavior on the public site.', 'thecore-elementor-widgets'))
                ->set_items($preview),
        ];
        $groups = [];
        foreach (Appearance::definitions() as $key => $definition) {
            $control = match ($definition['type']) {
                'color' => ColorControl::bind_to($key),
                'font' => FontFamilyControl::bind_to($key),
                'size' => Size_Control::bind_to($key)->set_units(['px', 'em', 'rem', '%', 'vw'])
                    ->set_default_unit('px')->set_disable_custom(true),
                default => Select_Control::bind_to($key)->set_options(array_merge(
                    [['label' => __('Preset / inherited', 'thecore-elementor-widgets'), 'value' => '']],
                    array_map(static fn(string $value): array => ['label' => $value, 'value' => $value], $definition['options'])
                )),
            };
            $groups[$definition['section']][] = $control->set_label(__($definition['label'], 'thecore-elementor-widgets'));
        }
        foreach ($groups as $label => $controls) {
            $sections[] = Section::make()->set_label(__($label, 'thecore-elementor-widgets'))->set_items($controls);
        }
        $sections[] = Section::make()->set_label(__('Settings', 'thecore-elementor-widgets'))->set_id('settings')
            ->set_items([Text_Control::bind_to('_cssid')->set_label(__('Panel ID', 'thecore-elementor-widgets'))
                ->set_meta($this->get_css_id_control_meta())]);
        return $sections;
    }

    protected function get_templates(): array
    {
        return ['thecore/elements/cookie-consent' => __DIR__ . '/cookie-consent.html.twig'];
    }

    protected function get_templates_contents()
    {
        $templates = $this->nativeTemplates();
        $key = 'thecore/elements/cookie-consent';
        $templates[$key] = (new EditorPreview())->template((new ConfigRepository())->active(), $templates[$key]);
        return $templates;
    }

    protected function render()
    {
        $settings = $this->get_atomic_settings();
        $id = 'thecore-cc-v4-' . sanitize_html_class($this->get_id());
        $classes = array_merge(
            [$this->get_base_styles_dictionary()['base']],
            is_array($settings['classes'] ?? null) ? $settings['classes'] : []
        );
        $css = (new Appearance())->css($id, $settings);
        $markup = (new Presentation())->render($settings, $id, Presentation::isEditorPreview(), $classes, (string) ($settings['_cssid'] ?? ''));
        // Overrides are already scoped and validated; native panel classes remain Elementor-owned.
        echo ($css !== '' ? '<style>' . $css . '</style>' : '') . $markup;
    }
}
