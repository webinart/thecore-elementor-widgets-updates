<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\CookieConsent;

/** Optional inner-part overrides; the panel itself uses native V4 styles. */
final class Appearance
{
    public static function definitions(): array
    {
        $definitions = [];
        foreach (
            [
            'overlay_color' => ['Banner', '', '--thecore-cc-overlay', 'Page overlay'],
            'accent_color' => ['Banner', '', '--thecore-cc-accent', 'Accent color'],
            'category_background' => ['Categories', '', '--thecore-cc-category-background', 'Card background'],
            'category_border' => ['Categories', '', '--thecore-cc-category-border', 'Card border'],
            'button_background' => ['Buttons', '', '--thecore-cc-button-background', 'Background'],
            'button_color' => ['Buttons', '', '--thecore-cc-button-color', 'Text color'],
            'button_border' => ['Buttons', '', '--thecore-cc-button-border', 'Border color'],
            'primary_background' => ['Primary button', '', '--thecore-cc-primary-background', 'Background'],
            'primary_color' => ['Primary button', '', '--thecore-cc-primary-color', 'Text color'],
            'primary_border' => ['Primary button', '', '--thecore-cc-primary-border', 'Border color'],
            ] as $key => [$section, $selector, $property, $label]
        ) {
            $definitions[$key] = compact('section', 'selector', 'property', 'label') + ['type' => 'color'];
        }
        foreach (
            [
            'notice' => ['Notice text', ' .thecore-cc__text'],
            'category_label' => ['Category labels', ' .thecore-cc__category label'],
            'category_description' => ['Category descriptions', ' .thecore-cc__category-description'],
            'buttons' => ['Button typography', ' .thecore-cc__button'],
            ] as $prefix => [$section, $selector]
        ) {
            foreach (
                [
                'color' => ['color', 'Color'],
                'font-family' => ['font', 'Font family'],
                'font-size' => ['size', 'Font size'],
                'line-height' => ['size', 'Line height'],
                'letter-spacing' => ['size', 'Letter spacing'],
                'font-weight' => ['enum', 'Font weight', ['inherit', '400', '500', '600', '700', '800', '900']],
                'text-transform' => ['enum', 'Text transform', ['none', 'uppercase', 'lowercase', 'capitalize']],
                ] as $property => $definition
            ) {
                if ($prefix === 'buttons' && $property === 'color') {
                    continue; // Button colors use shared variables so primary colors can still override them.
                }
                [$type, $label] = $definition;
                $definitions[$prefix . '_' . str_replace('-', '_', $property)] = compact('section', 'selector', 'property', 'type', 'label')
                    + ['options' => $definition[2] ?? []];
            }
        }
        foreach (
            [
            'viewport_padding' => ['Banner', '', 'padding', 'Viewport padding'],
            'panel_width' => ['Banner', '', '--thecore-cc-panel-width', 'Preset panel width'],
            'category_radius' => ['Categories', ' .thecore-cc__category', 'border-radius', 'Card radius'],
            'button_radius' => ['Buttons', ' .thecore-cc__button', 'border-radius', 'Border radius'],
            'button_padding' => ['Buttons', ' .thecore-cc__button', 'padding', 'Padding'],
            'buttons_gap' => ['Buttons', ' .thecore-cc__buttons', 'gap', 'Gap'],
            ] as $key => [$section, $selector, $property, $label]
        ) {
            $definitions[$key] = compact('section', 'selector', 'property', 'label') + ['type' => 'size'];
        }
        $align = ['left', 'center', 'right'];
        $justify = ['flex-start', 'center', 'flex-end', 'space-between'];
        $flex = ['0 1 auto', '0 0 auto', '1 1 auto', '1 1 0%', '1 1 100%'];
        foreach (
            [
            'notice_alignment' => ['Notice text', ' .thecore-cc__text', 'text-align', 'Alignment', $align],
            'category_alignment' => ['Categories', ' .thecore-cc__category', 'text-align', 'Text alignment', $align],
            'categories_alignment' => ['Categories', ' .thecore-cc__categories--inline', 'justify-content', 'Row alignment', $justify],
            'buttons_alignment' => ['Buttons', ' .thecore-cc__buttons', 'justify-content', 'Alignment', $justify],
            'buttons_direction' => ['Buttons', ' .thecore-cc__buttons', 'flex-direction', 'Direction', ['row', 'column']],
            'button_width' => ['Buttons', ' .thecore-cc__button', 'width', 'Width', ['auto', '100%']],
            'button_flex' => ['Buttons', ' .thecore-cc__button', 'flex', 'Flex', $flex],
            'primary_width' => ['Primary button', ' .thecore-cc__accept-button', 'width', 'Width', ['auto', '100%']],
            'primary_flex' => ['Primary button', ' .thecore-cc__accept-button', 'flex', 'Flex', $flex],
            ] as $key => [$section, $selector, $property, $label, $options]
        ) {
            $definitions[$key] = compact('section', 'selector', 'property', 'label', 'options') + ['type' => 'enum'];
        }
        return $definitions;
    }

    public function css(string $rootId, array $settings): string
    {
        $rules = [];
        foreach (self::definitions() as $key => $definition) {
            $value = $this->value($settings[$key] ?? null, $definition);
            if ($value !== '') {
                $selector = '#' . sanitize_html_class($rootId) . $definition['selector'];
                $rules[$selector][] = $definition['property'] . ':' . $value;
            }
        }
        $css = '';
        foreach ($rules as $selector => $declarations) {
            $css .= $selector . '{' . implode(';', $declarations) . ';}';
        }
        return $css;
    }

    public function twig(): string
    {
        $css = '';
        foreach (self::definitions() as $key => $definition) {
            $value = 'settings.' . $key;
            $condition = $value . ' is not null and ' . $value . ' is defined';
            if ($definition['type'] === 'size') {
                $condition .= ' and ' . $value . '.size is not null and ' . $value . '.unit in ["px", "em", "rem", "%", "vw"]';
                $output = '{{ (' . $value . '.size + 0) }}{{ ' . $value . '.unit }}';
            } elseif ($definition['type'] === 'enum') {
                $condition .= ' and ' . $value . ' in ' . json_encode($definition['options']);
                $output = '{{ ' . $value . ' }}';
            } else {
                $condition .= ' and ' . $value . ' != ""';
                // No HTML/style termination or CSS declaration separators in preview values.
                $output = '{{ ' . $value . '|replace({"<":"", ">":"", ";":"", "{":"", "}":""})|raw }}';
            }
            $css .= '{% if ' . $condition . ' %}#thecore-cc-v4-{{ id }}' . $definition['selector']
                . '{' . $definition['property'] . ':' . $output . ';}{% endif %}';
        }
        return $css;
    }

    private function value(mixed $value, array $definition): string
    {
        if ($definition['type'] === 'size') {
            if (
                ! is_array($value) || ! is_numeric($value['size'] ?? null)
                || ! in_array($value['unit'] ?? '', ['px', 'em', 'rem', '%', 'vw'], true)
            ) {
                return '';
            }
            $number = (float) $value['size'];
            return is_finite($number) && $number >= -100 && $number <= 10000
                ? rtrim(rtrim(sprintf('%.4F', $number), '0'), '.') . $value['unit'] : '';
        }
        if (! is_string($value)) {
            return '';
        }
        $value = trim($value);
        if ($definition['type'] === 'enum') {
            return in_array($value, $definition['options'], true) ? $value : '';
        }
        if ($definition['type'] === 'font') {
            return preg_match('/\A[\p{L}\p{N}\s,\x27"_-]{1,200}\z/u', $value) ? $value : '';
        }
        return preg_match('/\A(?:\#[a-f0-9]{3,8}|(?:rgb|rgba|hsl|hsla)\([0-9.,%\s\/-]+\)|var\(--[a-z0-9_-]+\)|transparent|currentcolor|inherit)\z/i', $value)
            ? $value : '';
    }
}
