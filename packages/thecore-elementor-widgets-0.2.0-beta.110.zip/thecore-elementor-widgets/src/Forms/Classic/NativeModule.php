<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Classic;

use TheCore\ElementorWidgets\Contracts\Bootable;

/** Opt-in frontend adapter. Elementor remains the sole server-side form processor. */
final class NativeModule implements Bootable
{
    public const SCRIPT = 'thecore-native-classic-form';
    public const FILTER = 'thecore_elementor_widgets/forms/native_classic';
    public const SCRIPT_DEPENDENCIES_FILTER = 'thecore_elementor_widgets/forms/native_classic/script_dependencies';

    public function register(): void
    {
        add_action('wp_enqueue_scripts', [$this, 'registerAssets'], 5);
        add_action('elementor/widgets/register', [$this, 'registerWidget'], 1000);
        add_action('elementor/frontend/widget/before_render', [$this, 'prepareWidget'], -10);
    }

    public function registerAssets(): void
    {
        wp_register_script(
            self::SCRIPT,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/native-classic-form.js',
            ['thecore-form-api'],
            THECORE_ELEMENTOR_WIDGETS_VERSION,
            true
        );
        wp_register_style(
            self::SCRIPT,
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/native-classic-form.css',
            [],
            THECORE_ELEMENTOR_WIDGETS_VERSION
        );
    }

    public function registerWidget(object $manager): void
    {
        if (class_exists('\\ElementorPro\\Modules\\Forms\\Widgets\\Form') && method_exists($manager, 'register')) {
            $manager->register(new NativeWidget());
        }
    }

    public static function isEnabled(object $widget): bool
    {
        if (! method_exists($widget, 'get_name') || $widget->get_name() !== 'form') {
            return false;
        }
        if (class_exists('\\Elementor\\Plugin') && \Elementor\Plugin::$instance->editor->is_edit_mode()) {
            return false;
        }
        return apply_filters(self::FILTER, false, $widget) === true;
    }

    /**
     * Declare the runtime and scripts owned by the fields actually rendered.
     * Field rendering may be cached; enqueue side effects cannot be the only
     * inventory used by a theme's dependency collector or a fragment renderer.
     *
     * The filter adds site-specific roots. It cannot remove the runtime or a
     * field's declared dependency; WordPress still resolves their transitive graph.
     *
     * @return string[]
     */
    public static function scriptDependencies(object $widget): array
    {
        $dependencies = [self::SCRIPT];
        $fields = method_exists($widget, 'get_settings_for_display')
            ? $widget->get_settings_for_display('form_fields')
            : [];
        $moduleClass = '\\ElementorPro\\Modules\\Forms\\Module';
        $registrar = null;
        if (is_array($fields) && $fields !== [] && class_exists($moduleClass)) {
            $module = $moduleClass::instance();
            $registrar = is_object($module) ? ($module->fields_registrar ?? null) : null;
        }
        if (is_object($registrar) && is_callable([$registrar, 'get'])) {
            $seen = [];
            foreach ($fields as $field) {
                $type = is_array($field) ? ($field['field_type'] ?? null) : null;
                if (! is_string($type) || $type === '' || isset($seen[$type])) {
                    continue;
                }
                $seen[$type] = true;
                $handler = $registrar->get($type);
                if (is_object($handler) && is_callable([$handler, 'get_script_depends'])) {
                    $declared = $handler->get_script_depends();
                    if (is_array($declared)) {
                        $dependencies = [...$dependencies, ...$declared];
                    }
                }
            }
        }

        $additional = apply_filters(self::SCRIPT_DEPENDENCIES_FILTER, $dependencies, $widget);
        $dependencies = [...$dependencies, ...(is_array($additional) ? $additional : [])];

        return array_values(array_unique(array_filter(
            $dependencies,
            static fn ($handle): bool => is_string($handle) && trim($handle) !== ''
        )));
    }

    public function prepareWidget(object $widget): void
    {
        if (! self::isEnabled($widget)) {
            return;
        }
        $settings = (array) $widget->get_settings_for_display();
        $config = [
            'version' => 1,
            'endpoint' => admin_url('admin-ajax.php'),
            'nextLabel' => (string) ($settings['step_next_label'] ?? 'Continuer'),
            'previousLabel' => (string) ($settings['step_previous_label'] ?? 'Retour'),
            'stepType' => (string) ($settings['step_type'] ?? 'number_text'),
            'stepShape' => (string) ($settings['step_icon_shape'] ?? 'circle'),
            'buttonWidth' => (string) ($settings['button_width'] ?? '100'),
        ];
        $widget->add_render_attribute('_wrapper', 'data-thecore-native-form', '1', true);
        $widget->add_render_attribute('_wrapper', 'data-thecore-native-config', wp_json_encode($config), true);
        wp_enqueue_script(self::SCRIPT);
        wp_enqueue_style(self::SCRIPT);
    }
}
