<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Classic;

/** Retains Pro rendering, controls, field hooks and PHP actions; isolates its JS dispatcher. */
final class NativeWidget extends \ElementorPro\Modules\Forms\Widgets\Form
{
    public function get_script_depends()
    {
        return NativeModule::isEnabled($this) ? NativeModule::scriptDependencies($this) : parent::get_script_depends();
    }

    public function get_style_depends(): array
    {
        $styles = parent::get_style_depends();
        return NativeModule::isEnabled($this) ? array_values(array_unique([...$styles, NativeModule::SCRIPT])) : $styles;
    }

    protected function add_render_attributes()
    {
        parent::add_render_attributes();
        if (NativeModule::isEnabled($this)) {
            $this->add_render_attribute('_wrapper', 'data-widget_type', 'thecore-native-form.default', true);
        }
    }
}
