<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Legacy\Widgets\AccessibilityModule;

final class DisplaySettings
{
    public const DEFAULT_HEADER_EYEBROW = 'Accessibility';
    public const DEFAULT_HEADER_TITLE = '';
    public const DEFAULT_HEADER_SUBTITLE = '';
    public const DEFAULT_MODULE_VERTICAL_POSITION = 'bottom';
    public const DEFAULT_MODULE_HORIZONTAL_POSITION = 'right';
    public const DEFAULT_SKIP_LINK_LABEL = 'Skip to content';
    public const DEFAULT_SKIP_LINK_TARGET_SELECTOR = 'main, #content, [role="main"]';
    public const DEFAULT_SKIP_LINK_MOUNT_SELECTOR = 'body';
    public const DEFAULT_CLOSE_BUTTON_LABEL = 'Close accessibility tools';
    public const DEFAULT_RESET_LABEL = 'Restore defaults';
    public const DEFAULT_HELP_LABEL = 'Help';
    public const DEFAULT_FEEDBACK_LABEL = 'Feedback';
    public const DEFAULT_SECTION_TITLES = [
        'section_content_adjustments_title' => 'Content Adjustments',
        'section_orientation_adjustments_title' => 'Orientation Adjustments',
        'section_color_adjustments_title' => 'Color Adjustments',
    ];
    public const DEFAULT_FEATURE_LABELS = [
        'feature_bigger_text_label' => 'Bigger text',
        'feature_bigger_line_height_label' => 'Bigger line height',
        'feature_text_align_label' => 'Text align',
        'feature_readable_font_label' => 'Readable font',
        'feature_grayscale_label' => 'Greyscale',
        'feature_contrast_label' => 'Contrast',
        'feature_page_structure_label' => 'Page structure',
        'feature_reading_mask_label' => 'Reading mask',
        'feature_hide_images_label' => 'Hide images',
        'feature_pause_animations_label' => 'Pause animations',
        'feature_highlight_links_label' => 'Highlight links',
        'feature_focus_outline_label' => 'Outline focus',
    ];
    /**
     * @var array<string, array{
     *   setting: string,
     *   label_setting: string,
     *   default_label: string,
     *   icon: string,
     *   section_title_setting: string
     * }>
     */
    private const FEATURE_DEFINITIONS = [
        'bigger-text' => [
            'setting' => 'feature_bigger_text',
            'label_setting' => 'feature_bigger_text_label',
            'default_label' => 'Bigger text',
            'icon' => 'bigger-text',
            'section_title_setting' => 'section_content_adjustments_title',
        ],
        'bigger-line-height' => [
            'setting' => 'feature_bigger_line_height',
            'label_setting' => 'feature_bigger_line_height_label',
            'default_label' => 'Bigger line height',
            'icon' => 'bigger-line-height',
            'section_title_setting' => 'section_content_adjustments_title',
        ],
        'text-align' => [
            'setting' => 'feature_text_align',
            'label_setting' => 'feature_text_align_label',
            'default_label' => 'Text align',
            'icon' => 'text-align',
            'section_title_setting' => 'section_content_adjustments_title',
        ],
        'readable-font' => [
            'setting' => 'feature_readable_font',
            'label_setting' => 'feature_readable_font_label',
            'default_label' => 'Readable font',
            'icon' => 'readable-font',
            'section_title_setting' => 'section_content_adjustments_title',
        ],
        'page-structure' => [
            'setting' => 'feature_page_structure',
            'label_setting' => 'feature_page_structure_label',
            'default_label' => 'Page structure',
            'icon' => 'page-structure',
            'section_title_setting' => 'section_orientation_adjustments_title',
        ],
        'reading-mask' => [
            'setting' => 'feature_reading_mask',
            'label_setting' => 'feature_reading_mask_label',
            'default_label' => 'Reading mask',
            'icon' => 'reading-mask',
            'section_title_setting' => 'section_orientation_adjustments_title',
        ],
        'hide-images' => [
            'setting' => 'feature_hide_images',
            'label_setting' => 'feature_hide_images_label',
            'default_label' => 'Hide images',
            'icon' => 'hide-images',
            'section_title_setting' => 'section_orientation_adjustments_title',
        ],
        'pause-animations' => [
            'setting' => 'feature_pause_animations',
            'label_setting' => 'feature_pause_animations_label',
            'default_label' => 'Pause animations',
            'icon' => 'pause-animations',
            'section_title_setting' => 'section_orientation_adjustments_title',
        ],
        'highlight-links' => [
            'setting' => 'feature_highlight_links',
            'label_setting' => 'feature_highlight_links_label',
            'default_label' => 'Highlight links',
            'icon' => 'highlight-links',
            'section_title_setting' => 'section_orientation_adjustments_title',
        ],
        'focus-outline' => [
            'setting' => 'feature_focus_outline',
            'label_setting' => 'feature_focus_outline_label',
            'default_label' => 'Outline focus',
            'icon' => 'focus-outline',
            'section_title_setting' => 'section_orientation_adjustments_title',
        ],
        'grayscale' => [
            'setting' => 'feature_grayscale',
            'label_setting' => 'feature_grayscale_label',
            'default_label' => 'Greyscale',
            'icon' => 'grayscale',
            'section_title_setting' => 'section_color_adjustments_title',
        ],
        'contrast' => [
            'setting' => 'feature_contrast',
            'label_setting' => 'feature_contrast_label',
            'default_label' => 'Contrast',
            'icon' => 'contrast',
            'section_title_setting' => 'section_color_adjustments_title',
        ],
    ];

    /**
     * @param array<string, mixed> $settings
     *
     * @return array<string, bool|string>
     */
    public function normalize(array $settings): array
    {
        $normalized = [
            'header_eyebrow_text' => $this->sanitizeText(
                $settings['header_eyebrow_text'] ?? self::DEFAULT_HEADER_EYEBROW,
                self::DEFAULT_HEADER_EYEBROW
            ),
            'header_title_text' => $this->sanitizeOptionalText(
                $settings['header_title_text'] ?? self::DEFAULT_HEADER_TITLE
            ),
            'header_subtitle_text' => $this->sanitizeOptionalTextarea(
                $settings['header_subtitle_text'] ?? self::DEFAULT_HEADER_SUBTITLE
            ),
            'module_vertical_position' => $this->sanitizeEnum(
                $settings['module_vertical_position'] ?? self::DEFAULT_MODULE_VERTICAL_POSITION,
                ['top', 'center', 'bottom'],
                self::DEFAULT_MODULE_VERTICAL_POSITION
            ),
            'module_horizontal_position' => $this->sanitizeEnum(
                $settings['module_horizontal_position'] ?? self::DEFAULT_MODULE_HORIZONTAL_POSITION,
                ['left', 'right'],
                self::DEFAULT_MODULE_HORIZONTAL_POSITION
            ),
            'close_button_label' => $this->sanitizeText(
                $settings['close_button_label'] ?? self::DEFAULT_CLOSE_BUTTON_LABEL,
                self::DEFAULT_CLOSE_BUTTON_LABEL
            ),
            'reset_label' => $this->sanitizeText(
                $settings['reset_label'] ?? self::DEFAULT_RESET_LABEL,
                self::DEFAULT_RESET_LABEL
            ),
            'section_content_adjustments_title' => $this->sanitizeText(
                $settings['section_content_adjustments_title'] ?? self::DEFAULT_SECTION_TITLES['section_content_adjustments_title'],
                self::DEFAULT_SECTION_TITLES['section_content_adjustments_title']
            ),
            'section_orientation_adjustments_title' => $this->sanitizeText(
                $settings['section_orientation_adjustments_title'] ?? self::DEFAULT_SECTION_TITLES['section_orientation_adjustments_title'],
                self::DEFAULT_SECTION_TITLES['section_orientation_adjustments_title']
            ),
            'section_color_adjustments_title' => $this->sanitizeText(
                $settings['section_color_adjustments_title'] ?? self::DEFAULT_SECTION_TITLES['section_color_adjustments_title'],
                self::DEFAULT_SECTION_TITLES['section_color_adjustments_title']
            ),
            'help_label' => $this->sanitizeText($settings['help_label'] ?? self::DEFAULT_HELP_LABEL, self::DEFAULT_HELP_LABEL),
            'help_url' => $this->sanitizeUrl($settings['help_url'] ?? ''),
            'feedback_label' => $this->sanitizeText(
                $settings['feedback_label'] ?? self::DEFAULT_FEEDBACK_LABEL,
                self::DEFAULT_FEEDBACK_LABEL
            ),
            'feedback_url' => $this->sanitizeUrl($settings['feedback_url'] ?? ''),
            'skip_link_enabled' => $this->toBool($settings['skip_link_enabled'] ?? false),
            'skip_link_label' => $this->sanitizeText(
                $settings['skip_link_label'] ?? self::DEFAULT_SKIP_LINK_LABEL,
                self::DEFAULT_SKIP_LINK_LABEL
            ),
            'skip_link_hidden' => $this->toBool($settings['skip_link_hidden'] ?? false),
            'skip_link_target_selector' => $this->sanitizeSelector(
                $settings['skip_link_target_selector'] ?? self::DEFAULT_SKIP_LINK_TARGET_SELECTOR,
                self::DEFAULT_SKIP_LINK_TARGET_SELECTOR
            ),
            'skip_link_mount_selector' => $this->sanitizeSelector(
                $settings['skip_link_mount_selector'] ?? self::DEFAULT_SKIP_LINK_MOUNT_SELECTOR,
                self::DEFAULT_SKIP_LINK_MOUNT_SELECTOR
            ),
        ];

        foreach (self::FEATURE_DEFINITIONS as $definition) {
            $normalized[$definition['setting']] = $this->toBool($settings[$definition['setting']] ?? true);
            $normalized[$definition['label_setting']] = $this->sanitizeText(
                $settings[$definition['label_setting']] ?? $definition['default_label'],
                $definition['default_label']
            );
        }

        return $normalized;
    }

    /**
     * @return array<string, string>
     */
    public static function getFeatureControlLabels(): array
    {
        $labels = [];

        foreach (self::FEATURE_DEFINITIONS as $definition) {
            $labels[$definition['setting']] = esc_html__($definition['default_label'], 'thecore-elementor-widgets');
        }

        return $labels;
    }

    /**
     * @return array<int, array{title: string, title_setting: string, items: array<string, array{setting: string, label_setting: string, label: string, icon: string}>}>
     */
    public static function getSectionDefinitions(): array
    {
        $sections = [];

        foreach (self::DEFAULT_SECTION_TITLES as $titleSetting => $defaultTitle) {
            $items = [];

            foreach (self::FEATURE_DEFINITIONS as $actionKey => $definition) {
                if ($definition['section_title_setting'] !== $titleSetting) {
                    continue;
                }

                $items[$actionKey] = [
                    'setting' => $definition['setting'],
                    'label_setting' => $definition['label_setting'],
                    'label' => esc_html__($definition['default_label'], 'thecore-elementor-widgets'),
                    'icon' => $definition['icon'],
                ];
            }

            $sections[] = [
                'title' => esc_html__($defaultTitle, 'thecore-elementor-widgets'),
                'title_setting' => $titleSetting,
                'items' => $items,
            ];
        }

        return $sections;
    }

    private function sanitizeText(mixed $value, string $default): string
    {
        if (! is_scalar($value)) {
            return $default;
        }

        $sanitized = sanitize_text_field((string) $value);

        return '' !== $sanitized ? $sanitized : $default;
    }

    private function sanitizeTextarea(mixed $value, string $default): string
    {
        if (! is_scalar($value)) {
            return $default;
        }

        $sanitized = sanitize_textarea_field((string) $value);

        return '' !== $sanitized ? $sanitized : $default;
    }

    private function sanitizeOptionalText(mixed $value): string
    {
        if (! is_scalar($value)) {
            return '';
        }

        return sanitize_text_field((string) $value);
    }

    private function sanitizeOptionalTextarea(mixed $value): string
    {
        if (! is_scalar($value)) {
            return '';
        }

        return sanitize_textarea_field((string) $value);
    }

    private function sanitizeSelector(mixed $value, string $default): string
    {
        if (! is_scalar($value)) {
            return $default;
        }

        $normalized = trim(wp_strip_all_tags((string) $value));

        return '' !== $normalized ? $normalized : $default;
    }

    private function sanitizeUrl(mixed $value): string
    {
        if (is_array($value)) {
            $value = $value['url'] ?? '';
        }

        if (! is_scalar($value)) {
            return '';
        }

        return esc_url_raw((string) $value);
    }

    /**
     * @param array<int, string> $allowed
     */
    private function sanitizeEnum(mixed $value, array $allowed, string $default): string
    {
        if (! is_string($value)) {
            return $default;
        }

        return in_array($value, $allowed, true) ? $value : $default;
    }

    private function toBool(mixed $value): bool
    {
        if (is_bool($value)) {
            return $value;
        }

        if (is_numeric($value)) {
            return 1 === (int) $value;
        }

        return is_string($value) && in_array(strtolower($value), ['yes', 'true', 'on'], true);
    }
}
