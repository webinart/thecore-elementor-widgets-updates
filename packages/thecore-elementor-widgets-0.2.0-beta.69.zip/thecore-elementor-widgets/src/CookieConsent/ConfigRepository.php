<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\CookieConsent;

use TheCore\ElementorWidgets\Elementor\Legacy\Widgets\CookieConsent\DisplaySettings;

final class ConfigRepository
{
    private const OPTION_NAME = 'thecore_elementor_widgets_cookie_consent_documents';
    private const OVERRIDE_OPTION_NAME = 'thecore_elementor_widgets_cookie_consent_override';
    private const TARGET_WIDGET_TYPE = 'thecore-cookie-consent';

    /**
     * @return array<int, array{saved_at: int, config: array<string, mixed>}>
     */
    public function all(): array
    {
        $stored = get_option(self::OPTION_NAME, []);

        if (! is_array($stored)) {
            return [];
        }

        $documents = [];

        foreach ($stored as $documentId => $entry) {
            if (! is_numeric($documentId) || ! is_array($entry)) {
                continue;
            }

            $config = $entry['config'] ?? null;

            if (! is_array($config)) {
                continue;
            }

            $documents[(int) $documentId] = [
                'saved_at' => isset($entry['saved_at']) && is_numeric($entry['saved_at'])
                    ? (int) $entry['saved_at']
                    : 0,
                'config' => $config,
            ];
        }

        return $documents;
    }

    public function hasSavedConfig(): bool
    {
        return [] !== $this->all();
    }

    /**
     * @return array<string, mixed>
     */
    public function active(): array
    {
        $this->migrateLegacyDocumentConfigToOverride();

        $override = $this->override();

        if (is_array($override)) {
            return array_replace_recursive($this->defaultConfig(), $override);
        }

        return $this->defaultConfig();
    }

    /**
     * @return array<string, mixed>|null
     */
    public function override(): ?array
    {
        $stored = get_option(self::OVERRIDE_OPTION_NAME, null);

        return is_array($stored) ? $stored : null;
    }

    /**
     * @param array<string, mixed> $config
     */
    public function saveOverride(array $config): void
    {
        update_option(self::OVERRIDE_OPTION_NAME, $config, false);
    }

    public function clearOverride(): void
    {
        delete_option(self::OVERRIDE_OPTION_NAME);
    }

    /**
     * @param mixed $document
     * @param array<string, mixed> $data
     */
    public function syncFromDocument($document, array $data): void
    {
        $this->migrateLegacyDocumentConfigToOverride();

        $documentId = $this->resolveDocumentId($document);

        if ($documentId <= 0) {
            return;
        }

        $documents = $this->all();
        $config = $this->extractWidgetConfig($data['elements'] ?? []);

        if ($config === null) {
            unset($documents[$documentId]);
        } else {
            $documents[$documentId] = [
                'saved_at' => time(),
                'config' => $config,
            ];
        }

        update_option(self::OPTION_NAME, $documents, false);
    }

    public function removeDocument(int $documentId): void
    {
        if ($documentId <= 0) {
            return;
        }

        $documents = $this->all();

        if (! isset($documents[$documentId])) {
            return;
        }

        unset($documents[$documentId]);

        update_option(self::OPTION_NAME, $documents, false);
    }

    /**
     * @param mixed $elements
     *
     * @return array<string, mixed>|null
     */
    private function extractWidgetConfig(mixed $elements): ?array
    {
        if (! is_array($elements)) {
            return null;
        }

        foreach ($elements as $element) {
            if (! is_array($element)) {
                continue;
            }

            if (($element['widgetType'] ?? null) === self::TARGET_WIDGET_TYPE) {
                $settings = $element['settings'] ?? [];

                return [
                    'theme_preset' => (new DisplaySettings())->normalizePresentation(
                        is_array($settings) ? $settings : []
                    )['theme_preset'],
                ];
            }

            if (! empty($element['elements']) && is_array($element['elements'])) {
                $nested = $this->extractWidgetConfig($element['elements']);

                if ($nested !== null) {
                    return $nested;
                }
            }
        }

        return null;
    }

    /**
     * @param mixed $document
     */
    private function resolveDocumentId($document): int
    {
        if (is_object($document)) {
            if (method_exists($document, 'get_main_id')) {
                return (int) $document->get_main_id();
            }

            if (method_exists($document, 'get_id')) {
                return (int) $document->get_id();
            }
        }

        return 0;
    }

    /**
     * @return array<string, mixed>
     */
    private function defaultConfig(): array
    {
        return (new DisplaySettings())->normalize([]);
    }

    private function migrateLegacyDocumentConfigToOverride(): void
    {
        if (is_array($this->override())) {
            return;
        }

        $legacyConfig = $this->latestLegacyDocumentConfig();

        if ($legacyConfig === null) {
            return;
        }

        $this->saveOverride(array_replace_recursive($this->defaultConfig(), $legacyConfig));
    }

    /**
     * @return array<string, mixed>|null
     */
    private function latestLegacyDocumentConfig(): ?array
    {
        $documents = $this->all();

        if ($documents === []) {
            return null;
        }

        uasort(
            $documents,
            static fn (array $left, array $right): int => ($right['saved_at'] ?? 0) <=> ($left['saved_at'] ?? 0)
        );

        foreach ($documents as $entry) {
            $config = $entry['config'] ?? null;

            if (is_array($config) && $this->isLegacyFunctionalConfig($config)) {
                return $config;
            }
        }

        return null;
    }

    /**
     * @param array<string, mixed> $config
     */
    private function isLegacyFunctionalConfig(array $config): bool
    {
        return array_key_exists('notice_text', $config)
            || array_key_exists('buttons', $config)
            || array_key_exists('categories', $config);
    }
}
