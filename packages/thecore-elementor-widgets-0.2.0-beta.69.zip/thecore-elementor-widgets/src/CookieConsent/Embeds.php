<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\CookieConsent;

final class Embeds
{
    public function __construct(
        private readonly ConfigRepository $configRepository,
        private readonly Helper $helper
    ) {
    }

    public function registerHooks(): void
    {
        add_filter('embed_oembed_html', [$this, 'blockEmbed'], 99, 4);
    }

    public function blockEmbed(string $cachedHtml, string $url, array $atts, int $postId): string
    {
        unset($atts, $postId);

        if (empty($this->configRepository->active()['block_embeds'])) {
            return $cachedHtml;
        }

        if ($this->helper->isCookieConsentSet() && $this->helper->isCookieCategoryAccepted('functional')) {
            return $cachedHtml;
        }

        $privacyPolicyTagStart = '';
        $privacyPolicyTagEnd = '';
        $privacyPolicyUrl = $this->helper->currentPrivacyPolicyUrl();

        if ('' !== $privacyPolicyUrl) {
            $privacyPolicyTagStart = '<a href="' . esc_url($privacyPolicyUrl) . '">';
            $privacyPolicyTagEnd = '</a>';
        }

        $embedProvider = parse_url($url, PHP_URL_HOST);
        $embedProvider = is_string($embedProvider) && '' !== $embedProvider ? $embedProvider : __('external provider', 'thecore-elementor-widgets');
        $embedContent = htmlspecialchars($cachedHtml, ENT_QUOTES);

        ob_start();
        ?>
        <div class="thecore-cc__embed thecore-cc__embed-placeholder">
            <p class="thecore-cc__embed-blocked-notice">
                <?php
                printf(
                    wp_kses_post(
                        __('%1$sCe contenu externe provenant de %3$s%2$s a été bloqué en raison de vos paramètres de cookies. En chargeant ce contenu intégré, vous acceptez notre %4$spolitique de confidentialité%5$s.', 'thecore-elementor-widgets')
                    ),
                    '<a href="' . esc_url($url) . '">',
                    '</a>',
                    esc_html($embedProvider),
                    $privacyPolicyTagStart,
                    $privacyPolicyTagEnd
                );
                ?>
            </p>
            <a
                role="button"
                tabindex="0"
                class="thecore-cc__embed-unblock"
                data-embed-content="<?php echo esc_attr($embedContent); ?>"
                data-embed-provider="<?php echo esc_attr($embedProvider); ?>"
            >
                <?php esc_html_e('Afficher le contenu externe', 'thecore-elementor-widgets'); ?>
            </a>
        </div>
        <?php

        return (string) ob_get_clean();
    }
}
