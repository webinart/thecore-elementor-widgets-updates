<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\AssetDelivery;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;

final class ClassicWidgetAssetDeliveryControls
{
    public static function register(Widget_Base $widget): void
    {
        self::registerTypeSection($widget, 'css');
        self::registerTypeSection($widget, 'js');
    }

    private static function registerTypeSection(Widget_Base $widget, string $type): void
    {
        $defaults = AssetDeliverySettings::widgetDefaults()[$type];
        $label = 'css' === $type ? __('CSS Delivery', 'thecore-elementor-widgets') : __('JS Delivery', 'thecore-elementor-widgets');
        $prefix = 'asset_' . $type . '_';

        $widget->start_controls_section(
            'thecore_' . $type . '_delivery',
            [
                'label' => $label,
                'tab' => Controls_Manager::TAB_ADVANCED,
            ]
        );

        $widget->add_control(
            $prefix . 'use_global',
            [
                'label' => __('Use global settings', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => '1',
                'default' => $defaults['use_global'] ? '1' : '',
                'description' => __('When enabled, this widget inherits the global delay strategy.', 'thecore-elementor-widgets'),
            ]
        );

        $widget->add_control(
            $prefix . 'enabled',
            [
                'label' => __('Enable delaying', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => '1',
                'default' => $defaults['enabled'] ? '1' : '',
                'description' => __('When disabled, this widget asset is always loaded immediately.', 'thecore-elementor-widgets'),
                'condition' => [
                    $prefix . 'use_global!' => '1',
                ],
            ]
        );

        $widget->add_control(
            $prefix . 'trigger',
            [
                'label' => __('Trigger', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SELECT,
                'default' => $defaults['trigger'],
                'options' => self::triggerOptions(),
                'condition' => [
                    $prefix . 'use_global!' => '1',
                    $prefix . 'enabled' => '1',
                ],
            ]
        );

        $widget->add_control(
            $prefix . 'viewport_threshold',
            [
                'label' => __('Viewport threshold (%)', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'default' => $defaults['viewport_threshold'],
                'condition' => [
                    $prefix . 'use_global!' => '1',
                    $prefix . 'enabled' => '1',
                    $prefix . 'trigger' => AssetDeliverySettings::TRIGGER_VIEWPORT,
                ],
            ]
        );

        $widget->add_control(
            $prefix . 'fallback_enabled',
            [
                'label' => __('Enable fallback delay', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => '1',
                'default' => $defaults['fallback_enabled'] ? '1' : '',
                'condition' => [
                    $prefix . 'use_global!' => '1',
                    $prefix . 'enabled' => '1',
                    $prefix . 'trigger!' => AssetDeliverySettings::TRIGGER_FALLBACK_ONLY,
                ],
            ]
        );

        $widget->add_control(
            $prefix . 'fallback_delay',
            [
                'label' => __('Fallback delay (ms)', 'thecore-elementor-widgets'),
                'type' => Controls_Manager::NUMBER,
                'min' => 100,
                'max' => 15000,
                'step' => 100,
                'default' => $defaults['fallback_delay'],
                'condition' => [
                    $prefix . 'use_global!' => '1',
                    $prefix . 'enabled' => '1',
                ],
            ]
        );

        $widget->end_controls_section();
    }

    /**
     * @return array<string, string>
     */
    private static function triggerOptions(): array
    {
        return [
            AssetDeliverySettings::TRIGGER_VIEWPORT => __('Element in viewport', 'thecore-elementor-widgets'),
            AssetDeliverySettings::TRIGGER_INTERACTION => __('Page interaction', 'thecore-elementor-widgets'),
            AssetDeliverySettings::TRIGGER_FALLBACK_ONLY => __('Fallback only', 'thecore-elementor-widgets'),
        ];
    }
}
