<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\AssetDelivery;

final class AssetDeliveryResolver
{
    /**
     * @param array{
     *     css: array{
     *         enabled: bool,
     *         trigger: string,
     *         viewport_threshold: int,
     *         fallback_enabled: bool,
     *         fallback_delay: int,
     *         override_widget_settings: bool
     *     },
     *     js: array{
     *         enabled: bool,
     *         trigger: string,
     *         viewport_threshold: int,
     *         fallback_enabled: bool,
     *         fallback_delay: int,
     *         override_widget_settings: bool
     *     }
     * } $globalSettings
     * @param array{
     *     css: array{
     *         use_global: bool,
     *         trigger: string,
     *         viewport_threshold: int,
     *         fallback_enabled: bool,
     *         fallback_delay: int
     *     },
     *     js: array{
     *         use_global: bool,
     *         trigger: string,
     *         viewport_threshold: int,
     *         fallback_enabled: bool,
     *         fallback_delay: int
     *     }
     * } $widgetSettings
     *
     * @return array{
     *     css: array{
     *         enabled: bool,
     *         trigger: string,
     *         viewport_threshold: int,
     *         fallback_enabled: bool,
     *         fallback_delay: int
     *     },
     *     js: array{
     *         enabled: bool,
     *         trigger: string,
     *         viewport_threshold: int,
     *         fallback_enabled: bool,
     *         fallback_delay: int
     *     }
     * }
     */
    public function resolve(array $globalSettings, array $widgetSettings): array
    {
        return [
            'css' => $this->resolveType($globalSettings['css'], $widgetSettings['css']),
            'js' => $this->resolveType($globalSettings['js'], $widgetSettings['js']),
        ];
    }

    /**
     * @param array{
     *     enabled: bool,
     *     trigger: string,
     *     viewport_threshold: int,
     *     fallback_enabled: bool,
     *     fallback_delay: int,
     *     override_widget_settings: bool
     * } $globalSettings
     * @param array{
     *     use_global: bool,
     *     enabled: bool,
     *     trigger: string,
     *     viewport_threshold: int,
     *     fallback_enabled: bool,
     *     fallback_delay: int
     * } $widgetSettings
     *
     * @return array{
     *     enabled: bool,
     *     trigger: string,
     *     viewport_threshold: int,
     *     fallback_enabled: bool,
     *     fallback_delay: int
     * }
     */
    private function resolveType(array $globalSettings, array $widgetSettings): array
    {
        $resolved = [
            'enabled' => $globalSettings['enabled'],
            'trigger' => $globalSettings['trigger'],
            'viewport_threshold' => $globalSettings['viewport_threshold'],
            'fallback_enabled' => $globalSettings['fallback_enabled'],
            'fallback_delay' => $globalSettings['fallback_delay'],
        ];

        if (! $resolved['enabled']) {
            return $resolved;
        }

        if ($globalSettings['override_widget_settings'] || $widgetSettings['use_global']) {
            return $resolved;
        }

        if (! $widgetSettings['enabled']) {
            return [
                'enabled' => false,
                'trigger' => $widgetSettings['trigger'],
                'viewport_threshold' => $widgetSettings['viewport_threshold'],
                'fallback_enabled' => $widgetSettings['fallback_enabled'],
                'fallback_delay' => $widgetSettings['fallback_delay'],
            ];
        }

        return [
            'enabled' => true,
            'trigger' => $widgetSettings['trigger'],
            'viewport_threshold' => $widgetSettings['viewport_threshold'],
            'fallback_enabled' => $widgetSettings['fallback_enabled'],
            'fallback_delay' => $widgetSettings['fallback_delay'],
        ];
    }
}
