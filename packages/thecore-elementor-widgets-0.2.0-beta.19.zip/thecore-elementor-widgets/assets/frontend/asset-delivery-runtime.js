(() => {
    if (window.__TheCoreAssetDeliveryBooted) {
        return;
    }

    window.__TheCoreAssetDeliveryBooted = true;

    const payload = window.TheCoreElementorWidgetsAssetDeliveryPayload;

    if (!payload || !Array.isArray(payload.instances) || !payload.assets) {
        return;
    }

    const loaded = window.__TheCoreAssetDeliveryLoaded || (window.__TheCoreAssetDeliveryLoaded = {});
    const head = document.head || document.getElementsByTagName('head')[0] || document.documentElement;
    const body = document.body || document.documentElement;
    const interactionCallbacks = [];
    let interactionBound = false;

    const hasLoadedTag = (domId) => Boolean(domId && document.getElementById(domId));

    const markLoaded = (asset) => {
        loaded[asset.load_key] = true;
    };

    const injectCss = (asset) => {
        if (!asset || loaded[asset.load_key] || hasLoadedTag(asset.domId)) {
            return;
        }

        if (asset.mode === 'inline') {
            const style = document.createElement('style');
            style.id = asset.domId;
            style.textContent = asset.content || '';
            head.appendChild(style);
            markLoaded(asset);
            return;
        }

        const link = document.createElement('link');
        link.id = asset.domId;
        link.rel = 'stylesheet';
        link.href = asset.url;
        link.media = 'all';
        link.onload = () => {
            markLoaded(asset);
        };
        link.onerror = () => {
            markLoaded(asset);
        };
        head.appendChild(link);
        markLoaded(asset);
    };

    const injectJs = (asset) => {
        if (!asset || loaded[asset.load_key] || hasLoadedTag(asset.domId)) {
            return;
        }

        const script = document.createElement('script');
        script.id = asset.domId;

        if (asset.mode === 'inline') {
            script.text = asset.content || '';
            body.appendChild(script);
            markLoaded(asset);
            return;
        }

        script.src = asset.url;
        script.async = false;
        script.onload = () => {
            markLoaded(asset);
        };
        script.onerror = () => {
            markLoaded(asset);
        };
        body.appendChild(script);
        markLoaded(asset);
    };

    const loadAsset = (type, handle) => {
        if (!handle) {
            return;
        }

        const assetMap = payload.assets[type] || {};
        const asset = assetMap[handle];

        if (!asset) {
            return;
        }

        if (type === 'css') {
            injectCss(asset);
            return;
        }

        injectJs(asset);
    };

    const runOnInteraction = (callback) => {
        interactionCallbacks.push(callback);

        if (interactionBound) {
            return;
        }

        interactionBound = true;

        const flush = () => {
            ['click', 'scroll', 'mousemove', 'touchstart', 'keydown'].forEach((eventName) => {
                window.removeEventListener(eventName, flush, listenerOptions);
            });

            interactionCallbacks.splice(0).forEach((queuedCallback) => {
                queuedCallback();
            });
        };

        const listenerOptions = {
            once: true,
            passive: true,
        };

        ['click', 'scroll', 'mousemove', 'touchstart', 'keydown'].forEach((eventName) => {
            window.addEventListener(eventName, flush, listenerOptions);
        });
    };

    const scheduleLoad = (type, settings, selector) => {
        if (!settings || !settings.handle) {
            return;
        }

        let hasRun = false;

        const trigger = () => {
            if (hasRun) {
                return;
            }

            hasRun = true;
            loadAsset(type, settings.handle);
        };

        if (settings.fallbackEnabled) {
            window.setTimeout(trigger, settings.fallbackDelay);
        }

        if (settings.trigger === 'fallback_only') {
            if (!settings.fallbackEnabled) {
                trigger();
            }

            return;
        }

        if (settings.trigger === 'interaction') {
            runOnInteraction(trigger);
            return;
        }

        const target = selector ? document.querySelector(selector) : null;

        if (!target || !('IntersectionObserver' in window)) {
            trigger();
            return;
        }

        const threshold = Math.max(0, Math.min(1, (settings.viewportThreshold || 0) / 100));
        const observer = new IntersectionObserver((entries) => {
            entries.forEach((entry) => {
                if (!entry.isIntersecting) {
                    return;
                }

                observer.disconnect();
                trigger();
            });
        }, {
            threshold,
        });

        observer.observe(target);
    };

    payload.instances.forEach((instance) => {
        if (!instance || !instance.selector) {
            return;
        }

        scheduleLoad('css', instance.css, instance.selector);
        scheduleLoad('js', instance.js, instance.selector);
    });
})();
