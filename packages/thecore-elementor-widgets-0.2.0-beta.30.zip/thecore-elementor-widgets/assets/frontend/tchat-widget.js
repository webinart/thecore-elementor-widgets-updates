/* ------------------------------------------------------------
   TChat – widget visiteur
------------------------------------------------------------ */
(() => {
	const mounts = document.querySelectorAll('[data-tchat-root], #tchat-root');
	if (!mounts.length || !window.TCHAT_SETTINGS) {
		return;
	}

	const mount = mounts[0];
	if (mount.dataset.tchatMounted === '1') {
		return;
	}
	mount.dataset.tchatMounted = '1';

	const getVisitorUUID = () => {
		const KEY = 'tchat_uuid';
		const cookieMatch = document.cookie.match(/(?:^|;\\s*)tchat_uuid=([^;]+)/);
		let uuid = cookieMatch ? cookieMatch[1] : localStorage.getItem(KEY);

		if (!uuid) {
			uuid = crypto.randomUUID();
			document.cookie = `tchat_uuid=${uuid}; path=/; max-age=${3600 * 24 * 365}`;
			localStorage.setItem(KEY, uuid);
		}

		return uuid;
	};

	const visitorUUID = getVisitorUUID();
	const settings = window.TCHAT_SETTINGS;
	const transport = settings.transport || {};
	const pollingCfg = transport.polling || {};

	let convId = null;
	let lastTS = '1970-01-01 00:00:00';
	let pollTimer = null;
	let eventSource = null;

	mount.innerHTML = `
		<button type="button" class="tchat-widget__button" aria-controls="tchat-visitor-modal" aria-expanded="false">💬</button>
		<div id="tchat-visitor-modal" class="tchat-widget__modal" aria-hidden="true">
			<header class="tchat-widget__header">
				<span>TChat</span>
				<button type="button" class="tchat-widget__close" aria-label="Close chat">✖</button>
			</header>
			<section class="tchat-widget__log"></section>
			<footer class="tchat-widget__footer">
				<input class="tchat-widget__input" placeholder="Votre message…" autocomplete="off" />
			</footer>
		</div>
	`;

	const button = mount.querySelector('.tchat-widget__button');
	const modal = mount.querySelector('.tchat-widget__modal');
	const closeButton = mount.querySelector('.tchat-widget__close');
	const log = mount.querySelector('.tchat-widget__log');
	const input = mount.querySelector('.tchat-widget__input');

	const currentMode = () => (transport.mode || 'polling');
	const openInterval = Number(pollingCfg.visitorOpenMs || 3000);
	const idleInterval = Number(pollingCfg.visitorIdleMs || 10000);

	const isOpen = () => modal.classList.contains('is-open');

	const appendMsg = (message) => {
		if (!message || typeof message.content !== 'string' || message.content === '') {
			return;
		}

		lastTS = message.created_at || lastTS;

		const row = document.createElement('p');
		row.className = `tchat-widget__message ${message.sender_type === 'agent' ? 'is-in' : 'is-out'}`;
		row.textContent = message.content;
		log.appendChild(row);
		row.scrollIntoView({ behavior: 'smooth', block: 'end' });
	};

	const setOpen = (open) => {
		modal.classList.toggle('is-open', open);
		modal.setAttribute('aria-hidden', open ? 'false' : 'true');
		button.setAttribute('aria-expanded', open ? 'true' : 'false');

		if (currentMode() === 'polling') {
			schedulePoll(0);
		}
	};

	button.addEventListener('click', () => setOpen(!isOpen()));
	closeButton.addEventListener('click', () => setOpen(false));

	const buildAjaxPayload = (since) => new URLSearchParams({
		action: 'tchat_poll',
		nonce: settings.nonce,
		conversation_id: String(convId),
		visitor_uuid: visitorUUID,
		since,
	});

	const loadHistory = async () => {
		if (!convId) {
			return;
		}

		const response = await fetch(settings.ajaxUrl, {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			body: buildAjaxPayload('1970-01-01 00:00:00'),
		});
		const payload = await response.json();
		if (!payload || !payload.success || !Array.isArray(payload.data)) {
			return;
		}

		log.innerHTML = '';
		payload.data.forEach(appendMsg);
	};

	const handleRealtimeMessage = (message) => {
		if (!message || Number(message.conversation_id) !== Number(convId)) {
			return;
		}

		if (message.sender_type === 'visitor' && message.visitor_uuid === visitorUUID) {
			return;
		}

		appendMsg(message);
	};

	const clearPolling = () => {
		if (!pollTimer) {
			return;
		}

		window.clearTimeout(pollTimer);
		pollTimer = null;
	};

	const schedulePoll = (delay) => {
		clearPolling();
		pollTimer = window.setTimeout(runPoll, delay);
	};

	const runPoll = async () => {
		if (!convId) {
			return;
		}

		try {
			const response = await fetch(settings.ajaxUrl, {
				method: 'POST',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
				body: buildAjaxPayload(lastTS),
			});
			const payload = await response.json();
			if (payload && payload.success && Array.isArray(payload.data)) {
				payload.data.forEach((message) => {
					if (message.sender_type === 'visitor' && message.visitor_uuid === visitorUUID) {
						return;
					}

					appendMsg(message);
				});
			}
		} finally {
			schedulePoll(isOpen() ? openInterval : idleInterval);
		}
	};

	const stopRealtime = () => {
		if (!eventSource) {
			return;
		}

		eventSource.close();
		eventSource = null;
	};

	const startSse = () => {
		if (typeof window.EventSource !== 'function' || !transport.sseEventsUrl) {
			return false;
		}

		const url = new URL(transport.sseEventsUrl, window.location.href);
		url.searchParams.set('conversation_id', String(convId));
		url.searchParams.set('visitor_uuid', visitorUUID);

		stopRealtime();

		const source = new window.EventSource(url.toString());
		source.addEventListener('message', (event) => {
			try {
				handleRealtimeMessage(JSON.parse(event.data));
			} catch (error) {
				console.warn('TChat SSE parse error', error);
			}
		});
		source.onerror = () => {
			stopRealtime();
			if (currentMode() === 'auto') {
				schedulePoll(0);
			}
		};

		eventSource = source;
		return true;
	};

	const initTransport = () => {
		const mode = currentMode();
		if ((mode === 'sse' || mode === 'auto') && startSse()) {
			return;
		}

		schedulePoll(0);
	};

	input.addEventListener('keydown', async (event) => {
		if (event.key !== 'Enter') {
			return;
		}

		const content = input.value.trim();
		if (!content || !convId) {
			return;
		}

		input.disabled = true;

		try {
			const response = await fetch(`${settings.restUrl}/persist`, {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({
					conversation_id: convId,
					visitor_uuid: visitorUUID,
					sender_type: 'visitor',
					content,
				}),
			});
			const payload = await response.json();
			if (payload && payload.message) {
				appendMsg(payload.message);
			}
			input.value = '';
		} catch (error) {
			console.error('TChat visitor send error', error);
		} finally {
			input.disabled = false;
			input.focus();
		}
	});

	fetch(`${settings.restUrl}/conversations`, {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json',
			...(settings.restNonce ? { 'X-WP-Nonce': settings.restNonce } : {}),
		},
		body: JSON.stringify({ uuid: visitorUUID }),
	})
		.then((response) => response.json())
		.then(async (payload) => {
			convId = Number(payload.id || 0);
			if (!convId) {
				return;
			}

			await loadHistory();
			initTransport();
		})
		.catch((error) => {
			console.error('TChat conversation bootstrap error', error);
		});
})();
