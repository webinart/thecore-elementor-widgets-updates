<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\TChat;

use TheCore\ElementorWidgets\Contracts\Bootable;
use TheCore\ElementorWidgets\TChat\Admin\AdminPage;
use TheCore\ElementorWidgets\TChat\Http\AdminController;
use TheCore\ElementorWidgets\TChat\Http\ConversationController;
use TheCore\ElementorWidgets\TChat\Http\MessageController;
use TheCore\ElementorWidgets\TChat\Http\PersistController;
use TheCore\ElementorWidgets\TChat\Support\ModuleSettings;

final class TChatModule implements Bootable
{
    public function register(): void
    {
        add_action('init', [$this, 'registerShortcode']);
        add_action('wp_enqueue_scripts', [$this, 'enqueueAssets']);
        add_action('rest_api_init', [$this, 'registerRoutes']);
        add_action('wp_ajax_tchat_poll', [$this, 'ajaxPoll']);
        add_action('wp_ajax_nopriv_tchat_poll', [$this, 'ajaxPoll']);

        AdminPage::register();
    }

    public function registerShortcode(): void
    {
        add_shortcode('tchat', static fn(): string => '<div id="tchat-root" data-tchat-root></div>');
    }

    public function enqueueAssets(): void
    {
        $js_file = THECORE_ELEMENTOR_WIDGETS_PATH . 'assets/frontend/tchat-widget.js';
        $css_file = THECORE_ELEMENTOR_WIDGETS_PATH . 'assets/frontend/tchat-widget.css';
        $version = (string) max(
            @filemtime($js_file) ?: 0,
            @filemtime($css_file) ?: 0,
            @filemtime(THECORE_ELEMENTOR_WIDGETS_FILE) ?: 0
        );

        wp_register_script(
            'tchat-widget',
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/tchat-widget.js',
            [],
            $version,
            true
        );

        wp_localize_script(
            'tchat-widget',
            'TCHAT_SETTINGS',
            [
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('tchat_nonce'),
                'restNonce' => wp_create_nonce('wp_rest'),
                'restUrl' => rest_url('tchat/v1'),
                'userName' => is_user_logged_in() ? wp_get_current_user()->display_name : null,
                'transport' => ModuleSettings::getFrontendSettings(),
            ]
        );

        wp_enqueue_script('tchat-widget');

        wp_enqueue_style(
            'tchat-widget',
            THECORE_ELEMENTOR_WIDGETS_URL . 'assets/frontend/tchat-widget.css',
            [],
            $version
        );
    }

    public function registerRoutes(): void
    {
        ConversationController::register();
        PersistController::register();
        AdminController::register();
        MessageController::register();
    }

    public function ajaxPoll(): void
    {
        check_ajax_referer('tchat_nonce', 'nonce');

        global $wpdb;

        $conversation_id = isset($_POST['conversation_id']) ? (int) $_POST['conversation_id'] : 0;
        $visitor_uuid = isset($_POST['visitor_uuid']) ? sanitize_text_field(wp_unslash((string) $_POST['visitor_uuid'])) : '';
        if (! $conversation_id) {
            wp_send_json_error('conversation_id missing', 400);
        }

        if ($visitor_uuid === '' || ! PersistController::visitorOwnsConversation($visitor_uuid, $conversation_id)) {
            wp_send_json_error('invalid conversation', 403);
        }

        if (isset($_POST['write']) && $_POST['write'] === '1') {
            $content = wp_kses_post(wp_unslash((string) ($_POST['content'] ?? '')));
            $created_at = current_time('mysql', true);

            $wpdb->insert(
                $wpdb->prefix . 'tchat_messages',
                [
                    'conversation_id' => $conversation_id,
                    'sender_type' => 'visitor',
                    'sender_id' => null,
                    'visitor_uuid' => $visitor_uuid,
                    'content' => $content,
                    'created_at' => $created_at,
                ],
                ['%d', '%s', '%d', '%s', '%s', '%s']
            );

            $wpdb->query(
                $wpdb->prepare(
                    "UPDATE {$wpdb->prefix}tchat_conversations
                     SET unread_count = unread_count + 1,
                         updated_at = %s
                     WHERE id = %d",
                    $created_at,
                    $conversation_id
                )
            );

            wp_send_json_success();
        }

        $since = sanitize_text_field((string) ($_POST['since'] ?? '1970-01-01 00:00:00'));

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, sender_type, sender_id, visitor_uuid, content, created_at
                 FROM {$wpdb->prefix}tchat_messages
                 WHERE conversation_id = %d AND created_at > %s
                 ORDER BY created_at ASC",
                $conversation_id,
                $since
            ),
            ARRAY_A
        );

        wp_send_json_success($rows);
    }
}
