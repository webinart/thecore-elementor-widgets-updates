<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\Counter;

final class DisplaySettings
{
    public const MAX_NUMBER = 1000000000000;
    public const MAX_TIME = 60000;
    public const MAX_DECIMALS = 10;
    public const SEPARATORS = ['', ' ', "\u{00A0}", "\u{202F}", ',', '.', "'", '’'];

    /**
     * Normalize resolved Atomic props, not the persisted $$type/value envelopes.
     *
     * @param array<string, mixed> $settings
     * @return array<string, mixed>
     */
    public function normalize(array $settings): array
    {
        $separator = $settings['separator'] ?? ' ';
        $decimalSeparator = $settings['decimal_separator'] ?? ',';

        return [
            'start' => $this->number($settings['start'] ?? 0, 0),
            'end' => $this->number($settings['end'] ?? 100, 100),
            'duration' => $this->integer($settings['duration'] ?? 2000, 0, self::MAX_TIME, 2000),
            'delay' => $this->integer($settings['delay'] ?? 0, 0, self::MAX_TIME, 0),
            'decimals' => $this->integer($settings['decimals'] ?? 0, 0, self::MAX_DECIMALS, 0),
            'separator' => in_array($separator, self::SEPARATORS, true) ? $separator : ' ',
            'decimal_separator' => in_array($decimalSeparator, [',', '.'], true) ? $decimalSeparator : ',',
            'prefix' => $this->text($settings['prefix'] ?? ''),
            'suffix' => $this->text($settings['suffix'] ?? ''),
            'label' => $this->text($settings['label'] ?? ''),
        ];
    }

    /** @param array<string, mixed> $settings */
    public function format(array $settings): string
    {
        return number_format(
            $settings['end'],
            $settings['decimals'],
            $settings['decimal_separator'],
            $settings['separator']
        );
    }

    private function number(mixed $value, float $fallback): float
    {
        if (! is_numeric($value) || ! is_finite((float) $value)) {
            return $fallback;
        }

        return max(-self::MAX_NUMBER, min(self::MAX_NUMBER, (float) $value));
    }

    private function integer(mixed $value, int $min, int $max, int $fallback): int
    {
        if (! is_numeric($value) || ! is_finite((float) $value)) {
            return $fallback;
        }

        return (int) max($min, min($max, (float) $value));
    }

    private function text(mixed $value): string
    {
        return is_scalar($value) ? sanitize_text_field((string) $value) : '';
    }
}
