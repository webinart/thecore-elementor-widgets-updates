<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Elementor\Atomic\Widgets\Counter;

final class MarkupBuilder
{
    /**
     * @param array<string, mixed> $settings Resolved Atomic props.
     * @param array<string, string> $attributes Only widget-owned attributes.
     * @param array<string, string> $styleClasses Atomic inner style targets.
     */
    public function build(array $settings, array $attributes = [], array $styleClasses = []): string
    {
        $display = new DisplaySettings();
        $settings = $display->normalize($settings);
        $value = $display->format($settings);
        $label = implode(' ', array_filter(
            [$settings['prefix'], $value, $settings['suffix'], $settings['label']],
            static fn (string $part): bool => '' !== $part
        ));
        // Immutable accessible value: do not announce every animation frame.
        $attributes = array_merge($attributes, [
            'data-thecore-counter' => 'true',
            'data-start' => (string) $settings['start'],
            'data-end' => (string) $settings['end'],
            'data-duration' => (string) $settings['duration'],
            'data-delay' => (string) $settings['delay'],
            'data-decimals' => (string) $settings['decimals'],
            'data-separator' => $settings['separator'],
            'data-decimal-separator' => $settings['decimal_separator'],
            'role' => 'group',
            'aria-label' => $label,
        ]);
        $html = '<div';
        foreach ($attributes as $name => $attribute) {
            $html .= ' ' . esc_attr($name) . '="' . esc_attr($attribute) . '"';
        }
        $html .= '><div class="' . esc_attr('thecore-counter__number ' . ($styleClasses['number'] ?? '')) . '" aria-hidden="true">';
        $parts = [];
        foreach (['prefix', 'value', 'suffix'] as $part) {
            $text = 'value' === $part ? $value : $settings[$part];
            if ('' === $text) {
                continue;
            }
            $marker = 'value' === $part ? ' data-thecore-counter-value' : '';
            $parts[] = '<span class="thecore-counter__' . $part . '"' . $marker . '>' . esc_html($text) . '</span>';
        }
        $html .= implode(' ', $parts) . '</div>';
        if ('' !== $settings['label']) {
            $html .= '<div class="' . esc_attr('thecore-counter__label ' . ($styleClasses['label'] ?? '')) . '" aria-hidden="true">' . esc_html($settings['label']) . '</div>';
        }

        return $html . '</div>';
    }
}
