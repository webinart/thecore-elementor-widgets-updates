<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Actions;

use TheCore\ElementorWidgets\Forms\ConfigurationException;
use TheCore\ElementorWidgets\Forms\FormDefinition;
use TheCore\ElementorWidgets\Forms\SubmissionException;

/** An opt-in, static acknowledgement; never reflects visitor content. */
final class AutoresponderAction implements SubmissionAction
{
    public function name(): string
    {
        return 'autoresponder';
    }

    public function prepare(FormDefinition $form, array $values): array
    {
        $id = $form->emailField('autoresponder-email-field');
        $recipient = $values[$id] ?? '';
        if (! is_string($recipient) || ! is_email($recipient) || preg_match('/[\r\n]/', $recipient)) {
            throw new SubmissionException('validation_failed', 'Veuillez verifier votre adresse email.', 422, [$id => 'Adresse email invalide.']);
        }
        $subject = $form->settings['autoresponder-subject'] ?? '';
        $body = $form->settings['autoresponder-message'] ?? '';
        if (
            ! is_string($subject) || ! is_string($body) || trim($subject) === '' || trim($body) === ''
            || strlen($subject) > 1000 || strlen($body) > 10000
        ) {
            throw new ConfigurationException('The autoresponder needs a subject and a static message.');
        }
        $body = trim(strip_tags($body));
        if ($body === '') {
            throw new ConfigurationException('The autoresponder needs a static text message.');
        }
        return ['recipient' => $recipient, 'subject' => trim(str_replace(["\r", "\n"], ' ', $subject)), 'body' => $body];
    }

    public function execute(array $prepared): void
    {
        if (! wp_mail($prepared['recipient'], $prepared['subject'], $prepared['body'], ['Content-Type: text/plain; charset=UTF-8'])) {
            throw new SubmissionException('autoresponder_failed', 'La confirmation de reception n\'a pas pu etre envoyee. Contactez-nous pour verifier votre demande.', 503);
        }
    }
}
