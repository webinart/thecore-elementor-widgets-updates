<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Actions;

use TheCore\ElementorWidgets\Forms\ConfigurationException;
use TheCore\ElementorWidgets\Forms\FormDefinition;
use TheCore\ElementorWidgets\Forms\SubmissionException;

final class EmailAction implements SubmissionAction
{
    public function name(): string
    {
        return 'email';
    }

    public function prepare(FormDefinition $form, array $values): array
    {
        $recipient = $form->settings['recipient'] ?: (string) get_option('admin_email');
        if (! is_email($recipient) || preg_match('/[\r\n]/', $recipient)) {
            throw new ConfigurationException('Invalid recipient.');
        }
        $body = $form->settings['form-name'] . "\n\n";
        foreach ($form->fields as $id => $field) {
            $value = $values[$id] ?? '';
            $body .= $field['label'] . ': ' . (is_array($value) ? implode(', ', $value) : $value) . "\n\n";
        }
        $prepared = ['recipient' => $recipient, 'body' => $body,
            'subject' => trim(str_replace(["\r", "\n"], ' ', $form->settings['subject']))];
        if (($form->settings['reply-to-field'] ?? '') !== '') {
            $id = $form->emailField('reply-to-field');
            $replyTo = $values[$id] ?? '';
            if (! is_string($replyTo) || ($replyTo !== '' && (! is_email($replyTo) || preg_match('/[\r\n]/', $replyTo)))) {
                throw new SubmissionException('validation_failed', 'Veuillez verifier votre adresse email.', 422, [$id => 'Adresse email invalide.']);
            }
            if ($replyTo !== '') {
                $prepared['replyTo'] = $replyTo;
            }
        }
        return $prepared;
    }

    public function execute(array $prepared): void
    {
        $headers = ['Content-Type: text/plain; charset=UTF-8'];
        if (isset($prepared['replyTo'])) {
            $headers[] = 'Reply-To: ' . $prepared['replyTo'];
        }
        if (! wp_mail($prepared['recipient'], $prepared['subject'], $prepared['body'], $headers)) {
            throw new SubmissionException('mail_failed', 'Le message n\'a pas pu etre envoye. Veuillez reessayer plus tard.', 503);
        }
    }
}
