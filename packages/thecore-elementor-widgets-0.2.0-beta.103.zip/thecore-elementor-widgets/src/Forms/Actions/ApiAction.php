<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Actions;

use TheCore\ElementorWidgets\Forms\Api\Client;
use TheCore\ElementorWidgets\Forms\Api\Mapping;
use TheCore\ElementorWidgets\Forms\ConfigurationException;
use TheCore\ElementorWidgets\Forms\FormDefinition;
use TheCore\ElementorWidgets\Forms\SubmissionException;

/** Adapts saved Atomic CSS IDs to the transport shared with Elementor Pro. */
final class ApiAction implements SubmissionAction
{
    public function name(): string
    {
        return 'api';
    }

    public function prepare(FormDefinition $form, array $values): array
    {
        $fields = [];
        $widgetIds = [];
        $mappedValues = [];
        foreach ($form->fields as $id => $field) {
            $fields[] = $field['domId'];
            $widgetIds[$field['domId']] = $id;
            $mappedValues[$field['domId']] = $values[$id] ?? '';
        }
        $connection = $form->settings['api-connection'] ?? '';
        $mapping = $form->settings['api-mapping'] ?? '';
        if (! is_string($connection) || ! is_string($mapping)) {
            throw new ConfigurationException('Invalid API action settings.');
        }
        try {
            $request = (new Mapping())->prepare(
                $mapping,
                $fields,
                $mappedValues,
                (string) ($form->settings['_api-submission-id'] ?? ''),
                (string) ($form->settings['_api-scope'] ?? '') . ':' . $connection
            );
        } catch (SubmissionException $error) {
            $errors = [];
            foreach ($error->fields as $cssId => $message) {
                if (isset($widgetIds[$cssId])) {
                    $errors[$widgetIds[$cssId]] = $message;
                }
            }
            throw new SubmissionException($error->errorCode, $error->getMessage(), $error->status, $errors);
        }
        (new Client())->validateRequest($connection, $request);
        return ['connection' => $connection, 'request' => $request];
    }

    public function execute(array $prepared): void
    {
        (new Client())->send($prepared['connection'], $prepared['request']);
    }
}
