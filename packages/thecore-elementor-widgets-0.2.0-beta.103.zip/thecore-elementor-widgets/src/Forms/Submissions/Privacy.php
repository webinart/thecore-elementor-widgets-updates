<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Submissions;

use TheCore\ElementorWidgets\Contracts\Bootable;
use Throwable;

/** WordPress verifies requester identities before invoking these callbacks. */
final class Privacy implements Bootable
{
    public const ID = 'thecore-elementor-form-submissions';
    private const PAGE_SIZE = 100;

    public function __construct(private readonly Store $store)
    {
    }

    public function register(): void
    {
        if (! Installer::isReady() && ! get_option(Installer::HISTORY_OPTION, false)) {
            // An optional feature that has never accepted data must not block legacy privacy exports.
            return;
        }
        add_filter('wp_privacy_personal_data_exporters', [$this, 'registerExporter']);
        add_filter('wp_privacy_personal_data_erasers', [$this, 'registerEraser']);
    }

    public function registerExporter(array $exporters): array
    {
        $exporters[self::ID] = ['exporter_friendly_name' => __('The Core — Demandes de formulaire', 'thecore-elementor-widgets'),
            'callback' => [$this, 'exportPersonalData']];
        return $exporters;
    }

    public function registerEraser(array $erasers): array
    {
        $erasers[self::ID] = ['eraser_friendly_name' => __('The Core — Demandes de formulaire', 'thecore-elementor-widgets'),
            'callback' => [$this, 'erasePersonalData']];
        return $erasers;
    }

    public function exportPersonalData(string $email, int $page = 1): array|\WP_Error
    {
        try {
            if (! Installer::isReady()) {
                return $this->error();
            }
            $hash = $this->store->emailIdentity()->hash($email);
            if ($hash === '') {
                return ['data' => [], 'done' => true];
            }
            $rows = $this->store->listByEmailHash($hash, (max(1, $page) - 1) * self::PAGE_SIZE, self::PAGE_SIZE);
            $data = [];
            foreach ($rows as $row) {
                $items = [
                    ['name' => __('Formulaire', 'thecore-elementor-widgets'), 'value' => (string) $row['form_name']],
                    ['name' => __('Page', 'thecore-elementor-widgets'), 'value' => (string) $row['post_id']],
                    ['name' => __('Date (UTC)', 'thecore-elementor-widgets'), 'value' => gmdate('Y-m-d H:i:s', (int) $row['created_at'])],
                    ['name' => __('Effacement prévu (UTC)', 'thecore-elementor-widgets'), 'value' => gmdate('Y-m-d H:i:s', (int) $row['expires_at'])],
                ];
                foreach (json_decode((string) $row['fields_json'], true, 64, JSON_THROW_ON_ERROR) as $field) {
                    $items[] = ['name' => (string) $field['label'],
                        'value' => is_array($field['value']) ? implode(', ', $field['value']) : (string) $field['value']];
                }
                $items[] = ['name' => __('État des actions', 'thecore-elementor-widgets'), 'value' => (string) $row['statuses_json']];
                $data[] = ['group_id' => self::ID, 'group_label' => __('Demandes de formulaire The Core', 'thecore-elementor-widgets'),
                    'item_id' => self::ID . '-' . (int) $row['id'], 'data' => $items];
            }
            return ['data' => $data, 'done' => count($rows) < self::PAGE_SIZE];
        } catch (Throwable) {
            return $this->error();
        }
    }

    public function erasePersonalData(string $email, int $page = 1): array|\WP_Error
    {
        unset($page); // Always consume the first batch, as deleting rows shifts offsets.
        try {
            if (! Installer::isReady()) {
                return $this->error();
            }
            $hash = $this->store->emailIdentity()->hash($email);
            $deleted = $hash === '' ? 0 : $this->store->deleteByEmailHash($hash, self::PAGE_SIZE);
            $remaining = $hash === '' ? [] : $this->store->listByEmailHash($hash, 0, 1, true);
            return ['items_removed' => $deleted > 0, 'items_retained' => false,
                'messages' => [], 'done' => $remaining === []];
        } catch (Throwable) {
            return $this->error();
        }
    }

    private function error(): \WP_Error
    {
        return new \WP_Error('thecore_submissions_unavailable', __('Les demandes n’ont pas pu être consultées ou effacées. Réessayez après vérification du stockage.', 'thecore-elementor-widgets'));
    }
}
