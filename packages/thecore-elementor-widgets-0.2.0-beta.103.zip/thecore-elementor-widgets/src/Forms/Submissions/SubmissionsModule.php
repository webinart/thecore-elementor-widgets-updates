<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Submissions;

use TheCore\ElementorWidgets\Contracts\Bootable;
use TheCore\ElementorWidgets\FormSecurity\Support\Secrets;
use Throwable;

/** Admin/privacy/maintenance stay available even when the Atomic form is disabled. */
final class SubmissionsModule implements Bootable
{
    public const CLEANUP_HOOK = 'thecore_elementor_form_submissions_cleanup';
    private Store $store;

    public function __construct(?Store $store = null)
    {
        $this->store = $store ?? new Store();
    }

    public function register(): void
    {
        add_action('admin_init', [Installer::class, 'maybeUpgrade']);
        add_action('init', [$this, 'schedule']);
        add_action(self::CLEANUP_HOOK, [$this, 'cleanup']);
        (new AdminPage($this->store))->register();
        (new Privacy($this->store))->register();
        if (defined('WP_CLI') && WP_CLI === true && class_exists('WP_CLI')) {
            \WP_CLI::add_command('thecore forms submissions install', static function (): void {
                if (! Installer::install()) {
                    \WP_CLI::error('The Core form archive installation failed; form protection remains independent.');
                    return;
                }
                \WP_CLI::success('The Core form archive installed for the current site.');
            });
            \WP_CLI::add_command('thecore forms submissions status', static function (): void {
                \WP_CLI::line(
                    Installer::isReady() && Installer::hasExpectedSchema() && Secrets::personalDataLookupIsPersistent()
                        ? 'ready' : 'unavailable'
                );
            });
            \WP_CLI::add_command('thecore forms submissions purge', function (): void {
                try {
                    \WP_CLI::success(sprintf('Removed %d expired requests and their email indexes.', $this->store->purgeExpired()));
                } catch (Throwable) {
                    \WP_CLI::error('Archive purge failed.');
                }
            });
        }
    }

    public function schedule(): void
    {
        if (Installer::isReady() && ! wp_next_scheduled(self::CLEANUP_HOOK)) {
            wp_schedule_event(time() + 3600, 'hourly', self::CLEANUP_HOOK);
        }
    }

    public function cleanup(): void
    {
        try {
            $this->store->purgeExpired(1000);
        } catch (Throwable) {
            // Never expose field values or break an unrelated cron task.
        }
    }

    public static function unschedule(bool $networkWide = false): void
    {
        if (! $networkWide || ! is_multisite()) {
            wp_clear_scheduled_hook(self::CLEANUP_HOOK);
            return;
        }
        $offset = 0;
        do {
            $ids = get_sites(['fields' => 'ids', 'number' => 100, 'offset' => $offset]);
            foreach ($ids as $id) {
                switch_to_blog((int) $id);
                try {
                    wp_clear_scheduled_hook(self::CLEANUP_HOOK);
                } finally {
                    restore_current_blog();
                }
            }
            $offset += count($ids);
        } while (count($ids) === 100);
    }
}
