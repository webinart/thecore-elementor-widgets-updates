<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Submissions;

use TheCore\ElementorWidgets\FormSecurity\Support\FormContext;
use TheCore\ElementorWidgets\Forms\FormDefinition;

interface SubmissionArchive
{
    /** Read-only preflight. The opaque result is never persisted in dry-run mode. */
    public function prepare(FormContext $context, FormDefinition $form, array $values): array;

    /** Persist before delivering actions; failure must prevent any delivery. */
    public function persist(array $prepared): int;

    /** Record action outcomes without delivering or retrying any action. */
    public function recordOutcome(int $id, array $statuses): void;
}
