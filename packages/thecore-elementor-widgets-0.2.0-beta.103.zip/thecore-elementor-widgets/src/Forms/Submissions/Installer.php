<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Submissions;

use TheCore\ElementorWidgets\FormSecurity\Support\Secrets;
use Throwable;

/** A separate optional schema: its failure never changes protection readiness. */
final class Installer
{
    public const VERSION = '1';
    public const OPTION_NAME = 'thecore_elementor_form_submissions_schema_version';
    public const HISTORY_OPTION = 'thecore_elementor_form_submissions_ever_installed';

    public static function tableName(string $kind = 'submissions'): string
    {
        global $wpdb;
        $suffix = match ($kind) {
            'submissions' => 'thecore_form_submissions',
            'emails' => 'thecore_form_submission_emails',
            default => '',
        };
        $prefix = is_object($wpdb) && isset($wpdb->prefix) && is_string($wpdb->prefix) ? $wpdb->prefix : '';
        $name = $prefix . $suffix;
        return $prefix !== '' && $suffix !== '' && strlen($name) <= 64
            && preg_match('/\A[A-Za-z0-9_]+\z/D', $name) === 1 ? $name : '';
    }

    public static function isReady(): bool
    {
        return function_exists('get_option')
            && (string) get_option(self::OPTION_NAME, '') === self::VERSION
            && (bool) get_option(self::HISTORY_OPTION, false);
    }

    public static function maybeUpgrade(): bool
    {
        if (self::isReady()) {
            return true;
        }
        $cli = defined('WP_CLI') && WP_CLI === true;
        if (! $cli && (! is_admin() || ! current_user_can('manage_options'))) {
            return false;
        }
        return self::install();
    }

    public static function install(): bool
    {
        global $wpdb;
        $table = self::tableName();
        $emails = self::tableName('emails');
        if ($table === '' || $emails === '' || ! is_object($wpdb) || ! method_exists($wpdb, 'get_charset_collate')) {
            return false;
        }
        if (! function_exists('dbDelta')) {
            if (! defined('ABSPATH') || ! is_readable(ABSPATH . 'wp-admin/includes/upgrade.php')) {
                return false;
            }
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        }
        try {
            $options = 'ENGINE=InnoDB ' . $wpdb->get_charset_collate();
            dbDelta([
                "CREATE TABLE {$table} (
                    id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                    post_id bigint(20) unsigned NOT NULL,
                    widget_id varchar(128) NOT NULL,
                    form_name text NOT NULL,
                    fields_json longtext NOT NULL,
                    statuses_json text NOT NULL,
                    created_at bigint(20) unsigned NOT NULL,
                    expires_at bigint(20) unsigned NOT NULL,
                    PRIMARY KEY  (id),
                    KEY expires_at (expires_at),
                    KEY created_at (created_at)
                ) {$options};",
                "CREATE TABLE {$emails} (
                    submission_id bigint(20) unsigned NOT NULL,
                    email_hash char(64) NOT NULL,
                    PRIMARY KEY  (submission_id, email_hash),
                    KEY email_hash (email_hash)
                ) {$options};",
            ]);
            if (! self::hasExpectedSchema()) {
                return false;
            }
            // The lookup key must survive salt rotation. Creation is reserved for installation.
            Secrets::personalDataLookup();
            if (! Secrets::personalDataLookupIsPersistent()) {
                return false;
            }
            // Publish the privacy-discovery marker before allowing accepted-data writes.
            update_option(self::HISTORY_OPTION, true, false);
            if (! get_option(self::HISTORY_OPTION, false)) {
                return false;
            }
            update_option(self::OPTION_NAME, self::VERSION, false);
            return self::isReady();
        } catch (Throwable) {
            return false;
        }
    }

    public static function hasExpectedSchema(): bool
    {
        global $wpdb;
        if (! is_object($wpdb) || ! method_exists($wpdb, 'get_results') || ! method_exists($wpdb, 'get_row')) {
            return false;
        }
        $schemas = [
            'submissions' => [
                'id' => '/\Abigint(?:\(20\))? unsigned\z/',
                'post_id' => '/\Abigint(?:\(20\))? unsigned\z/',
                'widget_id' => '/\Avarchar\(128\)\z/', 'form_name' => '/\Atext\z/',
                'fields_json' => '/\Alongtext\z/', 'statuses_json' => '/\Atext\z/',
                'created_at' => '/\Abigint(?:\(20\))? unsigned\z/',
                'expires_at' => '/\Abigint(?:\(20\))? unsigned\z/',
            ],
            'emails' => ['submission_id' => '/\Abigint(?:\(20\))? unsigned\z/', 'email_hash' => '/\Achar\(64\)\z/'],
        ];
        foreach ($schemas as $kind => $columns) {
            $name = self::tableName($kind);
            if ($name === '') {
                return false;
            }
            $status = $wpdb->get_row($wpdb->prepare('SHOW TABLE STATUS LIKE %s', $wpdb->esc_like($name)), 'ARRAY_A');
            if (! is_array($status) || ($status['Name'] ?? '') !== $name || strtolower((string) ($status['Engine'] ?? '')) !== 'innodb') {
                return false;
            }
            $rows = $wpdb->get_results("SHOW FULL COLUMNS FROM `{$name}`", 'ARRAY_A');
            $found = [];
            foreach (is_array($rows) ? $rows : [] as $row) {
                if (is_array($row)) {
                    $found[(string) ($row['Field'] ?? '')] = $row;
                }
            }
            foreach ($columns as $column => $pattern) {
                if (
                    ! isset($found[$column]) || preg_match($pattern, strtolower((string) $found[$column]['Type'])) !== 1
                    || ($found[$column]['Null'] ?? '') !== 'NO'
                ) {
                    return false;
                }
            }
            if ($kind === 'submissions' && ! str_contains(strtolower((string) ($found['id']['Extra'] ?? '')), 'auto_increment')) {
                return false;
            }
            $indexes = $wpdb->get_results("SHOW INDEX FROM `{$name}`", 'ARRAY_A');
            $indexColumns = [];
            foreach (is_array($indexes) ? $indexes : [] as $index) {
                if (! is_array($index)) {
                    continue;
                }
                $key = (string) ($index['Key_name'] ?? '');
                $indexColumns[$key][(int) ($index['Seq_in_index'] ?? 0)] = (string) ($index['Column_name'] ?? '');
                if ($key === 'PRIMARY' && (int) ($index['Non_unique'] ?? 1) !== 0) {
                    return false;
                }
            }
            $expected = $kind === 'submissions'
                ? ['PRIMARY' => ['id'], 'expires_at' => ['expires_at'], 'created_at' => ['created_at']]
                : ['PRIMARY' => ['submission_id', 'email_hash'], 'email_hash' => ['email_hash']];
            foreach ($expected as $key => $fields) {
                $actual = $indexColumns[$key] ?? [];
                ksort($actual);
                if (array_values($actual) !== $fields) {
                    return false;
                }
            }
        }
        return true;
    }

    /** Accepted requests survive deactivation, but must not orphan personal data on uninstall. */
    public static function purgeForUninstall(): bool
    {
        if (! function_exists('is_multisite') || ! is_multisite()) {
            return self::dropCurrentSite();
        }
        $offset = 0;
        do {
            $ids = get_sites(['fields' => 'ids', 'number' => 100, 'offset' => $offset]);
            foreach ($ids as $id) {
                switch_to_blog((int) $id);
                try {
                    if (! self::dropCurrentSite()) {
                        return false;
                    }
                } finally {
                    restore_current_blog();
                }
            }
            $offset += count($ids);
        } while (count($ids) === 100);
        return true;
    }

    private static function dropCurrentSite(): bool
    {
        global $wpdb;
        $table = self::tableName();
        $emails = self::tableName('emails');
        if ($table === '' || $emails === '' || ! is_object($wpdb)) {
            return false;
        }
        try {
            if ($wpdb->query("DROP TABLE IF EXISTS `{$emails}`, `{$table}`") === false) {
                return false;
            }
            delete_option(self::OPTION_NAME);
            delete_option(self::HISTORY_OPTION);
            return true;
        } catch (Throwable) {
            return false;
        }
    }
}
