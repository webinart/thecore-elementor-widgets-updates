<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Submissions;

use Closure;
use TheCore\ElementorWidgets\FormSecurity\Support\EmailIdentity;
use TheCore\ElementorWidgets\FormSecurity\Support\FormContext;
use TheCore\ElementorWidgets\FormSecurity\Support\Secrets;
use TheCore\ElementorWidgets\Forms\FormDefinition;
use TheCore\ElementorWidgets\Forms\SubmissionException;
use Throwable;

final class Store implements SubmissionArchive
{
    private Closure $clock;
    private Closure $readiness;

    public function __construct(
        private readonly ?object $database = null,
        ?callable $clock = null,
        ?callable $readiness = null,
        private readonly ?EmailIdentity $identity = null
    ) {
        $this->clock = Closure::fromCallable($clock ?? static fn (): int => time());
        $this->readiness = Closure::fromCallable($readiness ?? [Installer::class, 'isReady']);
    }

    public function prepare(FormContext $context, FormDefinition $form, array $values): array
    {
        $this->assertAvailable();
        $identity = $this->emailIdentity();
        $days = $form->settings['submission-retention-days'] ?? 90;
        if (! is_int($days) || $days < 1 || $days > 365 || count($values) > FormDefinition::MAX_FIELDS) {
            throw $this->failure();
        }
        $fields = [];
        $hashes = [];
        foreach ($values as $id => $value) {
            $field = $form->fields[$id] ?? null;
            if (! is_array($field) || ! in_array($field['type'] ?? '', ['text', 'email', 'tel', 'url', 'number', 'textarea', 'checkbox', 'radio', 'select'], true)) {
                throw $this->failure();
            }
            $items = is_array($value) ? $value : [$value];
            if ((is_array($value) && (! array_is_list($value) || count($value) > 100)) || $items === []) {
                // Empty multiple selections are legitimate validated values.
                if ($value !== []) {
                    throw $this->failure();
                }
            }
            foreach ($items as $item) {
                if (
                    ! is_string($item) || preg_match('//u', $item) !== 1
                    || (function_exists('mb_strlen') ? mb_strlen($item, 'UTF-8') : preg_match_all('/./us', $item)) > 10000
                ) {
                    throw $this->failure();
                }
                if ($field['type'] === 'email' && $item !== '') {
                    $hash = $identity->hash($item);
                    if ($hash === '') {
                        throw $this->failure();
                    }
                    $hashes[$hash] = true;
                }
            }
            $fields[] = ['id' => (string) $id, 'label' => strip_tags((string) ($field['label'] ?? $id)),
                'type' => $field['type'], 'value' => $value];
        }
        $json = json_encode($fields, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        if (strlen($json) > 131072 || ! is_string($form->settings['form-name'] ?? null) || strlen($form->settings['form-name']) > 1000) {
            throw $this->failure();
        }
        $statuses = array_fill_keys($form->settings['actions-after-submit'] ?? ['email'], 'pending');
        $now = ($this->clock)();
        return ['post_id' => $context->postId(), 'widget_id' => $context->widgetId(),
            'form_name' => $form->settings['form-name'], 'fields_json' => $json,
            'statuses_json' => $this->statusJson($statuses), 'email_hashes' => array_keys($hashes),
            'created_at' => $now, 'expires_at' => $now + $days * 86400];
    }

    public function persist(array $prepared): int
    {
        $this->assertAvailable();
        $db = $this->db();
        $table = $this->table();
        $emails = $this->table('emails');
        $expected = ['post_id', 'widget_id', 'form_name', 'fields_json', 'statuses_json', 'email_hashes', 'created_at', 'expires_at'];
        if (
            array_diff($expected, array_keys($prepared)) || array_diff(array_keys($prepared), $expected)
            || ! is_array($prepared['email_hashes']) || $prepared['expires_at'] <= ($this->clock)()
        ) {
            throw $this->failure();
        }
        try {
            if ($this->execute('query', 'START TRANSACTION') === false) {
                throw $this->failure();
            }
            $inserted = $this->execute('query', $db->prepare(
                "INSERT INTO `{$table}` (post_id,widget_id,form_name,fields_json,statuses_json,created_at,expires_at) VALUES (%d,%s,%s,%s,%s,%d,%d)",
                $prepared['post_id'],
                $prepared['widget_id'],
                $prepared['form_name'],
                $prepared['fields_json'],
                $prepared['statuses_json'],
                $prepared['created_at'],
                $prepared['expires_at']
            ));
            $id = (int) ($db->insert_id ?? 0);
            if ($inserted !== 1 || $id < 1) {
                throw $this->failure();
            }
            foreach ($prepared['email_hashes'] as $hash) {
                if (
                    ! is_string($hash) || preg_match('/\A[a-f0-9]{64}\z/D', $hash) !== 1
                    || $this->execute('query', $db->prepare("INSERT INTO `{$emails}` (submission_id,email_hash) VALUES (%d,%s)", $id, $hash)) !== 1
                ) {
                    throw $this->failure();
                }
            }
            if ($this->execute('query', 'COMMIT') === false) {
                throw $this->failure();
            }
            return $id;
        } catch (Throwable) {
            $this->rollback();
            throw $this->failure();
        }
    }

    public function recordOutcome(int $id, array $statuses): void
    {
        $this->assertAvailable();
        $db = $this->db();
        $table = $this->table();
        $json = $this->statusJson($statuses);
        if ($id < 1 || $this->execute('query', $db->prepare("UPDATE `{$table}` SET statuses_json=%s WHERE id=%d AND expires_at>%d", $json, $id, ($this->clock)())) === false) {
            throw $this->failure();
        }
    }

    public function count(): int
    {
        $this->assertAvailable();
        $db = $this->db();
        $result = $this->execute('get_var', $db->prepare('SELECT COUNT(*) FROM `' . $this->table() . '` WHERE expires_at>%d', ($this->clock)()));
        if ($result === null || ($db->last_error ?? '') !== '') {
            throw $this->failure();
        }
        return (int) $result;
    }

    public function list(int $page = 1, int $limit = 20): array
    {
        $limit = min(100, max(1, $limit));
        return $this->rows(
            'SELECT * FROM `' . $this->table() . '` WHERE expires_at>%d ORDER BY id DESC LIMIT %d OFFSET %d',
            [($this->clock)(), $limit, (max(1, $page) - 1) * $limit]
        );
    }

    public function get(int $id): ?array
    {
        $rows = $this->rows('SELECT * FROM `' . $this->table() . '` WHERE id=%d AND expires_at>%d LIMIT 1', [$id, ($this->clock)()]);
        return $rows[0] ?? null;
    }

    public function listByEmailHash(string $hash, int $offset = 0, int $limit = 100, bool $includeExpired = false): array
    {
        if (preg_match('/\A[a-f0-9]{64}\z/D', $hash) !== 1) {
            return [];
        }
        $expiry = $includeExpired ? '' : ' AND s.expires_at>%d';
        $values = $includeExpired ? [$hash] : [$hash, ($this->clock)()];
        return $this->rows(
            'SELECT s.* FROM `' . $this->table() . '` s INNER JOIN `' . $this->table('emails')
            . '` e ON e.submission_id=s.id WHERE e.email_hash=%s' . $expiry . ' ORDER BY s.id ASC LIMIT %d OFFSET %d',
            [...$values, min(100, max(1, $limit)), max(0, $offset)]
        );
    }

    public function delete(int $id): bool
    {
        return $id > 0 && $this->deleteWhere('s.id=%d', [$id]) > 0;
    }

    public function deleteByEmailHash(string $hash, int $limit = 100): int
    {
        $rows = $this->listByEmailHash($hash, 0, min(100, max(1, $limit)), true);
        return $this->deleteIds(array_column($rows, 'id'));
    }

    public function purgeExpired(int $limit = 500): int
    {
        $rows = $this->rows(
            'SELECT id FROM `' . $this->table() . '` WHERE expires_at<=%d ORDER BY id ASC LIMIT %d',
            [($this->clock)(), min(1000, max(1, $limit))]
        );
        return $this->deleteIds(array_column($rows, 'id'));
    }

    private function deleteIds(array $ids): int
    {
        $ids = array_values(array_filter(array_map('intval', $ids), static fn (int $id): bool => $id > 0));
        return $ids === [] ? 0 : $this->deleteWhere('s.id IN (' . implode(',', array_fill(0, count($ids), '%d')) . ')', $ids);
    }

    private function deleteWhere(string $where, array $values): int
    {
        $this->assertAvailable();
        $db = $this->db();
        $table = $this->table();
        $emails = $this->table('emails');
        try {
            if ($this->execute('query', 'START TRANSACTION') === false) {
                throw $this->failure();
            }
            $ids = $this->execute('get_results', $db->prepare("SELECT s.id FROM `{$table}` s WHERE {$where} FOR UPDATE", ...$values), 'ARRAY_A');
            if (! is_array($ids) || ($db->last_error ?? '') !== '') {
                throw $this->failure();
            }
            // One atomic multi-table deletion also removes every secondary email identity.
            $query = "DELETE s,e FROM `{$table}` s LEFT JOIN `{$emails}` e ON e.submission_id=s.id WHERE {$where}";
            if ($this->execute('query', $db->prepare($query, ...$values)) === false || $this->execute('query', 'COMMIT') === false) {
                throw $this->failure();
            }
            return count($ids);
        } catch (Throwable) {
            $this->rollback();
            throw $this->failure();
        }
    }

    private function rows(string $query, array $values): array
    {
        $this->assertAvailable();
        $db = $this->db();
        $rows = $this->execute('get_results', $db->prepare($query, ...$values), 'ARRAY_A');
        if (! is_array($rows) || ($db->last_error ?? '') !== '') {
            throw $this->failure();
        }
        return $rows;
    }

    public function emailIdentity(): EmailIdentity
    {
        if ($this->identity !== null) {
            return $this->identity;
        }
        if (! Secrets::personalDataLookupIsPersistent()) {
            throw $this->failure();
        }
        return new EmailIdentity(Secrets::personalDataLookup());
    }

    private function assertAvailable(): void
    {
        if (! ($this->readiness)() || $this->table() === '' || $this->table('emails') === '' || ! is_object($this->db())) {
            throw $this->failure();
        }
    }

    private function table(string $kind = 'submissions'): string
    {
        if ($this->database === null) {
            return Installer::tableName($kind);
        }
        $prefix = $this->database->prefix ?? '';
        $table = $prefix . ($kind === 'emails' ? 'thecore_form_submission_emails' : 'thecore_form_submissions');
        return is_string($prefix) && $prefix !== '' && strlen($table) <= 64 && preg_match('/\A[A-Za-z0-9_]+\z/D', $table) === 1 ? $table : '';
    }

    private function db(): ?object
    {
        global $wpdb;
        return $this->database ?? (is_object($wpdb) ? $wpdb : null);
    }

    /** SQL errors must not print/log a query containing a visitor's message. */
    private function execute(string $method, string $query, mixed ...$arguments): mixed
    {
        $db = $this->db();
        if ($db === null || ! method_exists($db, $method)) {
            throw $this->failure();
        }
        $previous = method_exists($db, 'suppress_errors') ? (bool) $db->suppress_errors(true) : null;
        try {
            return $db->{$method}($query, ...$arguments);
        } catch (Throwable) {
            throw $this->failure();
        } finally {
            if ($previous !== null) {
                $db->suppress_errors($previous);
            }
        }
    }

    private function rollback(): void
    {
        try {
            $this->execute('query', 'ROLLBACK');
        } catch (Throwable) {
            // A secondary rollback failure must never leak the original SQL/payload.
        }
    }

    private function statusJson(array $statuses): string
    {
        if (count($statuses) > 10 || $statuses === []) {
            throw $this->failure();
        }
        foreach ($statuses as $key => $status) {
            if (
                ! is_string($key) || preg_match('/\A[a-z0-9_-]{1,64}\z/D', $key) !== 1
                || ! in_array($status, ['pending', 'succeeded', 'failed', 'not_attempted', 'skipped'], true)
            ) {
                throw $this->failure();
            }
        }
        return json_encode($statuses, JSON_THROW_ON_ERROR);
    }

    private function failure(): SubmissionException
    {
        return new SubmissionException('storage_unavailable', 'Le stockage des demandes est indisponible. Veuillez réessayer plus tard.', 503);
    }
}
