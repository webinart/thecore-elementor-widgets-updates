<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Submissions;

use TheCore\ElementorWidgets\Contracts\Bootable;
use Throwable;

final class AdminPage implements Bootable
{
    public const PAGE_SLUG = 'thecore-elementor-form-submissions';
    public const DELETE_ACTION = 'thecore_elementor_delete_form_submission';
    public const NONCE_NAME = '_thecore_submission_nonce';

    public function __construct(private readonly Store $store)
    {
    }

    public function register(): void
    {
        add_action('admin_menu', [$this, 'registerMenu']);
        add_action('admin_post_' . self::DELETE_ACTION, [$this, 'handleDelete']);
    }

    public function registerMenu(): void
    {
        add_submenu_page(
            'thecore-elementor-widgets',
            __('Demandes reçues', 'thecore-elementor-widgets'),
            __('Demandes reçues', 'thecore-elementor-widgets'),
            'manage_options',
            self::PAGE_SLUG,
            [$this, 'renderPage']
        );
    }

    public function renderPage(): void
    {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('Vous n’êtes pas autorisé à consulter les demandes.', 'thecore-elementor-widgets'));
            return;
        }
        echo '<div class="wrap"><h1>' . esc_html__('Demandes de formulaire The Core', 'thecore-elementor-widgets') . '</h1>';
        echo '<p>' . esc_html__('Seuls les formulaires ayant activé la conservation apparaissent ici. Les demandes expirées ne sont plus consultables. Les états d’action ne constituent pas une confirmation de livraison du mail.', 'thecore-elementor-widgets') . '</p>';
        try {
            $id = $this->integer($_GET['submission_id'] ?? null);
            if ($id > 0) {
                $this->renderDetail($id);
            } else {
                $page = max(1, $this->integer($_GET['paged'] ?? null));
                $count = $this->store->count();
                $rows = $this->store->list($page);
                echo '<p>' . esc_html(sprintf(__('%d demande(s) conservée(s).', 'thecore-elementor-widgets'), $count)) . '</p>';
                echo '<table class="widefat striped"><thead><tr>';
                foreach (['Date (UTC)', 'Formulaire', 'Nom / e-mail', 'Actions'] as $heading) {
                    echo '<th>' . esc_html__($heading, 'thecore-elementor-widgets') . '</th>';
                }
                echo '</tr></thead><tbody>';
                foreach ($rows as $row) {
                    $summary = [];
                    foreach ($this->fields($row) as $field) {
                        if ($field['type'] === 'email' || preg_match('/nom|name/i', $field['label']) === 1) {
                            $summary[] = $this->value($field['value']);
                        }
                    }
                    echo '<tr><td>' . esc_html(gmdate('Y-m-d H:i:s', (int) $row['created_at'])) . '</td>';
                    echo '<td><a href="' . esc_url($this->url(['submission_id' => (int) $row['id']])) . '">' . esc_html((string) $row['form_name']) . '</a></td>';
                    echo '<td>' . esc_html(implode(' / ', $summary)) . '</td><td>' . esc_html((string) $row['statuses_json']) . '</td></tr>';
                }
                if ($rows === []) {
                    echo '<tr><td colspan="4">' . esc_html__('Aucune demande.', 'thecore-elementor-widgets') . '</td></tr>';
                }
                echo '</tbody></table><p>';
                if ($page > 1) {
                    echo '<a class="button" href="' . esc_url($this->url(['paged' => $page - 1])) . '">' . esc_html__('Précédent', 'thecore-elementor-widgets') . '</a> ';
                }
                if ($page * 20 < $count) {
                    echo '<a class="button" href="' . esc_url($this->url(['paged' => $page + 1])) . '">' . esc_html__('Suivant', 'thecore-elementor-widgets') . '</a>';
                }
                echo '</p>';
            }
        } catch (Throwable) {
            echo '<div class="notice notice-error"><p>' . esc_html__('Le stockage des demandes est indisponible. Aucun état des demandes ne peut être déduit.', 'thecore-elementor-widgets') . '</p></div>';
        }
        echo '</div>';
    }

    public function handleDelete(): void
    {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('Vous n’êtes pas autorisé à effacer cette demande.', 'thecore-elementor-widgets'));
            return;
        }
        $id = $this->integer($_POST['submission_id'] ?? null);
        $nonce = $_POST[self::NONCE_NAME] ?? null;
        if (
            ($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || $id < 1 || ! is_string($nonce)
            || ! wp_verify_nonce(wp_unslash($nonce), self::DELETE_ACTION . '_' . $id)
        ) {
            wp_die(esc_html__('Requête d’effacement invalide.', 'thecore-elementor-widgets'));
            return;
        }
        try {
            $this->store->delete($id);
        } catch (Throwable) {
            wp_die(esc_html__('La demande n’a pas pu être effacée.', 'thecore-elementor-widgets'));
            return;
        }
        wp_safe_redirect($this->url());
        // No exit is required: admin-post terminates immediately after this handler.
    }

    private function renderDetail(int $id): void
    {
        $row = $this->store->get($id);
        if ($row === null) {
            echo '<p>' . esc_html__('Demande introuvable ou expirée.', 'thecore-elementor-widgets') . '</p>';
            return;
        }
        echo '<p><a href="' . esc_url($this->url()) . '">' . esc_html__('Toutes les demandes', 'thecore-elementor-widgets') . '</a></p>';
        echo '<h2>' . esc_html((string) $row['form_name']) . '</h2><dl>';
        foreach ($this->fields($row) as $field) {
            echo '<dt><strong>' . esc_html((string) $field['label']) . '</strong></dt><dd style="white-space:pre-wrap">' . esc_html($this->value($field['value'])) . '</dd>';
        }
        echo '<dt>' . esc_html__('État des actions', 'thecore-elementor-widgets') . '</dt><dd>' . esc_html((string) $row['statuses_json']) . '</dd>';
        echo '<dt>' . esc_html__('Effacement prévu (UTC)', 'thecore-elementor-widgets') . '</dt><dd>' . esc_html(gmdate('Y-m-d H:i:s', (int) $row['expires_at'])) . '</dd></dl>';
        echo '<form action="' . esc_url(admin_url('admin-post.php')) . '" method="post">';
        echo '<input type="hidden" name="action" value="' . esc_attr(self::DELETE_ACTION) . '">';
        echo '<input type="hidden" name="submission_id" value="' . esc_attr((string) $id) . '">';
        echo '<input type="hidden" name="' . esc_attr(self::NONCE_NAME) . '" value="' . esc_attr(wp_create_nonce(self::DELETE_ACTION . '_' . $id)) . '">';
        echo '<button type="submit" class="button button-link-delete">' . esc_html__('Effacer définitivement cette demande', 'thecore-elementor-widgets') . '</button></form>';
    }

    private function fields(array $row): array
    {
        $fields = json_decode((string) $row['fields_json'], true, 64, JSON_THROW_ON_ERROR);
        return is_array($fields) ? $fields : [];
    }

    private function value(mixed $value): string
    {
        return is_array($value) ? implode(', ', $value) : (string) $value;
    }

    private function integer(mixed $value): int
    {
        return (is_int($value) || is_string($value)) && preg_match('/\A[1-9][0-9]{0,12}\z/D', (string) $value) === 1 ? (int) $value : 0;
    }

    private function url(array $args = []): string
    {
        return add_query_arg(['page' => self::PAGE_SLUG] + $args, admin_url('admin.php'));
    }
}
