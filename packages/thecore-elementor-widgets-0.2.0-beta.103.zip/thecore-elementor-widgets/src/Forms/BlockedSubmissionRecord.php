<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms;

use TheCore\ElementorWidgets\FormSecurity\Support\DataMinimizer;
use TheCore\ElementorWidgets\FormSecurity\Support\FormContext;

/** Minimal legacy-compatible DTO, built from the saved server-side definition. */
final class BlockedSubmissionRecord
{
    private const MAXIMUM_VALUE_BYTES = 8192;
    private const MAXIMUM_LIST_ITEMS = 20;

    private const ALLOWED_TYPES = ['text', 'email', 'tel', 'url', 'number', 'textarea', 'checkbox', 'radio', 'select'];

    private const TECHNICAL_IDS = [
        'context',
        'proof',
        'website',
        'test_token',
        'test-token',
        FormDefinition::SECURITY_FIELD,
    ];

    private const TECHNICAL_FRAGMENTS = [
        '_wpnonce',
        'altcha',
        'g-recaptcha-response',
        'h-captcha-response',
        'honeypot',
        'recaptcha',
        'thecore_form_security',
        'turnstile',
    ];

    private function __construct(
        private readonly array $fields,
        private readonly array $meta,
        private readonly array $settings
    ) {
    }

    public static function fromForm(FormContext $context, FormDefinition $form, array $submitted): self
    {
        $fields = [];

        foreach ($form->fields as $id => $field) {
            if (count($fields) >= FormDefinition::MAX_FIELDS) {
                break;
            }

            $domId = (string) ($field['domId'] ?? $id);
            if (
                ! in_array($field['type'] ?? '', self::ALLOWED_TYPES, true)
                || self::technicalId((string) $id)
                || self::technicalId($domId)
                || self::technicalId((string) ($field['name'] ?? ''))
                || $id === $context->fieldId()
            ) {
                continue;
            }

            // Readonly values are defined by the author, not visitor metadata.
            $value = ($field['readonly'] ?? false)
                ? ($field['value'] ?? '')
                : ($submitted[$id] ?? '');
            $multiple = 'select' === ($field['type'] ?? '') && ($field['multiple'] ?? false);
            $value = self::boundedValue($value, $multiple);

            if (null === $value) {
                continue;
            }

            $fields[$id] = [
                'id' => $domId,
                'title' => (string) ($field['label'] ?? $domId),
                'type' => (string) ($field['type'] ?? ''),
                'value' => $value,
            ];
        }

        $permalink = function_exists('get_permalink') ? get_permalink($context->postId()) : false;
        $homeUrl = home_url('/');
        $pageUrl = (new DataMinimizer())->canonicalReferrer(
            is_string($permalink) && '' !== $permalink ? $permalink : $homeUrl,
            $homeUrl
        );

        return new self(
            $fields,
            ['page_url' => ['value' => $pageUrl]],
            [
                'form_name' => (string) ($form->settings['form-name'] ?? ''),
                'form_post_id' => $context->postId(),
            ]
        );
    }

    public function get(string $key): array
    {
        return match ($key) {
            'fields' => $this->fields,
            'meta' => $this->meta,
            default => [],
        };
    }

    public function get_form_settings(string $key): mixed
    {
        return $this->settings[$key] ?? '';
    }

    private static function technicalId(string $identifier): bool
    {
        $identifier = strtolower($identifier);
        if (in_array($identifier, self::TECHNICAL_IDS, true)) {
            return true;
        }

        foreach (self::TECHNICAL_FRAGMENTS as $fragment) {
            if (str_contains($identifier, $fragment)) {
                return true;
            }
        }

        return false;
    }

    private static function boundedValue(mixed $value, bool $multiple): string|array|null
    {
        if (is_string($value)) {
            return self::boundedString($value);
        }

        if (! $multiple || ! is_array($value) || ! array_is_list($value)) {
            return null;
        }

        $items = [];
        foreach (array_slice($value, 0, self::MAXIMUM_LIST_ITEMS) as $item) {
            if (is_string($item)) {
                $items[] = self::boundedString($item);
            }
        }

        return $items;
    }

    private static function boundedString(string $value): string
    {
        $value = str_replace("\0", '', $value);

        if (1 !== preg_match('//u', $value)) {
            return '';
        }

        if (strlen($value) <= self::MAXIMUM_VALUE_BYTES) {
            return $value;
        }

        if (function_exists('mb_strcut')) {
            return mb_strcut($value, 0, self::MAXIMUM_VALUE_BYTES, 'UTF-8');
        }

        // Keep valid UTF-8 at a byte boundary even without the mbstring module.
        $value = substr($value, 0, self::MAXIMUM_VALUE_BYTES);
        while ('' !== $value && 1 !== preg_match('//u', $value)) {
            $value = substr($value, 0, -1);
        }

        return $value;
    }
}
