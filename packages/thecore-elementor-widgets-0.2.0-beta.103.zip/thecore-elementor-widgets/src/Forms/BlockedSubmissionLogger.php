<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms;

use TheCore\ElementorWidgets\FormSecurity\Infrastructure\BlockedSubmissionStore;
use TheCore\ElementorWidgets\FormSecurity\Infrastructure\SecurityStore;
use TheCore\ElementorWidgets\FormSecurity\Security\BlockedSubmissionLogger as SecurityBlockedSubmissionLogger;
use TheCore\ElementorWidgets\FormSecurity\Support\BlockedSubmissionPayloadBuilder;
use TheCore\ElementorWidgets\FormSecurity\Support\DataMinimizer;
use TheCore\ElementorWidgets\FormSecurity\Support\EmailIdentity;
use TheCore\ElementorWidgets\FormSecurity\Support\FormContext;
use TheCore\ElementorWidgets\FormSecurity\Support\Metrics;
use TheCore\ElementorWidgets\FormSecurity\Support\Secrets;
use TheCore\ElementorWidgets\FormSecurity\Support\SecuritySettings;
use Throwable;

/** Adapts Atomic refusals to the existing, bounded Form Security journal. */
final class BlockedSubmissionLogger implements BlockedSubmissionMonitor
{
    public function __construct(
        private readonly SecurityBlockedSubmissionLogger $logger,
        private readonly Metrics $metrics
    ) {
    }

    public static function fromDefaults(
        ?SecuritySettings $settings = null,
        ?SecurityStore $quotaStore = null
    ): self {
        // Key/schema creation belongs to installation, never a public refusal.
        $persistentKeyAvailable = Secrets::personalDataLookupIsPersistent();
        $lookupKey = $persistentKeyAvailable ? Secrets::personalDataLookup() : '';
        $metrics = new Metrics();

        return new self(
            new SecurityBlockedSubmissionLogger(
                new BlockedSubmissionStore(),
                $quotaStore ?? new SecurityStore(),
                new BlockedSubmissionPayloadBuilder(),
                new EmailIdentity($lookupKey),
                new DataMinimizer(),
                $settings ?? new SecuritySettings(),
                $metrics,
                $persistentKeyAvailable && Secrets::personalDataLookupIsPersistent()
            ),
            $metrics
        );
    }

    public function log(
        FormContext $context,
        FormDefinition $form,
        array $fields,
        SubmissionException $error
    ): void {
        if (($form->settings['log-blocked-submissions'] ?? false) !== true) {
            return;
        }

        // The same refusal code can also signal infrastructure failure (503).
        // Only actual anti-spam refusals, not outages or field errors, qualify.
        $reason = match ([$error->errorCode, $error->status]) {
            ['spam_rejected', 403] => 'blocked_honeypot',
            ['proof_invalid', 403] => 'blocked_altcha_invalid',
            ['proof_replayed', 409] => 'blocked_replay',
            ['submission_duplicate', 409] => 'blocked_duplicate',
            ['rate_limited', 429] => 'blocked_atomic_rate',
            default => null,
        };

        if (null === $reason) {
            return;
        }

        $this->incrementMetric($reason);

        // Rate-limit floods count as metrics only; do not keep their payloads.
        if ('blocked_atomic_rate' === $reason) {
            return;
        }

        try {
            $this->logger->log(
                BlockedSubmissionRecord::fromForm($context, $form, $fields),
                $reason,
                $context
            );
        } catch (Throwable) {
            // Includes integrator filters: journaling must never undo a block.
            $this->incrementMetric('blocked_log_write_error');
        }
    }

    private function incrementMetric(string $metric): void
    {
        try {
            $this->metrics->increment($metric);
        } catch (Throwable) {
            // Counters are secondary too; an unavailable option store is safe.
        }
    }
}
