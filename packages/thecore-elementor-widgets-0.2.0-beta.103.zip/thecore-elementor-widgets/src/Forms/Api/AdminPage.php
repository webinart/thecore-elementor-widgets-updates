<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Api;

use TheCore\ElementorWidgets\Contracts\Bootable;
use Throwable;

/** Per-site connection management. Secrets are accepted, never rendered back. */
final class AdminPage implements Bootable
{
    public const PAGE_SLUG = 'thecore-form-api-connections';
    public const SAVE_ACTION = 'thecore_form_api_save';
    public const DELETE_ACTION = 'thecore_form_api_delete';
    public const NONCE_NAME = '_thecore_api_nonce';

    public function __construct(private readonly Connections $connections)
    {
    }

    public function register(): void
    {
        add_action('admin_menu', [$this, 'registerMenu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueueAssets']);
        add_action('admin_post_' . self::SAVE_ACTION, [$this, 'handleSave']);
        add_action('admin_post_' . self::DELETE_ACTION, [$this, 'handleDelete']);
    }

    public function registerMenu(): void
    {
        add_submenu_page('thecore-elementor-widgets', __('Connexions API', 'thecore-elementor-widgets'), __('Connexions API', 'thecore-elementor-widgets'), 'manage_options', self::PAGE_SLUG, [$this, 'renderPage']);
    }

    public function enqueueAssets(string $hook): void
    {
        if (str_ends_with($hook, '_page_' . self::PAGE_SLUG)) {
            wp_enqueue_style('thecore-form-api-admin', THECORE_ELEMENTOR_WIDGETS_URL . 'assets/admin/form-api-connections.css', [], THECORE_ELEMENTOR_WIDGETS_VERSION);
        }
    }

    public function renderPage(): void
    {
        if (! $this->allowed()) {
            return;
        }
        echo '<div class="wrap thecore-api-connections"><h1>' . esc_html__('Connexions API', 'thecore-elementor-widgets') . '</h1>';
        echo '<p>' . esc_html__('Définissez les destinations utilisées par l’action « Envoyer à une API » des formulaires. Chaque connexion correspond à une opération de l’application destinataire.', 'thecore-elementor-widgets') . '</p>';
        $notice = $_GET['notice'] ?? '';
        if (in_array($notice, ['saved', 'deleted'], true)) {
            echo '<div class="notice notice-success"><p>' . esc_html__($notice === 'saved' ? 'Connexion enregistrée.' : 'Connexion supprimée.', 'thecore-elementor-widgets') . '</p></div>';
        }
        try {
            $rows = $this->connections->allForAdmin();
            $editing = null;
            $edit = is_string($_GET['edit'] ?? null) ? wp_unslash($_GET['edit']) : '';
            echo '<table class="widefat striped thecore-api-connection-list"><thead><tr>';
            foreach (['Connexion', 'Destination', 'Authentification', 'Actions'] as $heading) {
                echo '<th scope="col">' . esc_html__($heading, 'thecore-elementor-widgets') . '</th>';
            }
            echo '</tr></thead><tbody>';
            foreach ($rows as $row) {
                if ($row['id'] === $edit) {
                    $editing = $row;
                }
                echo '<tr><td><strong>' . esc_html($row['label']) . '</strong><br><code>' . esc_html($row['id']) . '</code></td>';
                echo '<td data-label="' . esc_attr(__('Destination', 'thecore-elementor-widgets')) . '">' . esc_html($row['url']) . '</td>';
                echo '<td data-label="' . esc_attr(__('Authentification', 'thecore-elementor-widgets')) . '">' . esc_html__($row['auth'] === 'bearer' ? 'Jeton Bearer enregistré' : 'Sans authentification', 'thecore-elementor-widgets') . '</td>';
                echo '<td class="thecore-api-connection-actions"><a class="button" href="' . esc_url($this->url(['edit' => $row['id']])) . '#connection">' . esc_html__('Modifier', 'thecore-elementor-widgets') . '</a> ';
                echo '<form action="' . esc_url(admin_url('admin-post.php')) . '" method="post" style="display:inline">';
                $this->hidden('action', self::DELETE_ACTION);
                $this->hidden('id', $row['id']);
                $this->hidden(self::NONCE_NAME, wp_create_nonce(self::DELETE_ACTION . '_' . $row['id']));
                echo '<button type="submit" class="button button-link-delete">' . esc_html__('Supprimer', 'thecore-elementor-widgets') . '</button></form></td></tr>';
            }
            if ($rows === []) {
                echo '<tr><td colspan="4">' . esc_html__('Aucune connexion. Ajoutez une destination ci-dessous, puis sélectionnez-la dans votre formulaire Elementor.', 'thecore-elementor-widgets') . '</td></tr>';
            }
            echo '</tbody></table>';
            if ($rows !== []) {
                echo '<p class="description">' . esc_html__('La suppression d’une connexion empêche l’envoi des formulaires qui l’utilisent.', 'thecore-elementor-widgets') . '</p>';
            }
            if ($edit !== '' && $editing === null) {
                echo '<div class="notice notice-error"><p>' . esc_html__('Connexion introuvable. Sélectionnez une connexion dans la liste.', 'thecore-elementor-widgets') . '</p></div>';
            }
            $this->renderForm($editing);
        } catch (Throwable) {
            echo '<div class="notice notice-error"><p>' . esc_html__('Les connexions sont indisponibles. Rechargez la page.', 'thecore-elementor-widgets') . '</p></div>';
        }
        echo '</div>';
    }

    public function handleSave(): void
    {
        if (! $this->allowed() || ! $this->verified(self::SAVE_ACTION)) {
            return;
        }
        $row = [];
        foreach (['id', 'label', 'url', 'auth', 'secret', 'body_key'] as $key) {
            if (! is_string($_POST[$key] ?? null)) {
                wp_die(esc_html__('Renseignez les paramètres de connexion attendus.', 'thecore-elementor-widgets'));
                return;
            }
            $row[$key] = wp_unslash($_POST[$key]);
        }
        $row['idempotent'] = ($_POST['idempotent'] ?? '') === '1';
        try {
            $rows = $this->connections->allForAdmin();
            $replaced = false;
            foreach ($rows as &$existing) {
                if ($existing['id'] === $row['id']) {
                    $existing = $row;
                    $replaced = true;
                }
            }
            unset($existing);
            if (! $replaced) {
                $rows[] = $row;
            }
            $this->connections->save($rows);
        } catch (Throwable) {
            wp_die(esc_html__('Connexion non enregistrée. Vérifiez l’identifiant, l’URL HTTPS et l’authentification. Le secret n’est pas réaffiché : renseignez-le de nouveau si vous souhaitiez le remplacer.', 'thecore-elementor-widgets'));
            return;
        }
        wp_safe_redirect($this->url(['notice' => 'saved']));
    }

    public function handleDelete(): void
    {
        if (! $this->allowed()) {
            return;
        }
        $id = is_string($_POST['id'] ?? null) ? wp_unslash($_POST['id']) : '';
        if ($id === '' || ! $this->verified(self::DELETE_ACTION . '_' . $id)) {
            return;
        }
        try {
            $rows = array_values(array_filter($this->connections->allForAdmin(), static fn (array $row): bool => $row['id'] !== $id));
            $this->connections->save($rows);
        } catch (Throwable) {
            wp_die(esc_html__('La connexion n’a pas pu être supprimée.', 'thecore-elementor-widgets'));
            return;
        }
        wp_safe_redirect($this->url(['notice' => 'deleted']));
    }

    private function renderForm(?array $row): void
    {
        $editing = $row !== null;
        $row ??= ['id' => '', 'label' => '', 'url' => '', 'auth' => 'none', 'has_secret' => false, 'idempotent' => false, 'body_key' => ''];
        echo '<h2 id="connection">' . esc_html__($editing ? 'Modifier la connexion' : 'Ajouter une connexion', 'thecore-elementor-widgets') . '</h2>';
        echo '<form action="' . esc_url(admin_url('admin-post.php')) . '" method="post">';
        $this->hidden('action', self::SAVE_ACTION);
        $this->hidden(self::NONCE_NAME, wp_create_nonce(self::SAVE_ACTION));
        echo '<table class="form-table" role="presentation"><tbody>';
        $this->input('id', 'Identifiant', $row['id'], 'text', 'Commence par une lettre minuscule, puis lettres, chiffres, tirets ou traits de soulignement. Stable une fois utilisé dans un formulaire.', 'required pattern="[a-z][a-z0-9_-]*" maxlength="64"' . ($editing ? ' readonly' : ''));
        $this->input('label', 'Nom de la connexion', $row['label'], 'text', 'Affiché dans le sélecteur Elementor. Exemple : Demande de famille d’accueil.', 'required maxlength="120"');
        $this->input('url', 'URL de destination', $row['url'], 'url', 'Adresse HTTPS complète de l’opération API. Sans paramètres, identifiants ou fragment dans l’URL.', 'required');
        echo '<tr><th scope="row"><label for="api-auth">' . esc_html__('Authentification', 'thecore-elementor-widgets') . '</label></th><td><select id="api-auth" name="auth">';
        foreach (['none' => 'Aucune', 'bearer' => 'Jeton Bearer'] as $value => $label) {
            echo '<option value="' . esc_attr($value) . '"' . ($row['auth'] === $value ? ' selected' : '') . '>' . esc_html__($label, 'thecore-elementor-widgets') . '</option>';
        }
        echo '</select></td></tr>';
        $this->input('secret', 'Jeton Bearer', '', 'password', $row['has_secret'] ? 'Un jeton est enregistré. Laissez ce champ vide pour le conserver ou saisissez un nouveau jeton pour le remplacer. Choisir « Aucune » supprime le jeton.' : 'Requis uniquement pour une authentification par jeton Bearer. Conservé côté serveur et jamais ajouté aux données Elementor.', 'autocomplete="new-password" spellcheck="false"');
        echo '</tbody></table><details><summary>' . esc_html__('Paramètres de l’API destinataire', 'thecore-elementor-widgets') . '</summary><table class="form-table" role="presentation"><tbody>';
        echo '<tr><th scope="row">' . esc_html__('Protection contre les doublons', 'thecore-elementor-widgets') . '</th><td><label for="api-idempotent"><input type="checkbox" id="api-idempotent" name="idempotent" value="1"' . ($row['idempotent'] ? ' checked' : '') . '> ' . esc_html__('L’API garantit qu’une même référence ne crée qu’une demande (en-tête Idempotency-Key ou champ JSON configuré).', 'thecore-elementor-widgets') . '</label><p class="description">' . esc_html__('À activer uniquement si cette garantie fait partie du contrat de l’API.', 'thecore-elementor-widgets') . '</p></td></tr>';
        $this->input('body_key', 'Champ de référence dans le JSON', $row['body_key'], 'text', 'Facultatif. Exemple : command_id. Ajoute au JSON la même référence que l’en-tête Idempotency-Key. Ne pas utiliser ce nom dans la correspondance des champs.');
        echo '</tbody></table></details><p class="submit"><button type="submit" class="button button-primary">' . esc_html__('Enregistrer la connexion', 'thecore-elementor-widgets') . '</button>';
        if ($editing) {
            echo ' <a class="button" href="' . esc_url($this->url()) . '">' . esc_html__('Annuler', 'thecore-elementor-widgets') . '</a>';
        }
        echo '</p></form>';
    }

    private function input(string $name, string $label, string $value, string $type, string $description, string $attributes = ''): void
    {
        echo '<tr><th scope="row"><label for="api-' . esc_attr($name) . '">' . esc_html__($label, 'thecore-elementor-widgets') . '</label></th><td><input class="regular-text" id="api-' . esc_attr($name) . '" name="' . esc_attr($name) . '" type="' . esc_attr($type) . '" value="' . esc_attr($value) . '" ' . $attributes . '><p class="description">' . esc_html__($description, 'thecore-elementor-widgets') . '</p></td></tr>';
    }

    private function hidden(string $name, string $value): void
    {
        echo '<input type="hidden" name="' . esc_attr($name) . '" value="' . esc_attr($value) . '">';
    }

    private function allowed(): bool
    {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('Vous n’êtes pas autorisé à gérer les connexions API.', 'thecore-elementor-widgets'));
            return false;
        }
        return true;
    }

    private function verified(string $action): bool
    {
        $nonce = $_POST[self::NONCE_NAME] ?? null;
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || ! is_string($nonce) || ! wp_verify_nonce(wp_unslash($nonce), $action)) {
            wp_die(esc_html__('Requête invalide. Rechargez la page et réessayez.', 'thecore-elementor-widgets'));
            return false;
        }
        return true;
    }

    private function url(array $args = []): string
    {
        return add_query_arg(['page' => self::PAGE_SLUG] + $args, admin_url('admin.php'));
    }
}
