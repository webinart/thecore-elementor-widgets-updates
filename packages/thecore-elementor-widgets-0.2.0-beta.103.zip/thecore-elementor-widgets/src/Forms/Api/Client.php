<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Api;

use JsonException;
use TheCore\ElementorWidgets\Forms\ConfigurationException;
use TheCore\ElementorWidgets\Forms\SubmissionException;
use Throwable;

/** A single bounded request. Replays require a caller-retained submission ID and remote support. */
final class Client
{
    public const MAX_BODY_BYTES = 65536;
    public const MAX_RESPONSE_BYTES = 16384;
    public const TIMEOUT_SECONDS = 10;

    public function __construct(private ?Connections $connections = null)
    {
        $this->connections ??= new Connections();
    }

    /** Validate every setting and the payload before other submission actions cause side effects. */
    public function validateRequest(string $connectionId, PreparedRequest $request): void
    {
        $this->requestArguments($connectionId, $request);
    }

    public function send(string $connectionId, PreparedRequest $request): DeliveryResult
    {
        [$url, $arguments, $idempotent] = $this->requestArguments($connectionId, $request);
        try {
            $response = wp_safe_remote_post($url, $arguments);
            if ($response instanceof \WP_Error || ! is_array($response)) {
                throw new \UnexpectedValueException('API request not confirmed.');
            }
            $status = (int) ($response['response']['code'] ?? 0);
            if ($status < 200 || $status >= 300) {
                throw new \UnexpectedValueException('API request not accepted.');
            }
        } catch (Throwable $error) {
            // No exception chaining: HTTP clients and servers can include tokens or submitted data.
            throw new SubmissionException(
                'api_delivery_unconfirmed',
                'La réception du formulaire n’a pas pu être confirmée. '
                    . ($idempotent ? 'Vous pouvez réessayer sans modifier le formulaire.'
                        : 'Veuillez contacter le site avant un nouvel envoi.'),
                503
            );
        }
        return new DeliveryResult($status, $request->idempotencyKey);
    }

    /** @return array{0:string,1:array<string,mixed>,2:bool} Private, includes the authorization header. */
    private function requestArguments(string $connectionId, PreparedRequest $request): array
    {
        $connection = $this->connections->get($connectionId);
        if (! preg_match('/\Atcw-[a-f0-9]{64}\z/', $request->idempotencyKey)) {
            throw new ConfigurationException('Invalid API submission identifier.');
        }
        $payload = $request->payload;
        if ($connection['body_key'] !== '') {
            if (array_key_exists($connection['body_key'], $payload)) {
                throw new ConfigurationException('The API request ID field conflicts with the saved mapping.');
            }
            $payload[$connection['body_key']] = $request->idempotencyKey;
        }
        try {
            $body = json_encode((object) $payload, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        } catch (JsonException $error) {
            throw new SubmissionException('api_payload_invalid', 'Certains champs ne peuvent pas être transmis.', 422);
        }
        if (strlen($body) > self::MAX_BODY_BYTES) {
            throw new SubmissionException('api_payload_too_large', 'Le contenu du formulaire est trop volumineux.', 422);
        }
        $headers = [
            'Content-Type' => 'application/json; charset=utf-8',
            'Accept' => 'application/json',
            'Idempotency-Key' => $request->idempotencyKey,
        ];
        if ($connection['auth'] === 'bearer') {
            $headers['Authorization'] = 'Bearer ' . $connection['secret'];
        }
        return [$connection['url'], [
            'headers' => $headers,
            'body' => $body,
            'timeout' => self::TIMEOUT_SECONDS,
            'redirection' => 0,
            'sslverify' => true,
            'reject_unsafe_urls' => true,
            'limit_response_size' => self::MAX_RESPONSE_BYTES,
            'blocking' => true,
            'cookies' => [],
            'data_format' => 'body',
        ], $connection['idempotent']];
    }
}
