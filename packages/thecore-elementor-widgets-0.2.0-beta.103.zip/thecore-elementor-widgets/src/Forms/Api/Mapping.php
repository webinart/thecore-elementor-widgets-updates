<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Api;

use JsonException;
use stdClass;
use TheCore\ElementorWidgets\Forms\ConfigurationException;
use TheCore\ElementorWidgets\Forms\SubmissionException;

/** Declarative JSON mapping only. No templates, executable expressions or implicit visitor metadata. */
final class Mapping
{
    private const MAX_MAPPING_BYTES = 32768;
    private const MAX_ROWS = 100;
    private const TYPES = ['string', 'integer', 'number', 'boolean', 'string_list', 'json'];

    /**
     * @param list<string> $fieldIds Stable IDs from the saved form definition, never from the visitor.
     * @param array<string, mixed> $values Values already validated by the form runtime.
     * @param string $submissionId Retain this ID for an explicit replay of the same submission.
     * @param string $scope Server-defined site/form/connection identity, not supplied by the visitor.
     */
    public function prepare(
        string $mappingJson,
        array $fieldIds,
        array $values,
        string $submissionId,
        string $scope
    ): PreparedRequest {
        if (! preg_match('/\A[A-Za-z0-9_-]{16,128}\z/', $submissionId)) {
            throw new SubmissionException('api_submission_id_invalid', 'Veuillez recharger le formulaire.', 422);
        }
        if ($scope === '' || strlen($scope) > 1024 || str_contains($scope, "\0")) {
            throw new ConfigurationException('An API submission requires a server-defined scope.');
        }
        $rows = $this->rows($mappingJson, $fieldIds);
        $payload = [];
        foreach ($rows as $row) {
            $source = $row['source'] ?? null;
            $present = $source === null || $source === '@submission_id' || array_key_exists($source, $values);
            $value = $source === null ? $row['value'] : ($source === '@submission_id' ? $submissionId : ($values[$source] ?? null));
            $empty = ! $present || $value === null || $value === '' || $value === [];
            if ($empty && ($source !== null || ($row['required'] ?? false) === true)) {
                if (($row['required'] ?? false) === true) {
                    throw $this->valueError($source);
                }
                continue;
            }
            $converted = $this->convert($value, $row['type'], $source);
            if (($row['required'] ?? false) === true && ($converted === '' || $converted === [])) {
                throw $this->valueError($source);
            }
            $this->assign($payload, $row['parts'], $converted);
        }
        $payload = $this->normalizeArrays($payload);
        // Payload is deliberately not part of the key: a remote idempotent API must reject a changed
        // payload using the same submission ID, rather than accidentally creating another operation.
        $key = 'tcw-' . hash('sha256', strlen($scope) . ':' . $scope . ':' . $submissionId);
        return new PreparedRequest($payload, $key);
    }

    /** @return list<array<string, mixed>> */
    private function rows(string $json, array $fieldIds): array
    {
        if (strlen($json) > self::MAX_MAPPING_BYTES) {
            throw new ConfigurationException('The API mapping is too large.');
        }
        try {
            $mapping = json_decode($json, false, 16, JSON_THROW_ON_ERROR);
        } catch (JsonException $error) {
            throw new ConfigurationException('The API mapping must be valid JSON.');
        }
        if (
            ! $mapping instanceof stdClass || ($mapping->version ?? null) !== 1
            || array_diff(array_keys(get_object_vars($mapping)), ['version', 'fields'])
            || ! is_array($mapping->fields ?? null) || $mapping->fields === []
            || count($mapping->fields) > self::MAX_ROWS
        ) {
            throw new ConfigurationException('The API mapping requires version 1 and a list of fields.');
        }
        $knownFields = [];
        foreach ($fieldIds as $id) {
            if (! is_string($id) || $id === '' || str_starts_with($id, '@')) {
                throw new ConfigurationException('Invalid form field definition for API mapping.');
            }
            $knownFields[$id] = true;
        }
        $rows = [];
        $tree = ['children' => [], 'leaf' => false];
        foreach ($mapping->fields as $entry) {
            if (! $entry instanceof stdClass) {
                throw new ConfigurationException('Invalid API mapping field.');
            }
            $row = get_object_vars($entry);
            if (
                array_diff(array_keys($row), ['target', 'source', 'value', 'type', 'required'])
                || ! is_string($row['target'] ?? null) || ! in_array($row['type'] ?? null, self::TYPES, true)
                || (isset($row['required']) && ! is_bool($row['required']))
                || (array_key_exists('source', $row) === array_key_exists('value', $row))
            ) {
                throw new ConfigurationException('An API field requires a target, a type and either source or value.');
            }
            if (array_key_exists('source', $row)) {
                $source = $row['source'];
                if (! is_string($source) || ($source !== '@submission_id' && ! isset($knownFields[$source]))) {
                    throw new ConfigurationException('An API mapping references an unknown form field.');
                }
            }
            $row['parts'] = $this->parts($row['target']);
            $this->registerPath($tree, $row['parts']);
            $rows[] = $row;
        }
        return $rows;
    }

    /** @return list<string|int> */
    private function parts(string $target): array
    {
        if (strlen($target) > 512) {
            throw new ConfigurationException('Invalid API target path.');
        }
        $parts = explode('.', $target);
        if (count($parts) > 8) {
            throw new ConfigurationException('API target paths support at most eight levels.');
        }
        foreach ($parts as $index => $part) {
            if ($index > 0 && preg_match('/\A(?:0|[1-9][0-9]?)\z/', $part)) {
                $parts[$index] = (int) $part;
                continue;
            }
            if (! preg_match('/\A[a-zA-Z_][a-zA-Z0-9_-]{0,63}\z/', $part)) {
                throw new ConfigurationException('Invalid API target path.');
            }
        }
        return $parts;
    }

    private function registerPath(array &$tree, array $parts): void
    {
        $node = &$tree;
        foreach ($parts as $part) {
            if ($node['leaf'] === true) {
                throw new ConfigurationException('API target paths overlap.');
            }
            $kind = is_int($part) ? 'array' : 'object';
            if (isset($node['kind']) && $node['kind'] !== $kind) {
                throw new ConfigurationException('An API target cannot mix object properties and array indices.');
            }
            $node['kind'] = $kind;
            if (! isset($node['children'][$part])) {
                $node['children'][$part] = ['children' => [], 'leaf' => false];
            }
            $node = &$node['children'][$part];
        }
        if ($node['leaf'] === true || $node['children'] !== []) {
            throw new ConfigurationException('API target paths overlap.');
        }
        $node['leaf'] = true;
    }

    private function assign(array &$payload, array $parts, mixed $value): void
    {
        $last = array_pop($parts);
        $node = &$payload;
        foreach ($parts as $part) {
            if (! isset($node[$part])) {
                $node[$part] = [];
            }
            $node = &$node[$part];
        }
        $node[$last] = $value;
    }

    /** Numeric path segments produce JSON lists, never accidental objects or sparse lists. */
    private function normalizeArrays(array $node): array
    {
        foreach ($node as &$value) {
            if (is_array($value)) {
                $value = $this->normalizeArrays($value);
            }
        }
        unset($value);
        if ($node !== [] && is_int(array_key_first($node))) {
            ksort($node, SORT_NUMERIC);
            if (! array_is_list($node)) {
                throw new ConfigurationException('API array indices must be consecutive, starting at zero.');
            }
        }
        return $node;
    }

    private function convert(mixed $value, string $type, ?string $source): mixed
    {
        switch ($type) {
            case 'string':
                if (! is_string($value) && ! is_int($value) && ! is_float($value)) {
                    throw $this->valueError($source);
                }
                return trim((string) $value);
            case 'integer':
                if (is_int($value)) {
                    return $value;
                }
                if (! is_string($value) || ! preg_match('/\A-?(?:0|[1-9][0-9]*)\z/', trim($value))) {
                    throw $this->valueError($source);
                }
                $integer = filter_var(trim($value), FILTER_VALIDATE_INT);
                if ($integer === false) {
                    throw $this->valueError($source);
                }
                return $integer;
            case 'number':
                if ((! is_string($value) && ! is_int($value) && ! is_float($value)) || ! is_numeric($value)) {
                    throw $this->valueError($source);
                }
                $number = (float) $value;
                if (! is_finite($number)) {
                    throw $this->valueError($source);
                }
                return $number;
            case 'boolean':
                if (is_bool($value)) {
                    return $value;
                }
                if (! is_string($value) && ! is_int($value)) {
                    throw $this->valueError($source);
                }
                $boolean = filter_var($value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
                if ($boolean === null) {
                    throw $this->valueError($source);
                }
                return $boolean;
            case 'string_list':
                if (is_string($value)) {
                    $value = preg_split('/[,\r\n]+/', $value);
                }
                if (! is_array($value) || ! array_is_list($value) || count($value) > 100) {
                    throw $this->valueError($source);
                }
                $list = [];
                foreach ($value as $item) {
                    if (! is_string($item) || strlen($item) > 1024) {
                        throw $this->valueError($source);
                    }
                    if (trim($item) !== '') {
                        $list[] = trim($item);
                    }
                }
                return array_values(array_unique($list));
            case 'json':
                try {
                    // Parse strings from textareas; literals retain their JSON object/list distinction.
                    $json = is_string($value) ? $value : json_encode($value, JSON_THROW_ON_ERROR);
                    return json_decode($json, false, 8, JSON_THROW_ON_ERROR);
                } catch (JsonException $error) {
                    throw $this->valueError($source);
                }
        }
        throw new ConfigurationException('Unsupported API mapping type.');
    }

    private function valueError(?string $source): SubmissionException
    {
        $fields = $source !== null && $source !== '@submission_id'
            ? [$source => 'Vérifiez la valeur de ce champ.'] : [];
        return new SubmissionException('api_field_invalid', 'Certains champs ne peuvent pas être transmis.', 422, $fields);
    }
}
