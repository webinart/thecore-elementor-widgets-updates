<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Api;

use Elementor\Controls_Manager;
use ElementorPro\Modules\Forms\Classes\Action_Base;
use Throwable;

/** Adapts a validated Elementor Pro form record to the shared JSON API client. */
final class LegacyAction extends Action_Base
{
    public const NAME = 'thecore_api';
    public const CONNECTION_SETTING = 'thecore_api_connection';
    public const MAPPING_SETTING = 'thecore_api_mapping';
    public const SUBMISSION_FIELD = 'thecore_api_submission_id';

    public function get_name()
    {
        return self::NAME;
    }

    public function get_label()
    {
        return __('Envoyer à une API', 'thecore-elementor-widgets');
    }

    public function register_settings_section($form)
    {
        $options = ['' => __('Choisir une connexion', 'thecore-elementor-widgets')] + ApiModule::connectionOptions();
        $form->start_controls_section('section_thecore_api', [
            'label' => $this->get_label(), 'condition' => ['submit_actions' => self::NAME],
        ]);
        $form->add_control(self::CONNECTION_SETTING, [
            'label' => __('Connexion', 'thecore-elementor-widgets'), 'type' => Controls_Manager::SELECT,
            'options' => $options, 'default' => '', 'label_block' => true, 'render_type' => 'none',
            'description' => __('À configurer dans The Core – Widgets → Connexions API. Rechargez l’éditeur après l’ajout d’une connexion. Si la réception par l’API doit conditionner les autres traitements, utilisez cette action seule.', 'thecore-elementor-widgets'),
            'dynamic' => ['active' => false], 'ai' => ['active' => false],
        ]);
        $form->add_control(self::MAPPING_SETTING, [
            'label' => __('Correspondance des champs (JSON)', 'thecore-elementor-widgets'), 'type' => Controls_Manager::TEXTAREA,
            'default' => '', 'placeholder' => ApiModule::mappingExample(), 'rows' => 12, 'render_type' => 'none',
            'description' => __('source : ID du champ Elementor ; target : propriété attendue par l’API ; type : string, integer, number, boolean ou string_list ; required : champ obligatoire. Utilisez value à la place de source pour une valeur fixe. Aucun jeton ni mot de passe dans ce JSON.', 'thecore-elementor-widgets'),
            'dynamic' => ['active' => false], 'ai' => ['active' => false],
        ]);
        $form->end_controls_section();
    }

    /** Portable mappings survive export; destination must be selected on the new site. */
    public function on_export($element)
    {
        unset($element['settings'][self::CONNECTION_SETTING]);
        return $element;
    }

    public function run($record, $ajax_handler)
    {
        try {
            if (array_key_exists('webinart_form_check_token', $_POST) || array_key_exists('test_token', $_POST)) {
                // This legacy adapter has no signed dry-run contract. Never send during a probe.
                throw new \RuntimeException('unsupported_signed_test');
            }
            $settings = $record->get('form_settings');
            $fields = $record->get('fields');
            $submissionId = $_POST[self::SUBMISSION_FIELD] ?? null;
            if (! is_array($settings) || ! is_array($fields) || ! is_string($submissionId) || preg_match('/\A[a-f0-9]{32}\z/D', $submissionId) !== 1) {
                throw new \RuntimeException('invalid_submission_context');
            }
            $connection = $settings[self::CONNECTION_SETTING] ?? null;
            $mapping = $settings[self::MAPPING_SETTING] ?? null;
            $postId = $settings['form_post_id'] ?? null;
            $formId = $settings['id'] ?? null;
            if (! is_string($connection) || ! is_string($mapping) || ! is_scalar($postId) || ! ctype_digit((string) $postId) || (int) $postId < 1 || ! is_string($formId) || $formId === '') {
                throw new \RuntimeException('invalid_form_configuration');
            }
            $fieldIds = [];
            $multipleFields = [];
            foreach ($settings['form_fields'] ?? [] as $definition) {
                $id = $definition['custom_id'] ?? null;
                $type = $definition['field_type'] ?? null;
                if (is_string($id) && $id !== '' && in_array($type, ['text', 'email', 'textarea', 'url', 'tel', 'number', 'date', 'time', 'select', 'checkbox', 'radio', 'acceptance', 'hidden'], true)) {
                    $fieldIds[] = $id;
                    $multipleFields[$id] = $type === 'checkbox'
                        || ($type === 'select' && ! empty($definition['allow_multiple']));
                }
            }
            $values = [];
            foreach ($fieldIds as $id) {
                if (isset($fields[$id]) && is_array($fields[$id])) {
                    $raw = $fields[$id]['raw_value'] ?? null;
                    if (is_array($raw)) {
                        if (! $multipleFields[$id] || ! array_is_list($raw) || count($raw) > 100) {
                            throw new \RuntimeException('invalid_multiple_field');
                        }
                        // Elementor joins multiple choices into a string. Keep their structure while
                        // applying the same text sanitization to every individual selected value.
                        $values[$id] = [];
                        foreach ($raw as $item) {
                            if (! is_scalar($item)) {
                                throw new \RuntimeException('invalid_multiple_field_value');
                            }
                            $values[$id][] = sanitize_text_field((string) $item);
                        }
                    } else {
                        // Use the value Elementor actually sanitized/validated, never raw input.
                        $values[$id] = $fields[$id]['value'] ?? '';
                    }
                }
            }
            $scope = 'legacy:' . home_url('/') . ':' . get_current_blog_id() . ':' . $postId . ':' . $formId . ':' . $connection;
            $request = (new Mapping())->prepare($mapping, $fieldIds, $values, $submissionId, $scope);
            (new Client(new Connections()))->send($connection, $request);
        } catch (Throwable) {
            $ajax_handler->add_error_message(__('La réception de votre demande par l’application n’a pas pu être confirmée. Vos informations restent dans le formulaire.', 'thecore-elementor-widgets'));
        }
    }
}
