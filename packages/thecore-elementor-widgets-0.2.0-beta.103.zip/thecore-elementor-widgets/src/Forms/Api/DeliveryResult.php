<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Api;

/** Only safe delivery metadata. The remote response body is intentionally discarded. */
final class DeliveryResult
{
    public function __construct(
        public readonly int $status,
        public readonly string $idempotencyKey
    ) {
    }
}
