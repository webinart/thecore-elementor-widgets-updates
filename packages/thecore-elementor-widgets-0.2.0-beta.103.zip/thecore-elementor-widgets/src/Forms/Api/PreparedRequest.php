<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Api;

/** Contains submitted data, never the connection token or an endpoint supplied by a visitor. */
final class PreparedRequest
{
    /** @param array<string, mixed> $payload JSON object produced from the saved mapping. */
    public function __construct(
        public readonly array $payload,
        public readonly string $idempotencyKey
    ) {
    }
}
