<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Api;

use TheCore\ElementorWidgets\Forms\ConfigurationException;

/** Server-only registry. No REST registration; only labels/IDs are passed to form controls. */
final class Connections
{
    public const OPTION_NAME = 'thecore_forms_api_connections';
    private const MAX_CONNECTIONS = 50;

    /** @return array<string, string> Connection ID => label, never URLs or credentials. */
    public function publicOptions(): array
    {
        $result = [];
        foreach ($this->stored() as $row) {
            if (is_array($row) && is_string($row['id'] ?? null) && is_string($row['label'] ?? null)) {
                $result[$row['id']] = $row['label'];
            }
        }
        return $result;
    }

    /** @return list<array{id:string,label:string,url:string,auth:string,has_secret:bool,idempotent:bool,body_key:string}> */
    public function allForAdmin(): array
    {
        $result = [];
        foreach ($this->stored() as $row) {
            if (! is_array($row)) {
                continue;
            }
            $result[] = [
                'id' => (string) ($row['id'] ?? ''),
                'label' => (string) ($row['label'] ?? ''),
                'url' => (string) ($row['url'] ?? ''),
                'auth' => (string) ($row['auth'] ?? 'none'),
                'has_secret' => is_string($row['secret'] ?? null) && $row['secret'] !== '',
                'idempotent' => ($row['idempotent'] ?? false) === true,
                'body_key' => (string) ($row['body_key'] ?? ''),
            ];
        }
        return $result;
    }

    /**
     * Replace the registry after validation of every row. Caller checks manage_options and nonce.
     * Empty/absent secret preserves the existing token for the same ID; auth=none erases it.
     * Removing a row deletes that connection. Tokens are never returned by allForAdmin().
     *
     * @param list<array<string, mixed>> $rows
     */
    public function save(array $rows): void
    {
        if (! array_is_list($rows) || count($rows) > self::MAX_CONNECTIONS) {
            throw new ConfigurationException('Invalid API connection registry.');
        }
        $existing = [];
        foreach ($this->stored() as $row) {
            if (is_array($row) && is_string($row['id'] ?? null)) {
                $existing[$row['id']] = $row;
            }
        }
        $next = [];
        foreach ($rows as $row) {
            if (! is_array($row)) {
                throw new ConfigurationException('Invalid API connection.');
            }
            $id = $row['id'] ?? null;
            if (! is_string($id) || ! preg_match('/\A[a-z][a-z0-9_-]{0,63}\z/', $id) || isset($next[$id])) {
                throw new ConfigurationException('Invalid or duplicate API connection ID.');
            }
            $next[$id] = $this->normalize($row, $existing[$id] ?? []);
        }
        // Explicitly nonautoload, including updates to a previously existing option.
        $saved = array_values($next);
        update_option(self::OPTION_NAME, $saved, false);
        // WordPress returns false both for an unchanged value and for a write failure.
        if ($this->stored() !== $saved) {
            throw new ConfigurationException('The API connection registry could not be saved.');
        }
    }

    /** Server-only transport configuration. Never embed this result in form HTML or logs. */
    public function get(string $id): array
    {
        foreach ($this->stored() as $row) {
            if (is_array($row) && ($row['id'] ?? null) === $id) {
                return $this->normalize($row, []);
            }
        }
        throw new ConfigurationException('The API connection is not available.');
    }

    private function stored(): array
    {
        $stored = get_option(self::OPTION_NAME, []);
        return is_array($stored) ? $stored : [];
    }

    private function normalize(array $row, array $existing): array
    {
        $id = $row['id'] ?? null;
        $label = $row['label'] ?? null;
        $url = $row['url'] ?? null;
        $auth = $row['auth'] ?? 'none';
        $idempotent = $row['idempotent'] ?? false;
        $bodyKey = $row['body_key'] ?? '';
        if (
            ! is_string($id) || ! preg_match('/\A[a-z][a-z0-9_-]{0,63}\z/', $id)
            || ! is_string($label) || trim($label) === '' || strlen($label) > 200
            || ! is_string($url) || ! in_array($auth, ['none', 'bearer'], true)
            || ! is_bool($idempotent) || ! is_string($bodyKey)
            || ($bodyKey !== '' && ! preg_match('/\A[a-zA-Z_][a-zA-Z0-9_-]{0,63}\z/', $bodyKey))
        ) {
            throw new ConfigurationException('Invalid API connection configuration.');
        }
        $secret = $row['secret'] ?? '';
        if (! is_string($secret)) {
            throw new ConfigurationException('Invalid API connection credential.');
        }
        if ($auth === 'none') {
            $secret = '';
        } else {
            if ($secret === '') {
                $secret = $existing['secret'] ?? '';
            }
            if (
                ! is_string($secret) || strlen($secret) > 4096
                || ! preg_match('/\A[A-Za-z0-9._~+\/-]+=*\z/', $secret)
            ) {
                throw new ConfigurationException('A valid bearer token is required for this connection.');
            }
        }
        $label = sanitize_text_field($label);
        if ($label === '') {
            throw new ConfigurationException('A connection label is required.');
        }
        return [
            'id' => $id,
            'label' => $label,
            'url' => Endpoint::validate($url),
            'auth' => $auth,
            'secret' => $secret,
            'idempotent' => $idempotent,
            'body_key' => $bodyKey,
        ];
    }
}
