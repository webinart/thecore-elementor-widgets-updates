<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms\Api;

use TheCore\ElementorWidgets\Forms\ConfigurationException;

/** Only administrator-saved HTTPS endpoints, without credentials or user-controlled URL parts. */
final class Endpoint
{
    public static function validate(string $url): string
    {
        if (strlen($url) > 2048 || preg_match('/[\x00-\x20\x7f\\\\]/', $url)) {
            throw new ConfigurationException('Invalid API connection URL.');
        }
        $parts = parse_url($url);
        if (
            ! is_array($parts) || ($parts['scheme'] ?? '') !== 'https'
            || isset($parts['user']) || isset($parts['pass']) || isset($parts['query']) || isset($parts['fragment'])
            || (isset($parts['port']) && $parts['port'] !== 443)
        ) {
            throw new ConfigurationException('An API connection requires a fixed HTTPS URL.');
        }
        $host = strtolower($parts['host'] ?? '');
        // Reject IP literals, ambiguous numeric hosts, local names and trailing-dot aliases.
        if (
            strlen($host) > 253
            || ! preg_match('/\A(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}\z/', $host)
            || preg_match('/\.(?:localhost|local|internal|invalid|test|example|onion)\z/', $host)
            || filter_var($host, FILTER_VALIDATE_IP) !== false
        ) {
            throw new ConfigurationException('The API endpoint must use a public domain name.');
        }
        // WordPress validates DNS/private addresses again immediately before the HTTP request.
        if (wp_http_validate_url($url) === false) {
            throw new ConfigurationException('The API endpoint is not allowed by the HTTP safety policy.');
        }
        return $url;
    }
}
