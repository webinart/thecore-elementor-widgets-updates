<?php

declare(strict_types=1);

namespace TheCore\ElementorWidgets\Forms;

use TheCore\ElementorWidgets\FormSecurity\Support\FormContext;

interface BlockedSubmissionMonitor
{
    /** The implementation must filter spam reasons and bound the untrusted field values. */
    public function log(FormContext $context, FormDefinition $form, array $fields, SubmissionException $error): void;
}
