( function () {
	'use strict';
	if ( window.theCoreFormApiSubmission ) { return; }
	const memory = new Map();
	const prefix = 'thecore-form-api:';
	const duration = 24 * 60 * 60 * 1000;
	function canonical( value ) {
		if ( Array.isArray( value ) ) { return value.map( canonical ); }
		if ( value && typeof value === 'object' ) {
			return Object.fromEntries( Object.keys( value ).sort().map( key => [ key, canonical( value[ key ] ) ] ) );
		}
		return value;
	}
	async function digest( value ) {
		if ( ! window.crypto?.subtle || ! window.crypto?.getRandomValues ) {
			throw new Error( 'Votre navigateur ne permet pas cet envoi sécurisé.' );
		}
		const hash = await window.crypto.subtle.digest( 'SHA-256', new TextEncoder().encode( value ) );
		return Array.from( new Uint8Array( hash ), byte => byte.toString( 16 ).padStart( 2, '0' ) ).join( '' );
	}
	async function storageKey( scope ) { return prefix + await digest( window.location.origin + ':' + scope ); }
	window.theCoreFormApiSubmission = {
		async prepare( scope, values ) {
			const key = await storageKey( scope );
			const fingerprint = await digest( JSON.stringify( canonical( values ) ) );
			let previous = memory.get( key );
			try { previous = JSON.parse( window.sessionStorage.getItem( key ) ) || previous; } catch ( error ) { /* Storage can be disabled. */ }
			if ( previous?.fingerprint === fingerprint && /^[a-f0-9]{32}$/.test( previous.id ) && previous.expires > Date.now() ) {
				memory.set( key, previous );
				return previous.id;
			}
			const id = Array.from( window.crypto.getRandomValues( new Uint8Array( 16 ) ), byte => byte.toString( 16 ).padStart( 2, '0' ) ).join( '' );
			const entry = { id, fingerprint, expires: Date.now() + duration };
			memory.set( key, entry );
			try { window.sessionStorage.setItem( key, JSON.stringify( entry ) ); } catch ( error ) { /* Keep the current page usable. */ }
			return id;
		},
		async clear( scope ) {
			const key = await storageKey( scope );
			memory.delete( key );
			try { window.sessionStorage.removeItem( key ); } catch ( error ) { /* No stored entry to clear. */ }
		},
	};
}() );
