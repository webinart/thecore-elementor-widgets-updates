(() => {
    const RUNTIME_KEY = '__thecoreCounterRuntime';

    if (window[RUNTIME_KEY]) {
        return;
    }

    window[RUNTIME_KEY] = true;

    const ROOT_SELECTOR = '[data-thecore-counter]';
    const VALUE_SELECTOR = '[data-thecore-counter-value]';
    const OPTION_ATTRIBUTES = [
        'data-thecore-counter',
        'data-start',
        'data-end',
        'data-duration',
        'data-delay',
        'data-decimals',
        'data-separator',
        'data-decimal-separator',
        'data-thecore-editor-preview',
    ];
    const states = new Map();
    const completedRoots = new WeakSet();
    const ALLOWED_SEPARATORS = ['', ' ', '\u00a0', '\u202f', ',', '.', "'", '\u2019'];
    const motionPreference = typeof window.matchMedia === 'function'
        ? window.matchMedia('(prefers-reduced-motion: reduce)')
        : null;
    let intersectionObserver = null;
    let mutationObserver = null;
    let booted = false;

    const isElement = (node) => node instanceof HTMLElement;
    const isEditorPreview = (root) => root.getAttribute('data-thecore-editor-preview') === '1'
        || document.body?.classList.contains('elementor-editor-active')
        || /(?:^|[?&])elementor-preview(?:=|&|$)/.test(window.location?.search || '');
    const prefersReducedMotion = () => Boolean(motionPreference?.matches);

    const readNumber = (root, name, fallback, minimum, maximum, integer = false) => {
        const raw = root.getAttribute(name);
        const numeric = raw !== null && /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i.test(raw.trim());
        const parsed = numeric ? Number(raw) : fallback;
        const value = Number.isFinite(parsed) ? parsed : fallback;
        const clamped = Math.min(maximum, Math.max(minimum, value));

        return integer ? Math.trunc(clamped) : clamped;
    };

    const readSeparator = (root, name, fallback, allowed = ALLOWED_SEPARATORS) => {
        const value = root.getAttribute(name);

        return allowed.includes(value) ? value : fallback;
    };

    const readOptions = (root) => ({
        start: readNumber(root, 'data-start', 0, -1e12, 1e12),
        end: readNumber(root, 'data-end', 100, -1e12, 1e12),
        duration: readNumber(root, 'data-duration', 2000, 0, 60000, true),
        delay: readNumber(root, 'data-delay', 0, 0, 60000, true),
        decimals: readNumber(root, 'data-decimals', 0, 0, 10, true),
        separator: readSeparator(root, 'data-separator', ' '),
        decimalSeparator: readSeparator(root, 'data-decimal-separator', ',', [',', '.']),
    });

    const createFormatter = (options) => {
        const formatter = typeof Intl !== 'undefined' && typeof Intl.NumberFormat === 'function'
            ? new Intl.NumberFormat('en-US', {
                useGrouping: false,
                minimumFractionDigits: options.decimals,
                maximumFractionDigits: options.decimals,
            })
            : null;

        return (value) => {
            let fixed = formatter ? formatter.format(value) : value.toFixed(options.decimals);

            // Match the server's formatting of rounded negative zero.
            if (/^-0(?:\.0+)?$/.test(fixed)) {
                fixed = fixed.slice(1);
            }

            const [integer, fraction] = fixed.split('.');
            const grouped = integer.replace(/\B(?=(\d{3})+(?!\d))/g, options.separator);

            return fraction === undefined ? grouped : `${grouped}${options.decimalSeparator}${fraction}`;
        };
    };

    const cancelWork = (state) => {
        if (state.timer !== null) {
            window.clearTimeout(state.timer);
            state.timer = null;
        }

        if (state.frame !== null) {
            window.cancelAnimationFrame(state.frame);
            state.frame = null;
        }

        intersectionObserver?.unobserve(state.root);
    };

    const writeValue = (state, text) => {
        state.lastWritten = text;

        if (state.value.textContent !== text) {
            state.value.textContent = text;
        }
    };

    const finish = (state) => {
        cancelWork(state);
        state.status = 'complete';
        completedRoots.add(state.root);
        // The server is authoritative, including PHP's half-rounding and locale separators.
        writeValue(state, state.finalText);
    };

    const discard = (state, restoreFinal = true) => {
        cancelWork(state);

        // A detached widget may later be reinserted; do not leave it halfway through a count.
        if (restoreFinal) {
            writeValue(state, state.finalText);
        }
        states.delete(state.root);
    };

    const begin = (state) => {
        state.timer = null;

        if (!state.root.isConnected) {
            discard(state);
            return;
        }

        if (prefersReducedMotion() || isEditorPreview(state.root)
            || state.options.duration === 0 || state.options.start === state.options.end) {
            finish(state);
            return;
        }

        state.status = 'running';
        completedRoots.add(state.root);
        writeValue(state, state.format(state.options.start));
        let startedAt = null;

        const tick = (timestamp) => {
            state.frame = null;

            if (!state.root.isConnected) {
                discard(state);
                return;
            }

            if (prefersReducedMotion() || isEditorPreview(state.root)) {
                finish(state);
                return;
            }

            startedAt ??= timestamp;
            const progress = Math.min(1, Math.max(0, (timestamp - startedAt) / state.options.duration));

            if (progress === 1) {
                finish(state);
                return;
            }

            // jquery-numerator's default easeOutQuad, without jQuery or Elementor handlers.
            const eased = 1 - (1 - progress) ** 2;
            const value = state.options.start + (state.options.end - state.options.start) * eased;
            writeValue(state, state.format(value));
            state.frame = window.requestAnimationFrame(tick);
        };

        state.frame = window.requestAnimationFrame(tick);
    };

    const scheduleStart = (state) => {
        if (state.status !== 'waiting') {
            return;
        }

        intersectionObserver?.unobserve(state.root);
        state.status = 'scheduled';

        if (state.options.delay > 0) {
            // Preserve the useful server-rendered final value until the animation really begins.
            state.timer = window.setTimeout(() => begin(state), state.options.delay);
        } else {
            begin(state);
        }
    };

    const initRoot = (root, finalOverride = null) => {
        if (!isElement(root) || !root.isConnected || states.has(root)) {
            return;
        }

        const value = root.querySelector(VALUE_SELECTOR);

        if (!isElement(value)) {
            return;
        }

        const options = readOptions(root);
        const finalText = typeof finalOverride === 'string' ? finalOverride : value.textContent;
        const state = {
            root, value, options, finalText, lastWritten: value.textContent,
            format: createFormatter(options), status: 'waiting', timer: null, frame: null,
        };
        states.set(root, state);

        if (typeof finalOverride === 'string') {
            writeValue(state, finalText);
        }

        if (completedRoots.has(root) || prefersReducedMotion() || isEditorPreview(root)
            || !intersectionObserver || typeof window.requestAnimationFrame !== 'function'
            || options.duration === 0 || options.start === options.end) {
            finish(state);
            return;
        }

        // Do not replace the server-rendered final number before an actual viewport entry.
        intersectionObserver.observe(root);
    };

    const initWithin = (context) => {
        if (isElement(context) && context.matches(ROOT_SELECTOR)) {
            initRoot(context);
        }

        context?.querySelectorAll?.(ROOT_SELECTOR).forEach(initRoot);
    };

    const synchronizeRoot = (root) => {
        const state = states.get(root);
        const value = root.querySelector(VALUE_SELECTOR);
        let finalOverride = null;

        if (state) {
            if (value === state.value && value.textContent === state.lastWritten) {
                // An option changed without new server markup: discard any intermediate frame.
                const options = readOptions(root);
                const samePresentation = options.end === state.options.end
                    && options.decimals === state.options.decimals
                    && options.separator === state.options.separator
                    && options.decimalSeparator === state.options.decimalSeparator;
                finalOverride = samePresentation ? state.finalText : createFormatter(options)(options.end);
            }

            discard(state, !root.matches(ROOT_SELECTOR));
        }

        if (root.matches(ROOT_SELECTOR)) {
            initRoot(root, finalOverride);
        }
    };

    const boot = () => {
        if (booted || !document.body) {
            return;
        }

        booted = true;

        if (typeof window.IntersectionObserver === 'function') {
            intersectionObserver = new window.IntersectionObserver((entries) => {
                entries.forEach((entry) => {
                    const state = states.get(entry.target);

                    if (entry.isIntersecting && state) {
                        scheduleStart(state);
                    }
                });
            });
        }

        initWithin(document);

        if (typeof window.MutationObserver === 'function') {
            mutationObserver = new window.MutationObserver((mutations) => {
                const changedRoots = new Set();
                let removedElement = false;

                mutations.forEach((mutation) => {
                    if (mutation.type === 'attributes') {
                        if (isElement(mutation.target)
                            && (states.has(mutation.target) || mutation.target.matches(ROOT_SELECTOR))) {
                            changedRoots.add(mutation.target);
                        }

                        return;
                    }

                    const addedElements = Array.from(mutation.addedNodes).filter(isElement);
                    const removedElements = Array.from(mutation.removedNodes).filter(isElement);
                    removedElement ||= removedElements.length > 0;

                    // Ignore text-node changes made by our own animation (no observer feedback loop).
                    if (addedElements.length === 0 && removedElements.length === 0) {
                        return;
                    }

                    addedElements.forEach(initWithin);

                    const root = isElement(mutation.target) ? mutation.target.closest(ROOT_SELECTOR) : null;

                    if (root) {
                        changedRoots.add(root);
                    }
                });

                if (removedElement) {
                    states.forEach((state) => {
                        if (!state.root.isConnected) {
                            discard(state);
                        }
                    });
                }

                changedRoots.forEach(synchronizeRoot);
            });
            mutationObserver.observe(document.body, {
                childList: true,
                subtree: true,
                attributes: true,
                attributeFilter: OPTION_ATTRIBUTES,
            });
        }
    };

    const stop = () => {
        mutationObserver?.disconnect();
        mutationObserver = null;
        states.forEach(finish);
        states.clear();
        intersectionObserver?.disconnect();
        intersectionObserver = null;
        booted = false;
    };

    const onMotionChange = () => {
        if (prefersReducedMotion()) {
            states.forEach(finish);
        }
    };

    if (typeof motionPreference?.addEventListener === 'function') {
        motionPreference.addEventListener('change', onMotionChange);
    } else if (typeof motionPreference?.addListener === 'function') {
        motionPreference.addListener(onMotionChange);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot, { once: true });
    } else {
        boot();
    }

    window.addEventListener('pagehide', stop);
    window.addEventListener('pageshow', boot);
})();
