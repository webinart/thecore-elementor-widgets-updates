( function () {
	'use strict';
	if ( window.theCoreLegacyFormApiLoaded ) { return; }
	window.theCoreLegacyFormApiLoaded = true;
	const states = new WeakMap();
	function eligible( form ) { return form?.matches?.( 'form.elementor-form' ) && form.closest( '[data-thecore-api="1"]' ); }
	function scope( form ) {
		return 'legacy:' + window.location.pathname + ':' + ( form.querySelector( '[name="post_id"]' )?.value || '' ) + ':' + ( form.querySelector( '[name="form_id"]' )?.value || '' );
	}
	function values( form ) {
		const result = {};
		for ( const [ key, value ] of new FormData( form ).entries() ) {
			if ( ! key.startsWith( 'form_fields[' ) || value instanceof File || /thecore_form_security|thecore_atomic_proof/.test( key ) ) { continue; }
			( result[ key ] ||= [] ).push( value );
		}
		return result;
	}
	function error( form ) {
		let output = form.querySelector( '[data-thecore-api-error]' );
		if ( ! output ) {
			output = document.createElement( 'div' );
			output.className = 'elementor-message elementor-message-danger';
			output.dataset.thecoreApiError = '1';
			output.setAttribute( 'role', 'alert' );
			form.appendChild( output );
		}
		output.textContent = 'Envoi indisponible. Rechargez la page avant de réessayer.';
	}
	document.addEventListener( 'submit', async event => {
		const form = event.target;
		if ( ! eligible( form ) ) { return; }
		let state = states.get( form );
		if ( ! state ) { state = { pending: false, ready: false }; states.set( form, state ); }
		if ( state.ready ) { state.ready = false; return; }
		event.preventDefault();
		event.stopImmediatePropagation();
		if ( state.pending ) { return; }
		state.pending = true;
		try {
			const id = await window.theCoreFormApiSubmission.prepare( scope( form ), values( form ) );
			let input = form.querySelector( '[name="thecore_api_submission_id"]' );
			if ( ! input ) { input = document.createElement( 'input' ); input.type = 'hidden'; input.name = 'thecore_api_submission_id'; form.appendChild( input ); }
			input.value = id;
			form.querySelector( '[data-thecore-api-error]' )?.remove();
			// Finish the original native submit task before requesting a new submission.
			await new Promise( resolve => window.setTimeout( resolve, 0 ) );
			state.ready = true;
			if ( event.submitter?.form === form ) { form.requestSubmit( event.submitter ); }
			else { form.requestSubmit(); }
			state.ready = false;
		} catch ( failure ) { error( form ); }
		finally { state.pending = false; }
	}, true );
	if ( window.jQuery ) {
		window.jQuery( document ).on( 'submit_success.thecoreApi', 'form.elementor-form', function () {
			if ( eligible( this ) ) { void window.theCoreFormApiSubmission.clear( scope( this ) ).catch( () => {} ); }
		} );
	}
}() );
