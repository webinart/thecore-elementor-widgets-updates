<?php

declare(strict_types=1);

if (! defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

require_once __DIR__ . '/src/Infrastructure/Autoloader.php';

(new \TheCore\ElementorWidgets\Infrastructure\Autoloader())->register();

$purged = (new \TheCore\ElementorWidgets\FormSecurity\Infrastructure\BlockedSubmissionDataPurger())
    ->purgeForUninstall();

if (! $purged) {
    wp_die(
        esc_html__(
            'La table temporaire des soumissions bloquées n’a pas pu être supprimée. La désinstallation est interrompue afin de ne pas laisser de données personnelles orphelines.',
            'thecore-elementor-widgets'
        )
    );
}

if (! \TheCore\ElementorWidgets\Forms\Submissions\Installer::purgeForUninstall()) {
    wp_die(
        esc_html__(
            'Les demandes conservées n’ont pas pu être supprimées. La désinstallation est interrompue afin de ne pas laisser de données personnelles orphelines.',
            'thecore-elementor-widgets'
        )
    );
}

\TheCore\ElementorWidgets\Forms\Submissions\SubmissionsModule::unschedule(is_multisite());
